# details & summary

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/erPdrj](https://codepen.io/yuanchuan/pen/erPdrj).

Codepen Challenge:
https://codepen.io/challenges/2018/may/