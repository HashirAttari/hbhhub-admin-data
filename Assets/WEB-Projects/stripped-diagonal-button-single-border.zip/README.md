# Stripped Diagonal Button Single Border

A Pen created on CodePen.io. Original URL: [https://codepen.io/Zeindelf/pen/vZbyEg](https://codepen.io/Zeindelf/pen/vZbyEg).

