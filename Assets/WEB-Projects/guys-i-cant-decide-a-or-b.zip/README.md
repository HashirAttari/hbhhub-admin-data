# guYs I cANt deCide – a Or B?

A Pen created on CodePen.io. Original URL: [https://codepen.io/ivorjetski/pen/wvbqqRd](https://codepen.io/ivorjetski/pen/wvbqqRd).

 An awful lot of box shadows, to do this: https://x.com/TylerNickerson/status/1799185732998992219

A recreation of Tyler Nickerson's amazing image using only CSS

https://instagram.com/ivorjetski

https://twitter.com/ivorjetski

https://youtube.com/c/ivorjetski