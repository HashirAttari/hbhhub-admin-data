# Dusty Particle Sphere

A Pen created on CodePen.

Original URL: [https://codepen.io/Zaku/pen/nzqqwW](https://codepen.io/Zaku/pen/nzqqwW).

Modified my Particle Heart (http://codepen.io/Zaku/pen/IkcqC) from Valentine's Day inspired by http://rectangleworld.com/blog/archives/298.