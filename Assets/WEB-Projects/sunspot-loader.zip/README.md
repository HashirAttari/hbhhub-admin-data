# Sunspot Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/vYGozeN](https://codepen.io/chrisgannon/pen/vYGozeN).

