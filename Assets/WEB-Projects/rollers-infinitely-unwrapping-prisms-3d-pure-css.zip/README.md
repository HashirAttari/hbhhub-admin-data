# Rollers! (infinitely unwrapping prisms; 3D, pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/LYEKPJ](https://codepen.io/thebabydino/pen/LYEKPJ).

Uses `transform-style: preserve-3d`, so no IE, not even 11, sorry. Also see [the more impressive looking version](http://codepen.io/thebabydino/pen/pzgiE). ;) Inspiration: 

![gif](http://1-ps.googleusercontent.com/x/www.bspcn.com/i.imgur.com/rUUSTzn.gif.pagespeed.ce.rv0dexCmKu.gif)