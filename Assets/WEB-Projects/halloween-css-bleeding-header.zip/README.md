# Halloween CSS Bleeding Header

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/zvZEBd](https://codepen.io/giana/pen/zvZEBd).

Working on a thing for Halloween. Webkit + FF only.