# Google Clone

A Pen created on CodePen.io. Original URL: [https://codepen.io/Kornil/pen/VaPbog](https://codepen.io/Kornil/pen/VaPbog).

A fully functional replica of Google's main page, you can use it for searches and everything else.
Styled with CSS to look as close as possible to current google main page, a bit of jquery magic to make it fully functional.