let btn = document.documentElement;
btn.addEventListener('mousemove', e => {
  let rect = btn.getBoundingClientRect();
  let x = e.clientX - rect.left;
  let y = e.clientY - rect.top;
  btn.style.setProperty('--x', x + 'px');
  btn.style.setProperty('--y', y + 'px');
});