# Simple Switch/Toggle Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/wMXONQ](https://codepen.io/leenalavanya/pen/wMXONQ).

Switch/Toggle Button