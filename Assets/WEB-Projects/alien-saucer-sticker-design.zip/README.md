# Alien Saucer Sticker Design 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Philip-Walsh/pen/jOoPKOX](https://codepen.io/Philip-Walsh/pen/jOoPKOX).

Comparison of sticker with filters and without