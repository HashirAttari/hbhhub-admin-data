# CSS Art #3 (hover)

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/vYymPwX](https://codepen.io/kitjenson/pen/vYymPwX).

This week has seen me without power for 50 straight hours and no water. I'm lucky though... I'm well taken care of. 

https://www.windowsofnewyork.com/
53 WOOSTER ST.

