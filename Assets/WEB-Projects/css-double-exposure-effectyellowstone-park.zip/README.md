# CSS Double Exposure Effect - Yellowstone Park

A Pen created on CodePen.io. Original URL: [https://codepen.io/riktar/pen/EyQemb](https://codepen.io/riktar/pen/EyQemb).

How to create  a Double Exposure Effect with only CSS blend mode.