# Daily UI #18 | Colorful switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/wWWwKm](https://codepen.io/havardob/pen/wWWwKm).

Based on this Dribbble-shot: https://dribbble.com/shots/2775486-Colorful-Switch
