# Image Hover 63 Hover Effects || Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/maheshambure21/pen/ZOyLKo](https://codepen.io/maheshambure21/pen/ZOyLKo).

