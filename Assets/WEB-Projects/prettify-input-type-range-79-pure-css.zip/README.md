# prettify `<input type=range>` #79 pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/myGmpg](https://codepen.io/thebabydino/pen/myGmpg).

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 36, 39 (nightly), Chrome 41, 43 (canary)/ Opera 28, IE 11 on Windows 8.

Chrome/ Opera have a bit of an extra when it comes to the appearance of the thumb. This is done using `/deep/` in Chrome stable/ Opera - careful, experimental stuff, only supported in Blink, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), no future really, already not working anymore in canary - see ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). I can still reproduce the look in canary using stuff like `::-webkit-slider-runnable-thumb:before` which now works (didn't before Chrome 41). 

The gradient ruler looks really ugly in Chrome/ Opera and not that good in Firefox. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/FqyFZ8o.jpg) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/).  