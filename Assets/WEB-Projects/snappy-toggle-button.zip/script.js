const highlightWrapper = document.querySelector(".highlight-wrapper");
const leftWrapper = document.querySelector(".left-wrapper");
const rightWrapper = document.querySelector(".right-wrapper");

const onButtonClick = () => {
  highlightWrapper.classList.toggle("toggle");
  leftWrapper.classList.toggle("toggle");
  rightWrapper.classList.toggle("toggle");
};