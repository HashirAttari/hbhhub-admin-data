# Snappy Toggle Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/visnuravichandran/pen/rNxyZed](https://codepen.io/visnuravichandran/pen/rNxyZed).

