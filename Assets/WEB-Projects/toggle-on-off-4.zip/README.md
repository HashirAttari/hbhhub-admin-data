# Toggle On/Off 4

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/dyLPJZL](https://codepen.io/alvaromontoro/pen/dyLPJZL).

Inspired by https://www.iconfinder.com/icons/1770528/off_on_toggle_button_toggle_click_toggle_switch_icon_icon