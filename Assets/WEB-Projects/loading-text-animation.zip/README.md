# Loading Text Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/vYavoEd](https://codepen.io/yudizsolutions/pen/vYavoEd).

When users are going to this site they run a loading splash screen with text split animation. Benefits for users while the website is loading at that time users want to be more engaged to watch this site.

Made by Hardi Kadakia from Yudiz