# 16 | Apple

A Pen created on CodePen.io. Original URL: [https://codepen.io/yitliu/pen/dKrYJm](https://codepen.io/yitliu/pen/dKrYJm).

