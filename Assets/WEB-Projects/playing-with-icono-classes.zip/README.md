# Playing with icono classes

A Pen created on CodePen.io. Original URL: [https://codepen.io/saeedalipoor/pen/QwGYgx](https://codepen.io/saeedalipoor/pen/QwGYgx).

just a quick demo about animating between icono classes.