# Daily UI #08 | Gradient border on button

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/PNBemZ](https://codepen.io/havardob/pen/PNBemZ).

