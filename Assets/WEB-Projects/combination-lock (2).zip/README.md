# Combination Lock

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/JRroNN](https://codepen.io/jkantner/pen/JRroNN).

An interactive lock made with the Draggable library from GreenSock. Drag the dial to the numbers below to open! Note: The unlock animation might be glitchy depending on your browser.

Update 5/18/21: Replaced obsolete Sass operations that broke this Pen