# Image Crop

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/rNMqoLW](https://codepen.io/ykadosh/pen/rNMqoLW).

This is a basic example of an image cropping tool. Click on the little circles or the box borders to resize the cropping tool. 

This pen was developed with Webrix.js - A set of powerful building blocks for React-based applications. For more information, visit https://webrix.amdocs.com/