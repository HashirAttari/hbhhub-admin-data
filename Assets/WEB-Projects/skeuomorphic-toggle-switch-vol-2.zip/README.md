# Skeuomorphic Toggle Switch (vol. 2)

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/NWOyxyO](https://codepen.io/nicolasjesenberger/pen/NWOyxyO).

Design by kolpikov: https://dribbble.com/shots/14326768-Kn-bz-Skeuomorphic-UI-Sample-for-Figma