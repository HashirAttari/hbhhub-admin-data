# H-TREE fractal 

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/abzyVme](https://codepen.io/franksLaboratory/pen/abzyVme).

