# Soccer player statistics 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/OJypExX](https://codepen.io/havardob/pen/OJypExX).

There's not a lot of soccer (football) on here, so I made this card view of my favorite player.  