# #webdev series - Another text particle animation!

A Pen created on CodePen.

Original URL: [https://codepen.io/hendrysadrak/pen/vOMrxJ](https://codepen.io/hendrysadrak/pen/vOMrxJ).

