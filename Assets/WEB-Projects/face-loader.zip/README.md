# Face Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/visnuravichandran/pen/JjGVBQa](https://codepen.io/visnuravichandran/pen/JjGVBQa).

