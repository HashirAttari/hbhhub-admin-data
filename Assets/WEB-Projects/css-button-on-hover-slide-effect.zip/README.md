# CSS Button On Hover Slide Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/RazorXio/pen/gMaoOW](https://codepen.io/RazorXio/pen/gMaoOW).

CSS Button On Hover Slide Effect.