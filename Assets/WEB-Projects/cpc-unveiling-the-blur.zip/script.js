// warp each word in a span (this could also be done direcctly in the HTML without the need for JS)
const container = document.getElementById("filtered");
const text = container.innerHTML;
const lines = text.split("<br>");
const html = lines.map(function (line) {
    const words = line.trim().split(/\s+/);
    const lineHtml = words.map(function (word) {
        return `<span>${word}</span>`;
    }).join(' ');
    return `${lineHtml}<br>`;
}).join('');
container.innerHTML = html;