# [CPC]  Unveiling the Blur

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/GRLVLgx](https://codepen.io/cbolson/pen/GRLVLgx).

1st submission in the weekly challenge.