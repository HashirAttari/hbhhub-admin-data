# Light Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/pozBdJE](https://codepen.io/ricardoolivaalonso/pen/pozBdJE).

