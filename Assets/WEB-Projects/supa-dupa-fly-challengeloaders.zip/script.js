// ***** Loader 1 Animation - Start *****
const loader1 = new TimelineMax({ repeat: -1 });
const loader1Duration = 0.5;
loader1
  .to(".loader-1 .shape-1", loader1Duration, { rotate: 360, transformOrigin: "center left" })
  .to(".loader-1 .shape-2", loader1Duration, { rotate: -180, transformOrigin: "center right" })
  .to(".loader-1 .shape-3", loader1Duration, { rotate: 360, transformOrigin: "center right" })
  .to(".loader-1 .shape-2", loader1Duration, { rotate: -360, transformOrigin: "center right" })
// ***** Loader 1 Animation - End *****

// ***** Loader 2 Animation - Start *****
const loader2 = new TimelineMax({ repeat: -1, yoyo: true });
const loader2Duration = 0.5;
loader2
  .to(".loader-2 .shape-1", loader2Duration, { translateX: -10, translateY: -10, scale: 0.7 }, 0)
  .to(".loader-2 .shape-2", loader2Duration, { translateX: 20, translateY: -10, scale: 0.7 }, 0)
  .to(".loader-2 .shape-3", loader2Duration, { translateY: 10, scale: 0.7 }, 0)
// ***** Loader 2 Animation - End *****

// ***** Loader 3 Animation - Start *****
const loader3 = new TimelineMax({ repeat:-1, yoyo: true });
const loader3Duration = 1;
loader3
  .to(".loader-3", loader3Duration, { ease: "back", rotate: 360 })
  .to(".loader-3 .shape-1", { translateX: -30, translateY: -30, scale: 0.7 }, 0)
  .to(".loader-3 .shape-2", { translateX: 30, translateY: -30, scale: 0.7 }, 0)
  .to(".loader-3 .shape-3", { translateY: 30, scale: 0.7 }, 0)
// ***** Loader 3 Animation - End *****

// ***** Loader 4 Animation - Start *****
const loader4 = new TimelineMax({ repeat:-1, yoyo: true });
const loader4Line1 = new TimelineMax();
const loader4Line2 = new TimelineMax();
const loader4Line3 = new TimelineMax();

loader4
  .fromTo(".loader-4 .line-1",{ translateX: -50 }, { translateX: 50 })
   .fromTo(".loader-4 .line-2",{ translateX: -20 }, { translateX: 20 }, 0)
  .fromTo(".loader-4 .line-3",{ translateX: -50 }, { translateX: 40 }, 0)
// ***** Loader 4 Animation - End *****