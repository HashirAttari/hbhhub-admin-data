# Toggle Worm (III)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/abxZoxj](https://codepen.io/alvaromontoro/pen/abxZoxj).

Inspired by Josetxu's Worm Toggle: https://codepen.io/josetxu/pen/QWPNWNa