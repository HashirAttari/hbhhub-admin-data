# Console Simulator

A Pen created on CodePen.io. Original URL: [https://codepen.io/MarioDesigns/pen/JbOyqe](https://codepen.io/MarioDesigns/pen/JbOyqe).

A fun console simulator, go ahead and try to find the commands available. Hope you have fun playing around with it!