# Flat UI colors

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/bOYzPz](https://codepen.io/ig_design/pen/bOYzPz).

