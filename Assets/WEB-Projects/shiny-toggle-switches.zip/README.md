# Shiny Toggle Switches

A Pen created on CodePen.io. Original URL: [https://codepen.io/nDav/pen/yeaVNd](https://codepen.io/nDav/pen/yeaVNd).

Shiny Toggle Switches made with CSS3 and conic-gradient.js