# Cubic Bezier examples

A Pen created on CodePen.io. Original URL: [https://codepen.io/bennettfeely/pen/DOexxp](https://codepen.io/bennettfeely/pen/DOexxp).

Try cubic-bezier as an animation timing function!