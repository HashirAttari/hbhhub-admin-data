# Toggle Emoji

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/JjVGwar](https://codepen.io/alvaromontoro/pen/JjVGwar).

Inspired by Vineeth.TR's Emo Toggle: inspired by https://codepen.io/vineethtrv/pen/ayOdQe