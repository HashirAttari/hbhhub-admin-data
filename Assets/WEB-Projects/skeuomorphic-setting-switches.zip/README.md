# Skeuomorphic Setting Switches

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/YzBddqx](https://codepen.io/jkantner/pen/YzBddqx).

Toggle switch idea from [this PSD by Julien Renvoye](https://dribbble.com/shots/637597-Free-PSD-IOS-Toggle).