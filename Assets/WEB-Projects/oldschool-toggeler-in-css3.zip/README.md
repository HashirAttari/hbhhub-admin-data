# oldschool toggeler in CSS3

A Pen created on CodePen.io. Original URL: [https://codepen.io/vsync/pen/nOyjVG](https://codepen.io/vsync/pen/nOyjVG).

a retro looking, CSS only button.