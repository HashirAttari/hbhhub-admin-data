var snd = new Audio('https://www.freesfx.co.uk/rx2/mp3s/2/2710_1329133090.mp3');
// delegated event on inputs of checkboxControl
document.addEventListener('change', function(e){
	if(e.target.parentNode.className.indexOf('checkboxControl') != -1){
		snd.currentTime = 0;
		snd.play(); 
	}
});