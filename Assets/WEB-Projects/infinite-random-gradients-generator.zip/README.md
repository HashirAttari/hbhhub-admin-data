# Infinite Random Gradients Generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/XwXEYX](https://codepen.io/kitjenson/pen/XwXEYX).

Infinite random gradients. 

Easily copy the necessary CSS with one click.