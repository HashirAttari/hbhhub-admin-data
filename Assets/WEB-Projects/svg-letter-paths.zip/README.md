# SVG Letter Paths

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/LwdVEV](https://codepen.io/run-time/pen/LwdVEV).

