const p1 = document.querySelector('.pad_one')
const p_hit = document.querySelector('.pad_hit')
const sc = document.querySelector('.score_block')
const sm = document.querySelector('#start_message')
const ttp = document.querySelector('#tap_to_play')
const death = document.querySelector('#death_box')
var drop_rate = 4
var drop_change = .25
var score = 0

function addItem() {
  var el = document.createElement('div')
  el.className = 'item'  
  el.style.filter = 'hue-rotate('+Math.random()*360+'deg) drop-shadow(0 0 5px rgba(0,0,0,.5))'  
  el.onanimationend = function() {
    el.style.left = Math.random()*95 + '%'
    el.style.top = '-5vw'
    el.style.zIndex = '3'
    el.style.animation = 'dropItem '+drop_rate+'s linear forwards'
  }
  document.querySelector('#elf_box').appendChild(el)  
}

// addItem()

function checkCollision() {
  if(document.querySelector('.item')) {
    var items = document.querySelectorAll('.item')
    items.forEach(function(elm){
      var elm_loc = elm.getBoundingClientRect()
      var elm_below = document.elementFromPoint(elm_loc.left + window.innerWidth*.01, elm_loc.top + elm_loc.height)
      // console.log(elm_below)

      if(elm_below && elm_below.classList.contains('pad_hit')) {
        elm.remove()
        score++
        sc.innerHTML = score

        if(drop_rate > 1) {
          drop_rate -= drop_change  
        }        
        if(score >= 50) {
          drop_rate = .75
        }
        addItem()
      }
      
      if(elm_below && elm_below.id == 'death_box') {
        document.querySelector('.item').remove()
        sm.style.display = 'block'
      }
    })
  }
}
var play = setInterval(checkCollision, 1000/60)

function movePad1(e) {
  document.documentElement.style.setProperty('--elf-img', 'url("https://contentservice.mc.reyrey.net/image_v1.0.0/?id=e973aa75-c36e-5ea4-b4ac-40e1fb8518cd&637739754663204389")')
  var x = e.clientX / window.innerWidth * 100
  p1.style.left = x + '%'
}
window.addEventListener('mousemove', movePad1)
window.addEventListener('touchmove', function(e){
  document.documentElement.style.setProperty('--elf-img', 'url("https://contentservice.mc.reyrey.net/image_v1.0.0/?id=e973aa75-c36e-5ea4-b4ac-40e1fb8518cd&637739754663204389")')
  var x = e.touches[0].clientX / window.innerWidth * 100
  p1.style.left = x + '%'
})

ttp.addEventListener('click', function(){
  drop_rate = 4
  score = 0
  sc.innerHTML = score
  sm.style.display = 'none'
  addItem()
})