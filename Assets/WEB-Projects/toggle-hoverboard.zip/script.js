// cambiar a indeterminado
document.querySelector(".indeterminado").indeterminate = true;