# Border 3

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/rNyorga](https://codepen.io/yuanchuan/pen/rNyorga).

