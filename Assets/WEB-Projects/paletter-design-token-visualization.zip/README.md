# paletter design-token visualization

A Pen created on CodePen.io. Original URL: [https://codepen.io/meodai/pen/XWMwYLM](https://codepen.io/meodai/pen/XWMwYLM).

