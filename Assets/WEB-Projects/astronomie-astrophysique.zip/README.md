# Astronomie & Astrophysique

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/KzVewZ](https://codepen.io/mselmany/pen/KzVewZ).

Playing around with Lissajous curves.

Forked from [Riley Shaw](http://codepen.io/rileyjshaw/)'s Pen [Astronomie & Astrophysique](http://codepen.io/rileyjshaw/pen/PNPVmK/).