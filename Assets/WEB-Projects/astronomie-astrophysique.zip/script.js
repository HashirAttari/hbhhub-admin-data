// Play with these!
const W = 500;
const NUM_DOTS = 8;
const TRAIL_LENGTH = 48;
const FG = '#3C3E33';
const BG = '#ECD9C4';
const INACTIVE_SPEED = 1;
const ACTIVE_SPEED = 4;
const CLEAR_FRAMES = true;

// Derived.
const H = W;
const RADIUS = W / NUM_DOTS / 8 / 3;
const PI2 = Math.PI * 2;
document.body.style.color = FG;
document.body.style.background = BG;

// Container element.
const collection = document.querySelector('.collection');
collection.style.maxWidth = `${(W / 2 + 12 * 2) * 3 - 1}px`;

class Sample {
  constructor(name, dotFn) {
    const container = document.createElement('div');
    const title = document.createElement('h2');
    const canvas = document.createElement('canvas');
    container.className = 'sample';
    container.style.width = `${W / 2}px`;
    title.textContent = name;
    title.style.background = BG;
    canvas.width = W;
    canvas.height = H;
    canvas.style.border = `1px solid ${rgba(FG, 0.3)}`;

    canvas.addEventListener('mouseenter', () => this.isActive = true, false);
    canvas.addEventListener('mouseleave', () => this.isActive = false, false);

    container.appendChild(canvas);
    container.appendChild(title);
    collection.appendChild(container);

    this.ctx = canvas.getContext('2d');
    this.ctx.translate(W / 2, H / 2);
    this.ctx.scale(1, -1);
    this.ctx.lineWidth = 1;
    this.ctx.strokeStyle = rgba(FG, 0.5);
    this.ctx.fillStyle = FG;

    if (CLEAR_FRAMES) {
      this.trails = Array.from({ length: NUM_DOTS }).map(() => []);
    }
    this.dots = Array.from({ length: NUM_DOTS }).map((_, i) => dotFn(i + 1));
    this.lastClock = 0;
    this.step(0, 0);
    this.nope = 0;
  }

  step(t, clock) {
    if (CLEAR_FRAMES) {
      this.ctx.clearRect(-W / 2, -H / 2, W, H);
    }

    const activeSpeed = this.isActive ? ACTIVE_SPEED : INACTIVE_SPEED;
    this.dots.forEach(({
      xRadius, yRadius, xAngle, yAngle, xSpeed, ySpeed },
    dotIdx) => {
      const x = Math.cos(t * xSpeed + xAngle) * xRadius;
      const y = Math.sin(t * ySpeed + yAngle) * yRadius;

      // Draw dot.
      this.ctx.beginPath();
      this.ctx.arc(x, y, RADIUS, 0, PI2);
      this.ctx.fill();
      this.ctx.closePath();

      if (CLEAR_FRAMES) {
        // Draw trails.
        this.ctx.beginPath();
        this.trails[dotIdx].forEach(({ x, y }, trailIdx) => {
          this.ctx[`${trailIdx ? 'line' : 'move'}To`](x, y);
        });
        this.ctx.stroke();
        this.ctx.closePath();

        // Update trail for next step.
        this.trails[dotIdx] =
        [...this.trails[dotIdx], { x, y }].slice(-TRAIL_LENGTH);
      }
    });

    const nextT = t + activeSpeed * (clock - this.lastClock) / 1000;
    window.requestAnimationFrame(this.step.bind(this, nextT));
    this.lastClock = clock;
  }}
;

new Sample('la première orbite', i => ({
  xRadius: -i * RADIUS * 4,
  yRadius: -i * RADIUS * 4,
  xAngle: 0,
  yAngle: 0,
  xSpeed: 1,
  ySpeed: 1 }));


new Sample('la deuxième orbite', i => ({
  xRadius: i * RADIUS * 8,
  yRadius: i * RADIUS * 8,
  xAngle: 0,
  yAngle: 0,
  xSpeed: 2 / i,
  ySpeed: 2 / i }));


new Sample('la troisième orbite', i => ({
  xRadius: i * RADIUS * 8,
  yRadius: i * RADIUS * 8,
  xAngle: PI2 / NUM_DOTS * i,
  yAngle: PI2 / NUM_DOTS * i,
  xSpeed: 0.25,
  ySpeed: 0.5 }));


new Sample('c\'est ça...', i => ({
  xRadius: i * RADIUS * 11,
  yRadius: i * RADIUS * 8,
  xAngle: 3,
  yAngle: PI2 / NUM_DOTS * i,
  xSpeed: 0.5,
  ySpeed: 1 }));


// Util.
function rgba(hex, alpha) {
  // Expand shorthand form (#000).
  const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
  hex = hex.replace(shorthandRegex, function (m, r, g, b) {
    return r + r + g + g + b + b;
  });

  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (result) {
    const r = parseInt(result[1], 16);
    const g = parseInt(result[2], 16);
    const b = parseInt(result[3], 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  } else return hex;
}