# "Bump" Accordion - CSS Only | CPC

A Pen created on CodePen.io. Original URL: [https://codepen.io/TheMOZZARELLA/pen/WNMbaBK](https://codepen.io/TheMOZZARELLA/pen/WNMbaBK).

Tried creating a "bump" effect on the adjacent list items when expanding one on the accordion. Responsive & CSS only accordion.