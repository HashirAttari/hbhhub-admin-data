let scene, camera, renderer, torus, pane, shapeParams, warpParams, colorParams, rotationParams, interactionParams;
let originalPositions;
let cameraRotation = { x: 0, y: 0 }; // Store the camera rotation state
let shapePreset, colorPreset, warpPreset, surfaceType, xSpeed, ySpeed, zSpeed;
let currentTipIndex = 0;

// Parameter limits
const PARAMS_LIMITS = {
    outerRadius: { min: 1, max: 400 },
    innerRadius: { min: 1, max: 400 },
    radialSegments: { min: 3, max: 200 },
    tubularSegments: { min: 3, max: 200 },
    warpAmount: { min: 0.0, max: 5 },
    warpSpeed: { min: 0.1, max: 5 },
    warpAmplitude: { min: 0.1, max: 5 },
    warpFrequency: { min: 0.1, max: 5 },
    rotationSpeed: { min: 0.0, max: 10.0 }
};

const shapePresets = {
    "Horn Torus": { outerRadius: 10, innerRadius: 10, radialSegments: 32, tubularSegments: 100 },
    "Horn Torus (Inside)": { outerRadius: 400, innerRadius: 400, radialSegments: 64, tubularSegments: 100 },
    "Donut": { outerRadius: 23, innerRadius: 10, radialSegments: 64, tubularSegments: 100 },
    "Stargate": { outerRadius: 15, innerRadius: 12, radialSegments: 20, tubularSegments: 20 },
    "Tensegrity": { outerRadius: 12, innerRadius: 12, radialSegments: 4, tubularSegments: 3 },
    "Triangle": { outerRadius: 30, innerRadius: 15, radialSegments: 64, tubularSegments: 3 },
    "Square": { outerRadius: 20, innerRadius: 8, radialSegments: 64, tubularSegments: 4 },
    "Universal Lattice": { outerRadius: 257, innerRadius: 245, radialSegments: 64, tubularSegments: 4 },
    "Flower": { outerRadius: 10, innerRadius: 10, radialSegments: 64, tubularSegments: 6 },
    "Inside-Out": { outerRadius: 5, innerRadius: 22, radialSegments: 64, tubularSegments: 32 },
    "Cone": { outerRadius: 1, innerRadius: 20, radialSegments: 3, tubularSegments: 100 },
    "Nut": { outerRadius: 1, innerRadius: 20, radialSegments: 64, tubularSegments: 3 },
    "Ring": { outerRadius: 20, innerRadius: 1, radialSegments: 20, tubularSegments: 100 }
};

const warpPresets = {
    "No Warp": { warp: 0.0, warpSpeed: 1.0, warpAmplitude: 1.0, warpFrequency: 1.0 },
    "Slow Swirl": { warp: 1.0, warpSpeed: 0.5, warpAmplitude: 1.0, warpFrequency: 1.0 },
    "Fast Swirl": { warp: 1.0, warpSpeed: 2.0, warpAmplitude: 1.0, warpFrequency: 1.0 },
    "Large Waves": { warp: 1.0, warpSpeed: 1.0, warpAmplitude: 2.0, warpFrequency: 0.5 },
    "Small Waves": { warp: 1.0, warpSpeed: 1.0, warpAmplitude: 0.5, warpFrequency: 2.0 },
    "Maximum Warp": { warp: 5.0, warpSpeed: 1.0, warpAmplitude: 5.0, warpFrequency: 5.0 }
};

const colorPresets = {
    "Aurora Borealis": { innerColor: '#ff00ed', outerColor: '#664cc2' },
    "Aurora Borealis 2": { innerColor: '#4b7907', outerColor: '#06491b' },
    "Aurora Borealis 3": { innerColor: '#00b6ff', outerColor: '#9e4cc2' },
    "Black Hole": { innerColor: '#000000', outerColor: '#d5d1e5' },
    "Deep Sea": { innerColor: '#84a1b8', outerColor: '#135b5c' },
    "Forest": { innerColor: '#06491b', outerColor: '#4b7907' },
    "Lavender": { innerColor: '#e6e6fa', outerColor: '#9370db' },
    "Ocean": { innerColor: '#4682b4', outerColor: '#00ced1' },
    "R B Contrast": { innerColor: '#ff3300', outerColor: '#17006c' },
    "Rose": { innerColor: '#ffc0cb', outerColor: '#ff69b4' },
    "Sunset": { innerColor: '#fbff00', outerColor: '#cf5151' },
    "Sunset 2": { innerColor: '#2c00ff', outerColor: '#c24c55' },
    "Sunset 3": { innerColor: '#ffc400', outerColor: '#c24c50' },
    "Void": { innerColor: '#18ff00', outerColor: '#07050c' },
    "White Hole": { innerColor: '#e8f4ff', outerColor: '#185859' },
    "Worm Hole": { innerColor: '#ffffff', outerColor: '#8c279c' }
};

const metaPresets = {
    "Aurora Horn": {
        shapePreset: "Horn Torus",
        colorPreset: "Aurora Borealis",
        warpPreset: "No Warp",
        surface: 'wireframe',
        xSpeed: 0.0, ySpeed: 0.0, zSpeed: 0.0, mouseRotation: true
    },
    "Cosmic Carousel": {
        shapePreset: "Horn Torus",
        colorPreset: "Aurora Borealis",
        warpPreset: "No Warp",
        surface: 'points',
        xSpeed: 0.0, ySpeed: 0.0, zSpeed: 0.4, mouseRotation: false
    },
    "Black Hole Stargate": {
        shapePreset: "Stargate",
        colorPreset: "Black Hole",
        warpPreset: "Slow Swirl",
        surface: 'points',
        xSpeed: 0.0, ySpeed: 0.0, zSpeed: 0.0, mouseRotation: true
    },
    "Lavender Flower": {
        shapePreset: "Flower",
        colorPreset: "Lavender",
        warpPreset: "Small Waves",
        surface: 'points',
        xSpeed: 0.0, ySpeed: 0.0, zSpeed: 1.5, mouseRotation: false
    },
    "Center of the Universe": {
        shapePreset: "Horn Torus (Inside)",
        colorPreset: "Aurora Borealis",
        warpPreset: "Large Waves",
        surface: 'wireframe',
        xSpeed: 0.0, ySpeed: 0.0, zSpeed: 1.0, mouseRotation: false
    },
    "Tensegrity Motion": {
        shapePreset: "Tensegrity",
        colorPreset: "Aurora Borealis",
        warpPreset: "Fast Swirl",
        surface: 'wireframe',
        xSpeed: 0.0, ySpeed: 0.0, zSpeed: 0.0, mouseRotation: true
    },
    "Particles": {
        shapePreset: "Flower",
        colorPreset: "Aurora Borealis",
        warpPreset: "Maximum Warp",
        surface: 'points',
        xSpeed: 0.5, ySpeed: 0.5, zSpeed: 0.5, mouseRotation: false
    },
    "Particle Accelerator": {
        shapePreset: "Donut",
        colorPreset: "Sunset 2",
        warpPreset: "Maximum Warp",
        surface: 'points',
        xSpeed: 0.5, ySpeed: 0.5, zSpeed: 0.5, mouseRotation: false
    },
    "Orbits": {
        shapePreset: "Horn Torus (Inside)",
        colorPreset: "Ocean",
        warpPreset: "Maximum Warp",
        surface: 'points',
        xSpeed: 0.0, ySpeed: 0.0, zSpeed: 0.0, mouseRotation: false
    },
    "Portal": {
        shapePreset: "Stargate",
        colorPreset: "Worm Hole",
        warpPreset: "Slow Swirl",
        surface: 'wireframe',
        xSpeed: 0.0, ySpeed: 0.0, zSpeed: 0.5, mouseRotation: false
    },
    "Wormhole Travel": {
        shapePreset: "Universal Lattice",
        colorPreset: "Black Hole",
        warpPreset: "Large Waves",
        surface: 'wireframe',
        xSpeed: 0.0, ySpeed: 0.0, zSpeed: 1.5, mouseRotation: false
    },
    "Quasar": {
        shapePreset: "Horn Torus (Inside)",
        colorPreset: "White Hole",
        warpPreset: "Fast Swirl",
        surface: 'wireframe',
        xSpeed: 5.0, ySpeed: 5.0, zSpeed: 5.0, mouseRotation: false
    },
    "Jellyfish": {
        shapePreset: "Flower",
        colorPreset: "Aurora Borealis",
        warpPreset: "Large Waves",
        surface: 'points',
        xSpeed: 0.0, ySpeed: 0.0, zSpeed: 0.0, mouseRotation: false
    },
    "Jelly": {
        shapePreset: "Horn Torus",
        colorPreset: "Sunset",
        warpPreset: "Large Waves",
        surface: 'wireframe',
        xSpeed: 1.0, ySpeed: 1.0, zSpeed: 1.0, mouseRotation: false
    },
    "Jelly Donut": {
        shapePreset: "Donut",
        colorPreset: "R B Contrast",
        warpPreset: "No Warp",
        surface: 'skin',
        xSpeed: 0.0, ySpeed: 0.0, zSpeed: 0.0, mouseRotation: true
    },
    "Ring of Rings": {
        shapePreset: "Ring",
        colorPreset: "Deep Sea",
        warpPreset: "Large Waves",
        surface: 'points',
        xSpeed: 1.0, ySpeed: 2.0, zSpeed: 0.0, mouseRotation: false
    }
};

const tips = [
    {
        number: 1,
        title: "Presets",
        text: "Play with the presets to see what is possible, and then try adjusting parameters manually on your own! There is a preset for each section (for Shape, Color and Warp) and also a Meta-Preset at the top that combines multiple presets and settings together."
    },
    {
        number: 2,
        title: "Zooming",
        text: "In the Shape section enable “Lock Radii Together” to zoom a shape in and out without affecting its shape. Zoom all the way in to view inside the shape."
    },
    {
        number: 3,
        title: "Rotation Controls",
        text: "You can rotate by moving the mouse, or by adjusting the X,Y,Z-coordinate speed sliders. To enable the X,Y,Z sliders, turn off the mouse rotation checkbox or press the ‘R’ key. To rotate around a precise camera angle, first rotate the shape into position using the mouse rotation feature. Then press the ‘R’ key to lock the position. Then adjust one or more of the X,Y,Z sliders. The Z axis slider will make the shape spin around its own axis."
    },
    {
        number: 4,
        title: "Surface Types",
        text: "Experiment with the different surface types to see the outside and inside of the shapes. The Wireframe and Points mode will let you see inside like X-Ray vision"
    },
    {
        number: 5,
        title: "Inside-Out",
        text: "You can make the inner radius bigger than the outer radius to make the shape go inside-out!"
    },
    {
        number: 6,
        title: "Hot Keys",
        text: "Press the ‘P’ key to toggle the control panel open and closed (or click on the panel title). Press the ‘R’ key to toggle the mouse rotation on/off (or tap the checkbox)."
    }
];

// Options for surface representation
const SURFACE_OPTIONS = {
    Wireframe: 'wireframe',
    Points: 'points',
    Skin: 'skin'
};

// Initial surface type
let currentSurfaceType = SURFACE_OPTIONS.Wireframe;

function addTooltip(element, text) {
    const infoButton = document.createElement('span');
    infoButton.className = 'info-button';
    infoButton.textContent = 'i';
    infoButton.setAttribute('data-tooltip', text);
    element.appendChild(infoButton);
}

function togglePane() {
    const folders = pane.children;
    const isExpanded = folders[0].expanded;
    folders.forEach(folder => {
        folder.expanded = !isExpanded;
    });
    pane.refresh();
}

function showTipDialog() {
    const tip = tips[currentTipIndex];
    const dialog = document.createElement('div');
    dialog.className = 'tip-dialog';
    dialog.innerHTML = `
        <h2>Tip #${tip.number}: ${tip.title}</h2>
        <p>${tip.text}</p>
        <div class="nav-buttons">
            <div class="prev-next-buttons">
                <button id="prevTip">⬅️ Previous</button>
                <button id="nextTip">Next ➡️</button>
            </div>
            <button id="closeTip">Close</button>
        </div>
    `;
    document.body.appendChild(dialog);

    document.getElementById('prevTip').onclick = () => {
        currentTipIndex = (currentTipIndex - 1 + tips.length) % tips.length;
        document.body.removeChild(dialog);
        showTipDialog();
    };
    document.getElementById('nextTip').onclick = () => {
        currentTipIndex = (currentTipIndex + 1) % tips.length;
        document.body.removeChild(dialog);
        showTipDialog();
    };
    document.getElementById('closeTip').onclick = () => {
        document.body.removeChild(dialog);
    };

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            document.body.removeChild(dialog);
        }
    }, { once: true });
}

// Apply meta preset
function applyMetaPreset(preset) {
    const params = metaPresets[preset];

    if (params.shapePreset) {
        Object.assign(shapeParams, shapePresets[params.shapePreset]);
        shapeParams.radiusDifference = shapeParams.innerRadius - shapeParams.outerRadius;
        shapePreset.value = params.shapePreset;
    }
    if (params.colorPreset) {
        Object.assign(colorParams, colorPresets[params.colorPreset]);
        colorPreset.value = params.colorPreset;
    }
    if (params.warpPreset) {
        Object.assign(warpParams, warpPresets[params.warpPreset]);
        warpPreset.value = params.warpPreset;
    }
    currentSurfaceType = params.surface;
    surfaceType.value = params.surface;

    Object.assign(rotationParams, {
        xSpeed: params.xSpeed, ySpeed: params.ySpeed, zSpeed: params.zSpeed
    });

    interactionParams.mouseRotation = params.mouseRotation;

    pane.refresh();
    createTorus();
    updateMaterial();
}

// Create the scene, camera, and renderer
function init() {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    camera.position.z = 50;

    // Tweakpane parameters
    shapeParams = { ...shapePresets["Horn Torus"], lockRadii: false, radiusDifference: shapePresets["Horn Torus"].innerRadius - shapePresets["Horn Torus"].outerRadius };
    warpParams = { ...warpPresets["No Warp"] };
    colorParams = { ...colorPresets["Aurora Borealis"] }; // Set default colors
    rotationParams = { xSpeed: 0.0, ySpeed: 0.0, zSpeed: 0.0, lockXYZ: false, xyzDifference: { x: 0, y: 0, z: 0 } };
    interactionParams = { mouseRotation: true, lockSegments: false, segmentsDifference: shapeParams.radialSegments - shapeParams.tubularSegments };

    // Create a container for Tweakpane and add styling
    const paneContainer = document.createElement('div');
    paneContainer.className = 'pane-container';
    document.body.appendChild(paneContainer);

    // Create Tweakpane and attach it to the container
    pane = new Tweakpane.Pane({ container: paneContainer });

    // Create a title folder to contain all other folders
    const titleFolder = pane.addFolder({ title: '3D Torus Simulator (\'P\' Key to toggle Panel)', expanded: true });

    // Tips button
    const tipsButton = titleFolder.addButton({ title: 'Tips 💡' }).on('click', () => {
        showTipDialog();
    });

    // Meta preset dropdown
    const metaPresetOptions = Object.keys(metaPresets).map((key, index) => ({ text: `${index + 1}. ${key}`, value: key }));
    const metaPreset = titleFolder.addBlade({
        view: 'list',
        label: 'Meta Presets',
        options: metaPresetOptions,
        value: 'Aurora Horn'
    }).on('change', ev => {
        applyMetaPreset(ev.value);
    });
    addTooltip(metaPreset.controller_.view.element, 'These presets adjust all parameters');

    // Shape folder
    const shapeFolder = titleFolder.addFolder({ title: 'Shape', expanded: true });

    // Shape preset dropdown
    const shapePresetOptions = [{ text: '(None)', value: '(None)' }, ...Object.keys(shapePresets).map((key, index) => ({ text: `${index + 1}. ${key}`, value: key }))];
    shapePreset = shapeFolder.addBlade({
        view: 'list',
        label: 'Shape Presets',
        options: shapePresetOptions,
        value: '(None)'
    }).on('change', ev => {
        if (ev.value === "(None)") return;
        Object.assign(shapeParams, shapePresets[ev.value]);
        shapeParams.radiusDifference = shapeParams.innerRadius - shapeParams.outerRadius;
        pane.refresh();
        createTorus();
    });
    addTooltip(shapePreset.controller_.view.element, 'Select a shape preset');

    // Radius settings subfolder
    const radiusFolder = shapeFolder.addFolder({ title: 'Radius Settings', expanded: true });

    // Checkbox for locking radii
    const lockRadii = radiusFolder.addInput(shapeParams, 'lockRadii', { label: 'Lock Radii Together' }).on('change', (ev) => {
        if (ev.value) {
            shapeParams.radiusDifference = shapeParams.innerRadius - shapeParams.outerRadius;
        }
    });
    addTooltip(lockRadii.controller_.view.element, 'Lock the inner and outer radius together (Use this to zoom in and out)');

    // Outer radius input
    const outerRadius = radiusFolder.addInput(shapeParams, 'outerRadius', { label: 'Outer Radius', min: PARAMS_LIMITS.outerRadius.min, max: PARAMS_LIMITS.outerRadius.max, step: 1 }).on('change', (ev) => {
        if (shapeParams.lockRadii) {
            shapeParams.innerRadius = ev.value + shapeParams.radiusDifference;
            shapeParams.innerRadius = Math.max(PARAMS_LIMITS.innerRadius.min, Math.min(shapeParams.innerRadius, PARAMS_LIMITS.innerRadius.max));
        }
        shapeParams.radiusDifference = shapeParams.innerRadius - shapeParams.outerRadius;
        pane.refresh();
        createTorus();
    });
    addTooltip(outerRadius.controller_.view.element, 'Adjust the outer radius');

    // Inner radius input
    const innerRadius = radiusFolder.addInput(shapeParams, 'innerRadius', { label: 'Inner Radius', min: PARAMS_LIMITS.innerRadius.min, max: PARAMS_LIMITS.innerRadius.max, step: 1 }).on('change', (ev) => {
        if (shapeParams.lockRadii) {
            shapeParams.outerRadius = ev.value - shapeParams.radiusDifference;
            shapeParams.outerRadius = Math.max(PARAMS_LIMITS.outerRadius.min, Math.min(shapeParams.outerRadius, PARAMS_LIMITS.outerRadius.max));
        }
        shapeParams.radiusDifference = shapeParams.innerRadius - shapeParams.outerRadius;
        pane.refresh();
        createTorus();
    });
    addTooltip(innerRadius.controller_.view.element, 'Adjust the inner radius');

    // Segments settings subfolder
    const segmentsFolder = shapeFolder.addFolder({ title: 'Segments Settings', expanded: true });

    // Checkbox for locking segments
    const lockSegments = segmentsFolder.addInput(interactionParams, 'lockSegments', { label: 'Lock Segments Together' }).on('change', (ev) => {
        if (ev.value) {
            interactionParams.segmentsDifference = shapeParams.radialSegments - shapeParams.tubularSegments;
        }
    });
    addTooltip(lockSegments.controller_.view.element, 'Lock the radial and tubular segments together');

    // Radial segments input
    const radialSegments = segmentsFolder.addInput(shapeParams, 'radialSegments', { label: 'Radial Segments', min: PARAMS_LIMITS.radialSegments.min, max: PARAMS_LIMITS.radialSegments.max, step: 1 }).on('change', (ev) => {
        if (interactionParams.lockSegments) {
            shapeParams.tubularSegments = ev.value - interactionParams.segmentsDifference;
            shapeParams.tubularSegments = Math.max(PARAMS_LIMITS.tubularSegments.min, Math.min(shapeParams.tubularSegments, PARAMS_LIMITS.tubularSegments.max));
        }
        interactionParams.segmentsDifference = shapeParams.radialSegments - shapeParams.tubularSegments;
        pane.refresh();
        createTorus();
    });
    addTooltip(radialSegments.controller_.view.element, 'Adjust the number of radial segments');

    // Tubular segments input
    const tubularSegments = segmentsFolder.addInput(shapeParams, 'tubularSegments', { label: 'Tubular Segments', min: PARAMS_LIMITS.tubularSegments.min, max: PARAMS_LIMITS.tubularSegments.max, step: 1 }).on('change', (ev) => {
        if (interactionParams.lockSegments) {
            shapeParams.radialSegments = ev.value + interactionParams.segmentsDifference;
            shapeParams.radialSegments = Math.max(PARAMS_LIMITS.radialSegments.min, Math.min(shapeParams.radialSegments, PARAMS_LIMITS.radialSegments.max));
        }
        interactionParams.segmentsDifference = shapeParams.radialSegments - shapeParams.tubularSegments;
        pane.refresh();
        createTorus();
    });
    addTooltip(tubularSegments.controller_.view.element, 'Adjust the number of tubular segments');

    // Surface folder
    const surfaceFolder = titleFolder.addFolder({ title: 'Surface', expanded: true });

    // Surface type dropdown
    const surfaceTypeOptions = Object.keys(SURFACE_OPTIONS).map((key, index) => ({ text: `${index + 1}. ${key}`, value: SURFACE_OPTIONS[key] }));
    surfaceType = surfaceFolder.addBlade({
        view: 'list',
        label: 'Surface Type',
        options: surfaceTypeOptions,
        value: currentSurfaceType
    }).on('change', ev => {
        currentSurfaceType = ev.value;
        createTorus();
    });
    addTooltip(surfaceType.controller_.view.element, 'Select the type of surface for the torus');

    // Color folder
    const colorFolder = titleFolder.addFolder({ title: 'Color', expanded: true });

    // Color preset dropdown
    const colorPresetOptions = [{ text: '(None)', value: '(None)' }, ...Object.keys(colorPresets).map((key, index) => ({ text: `${index + 1}. ${key}`, value: key }))];
    colorPreset = colorFolder.addBlade({
        view: 'list',
        label: 'Color Presets',
        options: colorPresetOptions,
        value: '(None)'
    }).on('change', ev => {
        if (ev.value === "(None)") return;
        Object.assign(colorParams, colorPresets[ev.value]);
        updateMaterial();
        pane.refresh();
    });
    addTooltip(colorPreset.controller_.view.element, 'Select a color preset');

    const innerColor = colorFolder.addInput(colorParams, 'innerColor', { label: 'Inner Color' }).on('change', () => updateMaterial());
    addTooltip(innerColor.controller_.view.element, 'Select the inner color');

    const outerColor = colorFolder.addInput(colorParams, 'outerColor', { label: 'Outer Color' }).on('change', () => updateMaterial());
    addTooltip(outerColor.controller_.view.element, 'Select the outer color');

    // Warp folder
    const warpFolder = titleFolder.addFolder({ title: 'Warp', expanded: true });

    // Warp preset dropdown
    const warpPresetOptions = [{ text: '(None)', value: '(None)' }, ...Object.keys(warpPresets).map((key, index) => ({ text: `${index + 1}. ${key}`, value: key }))];
    warpPreset = warpFolder.addBlade({
        view: 'list',
        label: 'Warp Presets',
        options: warpPresetOptions,
        value: '(None)'
    }).on('change', ev => {
        if (ev.value === "(None)") return;
        Object.assign(warpParams, warpPresets[ev.value]);
        pane.refresh();
    });
    addTooltip(warpPreset.controller_.view.element, 'Select a warp preset');

    // Warp amount
    const warp = warpFolder.addInput(warpParams, 'warp', { label: 'Warp Amount', min: PARAMS_LIMITS.warpAmount.min, max: PARAMS_LIMITS.warpAmount.max, step: 0.1 });
    addTooltip(warp.controller_.view.element, 'Adjust the amount of warp applied to the vertices');

    // Warp speed
    const warpSpeed = warpFolder.addInput(warpParams, 'warpSpeed', { label: 'Warp Speed', min: PARAMS_LIMITS.warpSpeed.min, max: PARAMS_LIMITS.warpSpeed.max, step: 0.1 });
    addTooltip(warpSpeed.controller_.view.element, 'Adjust the speed at which the warp effect oscillates');

    // Warp amplitude
    const warpAmplitude = warpFolder.addInput(warpParams, 'warpAmplitude', { label: 'Warp Amplitude', min: PARAMS_LIMITS.warpAmplitude.min, max: PARAMS_LIMITS.warpAmplitude.max, step: 0.1 });
    addTooltip(warpAmplitude.controller_.view.element, 'Adjust the amplitude (height) of the warp waves');

    // Warp frequency
    const warpFrequency = warpFolder.addInput(warpParams, 'warpFrequency', { label: 'Warp Frequency', min: PARAMS_LIMITS.warpFrequency.min, max: PARAMS_LIMITS.warpFrequency.max, step: 0.1 });
    addTooltip(warpFrequency.controller_.view.element, 'Adjust the frequency (number) of the warp waves');

    // Rotation folder
    const rotationFolder = titleFolder.addFolder({ title: 'Rotation', expanded: true });

    const mouseRotation = rotationFolder.addInput(interactionParams, 'mouseRotation', { label: "Mouse Rotation ('R' key)" }).on('change', (ev) => {
        xSpeed.disabled = ev.value;
        ySpeed.disabled = ev.value;
        zSpeed.disabled = ev.value;
        pane.refresh();
    });
    addTooltip(mouseRotation.controller_.view.element, 'Control rotation with mouse (Turn off to enable X,Y,Z rotation options)');

    // Rotation settings subfolder
    const rotationSettingsFolder = rotationFolder.addFolder({ title: 'XYZ Rotation Settings (to use disable mouse rotation)', expanded: true });

    // Checkbox for locking XYZ speeds
    const lockXYZ = rotationSettingsFolder.addInput(rotationParams, 'lockXYZ', { label: 'Lock XYZ Together' }).on('change', (ev) => {
        if (ev.value) {
            rotationParams.xyzDifference.x = rotationParams.xSpeed - rotationParams.ySpeed;
            rotationParams.xyzDifference.y = rotationParams.ySpeed - rotationParams.zSpeed;
            rotationParams.xyzDifference.z = rotationParams.zSpeed - rotationParams.xSpeed;
        }
    });
    addTooltip(lockXYZ.controller_.view.element, 'Lock the X, Y, Z rotation speeds together');

    xSpeed = rotationSettingsFolder.addInput(rotationParams, 'xSpeed', { label: 'X Axis Speed', min: PARAMS_LIMITS.rotationSpeed.min, max: PARAMS_LIMITS.rotationSpeed.max, step: 0.1, disabled: interactionParams.mouseRotation }).on('change', (ev) => {
        if (rotationParams.lockXYZ) {
            rotationParams.ySpeed = ev.value - rotationParams.xyzDifference.x;
            rotationParams.zSpeed = ev.value + rotationParams.xyzDifference.z;
            pane.refresh();
        }
    });
    addTooltip(xSpeed.controller_.view.element, 'Adjust the rotation speed around the X axis (Overwritten by mouse rotation option)');

    ySpeed = rotationSettingsFolder.addInput(rotationParams, 'ySpeed', { label: 'Y Axis Speed', min: PARAMS_LIMITS.rotationSpeed.min, max: PARAMS_LIMITS.rotationSpeed.max, step: 0.1, disabled: interactionParams.mouseRotation }).on('change', (ev) => {
        if (rotationParams.lockXYZ) {
            rotationParams.xSpeed = ev.value + rotationParams.xyzDifference.x;
            rotationParams.zSpeed = ev.value - rotationParams.xyzDifference.y;
            pane.refresh();
        }
    });
    addTooltip(ySpeed.controller_.view.element, 'Adjust the rotation speed around the Y axis (Overwritten by mouse rotation option)');

    zSpeed = rotationSettingsFolder.addInput(rotationParams, 'zSpeed', { label: 'Z Axis Speed', min: PARAMS_LIMITS.rotationSpeed.min, max: PARAMS_LIMITS.rotationSpeed.max, step: 0.1, disabled: interactionParams.mouseRotation }).on('change', (ev) => {
        if (rotationParams.lockXYZ) {
            rotationParams.xSpeed = ev.value - rotationParams.xyzDifference.z;
            rotationParams.ySpeed = ev.value + rotationParams.xyzDifference.y;
            pane.refresh();
        }
    });
    addTooltip(zSpeed.controller_.view.element, 'Adjust the rotation speed around the Z axis (Overwritten by mouse rotation option)');

    // About section
    const aboutFolder = titleFolder.addFolder({ title: 'About', expanded: false });

    const madeByFolder = aboutFolder.addFolder({ title: 'Made By', expanded: true });
    madeByFolder.addButton({ title: 'AshMystic.com' }).on('click', () => {
        window.open('https://ashmystic.com', '_blank');
    });

    const builtWithFolder = aboutFolder.addFolder({ title: 'Built With', expanded: true });
    builtWithFolder.addButton({ title: 'ThreeJS' }).on('click', () => {
        window.open('https://threejs.org', '_blank');
    });

    builtWithFolder.addButton({ title: 'TweakPane' }).on('click', () => {
        window.open('https://tweakpane.github.io/docs/', '_blank');
    });

    builtWithFolder.addButton({ title: 'ChatGPT' }).on('click', () => {
        window.open('https://chat.openai.com/', '_blank');
    });

    applyMetaPreset('Aurora Horn'); // Apply the first meta preset on load

    createTorus();

    let mouseX = 0;
    let mouseY = 0;

    // Event listener for mouse move
    document.addEventListener('mousemove', (event) => {
        if (interactionParams.mouseRotation) {
            mouseX = (event.clientX / window.innerWidth) * 2 - 1;
            mouseY = -(event.clientY / window.innerHeight) * 2 + 1;
        }
    });

    // Event listener for keyboard toggle (R and P keys)
    document.addEventListener('keydown', (event) => {
        if (event.key.toLowerCase() === 'r') {
            interactionParams.mouseRotation = !interactionParams.mouseRotation;
            xSpeed.disabled = interactionParams.mouseRotation;
            ySpeed.disabled = interactionParams.mouseRotation;
            zSpeed.disabled = interactionParams.mouseRotation;
            pane.refresh();
        } else if (event.key.toLowerCase() === 'p') {
            togglePane();
        }
    });

    // Animation loop
    function animate() {
        requestAnimationFrame(animate);

        const time = Date.now() * 0.002 * warpParams.warpSpeed; // Adjust the speed of the animation

        const positionAttribute = torus.geometry.getAttribute('position');

        for (let i = 0; i < positionAttribute.count; i++) {
            const x = originalPositions[i * 3];
            const y = originalPositions[i * 3 + 1];
            const z = originalPositions[i * 3 + 2];

            // Calculate the angle and distance from the center
            const angle = Math.atan2(y, x);
            const distance = Math.sqrt(x * x + y * y);

            // Calculate the offset for the vortex effect
            const offsetX = Math.sin(distance * warpParams.warpFrequency + time) * warpParams.warpAmplitude * warpParams.warp;
            const offsetY = Math.cos(distance * warpParams.warpFrequency + time) * warpParams.warpAmplitude * warpParams.warp;
            const offsetZ = Math.sin(distance * warpParams.warpFrequency - time) * warpParams.warpAmplitude * warpParams.warp;

            // Apply the offset to the vertices
            positionAttribute.setXYZ(i, x + offsetX, y + offsetY, z + offsetZ);
        }
        positionAttribute.needsUpdate = true;

        // Update torus rotation based on mouse movement
        if (!interactionParams.mouseRotation) {
            torus.rotation.x += rotationParams.xSpeed * 0.01;
            torus.rotation.y += rotationParams.ySpeed * 0.01;
            torus.rotation.z += rotationParams.zSpeed * 0.01;
        } else {
            torus.rotation.x = mouseY * Math.PI;
            torus.rotation.y = mouseX * Math.PI;
        }

        renderer.render(scene, camera);
    }

    animate();

    // Handle window resize
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
}

// Function to create or recreate the torus
function createTorus() {
    if (torus) {
        // Save current rotation
        cameraRotation.x = torus.rotation.x;
        cameraRotation.y = torus.rotation.y;

        scene.remove(torus);
        torus.geometry.dispose();
        torus.material.dispose();
    }

    const geometry = new THREE.TorusGeometry(shapeParams.outerRadius, shapeParams.innerRadius, shapeParams.radialSegments, shapeParams.tubularSegments);
    originalPositions = Float32Array.from(geometry.getAttribute('position').array);

    const vertexShader = `
        varying vec3 vPosition;
        varying vec3 vColor;
        uniform vec3 innerColor;
        uniform vec3 outerColor;
        void main() {
            vPosition = position;
            float distance = length(position.xy);
            float maxDistance = ${shapeParams.outerRadius}.0;
            float t = distance / maxDistance;
            vColor = mix(innerColor, outerColor, t);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
    `;

    const fragmentShader = `
        varying vec3 vColor;
        void main() {
            gl_FragColor = vec4(vColor, 1.0);
        }
    `;

    let material;
    switch (currentSurfaceType) {
        case SURFACE_OPTIONS.Skin:
        case SURFACE_OPTIONS.Wireframe:
            material = new THREE.ShaderMaterial({
                vertexShader: vertexShader,
                fragmentShader: fragmentShader,
                uniforms: {
                    innerColor: { value: new THREE.Color(colorParams.innerColor) },
                    outerColor: { value: new THREE.Color(colorParams.outerColor) }
                },
                wireframe: currentSurfaceType === SURFACE_OPTIONS.Wireframe
            });
            break;
        case SURFACE_OPTIONS.Points:
            material = new THREE.PointsMaterial({
                size: 0.2,
                vertexColors: true
            });

            const colors = new Float32Array(geometry.getAttribute('position').count * 3);
            for (let i = 0; i < geometry.getAttribute('position').count; i++) {
                const x = originalPositions[i * 3];
                const y = originalPositions[i * 3 + 1];
                const distance = Math.sqrt(x * x + y * y);
                const maxDistance = shapeParams.outerRadius;
                const t = distance / maxDistance;
                const color = new THREE.Color().lerpColors(
                    new THREE.Color(colorParams.innerColor),
                    new THREE.Color(colorParams.outerColor),
                    t
                );
                colors[i * 3] = color.r;
                colors[i * 3 + 1] = color.g;
                colors[i * 3 + 2] = color.b;
            }
            geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
            break;
    }

    torus = currentSurfaceType === SURFACE_OPTIONS.Points 
            ? new THREE.Points(geometry, material) 
            : new THREE.Mesh(geometry, material);
    scene.add(torus);

    // Restore rotation
    torus.rotation.x = cameraRotation.x;
    torus.rotation.y = cameraRotation.y;

    pane.refresh(); // Refresh the pane to ensure surface type is updated
}

// Function to update the material uniforms
function updateMaterial() {
    if (torus) {
        if (currentSurfaceType === SURFACE_OPTIONS.Points) {
            createTorus(); // Recreate torus to update colors for points
        } else if (torus.material.uniforms) {
            torus.material.uniforms.innerColor.value.set(colorParams.innerColor);
            torus.material.uniforms.outerColor.value.set(colorParams.outerColor);
        }
    }
}

init();