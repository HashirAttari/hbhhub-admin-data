# Slide to Unlock

A Pen created on CodePen.io. Original URL: [https://codepen.io/nihao/pen/GBOReQ](https://codepen.io/nihao/pen/GBOReQ).

