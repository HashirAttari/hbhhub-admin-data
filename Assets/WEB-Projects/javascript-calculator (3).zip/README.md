# Javascript Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/tiagovalverde/pen/WENWPa](https://codepen.io/tiagovalverde/pen/WENWPa).

Simulation of a regular calculator in javascript. A freecodecam project