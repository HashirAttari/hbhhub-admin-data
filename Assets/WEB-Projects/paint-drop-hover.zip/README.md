# Paint Drop Hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/MarioD/pen/BXZomr](https://codepen.io/MarioD/pen/BXZomr).

Cross browser paint drop hover effect.