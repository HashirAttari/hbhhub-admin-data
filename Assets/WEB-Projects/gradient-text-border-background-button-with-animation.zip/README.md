# Gradient text border background Button With Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/monkey-company/pen/zZZvRp](https://codepen.io/monkey-company/pen/zZZvRp).

