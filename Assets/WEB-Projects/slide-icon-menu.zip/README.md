# Slide Icon Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/hugo/pen/kxLGqm](https://codepen.io/hugo/pen/kxLGqm).

Haven't made a pen in a while, so here it is