# [PURE CSS] border animation without svg

A Pen created on CodePen.io. Original URL: [https://codepen.io/Rplus/pen/abPLGx](https://codepen.io/Rplus/pen/abPLGx).

single element animation icon~

inspired by:  
http://tympanus.net/Tutorials/BorderAnimationSVG/  
&  
http://mopcon.org/2014/news.php

brower support:

* [animation](http://caniuse.com/#feat=css-animation): IE10+
* [clip](https://developer.mozilla.org/en-US/docs/Web/CSS/clip#Browser_Compatibility): all browser