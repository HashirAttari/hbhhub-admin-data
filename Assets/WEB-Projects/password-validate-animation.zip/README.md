# Password validate animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/milanraring/pen/NWqPMeO](https://codepen.io/milanraring/pen/NWqPMeO).

