# Isometric iPhones

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/oMywGy](https://codepen.io/jkantner/pen/oMywGy).

Look at all those chickens…uh I mean iPhones. I basically turned [this Dribbble shot](https://dribbble.com/shots/4850948-Justalk-Mobile-UI) into a looping scroll animation with screenshots of my own.