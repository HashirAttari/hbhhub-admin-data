# Happy Birthday!

A Pen created on CodePen.io. Original URL: [https://codepen.io/wtaype/pen/NWOObBv](https://codepen.io/wtaype/pen/NWOObBv).

A simple birthday animation made using HTML and CSS for my friend.  Credit to [Eddie Lin @yshlin](https://codepen.io/yshlin/) for the awesome fireworks code.