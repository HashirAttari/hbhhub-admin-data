# CSS Phenakistoscope

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/gOZYBoo](https://codepen.io/amit_sheen/pen/gOZYBoo).

