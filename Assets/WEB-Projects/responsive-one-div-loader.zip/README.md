# Responsive one div loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/gOPyxOp](https://codepen.io/benhatsor/pen/gOPyxOp).

Fully responsive one div loader.