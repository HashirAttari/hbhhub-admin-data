# Trippy SVG filter

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pedro-Ondiviela/pen/dyEoBwr](https://codepen.io/Pedro-Ondiviela/pen/dyEoBwr).

Use the cursor over the image to "trip" it. Moving the cursor over it will change the displacement, the color and the skew, provoking an strange effect on the image.