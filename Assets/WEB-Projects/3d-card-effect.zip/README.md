# 3D Card Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/LYMdapW](https://codepen.io/ykadosh/pen/LYMdapW).

The card is rotated on the x/y axes based on the mouse position on the card.

To make the effect more realistic, I added some shadow and glow effects. 

The glow is done by drawing a radial gradient (from white to transparent) that is mixed with the background using 'overlay' mix blend mode. 

The shadow is done by layering multiple box-shadows and translating them inversely to the mouse position (i.e. when the mouse is on the top left corner, the shadow will be shifted to the bottom right corner)