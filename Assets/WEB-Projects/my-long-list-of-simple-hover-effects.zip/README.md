# My Long List of Simple Hover Effects

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/mjpGvj](https://codepen.io/markmead/pen/mjpGvj).

Need a simple button hover effect for your project? Here's my list of examples.