# CSS Wiggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/sparanoid/pen/kPwvVR](https://codepen.io/sparanoid/pen/kPwvVR).

CSS animation and blur filter experiment. WebKit only for the blur.