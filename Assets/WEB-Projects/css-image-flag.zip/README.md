# CSS image flag

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/mdpwGwW](https://codepen.io/amit_sheen/pen/mdpwGwW).

