# Re: Apple Keyboard in pure CSS. 

A Pen created on CodePen.io. Original URL: [https://codepen.io/januff/pen/NxNLJJ](https://codepen.io/januff/pen/NxNLJJ).

HN commenter [farlington](https://news.ycombinator.com/threads?id=farlington)'s response to the CSS challenge on this [“Apple Keyboard in pure CSS” Hacker News thread] (https://news.ycombinator.com/item?id=2299806).

Found auditing the “Help & Inspiration” citations of Mathew Preziotte's very excellent [Party Mode repo](https://github.com/preziotte/party-mode).