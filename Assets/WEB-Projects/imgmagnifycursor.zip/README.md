# imgmagnify - cursor

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/aqNmpg](https://codepen.io/leenalavanya/pen/aqNmpg).

