var i, imgmagnify = document.getElementsByClassName("img-magnify");
for (i = 0; i < imgmagnify.length; i++) {
  var imgmagnifyw,
    imgmagnifyh,
    imgmagnifym = document.createElement("div"),
    imgmagnifys = imgmagnify[i].getAttribute("data-img-magnify-size") || 100,
    imgmagnifyf = imgmagnify[i].getAttribute("data-img-magnify-zoom") || 1.5,
    imgmagnifyst =
      imgmagnify[i].currentStyle || window.getComputedStyle(imgmagnify[i]);

  imgmagnifym.style =
    "width:" +
    imgmagnifys +
    "px;height:" +
    imgmagnifys +
    "px; border-radius:100%;background-repeat:no-repeat;border:1px solid silver;position:absolute;pointer-events:none;top:-" +
    imgmagnifys +
    "px;left:-" +
    imgmagnifys +
    "px;background-image:url('" +
    imgmagnify[i].src +
    "')";
  imgmagnify[i].onmouseenter = function(a) {
    imgmagnifym.style.display = "block";
    imgmagnifyw =
      this.clientWidth -
      parseInt(imgmagnifyst.paddingLeft) -
      parseInt(imgmagnifyst.paddingRight);
    imgmagnifyh =
      this.clientHeight -
      parseInt(imgmagnifyst.paddingTop) -
      parseInt(imgmagnifyst.paddingBottom);
    imgmagnifym.style.backgroundSize =
      imgmagnifyw * imgmagnifyf + "px " + imgmagnifyh * imgmagnifyf + "px";
  }
  imgmagnify[i].onmouseover = imgmagnify[i].onmousemove = function(event) {
    imgmagnifym.style.top = event.clientY - imgmagnifys / 2 + "px";
    imgmagnifym.style.left = event.clientX - imgmagnifys / 2 + "px";
    var imgmagnifyx =
      (this.offsetLeft +
        this.clientLeft +
        parseInt(imgmagnifyst.paddingLeft) -
        event.clientX -
        ((window.pageXOffset || document.documentElement.scrollLeft) -
          (document.documentElement.clientLeft || 0))) *
        imgmagnifyf +
      imgmagnifys / 2;
    if (imgmagnifyx > 0) {
      imgmagnifyx = 0;
    }
    if (imgmagnifyx < imgmagnifys - imgmagnifyw * imgmagnifyf) {
      imgmagnifyx = imgmagnifys - imgmagnifyw * imgmagnifyf;
    }
    var imgmagnifyy =
      (this.offsetTop +
        this.clientTop +
        parseInt(imgmagnifyst.paddingTop) -
        event.clientY -
        ((window.pageYOffset || document.documentElement.scrollTop) -
          (document.documentElement.clientTop || 0))) *
        imgmagnifyf +
      imgmagnifys / 2;
    if (imgmagnifyy > 0) {imgmagnifyy = 0}
    if (imgmagnifyy < imgmagnifys - imgmagnifyh * imgmagnifyf) {
      imgmagnifyy = imgmagnifys - imgmagnifyh * imgmagnifyf}
    imgmagnifym.style.backgroundPosition =
      imgmagnifyx + "px " + imgmagnifyy + "px"
  }
  imgmagnify[i].onmouseleave = function() {
    imgmagnifym.style.display = "none"
  }
  document.body.appendChild(imgmagnifym)
}