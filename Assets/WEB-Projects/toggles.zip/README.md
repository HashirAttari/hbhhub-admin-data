# Toggles

A Pen created on CodePen.io. Original URL: [https://codepen.io/bennettfeely/pen/DZBajr](https://codepen.io/bennettfeely/pen/DZBajr).

Collection of some fresh, flat toggles. All utilize the "checkbox" hack. See: http://css-tricks.com/the-checkbox-hack/

Which # do you like best?