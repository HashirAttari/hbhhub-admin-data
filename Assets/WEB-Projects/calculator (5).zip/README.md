# Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/mostafazke/pen/oEVdjq](https://codepen.io/mostafazke/pen/oEVdjq).

Calculator project for freeCodeCamp  front-end path v1.1.2