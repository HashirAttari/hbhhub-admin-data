# Build a JavaScript Calculator FreeCodeCamp

A Pen created on CodePen.io. Original URL: [https://codepen.io/andydlindsay/pen/KgJddg](https://codepen.io/andydlindsay/pen/KgJddg).

Part of the FreeCodeCamp curriculum. Build a JavaScript calculator that fulfills the following:
User Story: I can add, subtract, multiply and divide two numbers.
User Story: I can clear the input field with a clear button.
User Story: I can keep chaining mathematical operations together until I hit the equal button, and the calculator will tell me the correct output.