# Claymorphic heart 

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/VwMVQEx](https://codepen.io/chrisgannon/pen/VwMVQEx).

