# Neon City (with ambient sound)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thekenneth/pen/boGGba](https://codepen.io/thekenneth/pen/boGGba).

Neon sign, probably placed in a dark and damp alleyway.