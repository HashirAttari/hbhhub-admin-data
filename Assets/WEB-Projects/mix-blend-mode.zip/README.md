# Mix-blend-mode

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/vQaWrv](https://codepen.io/yuanchuan/pen/vQaWrv).

CSS Challenge: https://twitter.com/yuanchuan23/status/1066555792122241024