$(document).ready(function () {
  // ***************** for spider *****************
  var check = document.getElementById("demo").innerHTML;

  var one = check.split(" ").length;
  if (one > 1) {
    var test = check.split(" ").join('<span class="expand-effect"></span>');
    document.getElementById("demo").innerHTML = test;
    $(".more").toggleClass("more-text");
  } else {
    $(".more").toggleClass("less-text");
    var target = Math.round(check.length / 2);
    var set = check.split("");
    set.splice(target, 0, '<span class="expand-effect"></span>');
    document.getElementById("demo").innerHTML = set.join("");
    console.log(set.join(""));
  }

  // ***************** for man *****************
  var word_two = document.getElementById("effect_two").innerHTML;

  var two = word_two.split(" ").length;
  if (two > 1) {
    var update_word_two = word_two
      .split(" ")
      .join('<span class="expand-effect"></span>');
    document.getElementById("effect_two").innerHTML = update_word_two;
    $(".more-two").toggleClass("more-text");
  } else {
    $(".more-two").toggleClass("less-text");
    var target_two = Math.round(word_two.length / 2);
    var set_two = word_two.split("");
    set_two.splice(target_two, 0, '<span class="expand-effect"></span>');
    document.getElementById("effect_two").innerHTML = set_two.join("");
    console.log(set_two.join(""));
  }

  // ***************** for moon *****************
  var word_three = document.getElementById("effect_three").innerHTML;

  var three = word_three.split(" ").length;
  if (three > 1) {
    var update_word_three = word_three
      .split(" ")
      .join('<span class="expand-effect"></span>');
    document.getElementById("effect_three").innerHTML = update_word_three;
    $(".more-three").toggleClass("more-text");
  } else {
    $(".more-three").toggleClass("less-text");
    var target_three = Math.round(word_three.length / 2);
    var set_three = word_three.split("");
    set_three.splice(target_three, 0, '<span class="expand-effect"></span>');
    document.getElementById("effect_three").innerHTML = set_three.join("");
    console.log(set_three.join(""));
  }

  // ***************** for moon *****************
  var word_four = document.getElementById("effect_four").innerHTML;

  var four = word_four.split(" ").length;
  if (four > 1) {
    var update_word_four = word_four
      .split(" ")
      .join('<span class="expand-effect"></span>');
    document.getElementById("effect_four").innerHTML = update_word_four;
    $(".more-four").toggleClass("more-text");
  } else {
    $(".more-four").toggleClass("less-text");
    var target_four = Math.round(word_four.length / 2);
    var set_four = word_four.split("");
    set_four.splice(target_four, 0, '<span class="expand-effect"></span>');
    document.getElementById("effect_four").innerHTML = set_four.join("");
    console.log(set_four.join(""));
  }
});