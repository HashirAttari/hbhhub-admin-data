# BS5 FullCalendar

A Pen created on CodePen.io. Original URL: [https://codepen.io/mikmok25/pen/BaqygYX](https://codepen.io/mikmok25/pen/BaqygYX).

This is a calendar component that is created using FullCalendar & Bootstrap 5 library it can dynamically add, edit/update, delete events. it also saves the events on your browser's local storage, so the events are persistent.

Usage: 

There are few ways to add events on this calendar component.
- Using the add event button assign an event title, start date, end date,
- Or you can select one/multiple  calendar dates and press add event button.
- To select multiple events drag the mouse from your desired dates.
- Right click the events and context menu will pop-up in order to update or delete event