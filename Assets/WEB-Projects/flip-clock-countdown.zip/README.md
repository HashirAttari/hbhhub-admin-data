# Flip Clock & Countdown

A Pen created on CodePen.io. Original URL: [https://codepen.io/shshaw/pen/vKzoLL](https://codepen.io/shshaw/pen/vKzoLL).

