# WebGL Eye Pattern

A Pen created on CodePen.io. Original URL: [https://codepen.io/ksenia-k/pen/poYZpyQ](https://codepen.io/ksenia-k/pen/poYZpyQ).

