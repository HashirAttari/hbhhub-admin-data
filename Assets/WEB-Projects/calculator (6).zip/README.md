# Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/andymcfee/pen/kMwOdj](https://codepen.io/andymcfee/pen/kMwOdj).

An HTML/CSS/JS calculator.  Featuring SCSS and CoffeeScript.

This was mostly just an exercise for me to start learning CoffeeScript.  Any feedback on ways to improve would be greatly appreciated.