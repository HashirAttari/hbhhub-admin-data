# DrawSVG loop

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/qBPoQpj](https://codepen.io/chrisgannon/pen/qBPoQpj).

Finally DrawSVG can do proper loop by animating beyond 100% - hooray!