gsap.set('svg', {
	visibility: 'visible'
})

let colorArray = ['#D49C3D','#D14B3D','#CF52EB','#44A3F7','#5ACB3C','#DEBF40'];

let tl = gsap.timeline({});
tl.set('rect', {
	stroke: gsap.utils.wrap(colorArray)
})
.fromTo('rect', {
	drawSVG:'0% 16.6%'
}, {
	drawSVG:'100% 116.6%',
	ease: 'linear',
	duration: 2,
	stagger: {
		each: 0.326,
		repeat: -1
	}
	
}).seek(100)