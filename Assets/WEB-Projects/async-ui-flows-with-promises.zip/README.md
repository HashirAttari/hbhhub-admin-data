# Async UI flows with promises

A Pen created on CodePen.io. Original URL: [https://codepen.io/pavlovsk/pen/poZwXmP](https://codepen.io/pavlovsk/pen/poZwXmP).

A fully keyboard accessible flow of screens. They are managed with pure JS promises and animated with pure CSS.

The views are promises themselves that I chain together.