# Custom select

A Pen created on CodePen.io. Original URL: [https://codepen.io/suez/pen/KKxyEa](https://codepen.io/suez/pen/KKxyEa).

