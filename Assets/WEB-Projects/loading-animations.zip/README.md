# Loading Animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/filipekiss/pen/gOqodE](https://codepen.io/filipekiss/pen/gOqodE).

Replicated the loading animations from http://jxnblk.github.io/loading/ made only with CSS/HTML instead of SVG. :)

I also added a few more animations to it.