# Windows XP

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/ZENaYma](https://codepen.io/atzedent/pen/ZENaYma).

This shader attempts to recreate the iconic Windows XP logo. 