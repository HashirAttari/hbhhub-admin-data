# Scroll-Triggered Animations (jQuery)

A Pen created on CodePen.io. Original URL: [https://codepen.io/bramus/pen/AzmevE](https://codepen.io/bramus/pen/AzmevE).

Trigger CSS animations on scroll. Detailed explanation can be found at http://www.bram.us/2013/11/20/scroll-animations/