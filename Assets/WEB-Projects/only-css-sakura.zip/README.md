# Only CSS: Sakura 

A Pen created on CodePen.io. Original URL: [https://codepen.io/YusukeNakaya/pen/BaoNaJY](https://codepen.io/YusukeNakaya/pen/BaoNaJY).

Making (YouTube Live)
https://www.youtube.com/watch?v=bWIGG8chcj8