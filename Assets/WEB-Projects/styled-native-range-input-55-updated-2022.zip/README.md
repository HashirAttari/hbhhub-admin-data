# Styled native range input #55 (updated 2022)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/qEYeyY](https://codepen.io/thebabydino/pen/qEYeyY).

**March 2022 update**

Major changes:

* got rid of Compass and Modernizr dependencies, neither of which was needed anyway

* ditched the 1 element restriction in order to get a better, cross-browser and more accessible result

* now using `output` elements for the sliders that have tooltips instead of the very hacky method of putting the value in the `content` of a pseudo on the thumb (only ever worked in Chrome and has been broken there too since 2015 anyway)

* since I now know how to code a multi thumb slider (see my [article](https://css-tricks.com/multi-thumb-sliders-particular-two-thumb-case/) on CSS-Tricks for details), I added that feature to match the design too (the original 2015 version only had a single handle for all sliders, even though the original design showed two handles for the second one)

* now using a `datalist` for the ruler with values instead of the very hacky method of adding the number values with spaces between them in the `content` of a pseudo on the track (a trick that only ever worked in Chrome and [even there the numbers could be badly aligned](https://twitter.com/owzim/status/570854690008801281) depending on the system/ browser; and it stopped working altogether there too since 2015 anyway); as a result of this plus adding configuration CSS variables, the HTML has gone from about 140 bytes to a little over 1.5kB, but this is more than compensated by the now much simpler and lighter CSS and JS

* ditched `absolute` positioning in favour of using a `grid` layout now; the look of it adapts nicely for various viewport sizes

* used smarter gradient techniques for the slider thumb and fill/ progress/ range highlight to better reproduce the design; I avoided the CSS-only route for the single handle sliders in Firefox via `-moz-range-progress` because the way that works would make implementing this design in particular incredibly hacky (and the result probably won't look as good as with the teeny tiny little bit of JS that I'm currently using)

* cleaned up the CSS and made it more maintainable by using CSS variables and the DRY switching technique, explained in this two part article I wrote for CSS-Tricks: [part one](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) and [part two](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/); overall, this has meant shrinking the compiled CSS from over 12kB to a little over 6.5kB

* got rid of the convoluted JS that was adding the fill/ progress/ range highlight and switched to a simpler method based on CSS variables (thus reduced the JS by more than 85% of what it was before, from close to 1.3kB to under 180 bytes, in spite of also spicing things up with some extra functionality)

* made it degrade gracefully in the no JS case (the wrapper's `::after` pseudo that's used to create the range highlights and the tooltips get `display: none` in the no JS case since the values they depend on don't get updated anyway)

* added `:focus-within`/ `:focus`/ `:hover` styles

* ensured it now behaves consistently in both Chromium browsers and Firefox; Safari ~~still has [gradient issues](https://twitter.com/anatudor/status/1501106249290690563) however and~~ doesn't want to display the `option` elements at all, though technically, [`datalist` is supported there](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/datalist#browser_compatibility) - [Safari bug](https://bugs.webkit.org/show_bug.cgi?id=237611)

* not providing free IE/ pre-Chromium support anymore

Expected result/ result in Chromium/ Firefox:

![screenshot with all sliders in focus](https://assets.codepen.io/2017/internal/screenshots/pens/qEYeyY.custom.png?version=1646763998)

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 36, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need any JS, while Firefox and Chrome/ Opera rely on it a bit for updating the fill of the range track. Chrome/ Opera also have a bit of an extra, the numbers on the ruler and the tooltip on the second slider. This is done using `/deep/` - careful, experimental stuff, only supported in Blink, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). I can also get a tooltip in IE via [`::-ms-tooltip`](https://msdn.microsoft.com/en-us/library/windows/apps/hh465805.aspx), but I cannot style that asshole. Fallback for no JS: display the same background for the entire track, both before and after the thumb. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. 

[Original sliders design by Victor Sosea on Dribbble](https://dribbble.com/shots/259211-Sliders).

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 