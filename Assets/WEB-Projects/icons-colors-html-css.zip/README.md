# Icons Colors HTML/Css

A Pen created on CodePen.io. Original URL: [https://codepen.io/wellingtonfialho/pen/XWWWzQ](https://codepen.io/wellingtonfialho/pen/XWWWzQ).

* For modern browsers *

" I will adding more icons as time"