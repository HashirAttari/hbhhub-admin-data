# Hex2RGB | An Animated Guide to Hex Codes

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/byLzQG](https://codepen.io/joshonweb/pen/byLzQG).

This is a animated guide to what hex codes are, and how to convert them to RGB.  Knowing this can make it easier to adjust, or understand your colors when all you have is the hex code. There a some interactivity and animations that make this guide semi-engaging.