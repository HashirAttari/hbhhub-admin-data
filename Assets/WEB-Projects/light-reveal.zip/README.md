# Light Reveal

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/BaWYdzP](https://codepen.io/kitjenson/pen/BaWYdzP).

