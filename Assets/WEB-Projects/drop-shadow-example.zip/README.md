# drop-shadow example

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/ZEWGzKp](https://codepen.io/yuanchuan/pen/ZEWGzKp).

Example for https://yuanchuan.dev/multiple-drop-shadows