# Button ripple effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/RwrzxyX](https://codepen.io/benhatsor/pen/RwrzxyX).

Button ripple effect on click.