# On / Off Switch 💡

A Pen created on CodePen.io. Original URL: [https://codepen.io/visnuravichandran/pen/GRZQVdP](https://codepen.io/visnuravichandran/pen/GRZQVdP).

Designed an On / Off Switch with the usage of Sun ☀️and Moon 🌙 as an toggle 

Animation is done using GSAP !