# Animated image border

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/ExdGyvM](https://codepen.io/cbolson/pen/ExdGyvM).

