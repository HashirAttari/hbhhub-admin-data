let canvas = document.getElementById('mycanvas');
let ctx = canvas.getContext('2d');

let w = window.innerWidth;
let h = window.innerHeight;
canvas.width = w;
canvas.height = h;

text = 'HOORAY!';

let props = {
  x: w / 2,
  y: h / 2,
  scale: 0.5
};

let tl = new gsap.timeline({
  onUpdate: draw,
  ease: 'quad.out',
  onComplete: draw,
  onCompleteParams: [true]
});

let duration = 7;

tl.to(props, {
    scale: 1, 
    x: (w / 2) - 200,
    duration: duration,
    ease: 'quad.in'
}, 0);

tl.to(props, {
    y: (h / 2) - 250,
    duration: duration,
    ease: 'none'
}, 0);

let _x = w / 2;
let _y = h / 2;

function draw(white = false) {
  
  let x = 0;
  let y = 100;
    
  ctx.save();
  
  ctx.translate(props.x, props.y);
  ctx.translate(-100, 0);
  ctx.font = 'bolder 120px Arial';

  let scale = props.scale;
  ctx.scale(scale, scale);
  for (let i = 0; i < text.length; i++) {
      ctx.save();
    
      let hue = Math.floor((i / text.length) * 360);
      ctx.fillStyle = `hsl(${hue}, 100%, 100%)`;
      ctx.strokeStyle = `hsl(${hue}, 100%, 50%)`;
      ctx.lineWidth = 10;
    
      let char = text[i];
      ctx.strokeText(char, x, y);
      ctx.fillText(char, x, y);
      ctx.fill();
      x += 100;
    
      ctx.restore();
  }
  
  ctx.restore();
}

window.addEventListener('click', () => {
  ctx.clearRect(0, 0, w, h);
  tl.time(0);
  tl.play();
})