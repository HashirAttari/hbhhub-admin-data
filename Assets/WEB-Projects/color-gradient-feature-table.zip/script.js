const $main = document.querySelector('main');
const $c = document.querySelectorAll("input");
const setColors = () => {
  $main.style.setProperty('--table-bg', $c[0].value);
  $main.style.setProperty('--table-color-1', $c[1].value);
  $main.style.setProperty('--table-color-2', $c[2].value);
  $main.style.setProperty('--table-border', $c[3].value);
}
$c.forEach(($el) => {
  $el.addEventListener("input", (e) => {
    setColors();
  });
});