# Color Gradient Feature Table

A Pen created on CodePen.io. Original URL: [https://codepen.io/simeydotme/pen/KKYpPQx](https://codepen.io/simeydotme/pen/KKYpPQx).

