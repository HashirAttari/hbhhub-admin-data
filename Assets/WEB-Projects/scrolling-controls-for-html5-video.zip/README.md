# Scrolling controls for HTML5 video

A Pen created on CodePen.io. Original URL: [https://codepen.io/waldo/pen/QpxjXE](https://codepen.io/waldo/pen/QpxjXE).



Forked from [Ollie](http://codepen.io/ollieRogers/)'s Pen [Scrolling controls for HTML5 video](http://codepen.io/ollieRogers/pen/lfeLc/).