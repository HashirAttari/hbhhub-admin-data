# Empire and Puzzles Emoji List

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/eaGyXR](https://codepen.io/run-time/pen/eaGyXR).

