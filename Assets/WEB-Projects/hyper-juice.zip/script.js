/* 

  Hyper Juice - XemsDoom
  
  This is a little project I've been working on for some couple of hours.
  I really like to just do random things with CSS and kinda miss use it
  as a canvas. This little thingy shows a lab where a database communicates
  with some servers and transmits juice through Ethernet cables(exactly).
  
  I know that the liquid which drops into the glasses might be off, it is really
  just a matter of how long your browser takes to draw the scene, that effects
  at the end how off the liquid will spill onto the glass. It's working fine
  for me in Chrome, it goes directly into the glass but I have some issues
  with Lame-Explorer but it's totally fine. If it happens that the liquid is off,
  just reload the page and it should be better.
  
  The treadmill with the glasses doesn't generate any glasses of course(no JS mate), 
  it's just that the animation timing is so exact that it looks like there are infinite 
  glasses. If you look closely to the right side of the treadmill, where the glasses 
  come in, you can see that at some time it jumps a little, that's where the animation 
  begins again.

*/