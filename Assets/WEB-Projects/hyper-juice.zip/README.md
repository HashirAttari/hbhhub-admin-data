# Hyper Juice

A Pen created on CodePen.io. Original URL: [https://codepen.io/XemsDoom/pen/DBmJXb](https://codepen.io/XemsDoom/pen/DBmJXb).

People say you can't press juice through Ethernet cables. Well, I actually accomplished this by running 5 NoSQL DBs in a message-passing, actor-system, fault tolerant, highly concurrent, highly available lab system, which presses 0.3ml of Hyper Juice into cold glasses.

With the three lemon sorts of Mars we discovered last century, we are ready to provide this special juice to humans and make them feel just more reactive.