# Simple 1 elem pure CSS card patterns

A Pen created on CodePen.io. Original URL: [https://codepen.io/nzbin/pen/yLZbebj](https://codepen.io/nzbin/pen/yLZbebj).

[See me code this](https://youtu.be/wPIQvB1nFv0) in under 9 minutes.

---

If the work I've been putting out for almost 9 years (I started coming up with clever solutions to questions on Stack Overflow in the spring of 2012) has helped you in any way or you just like it and you wish me to be able to continue putting out stuff, please consider one of the following:

* being a cool cat 😼🎩 and becoming a patron on Patreon

[![become a patron button](https://c5.patreon.com/external/logo/become_a_patron_button.png)](https://www.patreon.com/anatudor)

* getting me something off my Amazon WishList 

[🎁 🇺🇸](https://www.amazon.com/gp/registry/wishlist/2Y3C4722GXH0I/) / [🎁 🇬🇧](https://www.amazon.co.uk/gp/registry/wishlist/2I25W7U0KADSR/)

* or at least sharing this to show the rest of the world what can be done with CSS these days

Thank you!

---

[Original idea](https://codepen.io/CodeMeNatalie/pen/OJLYbrr).

Palettes:

* [Mostly Greige](https://www.colourlovers.com/palette/4599651/Mostly_Greige)
* [Red-Mono-01](https://www.colourlovers.com/palette/3665879/Red-Mono-01)
* [Walking Away](https://www.colourlovers.com/palette/623761/Walking_Away)
* [Winter's sky](https://www.colourlovers.com/palette/29221/winters_sky)
* [One and only](https://www.colourlovers.com/palette/9716/one_and_only)
* [Mostly conservative](https://www.colourlovers.com/palette/95117/Mostly_conservative)
* [HoneyGlow](https://www.colourlovers.com/palette/4190/HoneyGlow)
* [Top Colours + One](https://www.colourlovers.com/palette/10583/Top_Colours_One)
* [Mono Gold](https://www.colourlovers.com/palette/3783420/Mono_Gold)
* [Topaz](https://www.colourlovers.com/palette/9649/Topaz)
* [Mono Green](https://www.colourlovers.com/palette/3630649/Mono_Green_Hrtlns)
* [Green Feathers](https://www.colourlovers.com/palette/2601103/Green_Feathers)
* [Forest Gump](https://www.colourlovers.com/palette/30482/forrest_gump)
* [The frog](https://www.colourlovers.com/palette/30607/the_frog)
* [Dream magnet](https://www.colourlovers.com/palette/482774/dream_magnet)
* [Colours](https://www.colourlovers.com/palette/1221957/colours-most_follows)
* [Angelic fabric](https://www.colourlovers.com/palette/11082/angelic_fabric)
* [Have You Here Again](https://www.colourlovers.com/palette/10900/Have_You_Here_Again)
* [Lowrise stretch](https://www.colourlovers.com/palette/10297/lowrise_stretch)
* [Midnight Fog 2](https://www.colourlovers.com/palette/3199333/Midnight_Fog_2)
* [Mono Purple/ Gatos](https://www.colourlovers.com/palette/3747786/Mono_Purple_Gatos)
* [Mono Purple](https://www.colourlovers.com/palette/2832492/Mono_Purple)
* [Birthday Massacre](https://www.colourlovers.com/palette/550273/Birthday_Massacre)
* [Love to Dance](https://www.colourlovers.com/palette/8840/Love_To_Dance)
* [Mono Rose/ Gatos](https://www.colourlovers.com/palette/3747789/Mono_Rose_Gatos)
* [Red mono](https://www.colourlovers.com/palette/1294888/red_mono)
* [La cosa mas bella](https://www.colourlovers.com/palette/10945/la_cosa_mas_bella)

---

Dedicated to the memory of someone dear who passed away in January 2019. Missing you every day.