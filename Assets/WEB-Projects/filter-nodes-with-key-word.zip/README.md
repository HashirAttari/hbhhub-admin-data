# Filter nodes with key word

A Pen created on CodePen.io. Original URL: [https://codepen.io/dabeng/pen/xyMGrR](https://codepen.io/dabeng/pen/xyMGrR).

