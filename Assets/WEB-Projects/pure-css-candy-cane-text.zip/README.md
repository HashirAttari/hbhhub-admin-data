# Pure CSS Candy Cane Text

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/LpwOpm](https://codepen.io/giana/pen/LpwOpm).

Inspired by:  
http://pixaroma.com/free-candy-cane-text-effect/

Bevel effect made by stacking multiple text shadows under transparent text. Works only on white background because of the way blend modes are used.

Firefox + Webkit only. Not recommended for production due to poor performance and limited browser support.