# CSS box shadow particles v6

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/mPdXEj](https://codepen.io/giana/pen/mPdXEj).

Same as <a href="http://codepen.io/giana/pen/JGdbje">the first version</a>, only with different numbers.