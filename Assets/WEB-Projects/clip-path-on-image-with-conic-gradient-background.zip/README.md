# clip-path on image with conic-gradient background

A Pen created on CodePen.io. Original URL: [https://codepen.io/BlogFire/pen/OJoBeXJ](https://codepen.io/BlogFire/pen/OJoBeXJ).

