# Responsive Emoji Toggles #CodePenChallenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/GeorgePark/pen/xJREOG](https://codepen.io/GeorgePark/pen/xJREOG).

This pen shows how the CSS checkbox hack can be used to create responsive emoji toggles #CodePenChallenge