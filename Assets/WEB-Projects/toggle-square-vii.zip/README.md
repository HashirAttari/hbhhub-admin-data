# Toggle Square (VII)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/eYoZmKz](https://codepen.io/alvaromontoro/pen/eYoZmKz).

Components inspired by Rafael Gonzalez's toggles: https://codepen.io/rgg/pen/waEYye