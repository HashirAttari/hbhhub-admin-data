# javascript/jQuery calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/pcostanz/pen/DyjvJQ](https://codepen.io/pcostanz/pen/DyjvJQ).

I'm building a calculator using JavaScript and jQuery,  it's not finished yet but I've made a lot of progress.   If you're having trouble getting this to work, try opening it in 'full' mode: http://codepen.io/pcostanz/full/fimCu