# Gif Text Mask

A Pen created on CodePen.io. Original URL: [https://codepen.io/RAFA3L/pen/ExEbNWd](https://codepen.io/RAFA3L/pen/ExEbNWd).

