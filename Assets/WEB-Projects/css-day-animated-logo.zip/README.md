# CSS Day Animated Logo

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/xxQxpNP](https://codepen.io/havardob/pen/xxQxpNP).

An animated version of the conference CSSDay's logo