# iPhone (interactive)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Androplis/pen/oPgzXB](https://codepen.io/Androplis/pen/oPgzXB).

This is just a fun idea I had. Try to guess the password.
Hint: You would be a 'fool' if you can't guess the password!