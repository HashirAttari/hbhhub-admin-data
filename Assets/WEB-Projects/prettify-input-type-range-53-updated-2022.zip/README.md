# prettify `<input type=range>` #53 (updated 2022)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/yyjZYz](https://codepen.io/thebabydino/pen/yyjZYz).

**March 2022 update**

Major changes:

* got rid of Compass and Modernizr dependencies, neither of which was needed anyway

* now generating the HTML in a logical manner  from a Pug data array; since it now has some config CSS vars in style attributes, the generated HTML has gone up from 1.1kB to 3.5kB, but this is more than compensated by how much the CSS and JS have now shrunk

* ditched `absolute` positioning in favour of using a truly responsive `grid` layout now

* used smarter gradient techniques for the slider thumbs to better reproduce the design

* cleaned up the CSS and made it more maintainable by using CSS variables and the DRY switching technique, explained in this two part article I wrote for CSS-Tricks: [part one](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) and [part two](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/); this has meant reducing the SCSS by more than 20% from over 6.7kB to 5.3kB and the compiled CSS by almost 60% (to less than half of what it was before) from almost 14.8kB to barely over 6.1kB

* got rid of the convoluted JS that was adding the fill/ progress/ range highlight for the WebKit browsers and Firefox and switched to a simpler method based on CSS variables; thus reduced the JS by over 90% (to less than a tenth of what it was before) from over 1.5kB to just 140 bytes, in spite of also spicing things up with some extra functionality

* made it degrade gracefully in the no JS case (the track `background` that's used to create the range highlights gets `background-size` zeroed in the no JS case since the values they depend on don't get updated anyway)

* would have loved to make the highlight fully functional without JS in Firefox, but the `-moz-range-progress` element behaves in a weird way that makes it just not suitable to use when the track has rounded corners

* added `:focus`/ `:hover` styles

* ensured it now behaves consistently in both WebKit browsers and Firefox

* not providing free IE/ pre-Chromium support anymore

The result should now look like below:

![screenshot](https://assets.codepen.io/2017/internal/screenshots/pens/MYGBWZ.custom.png?version=1646328136)

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. No JS needed for the fourth slider or for the first three in IE. Fallback for no JS: display the same background for the entire track, both before and after the thumb. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found.

Original design from Shutterstock: [Blue Slider Set, ID 206589100](https://www.shutterstock.com/image-vector/set-various-slider-bar-control-panels-206589100).

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 