# Glowy loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/meoeqM](https://codepen.io/giana/pen/meoeqM).

I'm on a Sass-loop rainbow roll.

<a href="http://codepen.io/giana/pen/NGJNev">Fork with different values</a>