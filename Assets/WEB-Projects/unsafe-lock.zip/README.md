# Unsafe Lock

A Pen created on CodePen.io. Original URL: [https://codepen.io/bartaxyz/pen/DWEKVm](https://codepen.io/bartaxyz/pen/DWEKVm).

Working remake of this http://dribbble.com/shots/946731-Unsafe-Lock-Rebound