# My Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/tfeditm/pen/vZWmwv](https://codepen.io/tfeditm/pen/vZWmwv).

Responsive calculator in vintage style.