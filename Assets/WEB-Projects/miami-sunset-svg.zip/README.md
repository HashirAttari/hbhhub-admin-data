# Miami Sunset SVG

A Pen created on CodePen.io. Original URL: [https://codepen.io/leimapapa/pen/rNbPZjQ](https://codepen.io/leimapapa/pen/rNbPZjQ).

Trying to SVG-ize LoFi's pen: https://codepen.io/loficodes/pen/NWmLZeB