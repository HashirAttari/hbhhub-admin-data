# CSS MacBook Pro

A Pen created on CodePen.io. Original URL: [https://codepen.io/dhanishgajjar/pen/eERdyr](https://codepen.io/dhanishgajjar/pen/eERdyr).

Another CSS Device Experiment. It's not perfect :)