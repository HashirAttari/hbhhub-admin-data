# Clock Creator

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/xxyQJL](https://codepen.io/leenalavanya/pen/xxyQJL).

<!--- A simple Widget Creator for those interested in making a clock widget for their site --->