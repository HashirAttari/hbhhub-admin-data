const loader = document.querySelector('.loader');

window.addEventListener('scroll', function(e) {
  loader.style.strokeDashoffset = window.scrollY;
  if (window.scrollY == 0) {
    loader.style.stroke = "lightgreen";
  }
  else {
    loader.style.stroke = "white";
  }
})

window.scrollTo(0, 60);