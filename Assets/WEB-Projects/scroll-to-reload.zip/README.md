# Scroll to reload

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/gOPdVxq](https://codepen.io/benhatsor/pen/gOPdVxq).

