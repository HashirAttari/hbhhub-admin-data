# Magnifying glass - CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pedro-Ondiviela/pen/VwRjwgg](https://codepen.io/Pedro-Ondiviela/pen/VwRjwgg).

Simple magnifying glass effect done with svg backgrounds and a couple of CSS filters.