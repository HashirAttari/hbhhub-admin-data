# Lock/Unlock with Voice (Chrome Only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/GeorgePark/pen/GBYqZv](https://codepen.io/GeorgePark/pen/GBYqZv).

This pen shows how the speech recognition API can be used to retrieve a spoken word from a user and perform an action (e.g. locking/unlocking a padlock) if that word is valid (chrome only).

Padlock design inspired by [Chris Cacioppe on Dribbble](https://dribbble.com/shots/4009114-Unlock-Animation)