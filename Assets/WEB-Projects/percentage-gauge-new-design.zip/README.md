# Percentage Gauge New Design

A Pen created on CodePen.io. Original URL: [https://codepen.io/kh-mamun/pen/VqrbQz](https://codepen.io/kh-mamun/pen/VqrbQz).

