# Device loading (inspired by a pen by Jon Kantner)

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/yLWbyjZ](https://codepen.io/cbolson/pen/yLWbyjZ).

Inspired by this codepend by Jon Kantner
https://codepen.io/jkantner/pen/mdgejxq?editors=0100

I challenged myself to create something similar with a single element.