# Mobile menu, CSS only

A Pen created on CodePen.io. Original URL: [https://codepen.io/KikePuma/pen/QWEQedd](https://codepen.io/KikePuma/pen/QWEQedd).

Having fun and learning some CSS3 animations and transitions.

Inspired by this dribbble by The Purple Bunny:
https://dribbble.com/shots/1677163-Menu