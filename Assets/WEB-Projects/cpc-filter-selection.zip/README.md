# [cpc] Filter selection

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/pomoGKE](https://codepen.io/cbolson/pen/pomoGKE).

A tool to adjust several filter options with a preview of each filter and the combination.
Random image selection, code copy and reset buttons.