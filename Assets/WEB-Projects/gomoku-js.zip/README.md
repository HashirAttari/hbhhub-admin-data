# Gomoku JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/YwvPwO](https://codepen.io/mselmany/pen/YwvPwO).

Gomoku 5 in a row game.

Forked from [Anton Mudrenok](http://codepen.io/mudrenok/)'s Pen [Gomoku JS](http://codepen.io/mudrenok/pen/gpMXgg/).