# Linus Tech Tips Intro (CSS + Little SVG)

A Pen created on CodePen.io. Original URL: [https://codepen.io/mallendeo/pen/bYERav](https://codepen.io/mallendeo/pen/bYERav).

[Linus Tech Tips](https://www.youtube.com/user/LinusTechTips) intro animation recreated with (almost) pure HTML and CSS (mouse and cat logo shapes are SVG).

Well, this took me way longer than I care to admit. First, when I started, I tried to make the animation simpler using CSS variables, but they don't react to `@keyframes` changes in Firefox and Safari.
I had no way but to repeat the previous animation state on the next keyframe declaration, so more code :/

Also, Safari doesn't syncs colors when using `currentColor`. I could update it to use background instead and make an extra animation for inner elements but I think it's fine for now.

Haven't tested on Edge yet.

I did this for fun and because LTT is another of my favorite tech channels along with MKBHD (which I also did recreate his intro [here](https://codepen.io/mallendeo/pen/dvbQQx) ).

p.s. Linus, if you read this, you can use this on your next video, I guess people won't notice the difference.