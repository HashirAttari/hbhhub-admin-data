# Spring pagination

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/bGdVdwx](https://codepen.io/ainalem/pen/bGdVdwx).

A springy pagination indicator. 