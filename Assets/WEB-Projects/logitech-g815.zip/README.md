# Logitech G815

A Pen created on CodePen.io. Original URL: [https://codepen.io/staniel-petrov/pen/yLRMKOe](https://codepen.io/staniel-petrov/pen/yLRMKOe).

A fun project with HTML, CSS and Vanilla JS.

The keyboard almost fully imitates the behavior of the real thing and you can try every button on your keyboard or click the buttons with your mouse to see how they behave.