# Tetris Preloader

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/jOorBXy](https://codepen.io/jkantner/pen/jOorBXy).

A preloader as an endless game of Tetris!