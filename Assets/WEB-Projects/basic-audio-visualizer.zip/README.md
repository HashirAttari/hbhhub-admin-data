# Basic audio visualizer

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/PobBqjg](https://codepen.io/franksLaboratory/pen/PobBqjg).

