# Toggle Switch - Wooden Texture (II)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/NWJgdzv](https://codepen.io/alvaromontoro/pen/NWJgdzv).

A toggle switch created using a checkbox as a base. A single HTML element, no JS, no external images or SVG, just HTML and CSS. The wooden texture looks a bit fake though :-/