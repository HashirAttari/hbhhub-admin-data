# Show/Hide Password | @keyframers 1.19.2

A Pen created on CodePen.io. Original URL: [https://codepen.io/team/keyframers/pen/YOWyOJ](https://codepen.io/team/keyframers/pen/YOWyOJ).

_Built with [Splitting](https://splitting.js.org)_

David Khourshid and Stephen Shaw rapid-fire build several text animations with Splitting.js ( splitting.js.org ) and CSS!

* ⏰ Streamed live on August 27, 2018 at https://twitch.tv/keyframers
* 📺 Video: https://youtu.be/Yix-rJKLt98
* 💻 CodePen Collection: https://cdpn.io/collection/ANjzZP/

Animation 4: Show/hide password (Splitting.html)
💡 https://dribbble.com/shots/4636684-Show-hide-password
💻 https://cdpn.io/pen/YOWyOJ/

Additional Resources:

* Splitting.js https://splitting.js.org

Like what we're doing? There are many ways you can support @keyframers so we can keep live coding awesome animations!

* Like & subscribe on YouTube at https://youtube.com/keyframers
* Follow & tweet us at https://twitter.com/keyframers.
* Join the live streams & subscribe on Twitch http://twitch.tv/keyframers 
* Support us on Patreon at https://patreon.com/keyframers 

Topics covered:

* CSS Variables
* Splitting
* Staggering
* Nested Transforms
* Text Animation
* Character Animation