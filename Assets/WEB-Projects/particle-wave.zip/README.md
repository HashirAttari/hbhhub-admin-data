# Particle Wave

A Pen created on CodePen.io. Original URL: [https://codepen.io/nzbin/pen/dyavLvP](https://codepen.io/nzbin/pen/dyavLvP).

A canvas animation. It creates a number of "particles" which travel along a sine wave. Each particle has some randomness to its parameters to give it a more natural look overall. Tweak the constants near the top!