# Tab Bar Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/GRRNoqL](https://codepen.io/ricardoolivaalonso/pen/GRRNoqL).

