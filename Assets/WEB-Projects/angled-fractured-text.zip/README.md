# Angled Fractured Text

A Pen created on CodePen.io. Original URL: [https://codepen.io/mandymichael/pen/dWWqjN](https://codepen.io/mandymichael/pen/dWWqjN).

Creating a fractured text look with just css an extension of the standard effect (http://codepen.io/mandymichael/pen/pRXQZO) that uses clip path for the angle.

Check out some other cool text effects: http://codepen.io/collection/DamKJW/