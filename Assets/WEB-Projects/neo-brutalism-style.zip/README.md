# Neo-Brutalism Style

A Pen created on CodePen.io. Original URL: [https://codepen.io/grimfand/pen/BaMYLmO](https://codepen.io/grimfand/pen/BaMYLmO).

