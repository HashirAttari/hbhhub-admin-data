# Robot Arm

A Pen created on CodePen.io. Original URL: [https://codepen.io/mlho/pen/YRPGjZ](https://codepen.io/mlho/pen/YRPGjZ).

SVG robot arm