(function() {
  var svg = document.getElementById("arm-svg");

  function svgPoint(element, x, y) {
    var pt = svg.createSVGPoint();

    pt.x = x;
    pt.y = y;

    return pt.matrixTransform(element.getScreenCTM().inverse());
  }

  function getDistance(x1, y1, x2, y2) {
    return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
  }

  var shoulderPivotBox = document
    .getElementById("shoulder-pivot")
    .getBoundingClientRect();
  var elbowPivotBox = document
    .getElementById("elbow-pivot")
    .getBoundingClientRect();
  var clawPivotBox = document
    .getElementById("claw-pivot")
    .getBoundingClientRect();

  var originPt = svgPoint(
    svg,
    shoulderPivotBox.x + shoulderPivotBox.width / 2,
    shoulderPivotBox.y + shoulderPivotBox.height / 2
  );
  var elbowPt = svgPoint(
    svg,
    elbowPivotBox.x + elbowPivotBox.width / 2,
    elbowPivotBox.y + elbowPivotBox.height / 2
  );
  var clawPt = svgPoint(
    svg,
    clawPivotBox.x + clawPivotBox.width / 2,
    clawPivotBox.y + clawPivotBox.height / 2
  );

  var a = getDistance(elbowPt.x, elbowPt.y, clawPt.x, clawPt.y);
  var b = getDistance(originPt.x, originPt.y, elbowPt.x, elbowPt.y);

  // starting pose
  document.getElementById("arm-group").style.transform =
    "rotate(" + (45 + 90 - 90) + "deg)";
  document.getElementById("lower-group").style.transform =
    "rotate(" + (90 - 180) + "deg)";

  document.addEventListener("mousemove", function(e) {
    var pt = svgPoint(svg, e.clientX, e.clientY);

    c = getDistance(originPt.x, originPt.y, pt.x, pt.y);

    var angleOffset =
      Math.atan2(pt.y - originPt.y, pt.x - originPt.x) * 180 / Math.PI;

    var angleA =
      Math.acos(
        (Math.pow(b, 2) + Math.pow(c, 2) - Math.pow(a, 2)) / (2 * b * c)
      ) *
      180 /
      Math.PI;
    var angleC =
      Math.acos(
        (Math.pow(a, 2) + Math.pow(b, 2) - Math.pow(c, 2)) / (2 * a * b)
      ) *
      180 /
      Math.PI;

    if (c >= a + b) {
      angleA = 0;
      angleC = 180;
    }

    if (isNaN(angleA)) {
      angleA = 180;
    }

    document.getElementById("arm-group").style.transform =
      "rotate(" + (angleA + angleOffset - 90) + "deg)";
    document.getElementById("lower-group").style.transform =
      "rotate(" + (angleC - 180) + "deg)";
  });

  document.addEventListener("mousedown", function() {
    document.getElementById("top-grip").style.transform =
      "rotate(" + 32 + "deg)";
    document.getElementById("bottom-grip").style.transform =
      "rotate(" + -32 + "deg)";
  });

  document.addEventListener("mouseup", function() {
    document.getElementById("top-grip").style.transform =
      "rotate(" + 0 + "deg)";
    document.getElementById("bottom-grip").style.transform =
      "rotate(" + 0 + "deg)";
  });
})();