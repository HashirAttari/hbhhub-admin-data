// Back To The Future's Delorean.
// Inspired by Benjamin Last's art work https://www.artstation.com/artwork/dmc-bttf