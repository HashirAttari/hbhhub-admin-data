# DeLorean (CSS Art)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/yLzmKYp](https://codepen.io/ykadosh/pen/yLzmKYp).

I've been wanting to make a CSS version of this beautiful car for a while now, but I know it was going to be a challenge.

60 elements (and many more pseudo-elements) later, and here we are! A pure CSS  recreation of Back To The Future's DeLorean!

I'm using various CSS techniques here, including almost all sorts of gradients (linear, conic, radial, and their repeating counterparts), transformations  (rotate, skew, scale, perspective), and more...

Dedicated to my dear friend, one of the biggest BTTF fan, Udi Avganim!