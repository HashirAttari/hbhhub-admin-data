# Color Picker

A Pen created on CodePen.io. Original URL: [https://codepen.io/omrandmax/pen/GRdrKdN](https://codepen.io/omrandmax/pen/GRdrKdN).

A prototype to explore and test different color picker configurations.