# Styled native range input #31 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/zxRzPw](https://codepen.io/thebabydino/pen/zxRzPw).

**May 2021 description**

Major changes: 

* now using modern and more robust techniques

* ditched absolute positioning in favour of CSS grid

* using CSS variables to account for the different look of the two sliders

* using blend modes and `conic-gradient()` for the thumb decorations

* compacted the CSS to about half

* not providing free support for IE/ pre-Chromium Edge anymore

The external resources are only there to add the warning, which was sadly very necessary given a lot of people shared these saying that I designed them... which is not true.

---

If the work I've been putting out since early 2012 has helped you in any way or you just like it and you wish me to be able to continue putting out stuff, please consider one of the following:

* being a cool cat 😼🎩 and becoming a patron on Patreon

[![become a patron button](https://assets.codepen.io/2017/btn_patreon.png)](https://www.patreon.com/anatudor)

* making a one time donation via Ko-fi

[![ko-fi](https://assets.codepen.io/2017/btn_kofi.svg)](https://ko-fi.com/anatudor)

* getting me something off my Amazon WishList 

[🎁 🇺🇸](https://www.amazon.com/gp/registry/wishlist/2Y3C4722GXH0I/) / [🎁 🇬🇧](https://www.amazon.co.uk/gp/registry/wishlist/2I25W7U0KADSR/)

* or at least sharing this to show the rest of the world what can be done with CSS these days

Thank you!

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 (not fully) on Windows 8.

---

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/kHWkDQj.jpg) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/).