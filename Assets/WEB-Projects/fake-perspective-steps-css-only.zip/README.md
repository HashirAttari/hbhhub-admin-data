# Fake perspective steps (CSS only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/KKrLvXJ](https://codepen.io/amit_sheen/pen/KKrLvXJ).

