# Pure CSS mobile app animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/Wujek_Greg/pen/QrKaMb](https://codepen.io/Wujek_Greg/pen/QrKaMb).

