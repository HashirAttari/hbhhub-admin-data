# Okay Google

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/oNXYobv](https://codepen.io/MananTank/pen/oNXYobv).

