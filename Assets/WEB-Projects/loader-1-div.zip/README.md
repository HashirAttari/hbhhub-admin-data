# Loader (1 div)

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/PoNeRLj](https://codepen.io/benhatsor/pen/PoNeRLj).

Simple 1 div loader