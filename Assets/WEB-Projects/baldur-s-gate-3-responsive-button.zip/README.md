# Baldur’s Gate 3 Responsive Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/LYMBBeG](https://codepen.io/nicolasjesenberger/pen/LYMBBeG).

Responsive version of a button design from [Baldur’s Gate 3 website](https://baldursgate3.game), made using CSS `mask-border` property