# Rippling 3D SVG Text Displacement

A Pen created on CodePen.io. Original URL: [https://codepen.io/petebarr/pen/PoqbWob](https://codepen.io/petebarr/pen/PoqbWob).

The SVG distortion creates a kinda flag-like faux 3D rippling wave effect. Play with the dat-GUI for more extreme effects.

Note: This only works on desktop Chrome!