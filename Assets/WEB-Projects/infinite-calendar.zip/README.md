# Infinite Calendar

A Pen created on CodePen.io. Original URL: [https://codepen.io/tadaima/pen/WGRXyr](https://codepen.io/tadaima/pen/WGRXyr).

A liquid & 'light-weight' calendar. There's no libraries in this exercise, it's really hand-crafted.

Check out our 'body-cut' effect :D

Hope enjoy!