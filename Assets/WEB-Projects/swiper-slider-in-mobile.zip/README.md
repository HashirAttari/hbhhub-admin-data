# Swiper slider in mobile

A Pen created on CodePen.io. Original URL: [https://codepen.io/md-aqil/pen/RXaBRb](https://codepen.io/md-aqil/pen/RXaBRb).

Responsive and beautiful  swiper slider in mobile view
easy to customize option