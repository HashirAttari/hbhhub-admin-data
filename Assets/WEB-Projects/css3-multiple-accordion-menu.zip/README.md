# CSS3 Multiple Accordion Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/Frecosse/pen/kavMYN](https://codepen.io/Frecosse/pen/kavMYN).

A fully functional accordion menu, using unordered lists and checkboxes, to allow users to have accordion open/closed as required.

Makes use of IcoMoon typeface for menu icons.

Based on the PSD artwork created by Orman Clark (http://www.premiumpixels.com/freebies/vertical-navigation-menu-psd/)