var swiper = new Swiper(".swiper-container", {
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev"
  }
});

const textContent = document.querySelector(".text-content");
const slider = document.querySelectorAll(".slider");
const swiperSlider = document.querySelectorAll(".swiper-slide");
const swiperButtonWrapper = document.querySelector(".swiper-button-wrapper");

const maximizeSwiper = () => {
  swiperButtonWrapper.classList.add("show");
  textContent.classList.add("hide-text-content");

  slider.forEach((eachSliderClasss) => {
    eachSliderClasss.classList.add("maximizeSliderWidth");
    eachSliderClasss.classList.remove("minimizeSliderWidth");
  });

  swiperSlider.forEach((eachSwiperSliderClasss) => {
    eachSwiperSliderClasss.classList.add("maximizeSliderHeight");
    eachSwiperSliderClasss.classList.remove("minimizeSliderHeight");
  });
};

const minimizeSwiper = () => {
  swiperButtonWrapper.classList.remove("show");
  textContent.classList.remove("hide-text-content");

  slider.forEach((eachSliderClasss) => {
    eachSliderClasss.classList.remove("maximizeSliderWidth");
    eachSliderClasss.classList.add("minimizeSliderWidth");
  });
  swiperSlider.forEach((eachSwiperSliderClasss) => {
    eachSwiperSliderClasss.classList.remove("maximizeSliderHeight");
    eachSwiperSliderClasss.classList.add("minimizeSliderHeight");
  });
};