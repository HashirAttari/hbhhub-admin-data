# Swiper Board Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/visnuravichandran/pen/abdjNqo](https://codepen.io/visnuravichandran/pen/abdjNqo).

