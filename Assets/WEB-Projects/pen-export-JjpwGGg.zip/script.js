const properties = {
  
  /* display and positions */
  "display":{"section":1, "type":"dropdown", "options":["none","inline","block","flex","grid","inline-block","inline-flex","inline-grid","inline-table"]},
  "position":{"section":1, "type":"dropdown", "options":["static","fixed","sticky","relative","absolute"]},
  "justify-content":{"section":1, "type":"dropdown", "options":["flex-start","flex-end","center","space-between","space-around","space-evenly"], "requirements":["display","flex"]},
  "align-items":{"section":1, "type":"dropdown", "options":["stretch","center","flex-start","flex-end","baseline"], "requirements":["display","flex"]},
  
  /* sizes and opacity */
  "width":{"section":2, "type":"value"},
  "height":{"section":2, "type":"value"},
  "margin":{"section":2, "type":"quad-value"},
  "padding":{"section":2, "type":"quad-value"},
  "opacity":{"section":2, "type":"number"},
  
  /* background */
  "background-color":{"section":3, "type":"color"},
  "background-image":{"section":3, "type":"image"},
  "backdrop-filter":{"section":3, "type":"functions"},
  
  /* border */
  "border-width":{"section":4, "type":"quad-value"},
  "border-color":{"section":4, "type":"color"},
  "border-image":{"section":4, "type":"image"},
  
  /* text */
  "font-family":{"section":5, "type":"text"},
  "font-size":{"section":5, "type":"value"},
  "font-weight":{"section":5, "type":"number"},
  "color":{"section":5, "type":"color"},
  "font-style":{"section":5, "type":"dropdown", "options":["normal","italic","oblique"]},
  "text-decoration":{"section":5, "type":"multi-dropdown", "options":["overline","line-through","underline"]},
  
  "box-shadow":{"section":6, "type":"shadow"},
  
  "text-shadow":{"section":7, "type":"shadow"}
}

const sectionNames = ["none", "Display and Positionning", "sizes and opacity", "background", "border", "text", "shadow", "text-shadow"]

class htmlObject {
  constructor() {
  } 
}

const generatesettings = () => {
  
  const paramsdiv = document.querySelector(".objectparams");
  let currentSection = 0;
  let sectionEl;
  
  for (prop in properties) {
    
    // check if a new section is required
    if (currentSection != properties[prop]["section"]) {
      
      // set the current section to the new one
      currentSection = properties[prop]["section"]
      
      // create section title
      let titleEl = createEl("div", "paramsectiontitle");
      titleEl.innerHTML = sectionNames[currentSection];
      paramsdiv.appendChild(titleEl);
      
      // create section
      sectionEl = createEl("div", "paramsection");
      paramsdiv.appendChild(sectionEl);
    }
    
    // create element
    let paramEl = createEl("div", "parameter");
    let paramNameEl = createEl("div", "parametername");
    let paramPlusEl = createEl("div", "plus")
    let paramInputEl;
    paramNameEl.innerHTML = prop;
    paramEl.appendChild(paramNameEl);
    paramEl.appendChild(paramPlusEl);
    sectionEl.appendChild(paramEl);
    
    // create input
    if (properties[prop]["type"] == "value") {
      // if its a value
      paramInputEl = createEl("input", "paraminput");
      paramInputEl.setAttribute("type", "text");
      
    } else if (properties[prop]["type"] == "dropdown") {
      // if its a dropdown
      paramInputEl = createEl("select", "paraminput");
      properties[prop]["options"].forEach(function (option, i) {
        let optionEl = document.createElement("option");
        optionEl.value = option;
        optionEl.innerHTML = option;
        paramInputEl.appendChild(optionEl);
      });
    }
    
    // append the input
    paramEl.appendChild(paramInputEl);
  }
}

// create a div with a class
const createEl = (type, classes) => {
  let tempEl = document.createElement(type);
  tempEl.setAttribute("class", classes);
  return tempEl;
}

let websiteElements = {
  1: {"type":"div", "idname":"firstelement", "class":["testclass"], "children": [2]},
  2: {"type":"textNode", "idname":"childdiv", "class":["testclass"], "content":"test text"}
}

const generateElement = (id) => {
  const elProps = websiteElements[id];
  
  // if its a text node
  if (elProps["type"] == textNode) {
    return document.createTextNode(elProps["content"]);
  }
  
  // create the element
  let el = document.createElement(elProps["type"]);
  el.setAttribute("id", id);
  el.setAttribute("class", elProps["class"]);
  
  // add the children
  for (var i = 0; i < elProps["children"].length; i++) {
    el.appendChild(generateElement(elProps["children"][i]));
  }
}

const createElHtml = (id) => {
  const elData = websiteElements[id];
  
  // if its a text node;
  if (elProps["type"] == textNode) {
    return elProps["content"];
  }
  
  // if its anything else
  let children = "";
  let previousChildType = "";
  for (var i = 0; i < elProps["children"].length; i++) {
    // add line break between text nodes
    if (previousChildType == textNode) {
      
    }
    createElHtml(["children"][i]);
  }
}

generatesettings();

// document.write(Object.keys(properties));