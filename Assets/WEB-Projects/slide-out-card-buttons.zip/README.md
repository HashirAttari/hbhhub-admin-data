# Slide Out Card Buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/jahdaic/pen/DoYPLN](https://codepen.io/jahdaic/pen/DoYPLN).

These buttons look like cards that slide out of a sleeve. Useful for teasing a user or for any info that needs to remain hidden until the user chooses.