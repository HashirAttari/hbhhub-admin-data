# Math Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/emJPGg](https://codepen.io/mselmany/pen/emJPGg).

Included mouse and button play modes, you can switch btw twos.Just an experiment.