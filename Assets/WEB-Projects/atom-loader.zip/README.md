# Atom Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/eXreyj](https://codepen.io/ykadosh/pen/eXreyj).

Electrons orbiting a nucleus animated using SVG strokes