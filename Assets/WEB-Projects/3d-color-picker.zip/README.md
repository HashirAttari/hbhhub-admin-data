# 3D Color Picker

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/PoBPKvJ](https://codepen.io/ykadosh/pen/PoBPKvJ).

A beautiful 3D color picker, inspired by Oleg Frolov's design https://dribbble.com/shots/16133260-VR-Color-Picker

The 3D extrusion is done by stacking box-shadows and drop-shadows, you can read more about this technique here: https://yoavik.com/snippets/3d-text
