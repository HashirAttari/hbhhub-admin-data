import React from 'https://cdn.skypack.dev/react';
import ReactDOM from 'https://cdn.skypack.dev/react-dom';
import { RiPencilFill } from 'https://cdn.skypack.dev/react-icons@4.12.0/ri';
import { BsFillEraserFill } from 'https://cdn.skypack.dev/react-icons@4.12.0/bs';
import { BiColorFill } from 'https://cdn.skypack.dev/react-icons@4.12.0/bi';
import { ImCog } from 'https://cdn.skypack.dev/react-icons@4.12.0/im';
const COLORS = [
    [[350, 100, 60], [11, 100, 64], [31, 100, 60]],
    [[340, 33, 30], [183, 54, 33], [91, 40, 55]],
    [[260, 100, 55], [224, 100, 63], [200, 100, 63]],
    [[260, 28, 45], [257, 64, 77], [300, 100, 95]],
];
const ColorButton = ({ color, z }) => {
    return (React.createElement("button", { className: 'color-button', style: { '--h': color[0], '--s': color[1] + '%', '--l': color[2] + '%', zIndex: z } },
        React.createElement("div", { className: 'color-button__inner' })));
};
const ToolButton = ({ children }) => {
    return (React.createElement("button", { className: 'tool-button' }, children));
};
const ColorPicker = () => {
    return (React.createElement("div", { className: 'color-picker' },
        React.createElement("div", { className: 'color-picker__tools' },
            React.createElement(ToolButton, null,
                React.createElement(RiPencilFill, null)),
            React.createElement(ToolButton, null,
                React.createElement(BsFillEraserFill, null)),
            React.createElement(ToolButton, null,
                React.createElement(BiColorFill, null)),
            React.createElement(ToolButton, null,
                React.createElement(ImCog, null))),
        React.createElement("div", { className: 'color-picker__colors' }, COLORS.map((row, r) => (row.map((color, c) => (React.createElement(ColorButton, { key: `${r}-${c}`, color: color, z: r * 3 + (3 - c) }))))))));
};
export const App = () => {
    return (React.createElement("div", { className: 'app' },
        React.createElement(ColorPicker, null)));
};
ReactDOM.render(React.createElement(App, null), document.body);