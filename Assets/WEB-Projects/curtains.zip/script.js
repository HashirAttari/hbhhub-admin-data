const open_string = document.querySelector('#open_string')
const left_side = document.querySelector('#left_side')
const right_side = document.querySelector('#right_side')

// set the hero text here
const hero = document.querySelectorAll('.hero_text')
var hero_text = 'SUPER<br>DEALS'
hero.forEach(function(elm){
  elm.innerHTML = hero_text
})

open_string.addEventListener('touchmove', function(event) {
  event.preventDefault();
  var touch = event.touches[0].clientY; 
  if(touch < 5) {
    touch = 5
  }     
  var touch_perc = (touch/window.innerHeight)*100
  if(touch_perc > 80) {
    touch_perc = 80
  }    
  left_side.style.transform = 'translateX('+((-1)*(touch_perc - 5))+'%)'
    right_side.style.transform = 'translateX('+(touch_perc - 5)+'%)'
  open_string.style.top = touch_perc+'%'
}, false);

dragElement(open_string);
function dragElement(elmnt) {
  var dist = window.innerHeight*.8
  var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  elmnt.onmousedown = dragMouseDown;

  function dragMouseDown(e) {
    e = e || window.event;
    e.preventDefault();
    // get the mouse cursor position at startup:
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    // call a function whenever the cursor moves:
    document.onmousemove = elementDrag;
    elmnt.classList.toggle('grabbing')
  }

  function elementDrag(e) {
    e = e || window.event;
    e.preventDefault();

    pos2 = pos4 - e.clientY;
    pos4 = e.clientY;
    // set the element's new position:
    var newY = elmnt.offsetTop - pos2
    var perc = (newY/window.innerHeight)*100
    if(perc < 5) {
      perc = 5      
    }
    if(perc > 80) {
      perc = 80
    }
    elmnt.style.top = perc + '%'

    left_side.style.transform = 'translateX('+((-1)*(perc - 5))+'%)'
    right_side.style.transform = 'translateX('+(perc - 5)+'%)'
  }

  function closeDragElement() {
    /* stop moving when mouse button is released:*/
    document.onmouseup = null;
    document.onmousemove = null;
    elmnt.classList.toggle('grabbing')
  }
}