# Infinite rotating carousel with 100 list items (#cpc-100-list)

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/bGpjVaw](https://codepen.io/agalliat/pen/bGpjVaw).

