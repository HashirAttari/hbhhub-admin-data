# text reveal

A Pen created on CodePen.io. Original URL: [https://codepen.io/MarkBoots/pen/abXGmpg](https://codepen.io/MarkBoots/pen/abXGmpg).

