# Pure CSS3 breadcrumb navigation

A Pen created on CodePen.io. Original URL: [https://codepen.io/arkev/pen/nRGEYZ](https://codepen.io/arkev/pen/nRGEYZ).

breadcrumb navigation using pure CSS3