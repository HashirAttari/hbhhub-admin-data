# Smooth Keyboard Layout on CSS Grid

A Pen created on CodePen.

Original URL: [https://codepen.io/andrejsharapov/pen/pmdNKW](https://codepen.io/andrejsharapov/pen/pmdNKW).

I used the Raj Suhail pen as a basis and made a few changes to the keyboard settings.

https://codepen.io/irajsuhail/details/mYMZVm