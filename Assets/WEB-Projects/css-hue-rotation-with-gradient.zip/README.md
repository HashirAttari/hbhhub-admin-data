# CSS Hue rotation with gradient

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/xOOeMN](https://codepen.io/jcoulterdesign/pen/xOOeMN).

No idea you could do this, awesome effect