# Wordpress login concept 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/RwWZZYx](https://codepen.io/havardob/pen/RwWZZYx).

A re-imagined login screen for Wordpress CMS with a linear-gradient background.

The logo is copied from Wikipedia and recolored right here in the pen.
https://upload.wikimedia.org/wikipedia/commons/0/09/Wordpress-Logo.svg