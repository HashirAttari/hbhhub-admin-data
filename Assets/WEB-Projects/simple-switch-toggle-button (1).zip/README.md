# Simple Switch/Toggle Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/dGqRGy](https://codepen.io/leenalavanya/pen/dGqRGy).

Switch/Toggle Button