# Skeuomorphic Range Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/BaGjzJy](https://codepen.io/nicolasjesenberger/pen/BaGjzJy).

Design by Kizuku Kitada: https://dribbble.com/shots/7524988-Metal-HMI