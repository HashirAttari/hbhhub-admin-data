# Do the wave - :has() challenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pedro-Ondiviela/pen/dyrNWba](https://codepen.io/Pedro-Ondiviela/pen/dyrNWba).

Oh! There's a match and your team just scored! Move the mouse over the spectators to "do the wave".

An animation with an strong use of :has() selector, that has prevented us from using any Js.

Done for weekly codepen challenges.