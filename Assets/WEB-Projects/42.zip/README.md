# 42

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/jOKowqo](https://codepen.io/amit_sheen/pen/jOKowqo).

