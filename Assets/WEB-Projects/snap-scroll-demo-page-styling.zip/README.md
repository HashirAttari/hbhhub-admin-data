# Snap scroll demo page styling

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/rNRzgRj](https://codepen.io/giana/pen/rNRzgRj).

Using this to hold all the page  styling to [CSS scroll-driven scroll-snapping animations](https://codepen.io/giana/pen/BabdgjB) so as to not clutter the CSS section.