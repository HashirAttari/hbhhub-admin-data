# Virtual Keyboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/iamsainikhil/pen/gdYmOQ](https://codepen.io/iamsainikhil/pen/gdYmOQ).

# User Friendly Virtual Keyboard
A virtual keyboard with cool themes and custom key functionalities.

## Keyboard for *Windows*
Developed with **HTML**, **CSS**, and **JS** without any dependencies.

## To-do list
- *Themes*
- *Keyboard for Macintosh*
- *Custom music for any key*
- *Custom key functions*
- *Mobile responsive*

## *Want to see my other fun project*
### *Reaction Tester Game* 
> [Play](https://iamsainikhil.github.io/reaction-tester)
#### *Check out the Source Code*
> [View](https://github.com/iamsainikhil/reaction-tester)

## *If you want to get updated of my projects*
> [Follow Me](https://github.com/iamsainikhil)