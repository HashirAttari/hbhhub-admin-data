# Styled native range input #51

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/bNMWwq](https://codepen.io/thebabydino/pen/bNMWwq).

**February 2022 update**

Major changes:

* got rid of Compass and Modernizr dependencies, neither of which was needed anyway

* got rid of the convoluted JS that was adding the fill/ progress/ range highlight for the WebKit browsers and switched to a simpler method based on CSS variables (thus reduced the JS to less than 3% of what it was before); also switched to using `moz-range-progress` in Firefox, so that it's CSS-only in Firefox

* made it degrade gracefully in the no JS case in WebKit browsers

* ditched `absolute` positioning in favour of using a `grid` layout now

* used smarter gradient techniques for the slider thumbs to better reproduce the design (for the concept behind, see [this CSS-Tricks article](https://css-tricks.com/the-backgound-clip-property-and-use-cases/) I wrote)

* cleaned up the CSS (reduced the SCSS to less than half of what it was before and the improvement is even more dramatic when it comes to the compiled code) and made it more maintainable by using CSS variables and the DRY switching technique, explained in this two part article I wrote for CSS-Tricks: [part one](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) and [part two](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/)

* ensured it now behaves consistently in both WebKit browsers and Firefox - tested in latest Chrome, Firefox and Safari (via Epiphany, since I'm on Ubuntu)

* not providing free IE/ pre-Chromium support anymore

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true. Not for most browsers anyway.

---

If the work I've been putting out since the spring of 2012 has helped you in any way or you just like it and you wish me to be able to continue making stuff, please consider one of the following:

* being a cool cat 😼🎩 and becoming a patron on Patreon

[![become a patron button](https://assets.codepen.io/2017/btn_patreon.png)](https://www.patreon.com/anatudor)

* making a one time donation via Ko-fi

[![ko-fi](https://assets.codepen.io/2017/btn_kofi.svg)](https://ko-fi.com/anatudor)

* getting me something off my Amazon WishList 

[🎁 🇺🇸](https://www.amazon.com/gp/registry/wishlist/2Y3C4722GXH0I/) / [🎁 🇬🇧](https://www.amazon.co.uk/gp/registry/wishlist/2I25W7U0KADSR/)

* or at least sharing this to show the rest of the world what can be done with CSS these days

Thank you!

---

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need any JS, while Firefox and Chrome/ Opera rely on it a bit for updating the fill of the range track. Fallback for no JS: display the same background for the entire track, both before and after the thumb. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/NXdqDl8.png) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 