const body = document.querySelector('body');
const inputs = document.querySelectorAll('input[type="range"]');

inputs.forEach(input => {
  input.addEventListener('input', (e) => {
    document.documentElement.style.setProperty(input.dataset.for, e.target.value);
  });
  document.documentElement.style.setProperty(input.dataset.for, input.value);
});