# See through barber pole 💈

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/YzJzgqJ](https://codepen.io/amit_sheen/pen/YzJzgqJ).

