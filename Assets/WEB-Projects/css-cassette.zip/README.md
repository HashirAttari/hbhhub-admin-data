# Css Cassette

A Pen created on CodePen.io. Original URL: [https://codepen.io/yeshvanth/pen/jMeGem](https://codepen.io/yeshvanth/pen/jMeGem).

Created Cassette using only HTML & CSS with recording kind of animation. Inspiration took from dribbble, A tribute to @missmary_anne!

https://dribbble.com/shots/3009652-Cassette

Text Editor: Sublime Text 3
Language: HTML & CSS