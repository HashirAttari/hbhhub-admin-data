# Apple Watch Activity Dials CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/pvQwqW](https://codepen.io/mselmany/pen/pvQwqW).

From https://cssanimation.rocks/watch/

Forked from [Donovan Hutchinson](http://codepen.io/donovanh/)'s Pen [Apple Watch Activity Dials CSS](http://codepen.io/donovanh/pen/GgYEBZ/).