# Zipper Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/waiz3ple/pen/yLqJBEQ](https://codepen.io/waiz3ple/pen/yLqJBEQ).

