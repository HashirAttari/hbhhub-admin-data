# Neumorphism calculator with dark mode switch 

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/poReVdw](https://codepen.io/yudizsolutions/pen/poReVdw).

Neumorphism is a new trend in UI design. We Created a calculator Neumorphism design using CSS code with a dark mode switch. We need to use CSS multiple box-shadow properties to create the Neumorphism effect. for calculator functionalities, we used javascript as the backend. 

Made by Prachi Prajapati from Yudiz