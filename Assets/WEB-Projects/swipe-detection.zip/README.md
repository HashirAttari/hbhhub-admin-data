# Swipe detection

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/jOVyEdM](https://codepen.io/benhatsor/pen/jOVyEdM).

