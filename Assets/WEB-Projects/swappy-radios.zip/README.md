# Swappy radios

A Pen created on CodePen.io. Original URL: [https://codepen.io/liamj/pen/NegxNB](https://codepen.io/liamj/pen/NegxNB).

An elaborate radio button animation