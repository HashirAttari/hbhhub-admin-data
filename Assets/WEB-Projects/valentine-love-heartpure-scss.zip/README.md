# Valentine  Love heart - Pure SCSS

A Pen created on CodePen.

Original URL: [https://codepen.io/Nav2510/pen/VwMEEoq](https://codepen.io/Nav2510/pen/VwMEEoq).

Romantic love animations with glittering effects.