# Animated Number Spinner

A Pen created on CodePen.io. Original URL: [https://codepen.io/StarKnightt/pen/oNmmMNV](https://codepen.io/StarKnightt/pen/oNmmMNV).

This project features a vertical progress spinner created with HTML and CSS. The spinner is designed with a sleek green progress meter inside a stylish box, providing a visual indication of progress. The layout is centered on the page and utilizes the Poppins font for a modern and clean look.
