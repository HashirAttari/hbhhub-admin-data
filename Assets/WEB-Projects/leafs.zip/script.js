let p = document.querySelector('p'),
		p_width = p.getBoundingClientRect().width

function addBubbles() {
	for(var i=0;i<p_width/15;i++) {
		let b = document.createElement('div')
		b.className = 'bubble'
		b.style.width = Math.random() < .5 ? '20px' : '10px'
		b.style.left = Math.random() * (p_width - 20) + 'px'
		// b.style.filter = 'hue-rotate('+(Math.random()*360)+'deg)'
		b.style.animationDelay = 4 * Math.random() + 's'
		p.appendChild(b)
	}	
}
addBubbles()