# LEAFS

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/ZEZmWOB](https://codepen.io/kitjenson/pen/ZEZmWOB).

