const body = document.body;
const delay1 = document.getElementById("delay1");
const delay2 = document.getElementById("delay2");
const delay3 = document.getElementById("delay3");
const cubic1 = document.getElementById("cubic1");
const cubic2 = document.getElementById("cubic2");
const cubic3 = document.getElementById("cubic3");
const cubic4 = document.getElementById("cubic4");
const offset = document.getElementById("offset");
const hue = document.getElementById("hue");
const size = document.getElementById("size");

body.querySelectorAll(".slider").forEach(slider => { 
slider.addEventListener('input', e => {
  body.style.setProperty("--delay1", delay1.value);
  body.style.setProperty("--delay2", delay2.value);
  body.style.setProperty("--delay3", delay3.value);
  body.style.setProperty("--cubic1", cubic1.value);
  body.style.setProperty("--cubic2", cubic2.value);
  body.style.setProperty("--cubic3", cubic3.value);
  body.style.setProperty("--cubic4", cubic4.value);
  body.style.setProperty("--offset", offset.value);
  body.style.setProperty("--hue", hue.value + "deg");
  body.style.setProperty("--size", size.value + "px");
  });
});