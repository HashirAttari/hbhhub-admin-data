# A Cubey Slider (webkit)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ebrewe/pen/kxmVEL](https://codepen.io/ebrewe/pen/kxmVEL).

It's like a slider but it rotates cubeishly for reasons unknown.
(webkit)