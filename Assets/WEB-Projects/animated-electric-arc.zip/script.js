const leftCircleRadius = 25;
const rightCircleRadius = 25;
const borderSpacing = 5;

const lineCount = 5;
const lineWidth = 2;
const lineStep = 10;

const freq = 2.0;
const ampl = 50.0;

const canvas = document.querySelector('canvas');
const ctx = canvas.getContext('2d');

function setSize() {
    const s = Math.min(window.innerWidth, window.innerHeight);
    canvas.width  = 3 * s / 4;
    canvas.height = 3 * s / 4;
}

function translateRotation(center_x, center_y, radius, angle) {
    const x = center_x + Math.cos(angle * Math.PI / 180) * radius;
    const y = center_y + Math.sin(angle * Math.PI / 180) * radius;
    return {x: x, y: y};
}

function distance(p1x, p1y, p2x, p2y) {
    const dx = p2x - p1x;
    const dy = p2y - p1y;
    return Math.sqrt(dx * dx + dy * dy);
}

function calcVertical(p1x, p1y, p2x, p2y, lineWidth) {
    const dx = p2x - p1x;
    const dy = p2y - p1y;
    const length = distance(p1x, p1y, p2x, p2y);
    
    const pv1x = p1x - ((lineWidth / 2) / length) * dy;
    const pv1y = p1y + ((lineWidth / 2) / length) * dx;
    const pv2x = p1x + ((lineWidth / 2) / length) * dy;
    const pv2y = p1y - ((lineWidth / 2) / length) * dx;
    
    return {pv1x, pv1y, pv2x, pv2y};
}

const clampNumber = (num, a = 0, b = 1) => Math.max(Math.min(num, Math.max(a, b)), Math.min(a, b));

function draw() {
    const halfHeight = canvas.height / 2;
    
    const leftCircleCenterX = borderSpacing + leftCircleRadius;
    const leftCircleCenterY = halfHeight;
    
    const rightCircleCenterX = canvas.width - borderSpacing - rightCircleRadius;
    const rightCircleCenterY = halfHeight;
    
    const lineStart = translateRotation(leftCircleCenterX, leftCircleCenterY, leftCircleRadius,  360 - 45);
    
    const lineEnd = translateRotation(rightCircleCenterX, rightCircleCenterY, rightCircleRadius, 180 + 45);
    
    const lineSegments = (lineEnd.x - lineStart.x) / lineStep;
    
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    const poleLineWidth = 10;
    ctx.lineWidth = poleLineWidth;
    
    // left line
    const leftP1x = canvas.width / 4;
    const leftP1y = canvas.height;
    const leftP2x = leftCircleCenterX;
    const leftP2y = leftCircleCenterY;
    
    const leftVert = calcVertical(leftP1x, leftP1y, leftP2x, leftP2y, poleLineWidth);
    
    const linGradLeft = ctx.createLinearGradient(leftVert.pv1x, leftVert.pv1y, leftVert.pv2x, leftVert.pv2y);
    linGradLeft.addColorStop(0, 'rgb(64, 64, 64)');
    linGradLeft.addColorStop(0.5, 'rgb(192, 192, 192)');
    linGradLeft.addColorStop(1, 'rgb(64, 64, 64)');
    
    ctx.strokeStyle = linGradLeft;
    
    ctx.beginPath();
    ctx.moveTo(leftP1x, leftP1y);
    ctx.lineTo(leftP2x, leftP2y);
    ctx.stroke();
    
    // right line
    const rightP1x = 3 * canvas.width / 4;
    const rightP1y = canvas.height;
    const rightP2x = rightCircleCenterX;
    const rightP2y = rightCircleCenterY;
    
    const rightVert = calcVertical(rightP1x, rightP1y, rightP2x, rightP2y, poleLineWidth);
    
    const linGradRight = ctx.createLinearGradient(rightVert.pv1x, rightVert.pv1y, rightVert.pv2x, rightVert.pv2y);
    linGradRight.addColorStop(0, 'rgb(64, 64, 64)');
    linGradRight.addColorStop(0.5, 'rgb(192, 192, 192)');
    linGradRight.addColorStop(1, 'rgb(64, 64, 64)');
    
    ctx.strokeStyle = linGradRight;
    
    ctx.beginPath();
    ctx.moveTo(rightP1x, rightP1y);
    ctx.lineTo(rightP2x, rightP2y);
    ctx.stroke();
    
    // circle left
    const arcGradLeft = ctx.createRadialGradient(leftCircleCenterX, leftCircleCenterY, 0, leftCircleCenterX, leftCircleCenterY, leftCircleRadius);
    arcGradLeft.addColorStop(0, 'rgb(192, 192, 192)');
    arcGradLeft.addColorStop(1, 'rgb(64, 64, 64)');
    ctx.fillStyle = arcGradLeft;
    
    ctx.beginPath();
    ctx.arc(leftCircleCenterX, leftCircleCenterY, leftCircleRadius, 0, 2 * Math.PI);
    ctx.fill();
    
    // circle right
    const arcGradRight = ctx.createRadialGradient(rightCircleCenterX, rightCircleCenterY, 0, rightCircleCenterX, rightCircleCenterY, rightCircleRadius);
    arcGradRight.addColorStop(0, 'rgb(192, 192, 192)');
    arcGradRight.addColorStop(1, 'rgb(64, 64, 64)');
    ctx.fillStyle = arcGradRight;
    
    ctx.beginPath();
    ctx.arc(rightCircleCenterX, rightCircleCenterY, rightCircleRadius, 0, 2 * Math.PI);
    ctx.fill();
    
    // electric arc
    for(let lineNo = 0; lineNo < lineCount; lineNo++) {
        const togglePerFrame = (Math.random() * 2.0) - 1.0;
        const freqJitter = Math.random() * 2;
        const amplJitter = (Math.random() * 0.5) + 0.5;
        const colorJitter = Math.random() * 128 * togglePerFrame;
        const alphaJitter = Math.random() * 0.75;

        ctx.strokeStyle = `rgba(255, 255, ${128 + colorJitter}, ${alphaJitter})`;
        
        ctx.lineWidth = lineWidth + togglePerFrame;
        ctx.beginPath();
        ctx.moveTo(lineStart.x, lineStart.y);

        for(let i = 0; i < lineSegments; i++) {
            const tick = i / lineSegments;
            const clamp = clampNumber(Math.min(tick * 10.0, 10.0 - tick * 10.0));

            const togglePerSegment = (Math.random() * 2.0 - 1.0);
            
            const waveStep = tick * (2 * Math.PI);
            const waveJitter = togglePerSegment * 0.5;
            
            const arc = (2 * ampl * Math.sin(Math.PI + waveStep * 0.5));
            const wave = ((ampl * amplJitter) * (Math.sin(waveStep * (freq * freqJitter)) + waveJitter) * clamp);

            const nextX = lineStart.x + ((i * lineStep) + waveJitter);
            const nextY = lineStart.y + (arc + wave * togglePerFrame);

            ctx.lineTo(nextX, nextY);
        }
        ctx.lineTo(lineEnd.x, lineEnd.y);
        ctx.stroke();
    }
    
    requestAnimationFrame(draw);
}

window.addEventListener('resize', setSize);

setSize();
draw();