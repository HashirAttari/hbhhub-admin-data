# Animated electric arc

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/yLNbrLv](https://codepen.io/agalliat/pen/yLNbrLv).

