# Slide-in background hover effect | CSS animation 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/LWywma](https://codepen.io/havardob/pen/LWywma).

