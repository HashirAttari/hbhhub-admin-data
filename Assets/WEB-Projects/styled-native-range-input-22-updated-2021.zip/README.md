# Styled native range input #22 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/KwZKgz](https://codepen.io/thebabydino/pen/KwZKgz).

**May 2021**

* minor CSS cleanups, , in particular made most of the code for `::-moz-range-track` and `::-moz-range-progress` common to slash a few more lines of code

---

**January 2021 update**

Major changes:

* eliminated the 1 element constraint and now used a range `input` tied to a `datalist` for ruler labels (see [this twitter thread](https://twitter.com/anatudor/status/1225113768629325825)), both of them in a wrapper which stores the current value of the range input in a custom property - this greatly simplifies the JavaScript for updating the fake progress in WebKit browsers (Firefox has the `-moz-range-progress` pseudo for this and doesn't need JS at all)

* eliminated hacks like using the `-ms-` class for specifically targeting IE (which didn't even work in *pre-Chromium* Edge anyway, which got the `-webkit-` class instead) or the `track`'s `::after` pseudo-element for the progress ruler labels (that's now done cleanly and in a cross-browser manner with the `datalist` element)

* got rid of `absolute` positioning in favour of a CSS `grid` layout

* made it degrade gracefully in the no JS case (check with JS disabled)

* made it nicely responsive - the slider width and ruler labels adapt to the viewport width changes

Hopefully accessible.

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

**Original description**

See all the sliders I've created using just one range input in [this collection](http://codepen.io/collection/DgYaMj/).

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling the range track. There's a bit of an extra in Chrome/ Opera with a numeric guide. This is done using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). Fallback for no JS: simply display the same background for the entire track, both before and after the thumb. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](https://pbs.twimg.com/media/B9cX91ACUAIHyqb?format=png&name=large) 