# Recreation Cuberto Homepage Vanilla JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/Zwvyao](https://codepen.io/joshonweb/pen/Zwvyao).

a simplified recreation the cuberto.com homepage with no js libraries