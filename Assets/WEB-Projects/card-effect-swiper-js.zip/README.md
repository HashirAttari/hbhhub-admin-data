# Card Effect | Swiper JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/ecemgo/pen/ZEVojzN](https://codepen.io/ecemgo/pen/ZEVojzN).

Note: Please, do not use it in profit-making platforms and projects without permission.