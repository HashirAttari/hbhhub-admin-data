# Dot loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/JjpopGq](https://codepen.io/benhatsor/pen/JjpopGq).

