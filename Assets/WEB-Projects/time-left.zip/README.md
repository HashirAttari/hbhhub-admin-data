# Time Left

A Pen created on CodePen.io. Original URL: [https://codepen.io/sebpearce/pen/dMvVYR](https://codepen.io/sebpearce/pen/dMvVYR).

