# Origami

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/kXwRmn](https://codepen.io/hakimel/pen/kXwRmn).

Canvas doodle with pretty shapes and patterns.