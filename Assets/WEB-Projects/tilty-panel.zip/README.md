# Tilty Panel

A Pen created on CodePen.io. Original URL: [https://codepen.io/jexordexan/pen/RKNrEm](https://codepen.io/jexordexan/pen/RKNrEm).

An experiment trying to get a realistic 3D tilt effect using box-shadows, CSS transforms, and gradients for shading.