# Toggle switch [Pure CSS]

A Pen created on CodePen.io. Original URL: [https://codepen.io/kh-mamun/pen/oWdMjR](https://codepen.io/kh-mamun/pen/oWdMjR).

Animated toggle switch