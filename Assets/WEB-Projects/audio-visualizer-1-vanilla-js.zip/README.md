# Audio Visualizer 1 (vanilla JS)

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/wvoNqdv](https://codepen.io/franksLaboratory/pen/wvoNqdv).

