# Smart Remote Control With Dark/Light Mode

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/XWqwOJR](https://codepen.io/yudizsolutions/pen/XWqwOJR).

We have used neumorphism for a trendy and visually pleasant look of the Smart Remote Control App with both versions dark and light. For that concept css-variable is very useful.

We took reference from our dribble shot:
https://dribbble.com/shots/18910608-Smart-Remote-Control-App

Made by Rajnee Makwana from Yudiz