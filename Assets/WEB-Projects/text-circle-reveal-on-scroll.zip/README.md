# Text circle reveal on scroll

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/OJNJKgw](https://codepen.io/ig_design/pen/OJNJKgw).

