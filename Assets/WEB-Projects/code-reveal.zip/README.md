# Code Reveal 🫣

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/XWQXPjd](https://codepen.io/jh3y/pen/XWQXPjd).

