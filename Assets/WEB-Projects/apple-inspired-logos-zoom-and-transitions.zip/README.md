# Apple inspired logos zoom and transitions

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/ExzVzpP](https://codepen.io/cbolson/pen/ExzVzpP).

I saw something like this either on the Apple event video stream or on their website. Unfortunatly I can't find it now so I am not exactly sure how it worked.
Logo images randomly positioned and transistioned withing the viewport.