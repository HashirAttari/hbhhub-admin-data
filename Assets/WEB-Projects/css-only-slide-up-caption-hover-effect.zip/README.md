# CSS-only Slide-up Caption Hover Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/seyedi/pen/zYoeLEv](https://codepen.io/seyedi/pen/zYoeLEv).

Credits:

Technique: https://css-irl.info/css-only-slide-up-caption-hover-effect

Design: https://dribbble.com/shots/10951466-Social-Mobile-App

