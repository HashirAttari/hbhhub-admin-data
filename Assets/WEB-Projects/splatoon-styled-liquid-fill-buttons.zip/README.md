# Splatoon Styled Liquid Fill Buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/mGmqrJ](https://codepen.io/markmead/pen/mGmqrJ).

