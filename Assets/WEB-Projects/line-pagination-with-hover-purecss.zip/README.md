# Line Pagination with Hover (PureCSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/WgJzKJ](https://codepen.io/markmead/pen/WgJzKJ).

