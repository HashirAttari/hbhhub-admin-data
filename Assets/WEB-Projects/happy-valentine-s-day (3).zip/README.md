# Happy Valentine's Day!

A Pen created on CodePen.

Original URL: [https://codepen.io/mimoduo/pen/VeqogK](https://codepen.io/mimoduo/pen/VeqogK).

Credit goes to Emilee Beeson for the super hawt cutie face and Erica Remmele for the awesome Happy Valentines typography!