# Accessible Horizontal Accordion

A Pen created on CodePen.io. Original URL: [https://codepen.io/grzegorz-rogala/pen/vYMLpvV](https://codepen.io/grzegorz-rogala/pen/vYMLpvV).

This simple and partially responsive horizontal accordion can be used on a Moodle course page to deliver simple step-by-step instructions or procedures. It also includes ARIA attributes for enhanced accessibility. However, due to the horizontal layout it may not have the greatest user experience on mobile. 