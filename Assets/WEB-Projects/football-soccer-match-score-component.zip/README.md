# Football (soccer) match score component

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/MWKWZxZ](https://codepen.io/havardob/pen/MWKWZxZ).

Recreated this Dribbble-shot: https://dribbble.com/shots/7735602-GitBets-Match/attachments/438485?mode=media
