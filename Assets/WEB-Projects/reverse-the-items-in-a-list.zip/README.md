# Reverse the items in a list

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/byLZvg](https://codepen.io/run-time/pen/byLZvg).

