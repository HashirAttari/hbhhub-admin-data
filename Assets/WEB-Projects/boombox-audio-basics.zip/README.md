# Boombox: Audio Basics

A Pen created on CodePen.io. Original URL: [https://codepen.io/Rumyra/pen/qyMzqN](https://codepen.io/Rumyra/pen/qyMzqN).

A demo to get started with the Web Audio API.

Loading sounds, playing and pausing them and creating volume and panner nodes.