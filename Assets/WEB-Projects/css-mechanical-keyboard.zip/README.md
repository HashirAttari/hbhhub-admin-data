# CSS Mechanical Keyboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/bGKgxbe](https://codepen.io/ykadosh/pen/bGKgxbe).

