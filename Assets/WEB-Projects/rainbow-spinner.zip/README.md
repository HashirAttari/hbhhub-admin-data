# Rainbow spinner

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/KzQGyM](https://codepen.io/giana/pen/KzQGyM).

