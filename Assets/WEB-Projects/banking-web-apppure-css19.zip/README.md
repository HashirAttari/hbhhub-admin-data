# Banking Web App - pure css - #19

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/ExPJbWv](https://codepen.io/ig_design/pen/ExPJbWv).

