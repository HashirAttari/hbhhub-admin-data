# Toggle Simple

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/JjzoegX](https://codepen.io/alvaromontoro/pen/JjzoegX).

