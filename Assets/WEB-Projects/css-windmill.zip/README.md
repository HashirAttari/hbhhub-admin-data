# CSS Windmill

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/rNQmddZ](https://codepen.io/amit_sheen/pen/rNQmddZ).

