// ########################################################################
// Originally this animaiton activated when the user scrolled to the block
// ########################################################################

(function () {
  'use strict';
  
  var $animatedBlock = $('.js-tool-support');
  var $animatedTileElements = $('.js-tool-tile', $animatedBlock);
  var $animatedShadowElements = $('.js-tool-shadow', $animatedBlock);
  var $window = $(window);

  // Animated tiles
  if ($animatedTileElements.length > 0 && $animatedShadowElements.length > 0) {

    // Apply 'unanimated' class to tiles
    $animatedTileElements.each(function (index, element) {
      var $element = $(element);
      var inactiveClass = $animatedBlock.attr('data-tool-tile-inactive');

      if (inactiveClass) {
        $element.addClass(inactiveClass);
      }
    });

    // Apply 'unanimated' class to shadow
    $animatedShadowElements.each(function (index, element) {
      var $element = $(element);
      var inactiveClass = $animatedBlock.attr('data-tool-shadow-inactive');

      if (inactiveClass) {
        $element.addClass(inactiveClass);
      }
    });

    var calculateScroll = function () {

      // Get the current pages height
      var windowPos = $window.scrollTop() + $window.height();


      // If the animated block is now above the activation point, remove the old class and add the new one
      $animatedTileElements.each(function (index, element) {

        var $element = $(element);
        var currentBlockPosition = $animatedBlock.offset().top;
        var activationPoint = $animatedBlock.attr('data-tool-support-activation-point');

        if (activationPoint != null) {
          switch (activationPoint) {
            case "middle":
              activationPoint = $window.height() / 2;
              break;
            case "bottom":
              activationPoint = $window.height();
              break;
            default:
              activationPoint = 0;
          }

          windowPos = $window.scrollTop() + ($window.height() - activationPoint);
        }

        
        if (currentBlockPosition < windowPos) {
          var animationOrder = $element.attr('data-animation-order');
          var animationInterval = $animatedBlock.attr('data-animation-interval');
          var inactiveClass = $animatedBlock.attr('data-tool-tile-inactive');

          // timings for animation
          if (animationOrder === 'first') {
            if (inactiveClass) {
              $element.removeClass(inactiveClass);
            }

            $element.addClass($animatedBlock.attr('data-tool-tile-active'));
            $animatedTileElements = $animatedTileElements.not($element); // Pop from the list
          }
          else if (animationOrder === 'second') {
            setTimeout(function () {
              if (inactiveClass) {
                $element.removeClass(inactiveClass);
              }

              $element.addClass($animatedBlock.attr('data-tool-tile-active'));
              $animatedTileElements = $animatedTileElements.not($element); // Pop from the list
            }, animationInterval);
          }
          else if (animationOrder === 'third') {
            setTimeout(function () {
              if (inactiveClass) {
                $element.removeClass(inactiveClass);
              }

              $element.addClass($animatedBlock.attr('data-tool-tile-active'));
              $animatedTileElements = $animatedTileElements.not($element); // Pop from the list
            }, animationInterval * 2);
          }
          else if (animationOrder === 'forth') {
            setTimeout(function () {
              if (inactiveClass) {
                $element.removeClass(inactiveClass);
              }

              $element.addClass($animatedBlock.attr('data-tool-tile-active'));
              $animatedTileElements = $animatedTileElements.not($element); // Pop from the list
            }, animationInterval * 3);
          }
          else if (animationOrder === 'fifth') {
            setTimeout(function () {
              if (inactiveClass) {
                $element.removeClass(inactiveClass);
              }

              $element.addClass($animatedBlock.attr('data-tool-tile-active'));
              $animatedTileElements = $animatedTileElements.not($element); // Pop from the list
            }, animationInterval * 4);
          }
        }

      });

      $animatedShadowElements.each(function (index, element) {

        var $element = $(element);
        var currentBlockPosition = $animatedBlock.offset().top;
        var activationPoint = $animatedBlock.attr('data-tool-support-activation-point');

        if (activationPoint != null) {
          switch (activationPoint) {
            case "middle":
              activationPoint = $window.height() / 2;
              break;
            case "bottom":
              activationPoint = $window.height();
              break;
            default:
              activationPoint = 0;
          }

          windowPos = $window.scrollTop() + ($window.height() - activationPoint);
        }

        if (currentBlockPosition < windowPos) {
          var animationOrder = $element.attr('data-animation-order');
          var animationInterval = $animatedBlock.attr('data-animation-interval');
          var inactiveClass = $animatedBlock.attr('data-tool-shadow-inactive');

          // timings for animation
          if (animationOrder === 'first') {
            if (inactiveClass) {
              $element.removeClass(inactiveClass);
            }

            $element.addClass($animatedBlock.attr('data-tool-shadow-active'));
            $animatedShadowElements = $animatedShadowElements.not($element); // Pop from the list
          }
          else if (animationOrder === 'second') {
            setTimeout(function () {
              if (inactiveClass) {
                $element.removeClass(inactiveClass);
              }

              $element.addClass($animatedBlock.attr('data-tool-shadow-active'));
              $animatedShadowElements = $animatedShadowElements.not($element); // Pop from the list
            }, animationInterval);
          }
          else if (animationOrder === 'third') {
            setTimeout(function () {
              if (inactiveClass) {
                $element.removeClass(inactiveClass);
              }

              $element.addClass($animatedBlock.attr('data-tool-shadow-active'));
              $animatedShadowElements = $animatedShadowElements.not($element); // Pop from the list
            }, animationInterval * 2);
          }
          else if (animationOrder === 'forth') {
            setTimeout(function () {
              if (inactiveClass) {
                $element.removeClass(inactiveClass);
              }

              $element.addClass($animatedBlock.attr('data-tool-shadow-active'));
              $animatedShadowElements = $animatedShadowElements.not($element); // Pop from the list
            }, animationInterval * 3);
          }
          else if (animationOrder === 'fifth') {
            setTimeout(function () {
              if (inactiveClass) {
                $element.removeClass(inactiveClass);
              }

              $element.addClass($animatedBlock.attr('data-tool-shadow-active'));
              $animatedShadowElements = $animatedShadowElements.not($element); // Pop from the list
            }, animationInterval * 4);
          }
        }

      });
    };

    window.addEventListener("scroll", calculateScroll);
    
    //$(document).ready(calculateScroll());
    $(document).ready(function() {
      setTimeout(function() {
        calculateScroll();
      }, 1000);
    })
  }
  
})();