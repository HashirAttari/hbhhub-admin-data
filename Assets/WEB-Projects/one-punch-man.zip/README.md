# #ONE PUNCH MAN

A Pen created on CodePen.io. Original URL: [https://codepen.io/moritao/pen/wOqmXw](https://codepen.io/moritao/pen/wOqmXw).

ワンパンマンのサイタマをHTMLとCSSで描きました。