# Interactive particles canvas generated from image

A Pen created on CodePen.

Original URL: [https://codepen.io/richardevcom/pen/YzzOJXr](https://codepen.io/richardevcom/pen/YzzOJXr).

Interactive particles that react on mouse movement and has their own gravity and are generated from any images.