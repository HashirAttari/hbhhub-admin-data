# Cartoon character - following you

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pedro-Ondiviela/pen/BaMRQyY](https://codepen.io/Pedro-Ondiviela/pen/BaMRQyY).

Cartoon character animation with fake 3d rotation of an animated face