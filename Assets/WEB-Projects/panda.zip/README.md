# Panda

A Pen created on CodePen.io. Original URL: [https://codepen.io/mlho/pen/OamQPQ](https://codepen.io/mlho/pen/OamQPQ).

Waving panda animation made with CSS