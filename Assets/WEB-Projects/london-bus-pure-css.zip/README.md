# London Bus (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/YzqyYGy](https://codepen.io/ykadosh/pen/YzqyYGy).

A pure CSS London bus, based on Ekaterina Ushakova's design (https://www.123rf.com/photo_137888403_stock-vector-london-city-bus-on-blue-backgound-red-double-decker-bus-with-british-flag-on-it-side-view-vector-ill.html)

I created this pure CSS bus as a way to improve my CSS skills. Every additional detail introduces another challenge, and CSS offers a variety of ways to overcome them.