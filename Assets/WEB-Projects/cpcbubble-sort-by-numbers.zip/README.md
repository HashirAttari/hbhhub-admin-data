# CPC - Bubble sort by numbers

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/VwNGXVp](https://codepen.io/cbolson/pen/VwNGXVp).

