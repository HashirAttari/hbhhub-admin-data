import { Those3DTexts } from "https://cdn.skypack.dev/that-3d-text-library";

const words = new Those3DTexts().words;
const word = words[0];
const letters = word.letters;

// word.

let count = 0;

const tick = () => {
  count++;
  const step = 360 / letters.length;
  letters.forEach((letter, i) => {
    word.element.style.setProperty("--sin-" + i, Math.sin((count + step * i) * 0.1));
  });
  window.requestAnimationFrame(tick);
};

tick();