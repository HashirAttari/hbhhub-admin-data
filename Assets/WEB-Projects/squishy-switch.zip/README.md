# Squishy Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/bGQwBYo](https://codepen.io/nicolasjesenberger/pen/bGQwBYo).

Design by [@liamdforsyth](https://twitter.com/liamdforsyth) on Twitter: https://twitter.com/liamdforsyth/status/1671292132873719808