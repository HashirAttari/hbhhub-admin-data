/*
		Designed by: catalyst
		Original image: https://dribbble.com/catalystvibes
*/

let eyeR = document.querySelector("#eye-r");
let eyeR2 = document.querySelector("#eye-r2");

let toggleEyeFunc = () => {
	eyeR.classList.toggle("is-eye-hidden");
	eyeR2.classList.toggle("is-eye-hidden");

	setTimeout(() => {
		eyeR.classList.toggle("is-eye-hidden");
		eyeR2.classList.toggle("is-eye-hidden");
	}, 500);
};

document.body.addEventListener("click", toggleEyeFunc);