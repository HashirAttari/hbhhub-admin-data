# PAC-MAN Password Reveal w/ GSAP 

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/OJXGYLM](https://codepen.io/jh3y/pen/OJXGYLM).

