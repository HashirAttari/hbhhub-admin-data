# Tumbling stick (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/NWmaWxa](https://codepen.io/amit_sheen/pen/NWmaWxa).

