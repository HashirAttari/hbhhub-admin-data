# Fullscreen CSS Background Image Slideshow

A Pen created on CodePen.io. Original URL: [https://codepen.io/klesht/pen/vEOjrz](https://codepen.io/klesht/pen/vEOjrz).

Taking advantage of Sass with Bourbon, I've refactored the original Codrops demo of a Fullscreen Background Image Slideshow to be a little more compact and efficiently managed.

The markup for the slideshow is an unordered list that houses spans which will function as the elements for the background images of the slideshow.

A variable, $animation-delay, is defined as the duration of each slide.  This variable will be used to calculate the slideshow's cycle, and makes adding and removing slides a little more manageable.

The first instance of the variable is found tied to the spans that define the background images for each slide.  Here, the variable should be multiplied by the total number of slides in the slideshow to set the full length of the cycle.

Where the background images for each span of the slideshow are defined, the variable is further used to set the delay for each slide and ensure that a continuous cycle is created.

Keyframe steps also need to be calculated based on the total number of slides and slide duration.  First, divide slide duration by the total cycle time.  The resulting percentage will be the base step, and where in the animation the image will begin to fade.  An 'in-between' step is also needed preceding the base step, and is calculated by dividing the base step percentage by 2.  This step is where the image will be completely shown.  Finally, the step at which the image is to disappear completely will be following the base step, and is calculated by multiplying the base step by 1.5.


For more information, and the original demonstration, visit: http://tympanus.net/codrops/2012/01/02/fullscreen-background-image-slideshow-with-css3