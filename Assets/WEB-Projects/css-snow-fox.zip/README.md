# CSS Snow Fox

A Pen created on CodePen.io. Original URL: [https://codepen.io/davidkpiano/pen/woZNbB](https://codepen.io/davidkpiano/pen/woZNbB).

Animated snow fox walk cycle based on a [Dribbble](https://dribbble.com/shots/3153461-Snowfox-walk-cycle) by [Jonathan Dahl](https://dribbble.com/jwdahl).

Works best in Chrome and Firefox. This was pretty difficult to do!