# Life paradox | CSS Checkboxes

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/ZJJoQL](https://codepen.io/havardob/pen/ZJJoQL).

Saw this and thought it would be cool to recreate it with CSS and JS 

http://imgur.com/gallery/ajD0S