var canvas = document.getElementById('canvas'),
        ctx = canvas.getContext('2d'),
        canvasW = canvas.width = window.innerWidth,
        canvasH = canvas.height = window.innerHeight,
        x = 1,
        y = 1,
        size = 20,
        speedX = size/2,
        speedY = size/2,
        moveProb = 50;

    function random(min,max) {
        if(arguments.length < 2) {
            max = min;
            min = 0;
        }

        return Math.floor(Math.random() * (max - min) + min);
    }

    function clearCanvas() {
        ctx.save();
        ctx.beginPath();
        ctx.fillStyle = 'hsl(0,0%,5%)';
        ctx.fillRect(0,0,canvasW,canvasH);
        ctx.closePath();
        ctx.restore();
    }

    clearCanvas();

    function draw() {

        var gradient = ctx.createRadialGradient(x, y, 0, x, y, size);
            gradient.addColorStop(0, '#fff');
            gradient.addColorStop(0.5, 'hsla(' + random(0,360) + ',100%,20%,0.25)');
            gradient.addColorStop(1, '#000');

        x += speedX;
        y += speedY;

        if (x + size/2 > canvasW || x - size/2 < 0 || random(moveProb) === 1) {
            speedX *= -1;
        }

        if (y + size/2 > canvasH || y - size/2 < 0 || random(moveProb) === 1) {
            speedY *= -1;
        }

        ctx.save();
        ctx.beginPath();
        ctx.globalCompositeOperation = 'color-dodge';
        ctx.fillStyle = gradient;
        ctx.arc(x, y, 50, 0, Math.PI * 2);
        ctx.fill();
        ctx.closePath();
        ctx.restore();
    }

    function animate() {
        draw();
        window.requestAnimationFrame(animate);
    }

    window.requestAnimationFrame(animate);

    window.addEventListener('click',function() {
        clearCanvas();
        if (size === 20) {
            x = 1;
            y = 1;
            size = 100;
            speedX = size/2;
            speedY = size/2;
        } else {
            size = 20;
            speedX = size/2;
            speedY = size/2;
        }
    });

    window.addEventListener('contextmenu',function(e) {
        clearCanvas();
        x = 1;
        y = 1;
        size = 200;
        speedX = size/2;
        speedY = size/2;
        e.preventDefault();
    });