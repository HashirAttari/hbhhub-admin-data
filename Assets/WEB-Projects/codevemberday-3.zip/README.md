# #Codevember - Day 3

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/rOrgwe](https://codepen.io/giana/pen/rOrgwe).

Click on the canvas to toggle between large and small circles. Right click for polkadots.

Something quick and messy while I try catching up on NaNoWriMo.