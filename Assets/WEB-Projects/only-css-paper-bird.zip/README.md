# Only CSS: Paper Bird

A Pen created on CodePen.io. Original URL: [https://codepen.io/YusukeNakaya/pen/BwBgvq](https://codepen.io/YusukeNakaya/pen/BwBgvq).

Someday, I want to fly in the sky, like bird.