# Audio Visualizer 4 (vanilla JS)

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/qBqzedW](https://codepen.io/franksLaboratory/pen/qBqzedW).

