let hex = document.querySelector('.hex'),
    circle = document.querySelector('.circle'),
    circles = document.querySelector('.circles');

function updateColor() {
  let valid = /^#([0-9A-F]{3}){1,2}$/i.test('#'+hex.innerText);
  circle.style.background = valid ? '#'+hex.innerText : '';
  hex.classList = valid ? 'hex valid' : 'hex';
}

function submitColor() {
  hex.classList = 'hex submit';
  circles.classList.add('submit');
  circles.querySelectorAll('.circle').forEach(circle => {
    circle.style.background = '#'+hex.innerText;
  })
}