# Snowflake

A Pen created on CodePen.io. Original URL: [https://codepen.io/waldo/pen/jZRrVe](https://codepen.io/waldo/pen/jZRrVe).

The last snowflake dance, creative  processing perfect loop with pure css