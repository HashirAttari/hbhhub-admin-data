function convertURL(url){
  var foundQuest=false,tmpStr="",params=[];
  for (var i=0;i<url.length;i++){
    if (url[i]=='?'){foundQuest=true;}
    else if (foundQuest){
      if (url[i]=='/'){
        params.push(tmpStr);
        tmpStr="";
      }else{
        tmpStr+=url[i];
      }
    }
  }
  params.push(tmpStr);
  return params;
}

function redirect(params) {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var doc=JSON.parse(this.responseText);
      var url="https://www.reddit.com"+doc[0].data.children[0].data.permalink+params[1]+(params.length==3?"?context="+params[2]:"");
      //document.getElementById("link").href=url;
      window.location.href=url;
    }
  };
  xhttp.open("GET", "https://www.reddit.com/comments/"+params[0]+"/.json", true);
  xhttp.send();
}

var url=window.location.href;
if (url.includes("?")){
  redirect(convertURL(url));
}