# Outline-to-Fill Tab Icon Animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/rNbeEXg](https://codepen.io/jkantner/pen/rNbeEXg).

A mobile tab bar where outlined icons become solid and are even animated.