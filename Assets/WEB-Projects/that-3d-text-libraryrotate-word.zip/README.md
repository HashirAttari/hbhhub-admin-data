# That 3D Text Library - Rotate word

A Pen created on CodePen.io. Original URL: [https://codepen.io/ste-vg/pen/jOvdMRZ](https://codepen.io/ste-vg/pen/jOvdMRZ).

