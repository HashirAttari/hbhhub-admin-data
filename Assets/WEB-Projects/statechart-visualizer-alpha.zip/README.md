# Statechart Visualizer (Alpha)

A Pen created on CodePen.io. Original URL: [https://codepen.io/davidkpiano/pen/ayWKJO](https://codepen.io/davidkpiano/pen/ayWKJO).

This is an alpha version of a finite state machine and statechart visualizer based on my [XState library](https://github.com/davidkpiano/xstate) and Cytoscape.