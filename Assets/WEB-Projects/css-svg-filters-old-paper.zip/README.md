# CSS SVG Filters / Old Paper

A Pen created on CodePen.io. Original URL: [https://codepen.io/enebene/pen/eYaNgNW](https://codepen.io/enebene/pen/eYaNgNW).

