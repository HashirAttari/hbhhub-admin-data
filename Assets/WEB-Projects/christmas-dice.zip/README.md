# Christmas Dice 🎄

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/poEEybN](https://codepen.io/run-time/pen/poEEybN).

