let rolls = 0
let wins = 0
const die = document.querySelector('.wrap')
const cube = document.querySelector('.cube')
const score = document.querySelector('.score')
const title = document.querySelector('.title')
const randNum = () => Math.floor(Math.random() * 6) + 1
const coinHead = () => Math.random() < 0.5
const hideConfetti = () => {
    let daC = document.getElementById('daConfetti')
    if (daC){daC.remove()}
}
const showConfetti = () => {
    (()=>{hideConfetti(); let h=42;let d=(n)=>Math.floor(Math.random()*n);let k=(c)=>{let s=document.createElement('style');s.id='daConfetti';if(!!(window.attachEvent && !window.opera)){s.styleSheet.cssText=c;}else{s.appendChild(document.createTextNode(c));}document.getElementsByTagName('head')[0].appendChild(s);};k('@keyframes u{0%{transform:rotate(0deg);}25%{transform:rotate(10deg);}50%{transform:rotate(0deg);}75%{transform:rotate(-10deg);}100%{transform:rotate(0deg);}};');k('@keyframes m{0%{margin-top:2vh;opacity:0;transform:rotateX(-80deg)}20%{opacity:1.0;margin-top:0vh;margin-left:0vw;transform:rotateX(0deg) rotate('+d(360)+'deg);}100%{opacity:0.4;margin-top:100vh;margin-left:'+d(4)+'vw;transform:rotateX(440deg) rotate(1080deg);}};');let w=document.createElement('div');w.id='daWorld';w.style='animation:u 60s ease-in infinite;position:fixed;top:0;right:0;bottom:0;left:0;pointer-events:none;';document.body.appendChild(w);while(h--){let o=document.createElement('div');o.style=`pointer-events:none;opacity:0;animation:m ${d(4)+6}s ease-in ${d(4000)}ms infinite;z-index:1000;position:fixed;top:${d(40)}vh;left:${d(100)}vw;font-size:${d(20)+10}px;color:${['#7CE','#5AD','#368DDA','#ACE','#DEF'][d(5)]};`;o.innerHTML=['❃','❄','❅','❆','❇','❈','❉','❊','❋'][d(9)];w.appendChild(o);}})()
}

const checkWin = () => {
    // if (die.classList.contains('twist5') && cube.classList.contains('show2')) {
    rolls++
    if (cube.classList.contains('show2')) {
        document.querySelector('.page').classList.remove('light')
        document.querySelector('.page').classList.add('dark')
        score.innerText = 'Winner!'
        score.classList.add('win')
        showConfetti()
        wins++
    } else {
        document.querySelector('.page').classList.remove('dark')
        document.querySelector('.page').classList.add('light')
    }
}
const final = () => {
    for (let i=1; i <= 6; i++) {
        die.classList.remove(`twist${i}`)
    }
    if (randNum() >= 2) {
        die.classList.add(`twist${randNum()}`)
    }
    die.classList.remove('bigger')
    die.classList.add('smaller')
    const nMap = [0,1,6,2,5,3,4]
    let num = parseInt(cube.classList.toString().replace('cube show',''))
    if (num) {
        score.innerText = nMap[num]
    }
    
    checkWin()
    title.innerText = `${rolls} rolls • ${wins} sixes`
}
const show = n => {
    for (let i=1; i <= 6; i++) {
        cube.classList.remove(`show${i}`)
    }
    
    let rn = n || randNum()
    
    cube.classList.add(`show${rn}`)
}
const pick = () => {
  let timer = setInterval(show, 200)
  setTimeout(function(){ clearInterval(timer); final(); }, 400 )
}
const roll = () => {
  hideConfetti()
  document.querySelector('.page').classList.remove('dark')
  document.querySelector('.page').classList.add('light')
  cube.classList.remove(`grabbing`)
  
  let tPos = 200
  
    setTimeout(()=>{show(1)}, tPos)
    tPos += 200
    setTimeout(()=>{show(2)}, tPos)
    tPos += 200
    setTimeout(()=>{show(3)}, tPos)
    tPos += 200
  
  if (coinHead()) {
    setTimeout(()=>{show(2)}, tPos)
    tPos += 200
    setTimeout(()=>{show(4)}, tPos)
    tPos += 200
  }
  
  if (coinHead()) {
    setTimeout(()=>{show(6)}, tPos)
    tPos += 200
    setTimeout(()=>{show(5)}, tPos)
    tPos += 200
  }
  
  setTimeout(()=>{pick()}, tPos)
}

const updateCursor = () => {
  for (let i=1; i <= 6; i++) {
    die.classList.remove(`twist${i}`)
  }
  cube.classList.add(`grabbing`)
  die.classList.remove('smaller')
  die.classList.add('bigger')
  score.innerText = ''
  hideConfetti()
}

function init() {
    document.querySelector('.page').classList.add('light');
    die.addEventListener('mousedown', updateCursor);
    die.addEventListener('mouseup', roll);    
}

init();