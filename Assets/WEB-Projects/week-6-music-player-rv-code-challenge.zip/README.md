# Week #6 :: Music Player :: RV Code Challenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/QNwPyq](https://codepen.io/mselmany/pen/QNwPyq).

A music player.

My take on the 6th week of the RV Code Challenge.

Dribbble: https://dribbble.com/shots/2320171-Daily-UI-009-Music-Player

More information about these challenges at http://codepen.io/team/RedVentures/post/weekly-code-challenge/

Mirror: http://lab.islegend.com/challenge/music-player/

Forked from [Alex Fernandez](http://codepen.io/alexfislegend/)'s Pen [Week #6 :: Music Player :: RV Code Challenge](http://codepen.io/alexfislegend/pen/NGZZep/).