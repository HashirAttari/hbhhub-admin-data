# CSS-Only Mac Keyboard

A Pen created on CodePen.

Original URL: [https://codepen.io/nourabusoud/pen/rwKKEP](https://codepen.io/nourabusoud/pen/rwKKEP).

A simple Mac Keyboard using Haml and Sass, I dunno if this is the best approach but I never used Haml before and decided to try it out this time.

Used the colors for the keyboard from: https://codepen.io/januff/pen/NxNLJJ