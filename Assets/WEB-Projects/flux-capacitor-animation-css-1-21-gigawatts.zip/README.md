# Flux Capacitor (Animation, CSS) | ⚡️ 1.21 GIGAWATTS! ⚡️ 

A Pen created on CodePen.io. Original URL: [https://codepen.io/konstantindenerz/pen/yLxpjYz](https://codepen.io/konstantindenerz/pen/yLxpjYz).

This Flux Capacitor pen demonstrates some CSS features like animations, SVG path's d-prop animation, @property rule, conic-gradient, clip-path and inset: 0.
Be careful you need 1.21 gigawatts!