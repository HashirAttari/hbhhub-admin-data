# Button slide

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/VGQoaX](https://codepen.io/aaroniker/pen/VGQoaX).

Button for an action that requires a exceptional confirmation.