# Polaroid memories

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/KKGZGLW](https://codepen.io/havardob/pen/KKGZGLW).

My take on this week's challenge