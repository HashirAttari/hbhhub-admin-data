# Magic Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/omrandmax/pen/ExEMQpb](https://codepen.io/omrandmax/pen/ExEMQpb).

Yet another glowing card