# 3D Movement Responsive Popup

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/myORwz](https://codepen.io/mselmany/pen/myORwz).

A 3D popup message that follows the user's mouse movements.
Made in CSS3 + jQuery.

UPDATE : simplified the JS code by using a pseudo-element for the popup's shadow.

Forked from [Marc Malignan](http://codepen.io/MarcMalignan/)'s Pen [3D Movement Responsive Popup](http://codepen.io/MarcMalignan/pen/xByvJ/).