# Matrix Console en JavaScript

A Pen created on CodePen.io. Original URL: [https://codepen.io/locoalien/pen/AWWOJv](https://codepen.io/locoalien/pen/AWWOJv).

Simulacion de la consola de Matrix Creado con JavaScript y HTML5