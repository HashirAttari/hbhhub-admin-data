var date = new Date().getDate();
const d = new Date(Date.now());
let month_year = d.toLocaleString('en-US', {month: 'short', year: 'numeric'});

const cal = document.querySelector('#calendar')
const mon = document.querySelector('#month')
let nbOfDaysInCurrentMonth = new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth()+1, 1)).getDate() + 2

var dayOfTheWeek = (i) => {
  var date = new Date()
  var day_of_week = new Date(date.getFullYear(), date.getMonth(), 1 + i).toLocaleString('en-us', {  weekday: 'short' })
  return day_of_week
};

function getTime() {
  var today = new Date();
  var hour = today.getHours();
  if(hour > 12) {
    hour = hour - 12
  }
  var minute = today.getMinutes();
  var second = today.getSeconds();

  return hour + ":" + minute.toString().padStart(2, "0") + ":" + second.toString().padStart(2, "0");
}

var slice_width = 360 / nbOfDaysInCurrentMonth
for(var i=0;i<nbOfDaysInCurrentMonth - 2;i++){
  var s = document.createElement('div')
  s.className = 'slice'

  s.dataset.day = i + 1
  s.style.width = slice_width + '%'
  s.style.transform = 'translateX(-50%) rotate('+((slice_width*i)+slice_width)+'deg)'    

  if(i + 1 == date) {
    s.className = 'slice today'
    s.style.width = slice_width*3 + '%'
    s.style.transform = 'translateX(-50%) rotate('+((slice_width*i)+slice_width*2)+'deg)'
    s.onclick = function(){
      let r = (slice_width*(this.dataset.day)) + 360
      cal.style.transform = 'rotate(-'+(r+slice_width)+'deg)'
      mon.style.transform = 'translate(-50%,-50%) rotate('+(r+slice_width)+'deg)'
    }
  }
  if(i + 1 > date) {
    s.style.transform = 'translateX(-50%) rotate('+((slice_width*i)+slice_width*3)+'deg)'
  }

  var day = dayOfTheWeek(i)
  s.innerHTML += `<span data-day='${day}'>${day}</span><strong> ${(i+1)} </strong>` 
  cal.appendChild(s)
}

let lon;
let lat;

var c_temp;
if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition((position) => {
    // console.log(position);
    lon = position.coords.longitude;
    lat = position.coords.latitude;

    // API ID
    const api = "6d055e39ee237af35ca066f35474e9df";

    // API URL
    const base =
          `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&` +
          `lon=${lon}&appid=6d055e39ee237af35ca066f35474e9df`;

    // Calling the API
    fetch(base)
      .then((response) => {
      return response.json();
    })
      .then((data) => {
      // console.log(data);
      if(data){
        mon.querySelector('div').innerHTML += Math.round(((data.main.temp-273.15)*1.8)+32) + '°F<i>' + data.weather[0].main + '<i>'
      }      
    });
  });  
}

mon.innerHTML = '<div>'+ month_year.split(' ')[0] + '<strong> ' + month_year.split(' ')[1] + '</strong><hr><span></span></div>' 

setInterval(function(){
  document.documentElement.style.setProperty("--time", "'" + getTime() + "'");
}, 1000)

document.querySelector('.today').click()

function addColorPicker() {
  const colors = ['red','darkorange','goldenrod','limegreen','dodgerblue','Purple','violet','magenta']
  for(var i=0;i<colors.length;i++) {
    var s = document.createElement('div')
    s.className = 'swatch'
    s.dataset.clr = colors[i]
    s.style.background = colors[i]
    s.style.width = '30px'
    s.style.height = '30px'
    s.style.marginBottom = '.5rem'
    s.style.cursor = 'pointer'
    s.style.borderRadius = '50%'
    s.onclick = function(){
      document.documentElement.style.setProperty("--accent-clr", this.dataset.clr);
    }
    document.body.appendChild(s)
  }
}
addColorPicker()