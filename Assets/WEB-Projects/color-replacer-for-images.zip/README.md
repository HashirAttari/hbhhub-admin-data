# Color Replacer For Images

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/BjjJbE](https://codepen.io/leenalavanya/pen/BjjJbE).

