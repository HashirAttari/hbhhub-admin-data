var c = document.getElementById("myCanvas");
var ctx = c.getContext("2d");
var newRed = 0;
var newGreen = 0;
var newBlue = 0;

window.onload = function() {
	var fileInput = document.getElementById('myFile');
	var fileDisplayArea = document.getElementById('my');
	fileInput.onchange = function(e) {
		var file = fileInput.files[0];
		var reader = new FileReader();
		reader.onload = function(e) {
			fileDisplayArea.src = "";
			var img = fileDisplayArea;
			img.src = reader.result;
			
			ctx.clearRect(0, 0, c.width, c.height);
			var img = document.getElementById('my');
			ctx.drawImage(img, 0, 0, c.width, c.height);
		}
		reader.readAsDataURL(file);
	};
}

function myFunction(event) {
	var x = event.clientX - c.parentNode.offsetLeft;
	var y = event.clientY - c.parentNode.offsetTop;
	var imgData = ctx.getImageData(x, y, x + 0.1, y + 0.1);
	red = imgData.data[0];
	green = imgData.data[1];
	blue = imgData.data[2];
	if (red > 125 && green > 125 && blue > 125) {
		document.getElementById('demo').style.color = "black"
	} else {
		document.getElementById('demo').style.color = "white"
	}
	document.getElementById('demo').style.background = "rgb(" + red + "," + green + "," + blue + ")";
	document.getElementById('demo').innerHTML = "rgb(" + red + "," + green + "," + blue + ")<br/>" + rgbToHex(red, green, blue).toUpperCase();

	var imgd = ctx.getImageData(0, 0, c.width, c.height);
	var i;
	for (i = 0; i < imgd.data.length; i += 4) {
		if (imgd.data[i] < (red + 10) && imgd.data[i] > (red - 10) && imgd.data[i + 1] < (green + 10) && imgd.data[i + 1] > (green - 10) && imgd.data[i + 2] < (blue + 10) && imgd.data[i + 2] > (blue - 10)) {
			imgd.data[i] = newRed;
			imgd.data[i + 1] = newGreen;
			imgd.data[i + 2] = newBlue;
		}
	}
	ctx.putImageData(imgd, 0, 0);
}

function newColor(a) {
	newRed = hexToRgb(a).r;
	newGreen = hexToRgb(a).g;
	newBlue = hexToRgb(a).b;
}

function componentToHex(c) {
	var hex = c.toString(16);
	return hex.length == 1 ? "0" + hex : hex;
}

function rgbToHex(r, g, b) {
	return "#" + componentToHex(r) + componentToHex(g) + componentToHex(b);
}

function hexToRgb(hex) {
	var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
	return result ? {
		r: parseInt(result[1], 16),
		g: parseInt(result[2], 16),
		b: parseInt(result[3], 16)
	} : null;
}