# Pure CSS Russian Bears 🐻😎

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/jOOYMLm](https://codepen.io/jh3y/pen/jOOYMLm).

Been sitting on this one a while 😅

Had a thought ages ago about if it was possible to create pure CSS Russian dolls. Finally got round to exploring it and here it is!

I give you pure CSS Russian bears. Powered by SVG and CSS variables 😉
Randomly generated markup allows you to define how many bears are created. You can adjust the scales etc. via the `:root` CSS variables 👍

Enjoy!