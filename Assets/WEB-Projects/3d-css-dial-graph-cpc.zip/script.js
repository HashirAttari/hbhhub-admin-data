import { GUI } from "https://cdn.skypack.dev/dat.gui"
const gui = new GUI();

const minValue = 0;
const maxValue = 99;
const step = 1;

const data = {
  value: 30,
}

gui.add(data, 'value', minValue, maxValue, step).name('Value').onChange(updateData);

const dial = document.querySelector('.dial')
function updateData() {
  const newValue = (data.value - minValue) / (maxValue - minValue);
  dial.style.setProperty('--value', newValue);
  dial.style.setProperty('--textValue', data.value);
}

updateData();