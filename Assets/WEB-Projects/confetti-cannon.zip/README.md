# Confetti Cannon

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/dybxGrb](https://codepen.io/run-time/pen/dybxGrb).

Click, drag & release to shoot canvas confetti particles. Uses the GreenSock Physics2d plugin.