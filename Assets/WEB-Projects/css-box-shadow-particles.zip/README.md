# CSS box shadow particles

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/JGdbje](https://codepen.io/giana/pen/JGdbje).

One div, a thousand box shadows, and a very loud CPU fan.

Play with the options in the Sass maps. You can get completely different animations by changing a couple of numbers.

A more flexible version of my <a href="http://codepen.io/giana/pen/rxVNKx">CSS box shadow animation</a>. Box-shadow idea from <a href="https://css-tricks.com/css-animation-tricks/">CSS Animation Tricks</a>.