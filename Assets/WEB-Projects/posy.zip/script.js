document.addEventListener('click', function(e) {
  doodle && doodle.update(); 
});