# Scroll-animation query styling

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/XWGyRbL](https://codepen.io/giana/pen/XWGyRbL).

