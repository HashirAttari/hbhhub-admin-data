# Eye Balls with no overlap

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/eYYgBqx](https://codepen.io/franksLaboratory/pen/eYYgBqx).

