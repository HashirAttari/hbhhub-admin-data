// convert screen coords to svg coords
function coordinateTransform(screenPoint, svgObject) {
  var CTM = svgObject.getScreenCTM();
  return screenPoint.matrixTransform(CTM.inverse());
}

$(function() {
  var mDown = false;
  var svg = document.getElementById("zipper");
  var pt = svg.createSVGPoint();
  var sTop = 0;
  var sOffset = 0;

  $("#slider").mousedown(function(e) {
    mDown = true;
    sOffset = e.clientY - sTop;
  });

  $(document).mouseup(function() {
    mDown = false;
  });

  $(document).mousemove(function(e) {
    if (mDown) {
      sTop = Math.min(
        Math.max(e.clientY - sOffset, 0),
        $("#zipper").height() - $("#slider")[0].getBoundingClientRect().height
      );
      pt.y = sTop;

      var y = coordinateTransform(pt, svg).y;

      $("#gear-left").css({
        transform: "translateY(" + y + "px) rotate(" + -y / 10 + "deg)"
      });
      $("#slider").css({ transform: "translateY(" + y + "px)" });
      $("#gear-clip").attr("height", y + 50);
      $("#teeth-clip").attr("y", y + 40);
    }
  });

  document.getElementById("slider").addEventListener(
    "touchstart",
    function(e) {
      mDown = true;

      e.preventDefault();
      var touches = e.changedTouches;
      sOffset = touches[0].clientY - sTop;
    },
    false
  );

  document.addEventListener(
    "touchend",
    function(e) {
      e.preventDefault();
      mDown = false;
    },
    false
  );

  document.addEventListener(
    "touchmove",
    function(e) {
      if (mDown) {
        e.preventDefault();
        var touches = e.changedTouches;

        sTop = Math.min(
          Math.max(touches[0].clientY - sOffset, 0),
          $("#zipper").height() - $("#slider")[0].getBoundingClientRect().height
        );
        pt.y = sTop;

        var y = coordinateTransform(pt, svg).y;

        $("#gear-left").css({
          transform: "translateY(" + y + "px) rotate(" + -y / 10 + "deg)"
        });
        $("#slider").css({ transform: "translateY(" + y + "px)" });
        $("#gear-clip").attr("height", y + 50);
        $("#teeth-clip").attr("y", y + 40);
      }
    },
    false
  );
});