# Zipper

A Pen created on CodePen.io. Original URL: [https://codepen.io/mlho/pen/pOdxVq](https://codepen.io/mlho/pen/pOdxVq).

A zipping SVG zipper. Try clicking and dragging the zipper up and down! Now supports touch!