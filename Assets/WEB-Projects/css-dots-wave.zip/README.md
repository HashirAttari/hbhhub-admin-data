# CSS Dots wave

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/vYpZBwP](https://codepen.io/amit_sheen/pen/vYpZBwP).

