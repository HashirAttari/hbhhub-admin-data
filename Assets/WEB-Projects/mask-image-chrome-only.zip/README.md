# Mask-image (Chrome only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/BadmWeL](https://codepen.io/yuanchuan/pen/BadmWeL).

