# CSS "Ripple/Wave" checkbox and radio button

A Pen created on CodePen.io. Original URL: [https://codepen.io/msisto/pen/DKjeVX](https://codepen.io/msisto/pen/DKjeVX).

Animate the checking and the unchecking, using SASS and Bourbon.