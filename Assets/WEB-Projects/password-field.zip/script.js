const pathClosed = "M2 10.5C2 10.5 6.43686 15.5 10.5 15.5C14.5631 15.5 19 10.5 19 10.5";

function extractNumbers(path) {
  const regex = /(\d+\.\d+|\d+)/g;
  return (path.match(regex) || []).map(parseFloat);
}

function morphPath(fromPath, toPath, duration, callback) {
  const fromNumbers = extractNumbers(fromPath);
  const toNumbers = extractNumbers(toPath);
  const template = fromPath.replace(/(\d+\.\d+|\d+)/g, "{}");

  let startTime;

  function animate(timestamp) {
    if (!startTime) startTime = timestamp;
    const elapsedTime = timestamp - startTime;
    const progress = Math.min(elapsedTime / duration, 1);

    const currentNumbers = fromNumbers.map((startNum, index) => (startNum + (toNumbers[index] - startNum) * progress));
    const currentPath = template.split("{}").reduce((acc, part, index) => acc + part + (currentNumbers[index] || ""), "");

    callback(currentPath);

    if (progress < 1) requestAnimationFrame(animate);
  }

  requestAnimationFrame(animate);
}

document.querySelectorAll('.password-field').forEach(field => {
  const input = field.querySelectorAll('input');
  const button = field.querySelector('button');
  const pathElement = field.querySelector('svg .top');
  const pathOpen = pathElement.getAttribute('d');

  button.addEventListener('click', e => {
    if(field.classList.contains('show')) {
      field.classList.remove('show')
      morphPath(pathClosed, pathOpen, 200, (morphedPath) => {
        pathElement.setAttribute('d', morphedPath);
      })
      return
    }
    field.classList.add('show')

    morphPath(pathOpen, pathClosed, 200, (morphedPath) => {
      pathElement.setAttribute('d', morphedPath);
    })
  })

  field.addEventListener('pointermove', e => {
    const rect = button.getBoundingClientRect()
    const fullWidth = rect.width
    const halfWidth = fullWidth / 2
    const fullHeight = rect.height
    const halfHeight = fullHeight / 2
    let x = e.clientX - rect.left - halfWidth,
        y = e.clientY - rect.top - halfHeight

    field.style.setProperty('--eye-x', (x < -halfWidth ? -halfWidth : x > fullWidth ? fullWidth : x) / 15 + 'px')
    field.style.setProperty('--eye-y', (y < -halfHeight ? -halfHeight : y > fullHeight ? fullHeight : y) / 25 + 'px')
  })
  field.addEventListener('pointerleave', e => {
    field.style.setProperty('--eye-x', '0px')
    field.style.setProperty('--eye-y', '0px')
  })
  input.forEach(single => single.addEventListener('input', e => input.forEach(i => i.value = e.target.value)))
})