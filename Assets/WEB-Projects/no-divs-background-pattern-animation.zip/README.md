# No-divs background pattern animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/zYJzLoy](https://codepen.io/amit_sheen/pen/zYJzLoy).

