// Pure CSS ❤️
// Staggered CSS Animation on Page Load Guide: https://youtu.be/8AmccR91d80
// Animate HTML Details Guide: https://youtu.be/idoaw75xjhU