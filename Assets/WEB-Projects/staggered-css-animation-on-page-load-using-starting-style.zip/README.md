# Staggered CSS Animation on Page Load using @starting-style 

A Pen created on CodePen.io. Original URL: [https://codepen.io/ZoranJambor/pen/eYaEwez](https://codepen.io/ZoranJambor/pen/eYaEwez).

A demo for a guide on creating animated HTML Details element, and a staggered CSS transition/animation on page load. 

Staggered CSS Animation on Page Load Guide: https://youtu.be/8AmccR91d80
 Animate HTML Details Guide: https://youtu.be/idoaw75xjhU