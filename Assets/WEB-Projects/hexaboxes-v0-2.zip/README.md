# HexaBoxes v0.2

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/abwBVJK](https://codepen.io/amit_sheen/pen/abwBVJK).

