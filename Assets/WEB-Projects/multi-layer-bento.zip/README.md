# multi-layer bento

A Pen created on CodePen.io. Original URL: [https://codepen.io/mugosagi/pen/MWLmpqP](https://codepen.io/mugosagi/pen/MWLmpqP).

