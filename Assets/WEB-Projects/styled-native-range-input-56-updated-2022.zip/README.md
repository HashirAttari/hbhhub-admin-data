# Styled native range input #56 (updated 2022)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/PwaGLM](https://codepen.io/thebabydino/pen/PwaGLM).

**March 2022 update**

Major changes:

* got rid of Compass and Modernizr dependencies, neither of which was needed anymore anyway

* ditched the 1 element restriction in order to get a better, cross-browser and more accessible result; as a result of this plus adding configuration CSS variables, the HTML has gone from 225 bytes to a little over 900 bytes, but this is more than compensated by the now much simpler and lighter compiled CSS and JS

* since I now know how to code a multi thumb slider (see my [article](https://css-tricks.com/multi-thumb-sliders-particular-two-thumb-case/) on CSS-Tricks for details), I added that feature to match the design too (the original 2015 version only had a single handle for all sliders, even though the original design showed two handles for the second one)

* ditched `absolute` positioning in favour of using a `grid` layout now; the look of it adapts nicely for various viewport sizes

* used smarter gradient techniques for the slider thumb and fill/ progress/ range highlight to better reproduce the design; I avoided the CSS-only route for the single handle sliders in Firefox via `-moz-range-progress` because the way that works would make implementing this design in particular incredibly hacky (and the result probably won't look as good as with the teeny tiny little bit of JS that I'm currently using)

* cleaned up the CSS and made it more maintainable by using CSS variables and the DRY switching technique, explained in this two part article I wrote for CSS-Tricks: [part one](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) and [part two](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/); overall, this has meant shrinking the compiled CSS from  almost 12.75kB to under 6.35kB - that is, to less than half of what it was before, in spite of now having much higher fidelity in reproducing the design

* got rid of the convoluted JS that was adding the fill/ progress/ range highlight and switched to a simpler method based on CSS variables (thus reduced the JS by more than 90% of what it was before, from over 1.35kB to just 150 bytes, in spite of also spicing things up with some extra functionality)

* made it degrade gracefully in the no JS case (the  backgrounds of the wrappers' `::after` pseudos that are used to create the range highlights have their size zeroed in the no JS case since the values they depend on don't get updated anyway)

* added `:focus-within`/ `:focus`/ `:hover` styles

* ensured it now behaves consistently in Chromium browsers, Firefox and Safari

* not providing free IE/ pre-Chromium support anymore

Expected result/ result in Chromium/ Firefox:

![screenshot with all sliders in focus](https://assets.codepen.io/2017/internal/screenshots/pens/PwaGLM.custom.png?version=1647169261)

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 36, 39 (nightly), Chrome 40, 43 (canary)/ Opera 28, IE 11 on Windows 8. Fallback for no JS: simply display the same background, both before and after the thumb.

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found.

Original design from Shutterstock: [UI Sliders, Item ID 109578587](https://www.shutterstock.com/image-vector/ui-sliders-set-vector-109578587)

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 