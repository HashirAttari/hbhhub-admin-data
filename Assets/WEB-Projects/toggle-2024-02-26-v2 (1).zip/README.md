# Toggle 2024-02-26 (v2)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/WNWQzEa](https://codepen.io/alvaromontoro/pen/WNWQzEa).

