# Office

A Pen created on CodePen.io. Original URL: [https://codepen.io/jackiezen/pen/ddgGyP](https://codepen.io/jackiezen/pen/ddgGyP).

Click anywhere on the screen first in order to hear the sounds!

Drawn and animated completely in CSS (except for the pictures).
Sounds are triggered in the JS.