# CSS box shadow particles v5

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/wMaNGW](https://codepen.io/giana/pen/wMaNGW).

Same as <a href="http://codepen.io/giana/pen/JGdbje">the first version</a>, only with different numbers.