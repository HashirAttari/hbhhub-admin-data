# Check Done SVG Animated

A Pen created on CodePen.io. Original URL: [https://codepen.io/bernethe/pen/gOJrgqq](https://codepen.io/bernethe/pen/gOJrgqq).

