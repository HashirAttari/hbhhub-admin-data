# CSS scroll-driven animation timer

A Pen created on CodePen.io. Original URL: [https://codepen.io/hexagoncircle/pen/dyrooOq](https://codepen.io/hexagoncircle/pen/dyrooOq).

Alternate version of page-timer component used on <a href="https://ryanmulligan.dev">ryanmulligan.dev</a> blog posts (where supported)