# Animated CheckBox with Sound Effect 🔊

A Pen created on CodePen.io. Original URL: [https://codepen.io/visnuravichandran/pen/dyMRqMy](https://codepen.io/visnuravichandran/pen/dyMRqMy).

Animated CheckBox with some sound effect as a part of the #codethisdesign Challenge

https://twitter.com/Iamkailashb/status/1299691579800608768



