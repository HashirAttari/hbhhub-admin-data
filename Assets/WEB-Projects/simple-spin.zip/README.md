# Simple Spin

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/WEaeRZ](https://codepen.io/giana/pen/WEaeRZ).

