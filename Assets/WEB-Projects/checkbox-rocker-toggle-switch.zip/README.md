# Checkbox Rocker Toggle Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/marcusconnor/pen/QJNvMa](https://codepen.io/marcusconnor/pen/QJNvMa).

An HTML checkbox form element styled as a rocker toggle switch.