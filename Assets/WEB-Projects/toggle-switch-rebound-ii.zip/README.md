# Toggle Switch: Rebound (II)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/BabdORd](https://codepen.io/alvaromontoro/pen/BabdORd).

A toggle switch component coded with a single HTML element and CSS. No JS or external images.

Inspired by: https://dribbble.com/shots/889439-Toggle-Rebound/attachments/8564956?mode=media