# Accordion 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/SteliosBox/pen/VzPMKy](https://codepen.io/SteliosBox/pen/VzPMKy).

