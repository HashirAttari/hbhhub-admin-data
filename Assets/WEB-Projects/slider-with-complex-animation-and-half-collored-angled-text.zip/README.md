# Slider with complex animation and half-collored angled text

A Pen created on CodePen.io. Original URL: [https://codepen.io/mrspok407/pen/YWLqVo](https://codepen.io/mrspok407/pen/YWLqVo).

