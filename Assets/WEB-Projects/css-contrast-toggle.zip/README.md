# CSS Contrast Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/vYKVNEo](https://codepen.io/benhatsor/pen/vYKVNEo).

Click to toggle.