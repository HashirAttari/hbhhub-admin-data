# INFINITE VIRUS

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/qBOWjRm](https://codepen.io/MananTank/pen/qBOWjRm).

It looks like number of dots is quadrupling every 2 seconds, like a virus. Actually, the number of dots is constant. This illusion is created by animating in a  way such that two consecutive animation cycles transition seamlessly. uncomment the background-repeat property to see the building block of this effect.