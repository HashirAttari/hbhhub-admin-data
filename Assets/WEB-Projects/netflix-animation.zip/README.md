# NETFLIX animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/KKpRJed](https://codepen.io/MananTank/pen/KKpRJed).

