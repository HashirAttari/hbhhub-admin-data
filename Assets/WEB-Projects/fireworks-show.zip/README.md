# Fireworks Show

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/adjEeY](https://codepen.io/leenalavanya/pen/adjEeY).

150 divs, in different colors, speeds and directions.

No Libraries, no preprocessors, no images.