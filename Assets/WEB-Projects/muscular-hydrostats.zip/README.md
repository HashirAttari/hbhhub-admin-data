# Muscular Hydrostats

A Pen created on CodePen.io. Original URL: [https://codepen.io/soulwire/pen/DZYRgY](https://codepen.io/soulwire/pen/DZYRgY).

Tentacle simulation using inverse kinematics