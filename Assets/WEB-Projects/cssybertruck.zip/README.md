# CSSYBERTRUCK

A Pen created on CodePen.io. Original URL: [https://codepen.io/davidkpiano/pen/gOOJyGz](https://codepen.io/davidkpiano/pen/gOOJyGz).

A 3D CSS-only version of the very polygonal Tesla Cybertruck.

Click the windows for a surprise.

Works best in Chrome/Edge.