# 100 Divs 100 Colors

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/JjXvJYx](https://codepen.io/run-time/pen/JjXvJYx).

Doing each codepen challenge without changing the original HTML