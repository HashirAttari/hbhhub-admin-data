# Background patterns

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/xxEXwZw](https://codepen.io/yuanchuan/pen/xxEXwZw).

https://yuanchuan.dev/how-to-make-seamless-patterns