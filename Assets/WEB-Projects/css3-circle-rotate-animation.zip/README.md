# CSS3 Circle Rotate Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/naoyashiga/pen/kNNMxE](https://codepen.io/naoyashiga/pen/kNNMxE).

using border-top,bottom,right,left and animation