# Flat Design template

A Pen created on CodePen.io. Original URL: [https://codepen.io/slimsmearlapp/pen/DRZGZq](https://codepen.io/slimsmearlapp/pen/DRZGZq).

Hey this is a design template im working on. The design doesn't come from me, the original design comes from an image : http://d.pr/i/ZEmZ , and, as i mentioned, it is NOT mine. I really love that design and I hope the actual designer doesn't mind me designing his idea. I just wanted to see if I could do something like this in CSS. I won't use this design in any project or in any commercial use. 