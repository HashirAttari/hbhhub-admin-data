# CSS Border transitions

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/yYBpVY](https://codepen.io/giana/pen/yYBpVY).

UPDATE:

Here are some useful mixins to help you create & customize your own buttons:

<ol>
<li><a href="https://codepen.io/giana/pen/WjXEMo">Draw</a>
<li><a href="https://codepen.io/giana/pen/xdXpJB">Draw meet</a>
</ol>

Check out <a href="https://codepen.io/collection/AObpre/">my button collection</a> for more.