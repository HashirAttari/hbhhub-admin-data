# HTML5 Canvas animated clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/tarick/pen/jWOWOV](https://codepen.io/tarick/pen/jWOWOV).

Animated HTML5 canvas clock 