# Minitel - Type something

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/NWGdxmd](https://codepen.io/ricardoolivaalonso/pen/NWGdxmd).

