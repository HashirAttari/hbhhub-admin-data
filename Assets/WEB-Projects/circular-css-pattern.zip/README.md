# Circular CSS pattern

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/NWLyrKo](https://codepen.io/t_afif/pen/NWLyrKo).

More CSS-only patterns: https://github.com/Afif13/CSS-Pattern