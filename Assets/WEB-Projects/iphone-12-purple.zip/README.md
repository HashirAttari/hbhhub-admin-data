# iPhone 12 purple

A Pen created on CodePen.io. Original URL: [https://codepen.io/ece_mina/pen/poRGeKO](https://codepen.io/ece_mina/pen/poRGeKO).

