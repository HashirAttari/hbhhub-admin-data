# Pure CSS Apple Watch 4 - For real

A Pen created on CodePen.io. Original URL: [https://codepen.io/equinusocio/pen/PoNYGGX](https://codepen.io/equinusocio/pen/PoNYGGX).

This is the first "For real" element made with just CSS after many years. Enjoy this Apple Watch 4 which reacts to the light.

Follow me on Twitter @equinusocio

https://twitter.com/equinusocio
