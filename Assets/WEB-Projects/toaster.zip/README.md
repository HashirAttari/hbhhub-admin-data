# Toaster

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/zYoOWmq](https://codepen.io/benhatsor/pen/zYoOWmq).

Toaster with [coco (CSS Orientation Controls)](https://github.com/benhatsor/coco) added.  Move around with keypad & drag to rotate.