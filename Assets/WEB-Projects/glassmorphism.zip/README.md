# Glassmorphism

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/qBqKGgM](https://codepen.io/yudizsolutions/pen/qBqKGgM).

Glassmorphism is a new trend in web design. we need to give a glass effect to the front(upper) element and give a spread effect to the back element. we use backdrop-filter and background-clip property for this glass effect.

Made by Shivangi Majithiya from Yudiz