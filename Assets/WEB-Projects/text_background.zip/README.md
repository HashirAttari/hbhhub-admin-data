# text_background

A Pen created on CodePen.io. Original URL: [https://codepen.io/Lo-La/pen/wvZxZvN](https://codepen.io/Lo-La/pen/wvZxZvN).

