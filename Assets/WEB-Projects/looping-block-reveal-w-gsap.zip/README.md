# Looping Block Reveal w/ GSAP ✨

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/rEPrOb](https://codepen.io/jh3y/pen/rEPrOb).

Ever wanted to create a looping block reveal effect?

Here it is!

Read the article: [HOW TO: Looping Block Reveal Effect](https://blog.prototypr.io/how-to-looping-block-reveal-effects-fcb9ded9c6f9)

Enjoy!