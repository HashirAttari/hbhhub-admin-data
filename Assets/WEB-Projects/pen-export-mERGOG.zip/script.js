function getSelect(){
  var text = "";
  text = window.getSelection().toString();
  alert(text);
}

function closeSG(){
  document.getElementById("sgoverlay").style.display="none";
}

    //<iframe src="https://duckduckgo.com/?q=stuff"></iframe>
    //<button onclick=getSelect()>Click</button>