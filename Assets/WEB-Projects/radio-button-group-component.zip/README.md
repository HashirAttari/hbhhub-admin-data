# Radio button group component

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/GRrOMMz](https://codepen.io/havardob/pen/GRrOMMz).

A common pattern for radio buttons nowadays is grouping them together in a tab-like way. This is an example of that 