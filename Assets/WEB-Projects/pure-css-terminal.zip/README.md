# Pure CSS Terminal

A Pen created on CodePen.io. Original URL: [https://codepen.io/shakdaniel/pen/OmZeJy](https://codepen.io/shakdaniel/pen/OmZeJy).

Testing my self by creating stuff with the least amount of HTML elements.