# Synchronized charts

A Pen created on CodePen.io. Original URL: [https://codepen.io/sparanoid/pen/OJRvGvO](https://codepen.io/sparanoid/pen/OJRvGvO).

