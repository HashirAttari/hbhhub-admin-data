# Mini-world 1

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/yLgEpmP](https://codepen.io/ricardoolivaalonso/pen/yLgEpmP).

