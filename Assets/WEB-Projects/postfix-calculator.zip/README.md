# Postfix Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/OJNNQOz](https://codepen.io/ykadosh/pen/OJNNQOz).

This is an old project of mine, resurrected from the dead :) 
I made this back in 2014, as I was learning about postfix notation in the university. This calculator uses postfix notation to compute the result of the expression given to it by the user. 

I kept the code as it is, so I apologize if it looks a bit outdated... :)

To read more about postfix notation, see https://en.wikipedia.org/wiki/Reverse_Polish_notation