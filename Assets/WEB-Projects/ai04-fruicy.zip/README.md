# AI04: Fruicy

A Pen created on CodePen.io. Original URL: [https://codepen.io/cjgammon/pen/eYLeJpL](https://codepen.io/cjgammon/pen/eYLeJpL).

Alien Interfaces: 04 - Designed by AI / ML with midjourney.  
See the process here: 
https://alieninterfaces.com/cases/fruicy.html