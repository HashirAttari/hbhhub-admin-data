# SVG Preloaders

A Pen created on CodePen.io. Original URL: [https://codepen.io/alexanderkwright/pen/gOEZMv](https://codepen.io/alexanderkwright/pen/gOEZMv).

Manipulating SVG paths using animation, rotation, and Sass.
Based off of the dribbble shot by David Urbinati here: http://drbl.in/mBsi