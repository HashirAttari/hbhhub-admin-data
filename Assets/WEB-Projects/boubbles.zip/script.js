const $els = Array.from(document.querySelectorAll('.inner'));

setInterval(() => {
  $els[Math.floor(Math.random() * $els.length)].classList.toggle('a');
  $els[Math.floor(Math.random() * $els.length)].classList.remove('b');
  $els[Math.floor(Math.random() * $els.length)].classList.remove('c');
}, 50);
setInterval(() => {
  $els[Math.floor(Math.random() * $els.length)].classList.toggle('b');
}, 550);
setInterval(() => {
  $els[Math.floor(Math.random() * $els.length)].classList.toggle('c');
}, 550);