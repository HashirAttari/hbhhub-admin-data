# Trending Web Projects Grid

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/bGpdVLq](https://codepen.io/ykadosh/pen/bGpdVLq).

A CSS grid layout showing the most trending open-source projects developed using web technologies (JavaScript, HTML, CSS). The box size is determined based on the number of weekly stars. The more weekly stars, the more trending the project is, and the larger the box is.