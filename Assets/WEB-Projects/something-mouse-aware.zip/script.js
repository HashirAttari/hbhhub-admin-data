var char = document.getElementById('char')
var cha = char.getBoundingClientRect()
var stage = document.getElementById('stage')
var sta = stage.getBoundingClientRect()
var staO = stage.offsetLeft
var half = window.innerWidth/2
var halfH = window.innerHeight/2

window.addEventListener('mousemove', function(e){
  var x = e.clientX;
  var r = x < half ? -(1-(x/half)) : (1-(half/x))*2;
  var y = e.clientY
  var ry = y < halfH ? (1-(y/halfH)) : -(1-(halfH/y))*2;
  console.log(ry)
 
  char.style.transform = "rotateY("+r*55+"deg)"
  
  var eyes = "0% "+ry*(-25)+"%";
  
  let root = document.documentElement;
  root.style.setProperty('--eyes', eyes);
})