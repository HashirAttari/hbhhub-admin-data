# Something: Mouse Aware

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/BXdBVK](https://codepen.io/kitjenson/pen/BXdBVK).

This something is aware of it's surroundings (mouse movement).