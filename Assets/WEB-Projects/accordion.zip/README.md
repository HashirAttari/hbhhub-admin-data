# Accordion

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/abBJgQo](https://codepen.io/havardob/pen/abBJgQo).

A demonstation of what you can do with the details and summary elements