# Time is important!

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/vEGjXX](https://codepen.io/mselmany/pen/vEGjXX).

A pen from my another irrelevant project.I focused css class approach for animating.There is no any text output for html, just added-removed css classes ...