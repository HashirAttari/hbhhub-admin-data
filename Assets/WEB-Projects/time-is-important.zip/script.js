$(document).ready(function () {

    var Request = {
        print: function (c) {
            for (var d = 1; d <= c.toString().length; d++) {
                var $elemClasses = document.getElementById("digit-" + d).className;
                $elemClasses = "";
                $elemClasses += " is-n-" + c.toString().split('').reverse().join('').substring(d - 1, d);
                $("#digit-" + d).removeClass().addClass($elemClasses);
            }
        }
    }

    $(".style").on("click", function () {
        $(this).addClass("is-active").siblings(".style").removeClass("is-active");
        if( $(this).is(".style.one") ){
            $("body").removeClass("mode-2").addClass("mode-1");
        } else if( $(this).is(".style.two") ){
            $("body").removeClass("mode-1").addClass("mode-2");
        }
    });

    setInterval( function() {
        var hours = new Date().getHours();
        var minutes = new Date().getMinutes();
        var seconds = new Date().getSeconds();
        
        var timeString = (( hours < 10 ? "0" : "" ) + hours) + (( minutes < 10 ? "0" : "" ) + minutes) + (( seconds < 10 ? "0" : "" ) + seconds);
        
        Request.print(timeString);
        
    }, 1000);	






});