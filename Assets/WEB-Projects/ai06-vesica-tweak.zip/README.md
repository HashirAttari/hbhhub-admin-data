# AI06: Vesica tweak

A Pen created on CodePen.io. Original URL: [https://codepen.io/cjgammon/pen/eYPOVGd](https://codepen.io/cjgammon/pen/eYPOVGd).

Alien Interfaces: 05 - Designed by AI / ML with Midjourney.

See the process here: 
https://alieninterfaces.com/cases/vesica.html