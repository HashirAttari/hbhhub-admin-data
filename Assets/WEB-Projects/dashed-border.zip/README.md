# Dashed-border

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/KyJvmo](https://codepen.io/yuanchuan/pen/KyJvmo).

css-doodle DEMO http://yuanchuan.name/css-doodle