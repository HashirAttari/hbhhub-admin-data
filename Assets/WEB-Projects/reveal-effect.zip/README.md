# Reveal Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/XdrOzg](https://codepen.io/leenalavanya/pen/XdrOzg).

with a little firecrackers