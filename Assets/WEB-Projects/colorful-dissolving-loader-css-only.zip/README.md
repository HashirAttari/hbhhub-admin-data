# Colorful Dissolving Loader (CSS only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/JjBLaGG](https://codepen.io/amit_sheen/pen/JjBLaGG).

