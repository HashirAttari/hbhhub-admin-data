# Constellations Mouse Trail

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/oNYYRYR](https://codepen.io/franksLaboratory/pen/oNYYRYR).

