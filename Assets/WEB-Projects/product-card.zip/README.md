# Product Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/NPLELa](https://codepen.io/mselmany/pen/NPLELa).



Forked from [Virgil Pana](http://codepen.io/virgilpana/)'s Pen [Product Card](http://codepen.io/virgilpana/pen/RNYQwB/).