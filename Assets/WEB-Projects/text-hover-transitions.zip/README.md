# Text :hover Transitions

A Pen created on CodePen.io. Original URL: [https://codepen.io/designcouch/pen/zYWPmV](https://codepen.io/designcouch/pen/zYWPmV).

Playing around with fancy hover states.