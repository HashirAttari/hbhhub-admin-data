# Underline Pen Strokes (Randomly Generated)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/bGqJKqJ](https://codepen.io/ykadosh/pen/bGqJKqJ).

I'm using SVG to generate random underline pen strokes. The strokes vary in thickness and shape, and they take the width of the text that they underline.

You can read more about the code and process in my dev.to short tutorial: https://dev.to/ykadosh/underline-pen-strokes-randomly-generated-53k7