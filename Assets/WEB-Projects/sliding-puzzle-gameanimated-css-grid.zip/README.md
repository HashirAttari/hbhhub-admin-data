# Sliding Puzzle Game - Animated CSS Grid

A Pen created on CodePen.io. Original URL: [https://codepen.io/daviddarnes/pen/EOqZdw](https://codepen.io/daviddarnes/pen/EOqZdw).

Holiday season challenge to build a sliding puzzle game, check out the write-up https://simpleweb.co.uk/coding-a-festive-puzzle-game-with-modern-front-end-techniques/