# Toggle Hexagon II (use SVG instead)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/yLrYeNY](https://codepen.io/alvaromontoro/pen/yLrYeNY).

Use SVG instead of this version.