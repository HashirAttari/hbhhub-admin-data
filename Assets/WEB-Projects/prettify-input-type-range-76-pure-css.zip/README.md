# prettify `<input type=range>` #76 pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/RNYrJM](https://codepen.io/thebabydino/pen/RNYrJM).

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 36, 39 (nightly), Chrome 41, 43 (canary)/ Opera 28, IE 11 on Windows 8. Pure CSS. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/2AynKd5.jpg) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 