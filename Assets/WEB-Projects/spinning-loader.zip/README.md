# Spinning Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/pattmorter/pen/AxzXEv](https://codepen.io/pattmorter/pen/AxzXEv).

A cool little loading thingy