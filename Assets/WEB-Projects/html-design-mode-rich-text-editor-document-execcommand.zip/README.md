# HTML Design Mode Rich Text Editor (Document.execCommand())

A Pen created on CodePen.io. Original URL: [https://codepen.io/coinoperatedgoi/pen/jYzdrO](https://codepen.io/coinoperatedgoi/pen/jYzdrO).

I wanted to try to recreate a TinyMCE type editor using 'contenteditable' and 'document.execCommand()'