var scene = document.querySelector("x").coco();
var controls = document.querySelectorAll(".controls input");

controls.forEach((input) => {
  input.oninput = function () {
    var pos = {
      x: Number(controls[0].value),
      y: Number(controls[1].value),
      z: Number(controls[2].value)
    };

    scene.camera(pos.x, pos.y, pos.z);
  };
});