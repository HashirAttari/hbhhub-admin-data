# CSS only tabs

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/abQwPxO](https://codepen.io/cbolson/pen/abQwPxO).

