# Background clip text hover animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/ErvoOb](https://codepen.io/ig_design/pen/ErvoOb).

