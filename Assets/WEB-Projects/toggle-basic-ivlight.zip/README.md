# Toggle Basic (IV - Light)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/PogbOrZ](https://codepen.io/alvaromontoro/pen/PogbOrZ).

A basic toggle switch. No bells or whistles.