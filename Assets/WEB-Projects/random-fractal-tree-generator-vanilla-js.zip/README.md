# Random Fractal Tree Generator (vanilla JS)

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/ZEbGoPB](https://codepen.io/franksLaboratory/pen/ZEbGoPB).

