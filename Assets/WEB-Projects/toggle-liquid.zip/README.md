# Toggle liquid

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/XWGJorW](https://codepen.io/alvaromontoro/pen/XWGJorW).

Video of how it was coded: https://www.youtube.com/live/fA1-zNsROW8