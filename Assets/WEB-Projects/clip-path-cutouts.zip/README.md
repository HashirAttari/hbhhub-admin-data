# Clip Path Cutouts

A Pen created on CodePen.io. Original URL: [https://codepen.io/danwilson/pen/RwYegOr](https://codepen.io/danwilson/pen/RwYegOr).

