# CSS / SVG Filter Generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/alexandrevacassin/pen/ExzWNyZ](https://codepen.io/alexandrevacassin/pen/ExzWNyZ).

Play with different filters and combine them to produce amazing results. CSS and SVG filter codes are generated automatically.