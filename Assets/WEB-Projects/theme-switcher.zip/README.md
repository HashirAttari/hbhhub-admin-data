# Theme Switcher

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/xxROBjX](https://codepen.io/havardob/pen/xxROBjX).

Change to a different theme with just a few lines of JavaScript