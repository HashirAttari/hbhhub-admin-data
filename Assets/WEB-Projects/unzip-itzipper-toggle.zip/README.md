# UnZip it !!! --- Zipper Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/rajatkantinandi/pen/PELXBa](https://codepen.io/rajatkantinandi/pen/PELXBa).

## UnZip it !!! --- Zipper Toggle checkbox
Made with pure CSS & SVGs

-- Inspired by "Sriracha Toggle" -By  Adam Kuhn

https://codepen.io/cobra_winfrey/pen/GyPZoR