# Naruto Shippuden - Tendo Pain

A Pen created on CodePen.io. Original URL: [https://codepen.io/tdullah/pen/pdzNZo](https://codepen.io/tdullah/pen/pdzNZo).

Yahiko was a shinobi from Amegakure. Alongside his fellow war orphans, Nagato and Konan, he founded and led the Akatsuki in an attempt to bring peace. Following Yahiko's death, Nagato would turn his body into the Deva Path of his Six Paths of Pain, which he used as the continued public image of Akatsuki's leadership. 