# svg ms logo spinner

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/gMmjEo](https://codepen.io/run-time/pen/gMmjEo).

