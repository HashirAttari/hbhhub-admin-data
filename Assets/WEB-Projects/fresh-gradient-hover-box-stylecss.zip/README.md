# Fresh Gradient Hover Box Style - CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/TheMOZZARELLA/pen/MWrVxXx](https://codepen.io/TheMOZZARELLA/pen/MWrVxXx).

A fresh lil box style I wrote