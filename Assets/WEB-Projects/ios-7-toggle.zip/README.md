# iOS 7 Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/daneden/pen/kWMQMp](https://codepen.io/daneden/pen/kWMQMp).

CSS/HTML only recreation of the iOS 7 toggle buttons. I love the little bounce that the slide has.