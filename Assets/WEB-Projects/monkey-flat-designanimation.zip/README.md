# Monkey Flat Design - Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/ExYmQWV](https://codepen.io/ricardoolivaalonso/pen/ExYmQWV).

