# Circular text with pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/NWJpMPE](https://codepen.io/amit_sheen/pen/NWJpMPE).

