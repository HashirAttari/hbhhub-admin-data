# Styled native range input #40 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/azqaex](https://codepen.io/thebabydino/pen/azqaex).

**May 2021 update**

Major changes:

* got rid of Compass and Modernizr dependencies, neither of which was needed anyway anymore

* ditched the 1 element restriction to make it functional again (the hacky `/deep/` technique from early 2015 had stopped working within the same year, so I've now eliminated all that completely useless code) and accessible - the slider end values are now `option` elements within a `datalist` tied to the corresponding range input

* generated the HTML in a logical manner with Pug that also helps me pass some custom properties to the CSS

* got rid of the convoluted JS that was adding the fill/ progress highlight and switched to a simpler method based on CSS variables (this reduced the JS to less than a fifth of what it was before!!!)

* made it degrade gracefully in the no JS case (there's just no track fill)

* ditched `absolute` positioning in favour of using a `grid` layout now

* made it responsive in a simple manner

* cleaned up the CSS and made it more maintainable by using CSS variables and the DRY switching technique, explained in this two part article I wrote for CSS-Tricks: [part one](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) and [part two](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/)

* used a single `linear-gradient` + `clip-path` for the graphical volume increase indicator instead of a `linear-gradient` for each bar 😱

* actually bothered to look for a font that would match the original design

* made the whole thing greyscaled if not hovered and no focus on the slider

* ensured it now behaves consistently in both WebKit browsers and Firefox

* corrected thumb motion behaviour using the [track wrapper](https://codepen.io/thebabydino/pen/NWpNGpo) in Chrome (the way it [behaves in Firefox](https://css-tricks.com/sliding-nightmare-understanding-range-input/#the-range-thumb-component), within the `content-box` of the `actual input`, causes no problems)

* would have loved to make it all CSS-only in Firefox, but the way `::-moz-range-progress` behaves [is just not practical](https://css-tricks.com/sliding-nightmare-understanding-range-input/#the-range-progress-fill-component) 😭

* not providing IE/ pre-Chromium support anymore

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling the range track. Chrome/ Opera have a bit of an extra, the end labels over the track. This is done using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). Fallback for no JS: simply display the same background for the entire track, both before and after the thumb and no end labels.

---

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/GNBNJBC.jpg) 

---

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 