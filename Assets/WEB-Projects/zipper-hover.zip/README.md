# Zipper hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/minutti/pen/AjPWKw](https://codepen.io/minutti/pen/AjPWKw).

