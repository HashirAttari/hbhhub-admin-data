# Valentine's Day Card (open/ close on click)

A Pen created on CodePen.

Original URL: [https://codepen.io/lenasta92579651/pen/podogVq](https://codepen.io/lenasta92579651/pen/podogVq).

