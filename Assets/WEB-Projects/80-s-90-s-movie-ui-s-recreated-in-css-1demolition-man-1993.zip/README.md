# 80's / 90's Movie UI's recreated in CSS #1 - Demolition Man 1993

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/qYJWyq](https://codepen.io/jcoulterdesign/pen/qYJWyq).

Today 80's / 90's movie recreated UI piece in CSS is taken from Demolition Man 1993. During the scene where they use a computer to find Simon around the 20 minute mark.