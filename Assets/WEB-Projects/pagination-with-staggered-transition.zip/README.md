# Pagination with staggered transition

A Pen created on CodePen.io. Original URL: [https://codepen.io/cleveryeti/pen/wvRoJyd](https://codepen.io/cleveryeti/pen/wvRoJyd).

Smooth stagerred transition between pages
Made for the pagination codepen challenge