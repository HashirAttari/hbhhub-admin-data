# Color wheel flower - no HTML

A Pen created on CodePen.

Original URL: [https://codepen.io/Pedro-Ondiviela/pen/JoRYmxJ](https://codepen.io/Pedro-Ondiviela/pen/JoRYmxJ).

Simple color wheel animation showing how much can be done just with ::before and ::after.

Done for March Codepen Challenge