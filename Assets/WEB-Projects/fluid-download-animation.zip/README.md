# Fluid download animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/yRdoYN](https://codepen.io/aaroniker/pen/yRdoYN).

From https://dribbble.com/shots/4489483-Microinteraction-Downloader-Art-Line-UX-Motion-Design