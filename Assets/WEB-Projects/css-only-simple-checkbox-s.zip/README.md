# CSS only simple checkbox's

A Pen created on CodePen.io. Original URL: [https://codepen.io/Funsella/pen/Dmoqwg](https://codepen.io/Funsella/pen/Dmoqwg).

