# Circular Carousel MotionPath - Draggable & Inertia

A Pen created on CodePen.io. Original URL: [https://codepen.io/GreenSock/pen/BabLjzN](https://codepen.io/GreenSock/pen/BabLjzN).

