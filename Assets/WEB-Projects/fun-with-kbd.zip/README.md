# Fun with <kbd>

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/mdrgBPp](https://codepen.io/benhatsor/pen/mdrgBPp).

