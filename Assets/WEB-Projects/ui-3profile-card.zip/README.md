# UI #3 - Profile Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/AlbertFeynman/pen/YJGjmz](https://codepen.io/AlbertFeynman/pen/YJGjmz).

Codepen profile card. Full page view works best.