# Dancing bubble

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pedro-Ondiviela/pen/OJdmGmX](https://codepen.io/Pedro-Ondiviela/pen/OJdmGmX).

A bubble that follows your cursor and reflect the background behind