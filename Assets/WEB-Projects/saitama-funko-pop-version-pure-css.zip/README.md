# Saitama Funko Pop version (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/inescodes/pen/JjXomBv](https://codepen.io/inescodes/pen/JjXomBv).

