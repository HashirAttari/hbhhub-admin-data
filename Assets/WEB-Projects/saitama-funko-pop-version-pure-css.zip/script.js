/* 
The responsive unit technique is taken from Jhey Tompkins's article 
https://css-tricks.com/advice-for-complex-css-illustrations/ 
*/