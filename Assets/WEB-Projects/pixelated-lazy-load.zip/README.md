# Pixelated Lazy Load

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/JjPmObK](https://codepen.io/markmead/pen/JjPmObK).

