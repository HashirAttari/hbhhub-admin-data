# Möbius 6hedrons (pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/mJojKd](https://codepen.io/thebabydino/pen/mJojKd).

Live coded in 30 minutes on the 11th of August 2015. Explained how I did it in [this article on CSS-Tricks](https://css-tricks.com/how-i-live-coded-my-most-hearted-codepen-demo/). Uses `transform-style: preserve-3d`, so it can only work in browsers supporting it. This excludes IE up to and including 11. It's also ugly if CSS filters are not supported. Tested and works in Firefox 39, Chrome 44, 46 (canary)/ Opera 31 beta on Windows 8. Inspiration:  [source](http://12gon.tumblr.com/post/78733618405/m%C3%B6bius-6hedrons-3d).

If the work I've been putting out since early 2012 has helped you in any way or you just like it and you wish me to be able to continue putting out stuff, please consider one of the following:

* being a cool cat 😼🎩 and becoming a patron on Patreon

[![become a patron button](https://assets.codepen.io/2017/btn_patreon.png)](https://www.patreon.com/anatudor)

* making a one time donation via Ko-fi

[![ko-fi](https://assets.codepen.io/2017/btn_kofi.svg)](https://ko-fi.com/anatudor)

* getting me something off my Amazon WishList 

[🎁 🇺🇸](https://www.amazon.com/gp/registry/wishlist/2Y3C4722GXH0I/) / [🎁 🇬🇧](https://www.amazon.co.uk/gp/registry/wishlist/2I25W7U0KADSR/)

* or at least sharing this to show the rest of the world what can be done with CSS these days

Thank you!