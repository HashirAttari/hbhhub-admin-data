# 02 - JS + CSS Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/GNBvpp](https://codepen.io/run-time/pen/GNBvpp).

02 - JS + CSS Clock

Build 30 things in 30 days using Vanilla JS

https://javascript30.com