# 90's retro fire buttons (vanilla JS)

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/XWRmpbB](https://codepen.io/franksLaboratory/pen/XWRmpbB).

