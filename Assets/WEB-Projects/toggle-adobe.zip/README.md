# Toggle Adobe

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/QWobjWg](https://codepen.io/alvaromontoro/pen/QWobjWg).

