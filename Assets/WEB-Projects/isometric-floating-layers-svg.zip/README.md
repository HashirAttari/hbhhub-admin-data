# Isometric Floating Layers (SVG)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/RwKpKGM](https://codepen.io/ykadosh/pen/RwKpKGM).

I made this SVG animated illustration for a piece I was writing about Webrix.js (you can find it here: https://webrix.amdocs.com/motivation).

I've made a <Layer> component that is completely configurable (size, color, position, text), and you can stack as many as you need together and create your own illustration.

I'm using 3 <path/> elements internally to draw the layers and make them appear 3D, one for the shadow, one for the highlight, and one for the body.