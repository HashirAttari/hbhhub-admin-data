# Toilet Paper Roll Toggle - CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/VwNbwwb](https://codepen.io/josetxu/pen/VwNbwwb).

Inspired by <strong>Oleg Sheremet's</strong> <a href="https://dribbble.com/shots/1592720-Pure-Soft-White">"Pure Soft White"</a> Dribbble Shot.