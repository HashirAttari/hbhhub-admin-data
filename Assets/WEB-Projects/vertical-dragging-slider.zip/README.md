# Vertical dragging slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/luigimannoni/pen/dyZeZQ](https://codepen.io/luigimannoni/pen/dyZeZQ).

Vertical drag/swipe slider with DragDealer.js