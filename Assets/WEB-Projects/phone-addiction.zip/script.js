const phone = document.getElementById("phone");

// kevin powell is such a gr8 guy
document.addEventListener("mousemove", (e) => {
  rotateElement(e, phone);
});

function rotateElement(event, element) {
  const x = event.clientX;
  const y = event.clientY;

  const middleX = window.innerWidth/2;
  const middleY = window.innerHeight/1.5;

  const offsetX = ((x - middleX) / middleX) * 45;
  const offsetY = ((y - middleY) / middleY) * 45;
	
  element.style.setProperty("--rotateX", offsetX + "deg");
  element.style.setProperty("--rotateY", -1 * offsetY + "deg");
}