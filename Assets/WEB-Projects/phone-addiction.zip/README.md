# Phone addiction

A Pen created on CodePen.io. Original URL: [https://codepen.io/badly_written_stylesheet/pen/eYxqjwg](https://codepen.io/badly_written_stylesheet/pen/eYxqjwg).

