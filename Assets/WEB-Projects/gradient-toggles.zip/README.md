# Gradient toggles

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/arRbWv](https://codepen.io/ainalem/pen/arRbWv).

Toggles with gradients that are gradually animated away when disabling toggles.