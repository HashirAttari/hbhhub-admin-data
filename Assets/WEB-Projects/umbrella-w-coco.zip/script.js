import cocobean from "https://cdn.skypack.dev/cocobean@0.2.3";
document.querySelector('.camera').coco();