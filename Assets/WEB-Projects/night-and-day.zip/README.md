# Night and day

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/ZEORKPm](https://codepen.io/benhatsor/pen/ZEORKPm).

Click to toggle.