var title = document.querySelector('.title');
var h1 = document.querySelector('.title h1');

title.addEventListener('click', e => {
  if (title.classList.contains('night')) {
    title.classList = 'title noon';
    h1.innerHTML = 'Day';
  } else if (title.classList.contains('noon')) {
    title.classList = 'title night';
    h1.innerHTML = 'Night';
  }
})