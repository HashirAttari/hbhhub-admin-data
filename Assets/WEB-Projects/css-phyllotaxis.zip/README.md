# CSS Phyllotaxis 

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/XWbwdmX](https://codepen.io/MananTank/pen/XWbwdmX).

This is just a single div with a lot of shadows 