# Content filter v2 - pure css - #09

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/vYLGMdr](https://codepen.io/ig_design/pen/vYLGMdr).

