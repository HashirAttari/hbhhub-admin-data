# ATM Card with Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/WNjvbVv](https://codepen.io/yudizsolutions/pen/WNjvbVv).

We have made ATM card using HTML elements with CSS properties and "font-awesome" to look simple & attractive!

Made by Gyanesh Trivedi from Yudiz