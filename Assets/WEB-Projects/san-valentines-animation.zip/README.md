# SAN VALENTINES ANIMATION

A Pen created on CodePen.

Original URL: [https://codepen.io/gl0gl0/pen/bgxeKr](https://codepen.io/gl0gl0/pen/bgxeKr).

CSS Drawing + SVG animation