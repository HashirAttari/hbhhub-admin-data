# Styled native range input #5 (updated 2020)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/ogoxgZ](https://codepen.io/thebabydino/pen/ogoxgZ).

**February 2020 update**

Cleaned up the code a bit, particularly the JS. Switched to using CSS variables to emulate the fill in WebKit browsers which don't have a dedicated pseudo-element for it. Sadly, emulating the fill this way means we need JS to update the value of this variable from the JS, which is not necessary for Firefox (which has `::-moz-range-progress`) or old Edge/ IE (which have `::-ms-fill-lower`). 

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

**Original description**

Goal: create a nicely styled crossbrowser 1 element slider. IE needs  no JS. Firefox and Chrome/ Opera need a little JS help when it comes to styling the slider track. Inspiration:

![image](http://i.imgur.com/WNN2t7n.jpg) 

See also: [#1](http://codepen.io/thebabydino/pen/JoOomG/), [#2](http://codepen.io/thebabydino/pen/ogoXwG), [#3](http://codepen.io/thebabydino/pen/PwOPMG/), [#4](http://codepen.io/thebabydino/pen/Bymjmm), [#6](http://codepen.io/thebabydino/pen/YPEqVY/)