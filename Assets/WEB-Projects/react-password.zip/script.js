import React from "https://esm.sh/react@17";
import ReactDOM from "https://esm.sh/react-dom@17";

function InputPassword() {
  const [value, setValue] = React.useState("Pa$$Word");
  const [hide, setHide] = React.useState(false);
  const [displayValue, setDisplayValue] = React.useState("Pa$$Word");
  const [isAnimating, setIsAnimating] = React.useState(false);

  const getRandomChar = () => {
    const chars =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    return chars.charAt(Math.floor(Math.random() * chars.length));
  };

  const animateTransition = toHide => {
    setIsAnimating(true);
    const originalValue = value.split("");
    const maskedValue = Array(originalValue.length).fill("#");
    const animationFrames = 15;
    const interval = 20;

    let currentStep = 0;

    const intervalId = setInterval(() => {
      const newDisplay = originalValue.map((char, index) => {
        if (currentStep >= animationFrames)
        return toHide ? maskedValue[index] : originalValue[index];
        return getRandomChar();
      });

      setDisplayValue(newDisplay.join(""));
      currentStep++;

      if (currentStep > animationFrames) {
        clearInterval(intervalId);
        setIsAnimating(false);
        setDisplayValue(
        toHide ? maskedValue.join("") : originalValue.join(""));

      }
    }, interval);
  };

  React.useEffect(() => {
    animateTransition(hide);
  }, [hide]);

  const handleInputChange = e => {
    const newValue = e.target.value;
    if (hide) {
      const visibleLength = displayValue.length;
      if (newValue.length > visibleLength) {
        setValue(prev => prev + newValue.slice(-1));
      } else if (newValue.length < visibleLength) {
        setValue(prev => prev.slice(0, -1));
      }
      setDisplayValue("#".repeat(newValue.length));
    } else {
      setValue(newValue);
      setDisplayValue(newValue);
    }
  };

  return /*#__PURE__*/(
    React.createElement("div", null, /*#__PURE__*/
    React.createElement("label", { style: { fontSize: 22, marginBottom: 15, display: "block" } }, "Enter password:"), /*#__PURE__*/


    React.createElement("ul", {
      className: "inputPassword",
      style: { display: "flex", alignItems: "center" } }, /*#__PURE__*/

    React.createElement("li", null, /*#__PURE__*/
    React.createElement("input", {
      type: "text",
      value:
      isAnimating ?
      displayValue :
      hide ?
      "#".repeat(value.length) :
      value,

      onChange: handleInputChange })), /*#__PURE__*/


    React.createElement("button", {
      onClick: () => setHide(prev => !prev),
      disabled: isAnimating }, /*#__PURE__*/

    React.createElement("i", { className: `fas fa-eye${!hide ? "-slash" : ""}` })))));




}

function App() {
  React.useEffect(() => {
    if (typeof addVideoLinks === "function") {
      addVideoLinks("7446819579298434326", "KJwpwDf_No8", "#35c4ff");
    }
  }, []);

  return /*#__PURE__*/(
    React.createElement("main", null, /*#__PURE__*/
    React.createElement(InputPassword, null)));


}
ReactDOM.render( /*#__PURE__*/React.createElement(App, null), document.getElementById("root"));