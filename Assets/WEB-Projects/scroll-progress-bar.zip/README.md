# Scroll Progress Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/simoberny/pen/yboQmo](https://codepen.io/simoberny/pen/yboQmo).

