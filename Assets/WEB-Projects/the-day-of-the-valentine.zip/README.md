# The day of the Valentine

A Pen created on CodePen.

Original URL: [https://codepen.io/join/pen/zeLoaQ](https://codepen.io/join/pen/zeLoaQ).

Expr js: Валентинка - молния.
Fork: Lightning Points from akm2.
css js canvas animation heart lightning vitality energy love is