# Pulsing polygon grid #7

A Pen created on CodePen.io. Original URL: [https://codepen.io/nzbin/pen/GRzWLqZ](https://codepen.io/nzbin/pen/GRzWLqZ).

Pulsing polygon grid.

Actual strokes and fills are expensive so I split the array of polygons into 4 buckets, each using one of the hex values of the theme and then split the polygons in each depending on whether we want to give them a fill or a stroke - see the contents of the `draw()` function.

If you like this demo or my work in general, you can support it with a gift to keep me afloat:

[🎁🇺🇸](https://amazon.com/hz/wishlist/ls/2Y3C4722GXH0I)

[🎁🇬🇧](https://amazon.co.uk/hz/wishlist/ls/2I25W7U0KADSR)

[Palette](https://www.colourlovers.com/palette/1890/fall_ingto_winter).

---

Dedicated to the memory of someone dear who passed away in January 2019.