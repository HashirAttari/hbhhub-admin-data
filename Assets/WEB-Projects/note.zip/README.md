# Note

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/WNrgKGK](https://codepen.io/havardob/pen/WNrgKGK).

A note component with fading borders using border-image-source. 