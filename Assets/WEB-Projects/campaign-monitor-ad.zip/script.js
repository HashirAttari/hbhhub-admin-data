$('.replay').on('click', function() {
  showSlides();
});


showSlides();



function showSlides() {
  var device = $('.device');
  var body =  $('.ad-frame');
  
  body.removeClass().addClass('ad-frame slide-1');
  device.removeClass().addClass('device client empty hidden');

  setTimeout(function() {
      body.removeClass('slide-1').addClass('slide-2');
      device.removeClass('hidden');
  }, 2000);
setTimeout(function() {
      body.removeClass('slide-2').addClass('slide-3'); 
      device.removeClass('empty');
  }, 3750);
 setTimeout(function() {
      body.removeClass('slide-3').addClass('slide-4'); 
      device.removeClass('client').addClass('desktop');
  }, 7500);

  setTimeout(function() {
      body.removeClass('slide-4').addClass('slide-5'); 
      device.removeClass('desktop').addClass('tablet');
  }, 9500);

  setTimeout(function() {
      body.removeClass('slide-5').addClass('slide-6'); 
      device.removeClass('tablet').addClass('phone');
  }, 11500);
  
  setTimeout(function() {
      body.removeClass('slide-6').addClass('slide-7'); 
      device.addClass('lost');
  }, 13500);
}