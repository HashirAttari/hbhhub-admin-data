# Playdate Gaming Console

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisota/pen/eYpyqYG](https://codepen.io/chrisota/pen/eYpyqYG).

I created a Playdate illustration in pure HTML and CSS for fun (no SVG or images used). The most challenging (but rewarding) part of this project was trying to create the rivets/screws in the multiple corners of the device—the middle of the rivet is see-through.

Although there is more I would like to do with this (like add more details to the device or the screen itself), I will consider this finalized for now.

Enjoy!