# App Icon - Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolazj/pen/PwjxYN](https://codepen.io/nicolazj/pen/PwjxYN).

App Icon - Clock