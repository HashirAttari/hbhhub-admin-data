# Swipe Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/gpressutto5/pen/NjJobG](https://codepen.io/gpressutto5/pen/NjJobG).

It's a web preview of the android custom component ebanx/swipe-button.