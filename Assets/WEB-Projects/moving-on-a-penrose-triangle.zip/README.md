# Moving on a Penrose Triangle

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/gOWXMJp](https://codepen.io/amit_sheen/pen/gOWXMJp).

