# Glowing On/Off Buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/gOjNdog](https://codepen.io/jkantner/pen/gOjNdog).

Light and dark toggle buttons with a little glow in the center. Based on the one in [this Dribbble shot](https://dribbble.com/shots/14278079-Daily-UI-015-On-Off-Switch) by Rahul Agarwal.

Update 2/11/23: Ditched responsive font sizing due to box shadow issues while resizing the window