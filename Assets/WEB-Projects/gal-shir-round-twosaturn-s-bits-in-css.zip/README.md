# Gal Shir Round Two - Saturn's bits in CSS.

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/qoxBVv](https://codepen.io/jcoulterdesign/pen/qoxBVv).

