# Hexagaonal bg image

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/yLZyaZw](https://codepen.io/cbolson/pen/yLZyaZw).

