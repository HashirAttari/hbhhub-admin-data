# Funky Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/KVNrLa](https://codepen.io/jcoulterdesign/pen/KVNrLa).

Hey guys! I just wanted to create a simple funky loading animation! Always wanted to make something like this :p! I hope you like it :D!

Forked from [Jack Thomson](http://codepen.io/Jackthomsonn/)'s Pen [Funky Loader](http://codepen.io/Jackthomsonn/pen/wModMm/).