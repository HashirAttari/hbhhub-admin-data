# Thumbs up confetti

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/xxwrNPY](https://codepen.io/aaroniker/pen/xxwrNPY).

