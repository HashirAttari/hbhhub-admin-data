/*
This spinner scales to fit any container and is entirely done by applying CSS transitions around SVG paths.

The drawing effect is done by using a dashed line around each path where the gap size is larger than the entire path and then transitions down to 0 gap.
*/