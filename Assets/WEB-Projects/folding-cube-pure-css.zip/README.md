# Folding cube (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/poNWQJJ](https://codepen.io/benhatsor/pen/poNWQJJ).

