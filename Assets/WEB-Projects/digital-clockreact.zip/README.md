# Digital Clock - React

A Pen created on CodePen.io. Original URL: [https://codepen.io/matthewvincent/pen/BKoYLm](https://codepen.io/matthewvincent/pen/BKoYLm).

Glowing orb clock made with React