# Mouth Animation - Monster

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/mdbGvmr](https://codepen.io/ricardoolivaalonso/pen/mdbGvmr).

