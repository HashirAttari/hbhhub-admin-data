# Fading text with CSS blend modes

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/aJmxXm](https://codepen.io/giana/pen/aJmxXm).

I'm pretty sure I saw this effect months ago on another pen (using SVG?), but I can't remember it. If anyone does, please link so I can credit for the inspo.