# Pure javascript calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/jorje/pen/yowNbe](https://codepen.io/jorje/pen/yowNbe).

This is well documented and well styled pure js calculator with history saving function. I bet it's unbreakable! Try 0.1+0.2, try to put two operators or dots at row, try to refill screen. I M P O S I B L E