# CSS Vortex thingy

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/bpKxQY](https://codepen.io/jcoulterdesign/pen/bpKxQY).

Honestly....this started off as a button. This is how distracted i get