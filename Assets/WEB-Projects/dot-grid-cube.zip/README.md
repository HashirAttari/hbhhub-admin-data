# Dot Grid Cube

A Pen created on CodePen.io. Original URL: [https://codepen.io/Raphael/pen/kKNjYv](https://codepen.io/Raphael/pen/kKNjYv).

Made with CSS only, collapses while being clicked or touched