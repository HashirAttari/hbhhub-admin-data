$( 'body' ).on( 'touchstart touchend', function() {
	$( '#cube' ).toggleClass( 'active' );
});