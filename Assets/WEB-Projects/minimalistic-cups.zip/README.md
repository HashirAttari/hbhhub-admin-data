# Minimalistic Cups

A Pen created on CodePen.io. Original URL: [https://codepen.io/visnuravichandran/pen/JjXWEox](https://codepen.io/visnuravichandran/pen/JjXWEox).

