# CSS box shadow particles v7

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/OMVqWz](https://codepen.io/giana/pen/OMVqWz).

Same as <a href="http://codepen.io/giana/pen/JGdbje">the first version</a>, only with different numbers.