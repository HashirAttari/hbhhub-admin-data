var dzielnik;
var iloraz;
var dzielna;
var dobre = 0;
var zle = 0;


document.getElementById("odpowiedz")
    .addEventListener("keyup", function(event) {
    event.preventDefault();
    if (event.keyCode == 13) {
        document.getElementById("wyslij").click();
    }
});

function generujLiczby(){
   dzielnik = Math.floor(Math.random() *12) +1;
   iloraz = Math.floor(Math.random() *12) +1;
   dzielna = iloraz * dzielnik;
   document.getElementById("odpowiedz").focus();
   document.getElementById('dzielna').innerHTML=dzielna;
   document.getElementById('dzielnik').innerHTML=dzielnik;
   document.getElementById('dobre').innerHTML=dobre;
   document.getElementById('zle').innerHTML=zle;
}



function liczbaOdpowiedzi(){
  if(dobre == 5){
    document.getElementById('wroc').style.visibility ='visible'
    generujLiczby()
    document.getElementById('odpowiedz').value=""; 
  }else{
   generujLiczby() 
   document.getElementById('odpowiedz').value="";
  }
}

function sprawdzWynik(){
  var wynik = document.getElementById('odpowiedz').value;
  console.log(wynik);
  if(wynik == iloraz){
    dobre = dobre + 1;
    liczbaOdpowiedzi();     
  }else if (wynik ==""){
  }else{
    zle = zle + 1;
    liczbaOdpowiedzi();
  }
}

function otworzMenu(){
  dobre = 0;
  zle = 0;
  document.getElementById('wroc').style.visibility="hidden";
}
function start(){
  document.getElementById('main-panel').classList.add('obrot');
  window.setTimeout(generujLiczby, 1000);
}
function powrot(){
  document.getElementById('main-panel').classList.remove('obrot');
  otworzMenu();
}