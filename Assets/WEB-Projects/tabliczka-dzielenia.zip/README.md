# Tabliczka dzielenia

A Pen created on CodePen.io. Original URL: [https://codepen.io/Wujek_Greg/pen/RVqpzW](https://codepen.io/Wujek_Greg/pen/RVqpzW).

