# asdf

A Pen created on CodePen.

Original URL: [https://codepen.io/TimPietrusky/pen/DzYMNz](https://codepen.io/TimPietrusky/pen/DzYMNz).

My entry for the js13kGames competition 2012. A remake of the 1978 launched [Simon](http://en.wikipedia.org/wiki/Simon_\(game\)) electronic game!

[asdf on js13kGames](http://js13kgames.com/entries/asdf/)

2012 by [Tim Pietrusky](http://timpietrusky.com) for js13kGames 2012

## How to play?

[Watch my screencast on how to play the game.](http://youtu.be/s2pEb37OUT8)

## Preview

![asdf preview](http://timpietrusky.koding.com/asdf/img/400x250.png)


## KOG

This is a Keyboard-Only-Game (KOG). So please use your keyboard. There will maybe a clickable version later.

## Browser support

Best played with the latest WebKit-browsers (Chrome or Safari) because WebKit has much better performance, css filter and css repeating-radial-gradient support.

## Thanks to

### Pub/sub by Peter Higgins 
https://github.com/phiggins42/bloody-jquery-plugins/blob/master/pubsub.js

### riffwave.js by Pedro Ladaria
http://codebase.es/riffwave/