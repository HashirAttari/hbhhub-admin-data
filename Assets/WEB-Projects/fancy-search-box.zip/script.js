$('.search-box').click(function(){
  $('.base').addClass('active');
  
   setTimeout(function(){
    $('.cross').addClass('show-cross')
    }, 300);
  
    setTimeout(function(){
      $('.search-box').addClass('move-search')
      }, 100);
}); 

$('.cross').click(function(){
  setTimeout(function(){
    $('.base').removeClass('active');
  }, 100);
  
  $('.cross').removeClass('show-cross');
    
  $('.search-box').removeClass('move-search');
});