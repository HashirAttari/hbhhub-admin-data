# Fancy search box

A Pen created on CodePen.io. Original URL: [https://codepen.io/kh-mamun/pen/apxvjm](https://codepen.io/kh-mamun/pen/apxvjm).

Very basic codes for a fancy search box.