# Animated Terminal Session

A Pen created on CodePen.io. Original URL: [https://codepen.io/simoami/pen/eYrPdz](https://codepen.io/simoami/pen/eYrPdz).

Animated terminal session with scriptable output.