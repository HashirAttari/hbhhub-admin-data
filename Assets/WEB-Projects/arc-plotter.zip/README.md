# Arc plotter

A Pen created on CodePen.

Original URL: [https://codepen.io/shubniggurath/pen/QwKbVja](https://codepen.io/shubniggurath/pen/QwKbVja).

An interactive, parametric exploration inspired by Sol LeWitt’s Wall Drawing 1136. LeWitt’s work often focused on the execution of simple rules to create complex visual systems. Here, that "rule" is the maintenance of tangent continuity between alternating circular arcs.

For each point (see by checking "Edit points") the code calculates the normal and bisector intersections to ensure each new arc begins exactly where the last ended, pointing in the same direction. It includes some additional logic to ensure that arc direction (CW/CCW) remains sane based on the cross product and direction between previous and next points.