import { Vec2 } from "https://cdn.skypack.dev/wtc-math@1.0.20";
import { Pane } from "https://esm.sh/tweakpane@4";

class Arcer {
  #points = [];
  #arcs = [];
  constructor() {}

  addArc(P1, P2) {
    const lastArc = this.lastArc;
    const tangent = lastArc ? lastArc.exitTangent : -Math.PI / 2;
    const clockwise = this.points.length % 2 !== 0;
    const arc = this.calculateArc(P1, P2, tangent, clockwise);
    this.arcs.push(arc);
    return arc;
  }

  addPoint(P2) {
    this.points.push(P2);
  }

  calculateArc(P1, P2, tangentAngle, predictedClockwise) {
    // Determine the actual direction for this segment
    // This logic ensures we don't curl "inward" incorrectly by checking
    // if the point is on the "wrong side" of the tangent for the requested direction.
    const chordDir = P2.subtractNew(P1);
    const tangentDir = new Vec2(Math.cos(tangentAngle), Math.sin(tangentAngle));
    const cross = tangentDir.x * chordDir.y - tangentDir.y * chordDir.x;
    let clockwise = predictedClockwise;
    // This checks if the point is on the "inside" of the tangent direction for the requested arc direction.
    // If clockwise is true, we expect the point to be on the left side of the tangent (cross > 0).
    // If clockwise is false, we expect the point to be on the right side of the tangent (cross < 0).
    if ((!clockwise && cross < 0) || (clockwise && cross > 0))
      clockwise = !clockwise;

    // Standard Circle Math (Intersection of Normal & Bisector)
    const normalAngle = clockwise
      ? tangentAngle - Math.PI / 2
      : tangentAngle + Math.PI / 2;

    const normalDir = new Vec2(Math.cos(normalAngle), Math.sin(normalAngle));
    const midpoint = P1.addNew(P2).scale(0.5);
    const bisectorDir = new Vec2(-chordDir.y, chordDir.x);

    const denominator =
      normalDir.x * bisectorDir.y - normalDir.y * bisectorDir.x;

    // Handle Straight Line case
    if (Math.abs(denominator) < 1e-10) {
      return {
        type: "line",
        p1: P1,
        p2: P2,
        exitTangent: Math.atan2(P2.y - P1.y, P2.x - P1.x),
        clockwise: clockwise,
      };
    }

    const t =
      ((midpoint.x - P1.x) * bisectorDir.y -
        (midpoint.y - P1.y) * bisectorDir.x) /
      denominator;

    const center = new Vec2(P1.x + t * normalDir.x, P1.y + t * normalDir.y);

    const P1C = P1.subtractNew(center);
    const P2C = P2.subtractNew(center);
    const radius = P1C.length;
    const startAngle = P1C.angle;
    const endAngle = P2C.angle;

    // calculate Exit Tangent
    const exitTangent = clockwise
      ? endAngle - Math.PI / 2
      : endAngle + Math.PI / 2;

    return {
      P1,
      P2,
      type: "arc",
      center,
      radius,
      startAngle,
      endAngle,
      exitTangent,
      anticlockwise: !clockwise, // Canvas uses anticlockwise
      clockwise,
    };
  }

  get points() {
    return this.#points;
  }
  get arcs() {
    return this.#arcs;
  }
  get lastPoint() {
    return this.#points.length > 0
      ? this.#points[this.#points.length - 1]
      : null;
  }
  get lastArc() {
    return this.#arcs.length > 0 ? this.#arcs[this.#arcs.length - 1] : null;
  }
}

const NS = "http://www.w3.org/2000/svg";
const svg = document.getElementById("svg");

// Cosine palette presets — each entry is { a, b, c, d } where
// colour = a + b * cos(2π * (c*t + d)), all as [r, g, b] triples.
const PALETTES = {
  rainbow: {
    a: [0.5, 0.5, 0.5],
    b: [0.5, 0.5, 0.5],
    c: [1.0, 1.0, 1.0],
    d: [0.0, 0.33, 0.67],
  },
  warm: {
    a: [0.5, 0.5, 0.5],
    b: [0.5, 0.5, 0.5],
    c: [1.0, 1.0, 0.5],
    d: [0.8, 0.9, 0.3],
  },
  cool: {
    a: [0.5, 0.5, 0.5],
    b: [0.5, 0.5, 0.5],
    c: [1.0, 0.7, 0.4],
    d: [0.0, 0.15, 0.2],
  },
  neon: {
    a: [0.5, 0.5, 0.5],
    b: [0.5, 0.5, 0.5],
    c: [2.0, 1.0, 0.0],
    d: [0.5, 0.2, 0.25],
  },
  sunset: {
    a: [0.8, 0.5, 0.4],
    b: [0.2, 0.4, 0.2],
    c: [2.0, 1.0, 1.0],
    d: [0.0, 0.25, 0.25],
  },
  ice: {
    a: [0.4, 0.6, 0.7],
    b: [0.3, 0.3, 0.3],
    c: [0.8, 0.8, 0.5],
    d: [0.0, 0.1, 0.3],
  },
};
// Cosine palette — maps t [0,1] to an rgb colour string using the active preset
// Copyright Inigo Quilez
function palette(t) {
  const { a, b, c, d } = PALETTES[PARAMS.palette];
  const o = PARAMS.paletteOffset;
  const s = PARAMS.paletteScale;
  const cos = (x) => Math.cos(2 * Math.PI * x);
  const r = Math.round((a[0] + b[0] * cos(o + c[0] * t * s + d[0])) * 255);
  const g = Math.round((a[1] + b[1] * cos(o + c[1] * t * s + d[1])) * 255);
  const bl = Math.round((a[2] + b[2] * cos(o + c[2] * t * s + d[2])) * 255);
  return `rgb(${r},${g},${bl})`;
}

const PARAMS = {
  stepOffset: 6,
  steps: 15,
  pointCount: 8,
  lineWidth: 2,
  arcsFirst: false,
  palette: "rainbow",
  paletteOffset: 0,
  paletteScale: 0.5,
  clipArcs: false,
  debugClip: false,
  debugPoints: false,
};

let dimensions = { x: window.innerWidth, y: window.innerHeight };
let points = [];
let arcs = [];
let gradientParams = { angle: 0, stops: [0, 0.5, 1] };
let dragState = { active: false, pointIndex: -1 };


// Return a copy of arc with radius shifted by distance, with P1/P2 recalculated
function projectArc(arc, distance) {
  const r = arc.radius + distance;
  if (r <= 0) return null;
  return {
    ...arc,
    radius: r,
    P1: new Vec2(
      arc.center.x + Math.cos(arc.startAngle) * r,
      arc.center.y + Math.sin(arc.startAngle) * r,
    ),
    P2: new Vec2(
      arc.center.x + Math.cos(arc.endAngle) * r,
      arc.center.y + Math.sin(arc.endAngle) * r,
    ),
  };
}

// Build an SVG path 'd' string for an annular sector (wedge) clipping shape.
// innerRadius == 0 produces a pie-slice; otherwise an annular ring sector.
function arcWedgePath(arc, innerRadius, outerRadius) {
  const { center, startAngle, endAngle, clockwise } = arc;

  const span = clockwise
    ? (endAngle - startAngle + 2 * Math.PI) % (2 * Math.PI)
    : (startAngle - endAngle + 2 * Math.PI) % (2 * Math.PI);
  const largeArc = span > Math.PI ? 1 : 0;
  const sweep = clockwise ? 1 : 0;

  const ox1 = center.x + Math.cos(startAngle) * outerRadius;
  const oy1 = center.y + Math.sin(startAngle) * outerRadius;
  const ox2 = center.x + Math.cos(endAngle) * outerRadius;
  const oy2 = center.y + Math.sin(endAngle) * outerRadius;

  if (innerRadius <= 0) {
    return [
      `M ${center.x} ${center.y}`,
      `L ${ox1} ${oy1}`,
      `A ${outerRadius} ${outerRadius} 0 ${largeArc} ${sweep} ${ox2} ${oy2}`,
      `Z`,
    ].join(" ");
  }

  const ix1 = center.x + Math.cos(startAngle) * innerRadius;
  const iy1 = center.y + Math.sin(startAngle) * innerRadius;
  const ix2 = center.x + Math.cos(endAngle) * innerRadius;
  const iy2 = center.y + Math.sin(endAngle) * innerRadius;

  return [
    `M ${ix1} ${iy1}`,
    `L ${ox1} ${oy1}`,
    `A ${outerRadius} ${outerRadius} 0 ${largeArc} ${sweep} ${ox2} ${oy2}`,
    `L ${ix2} ${iy2}`,
    `A ${innerRadius} ${innerRadius} 0 ${largeArc} ${1 - sweep} ${ix1} ${iy1}`,
    `Z`,
  ].join(" ");
}

// Build an SVG path 'd' string from an arc/line segment object
function arcToPath(arc) {
  if (arc.type === "line") {
    return `M ${arc.p1.x} ${arc.p1.y} L ${arc.p2.x} ${arc.p2.y}`;
  }

  const { P1, P2, radius, startAngle, endAngle, clockwise } = arc;

  // Angular span in the direction of travel determines the large-arc flag
  const span = clockwise
    ? (endAngle - startAngle + 2 * Math.PI) % (2 * Math.PI)
    : (startAngle - endAngle + 2 * Math.PI) % (2 * Math.PI);

  const largeArc = span > Math.PI ? 1 : 0;
  const sweep = clockwise ? 1 : 0;

  return `M ${P1.x} ${P1.y} A ${radius} ${radius} 0 ${largeArc} ${sweep} ${P2.x} ${P2.y}`;
}

// Recompute arcs from the current points[] array
function rebuildArcs() {
  const arcer = new Arcer();
  points.forEach((p) => {
    const prev = arcer.lastPoint;
    arcer.addPoint(p);
    if (prev) arcer.addArc(prev, p);
  });
  arcs = arcer.arcs;
}

// Generate random points left→right and compute arcs between them
function generatePoints() {
  const { x: W, y: H } = dimensions;
  const count = PARAMS.pointCount;
  const bleed = W * 0.15; // how far off-screen the end points sit
  const my = H * 0.15;

  points = [];
  for (let i = 0; i < count; i++) {
    const x = -bleed + (i / (count - 1)) * (W + bleed * 2);
    const y = my + Math.random() * (H - my * 2);
    points.push(new Vec2(x, y));
  }
  rebuildArcs();

  gradientParams = {
    angle: Math.random() * Math.PI * 2,
    stops: [Math.random(), Math.random(), Math.random()],
  };
}

// Render all arcs (with radial offsets) to SVG
function draw() {
  while (svg.firstChild) svg.removeChild(svg.firstChild);

  // Background gradient
  const defs = document.createElementNS(NS, "defs");
  const grad = document.createElementNS(NS, "linearGradient");
  grad.setAttribute("id", "bg-grad");
  grad.setAttribute("gradientUnits", "userSpaceOnUse");
  // Derive start/end points from random angle through screen centre
  const cx = dimensions.x / 2,
    cy = dimensions.y / 2;
  const gr = Math.hypot(cx, cy);
  grad.setAttribute("x1", cx + Math.cos(gradientParams.angle) * gr);
  grad.setAttribute("y1", cy + Math.sin(gradientParams.angle) * gr);
  grad.setAttribute("x2", cx - Math.cos(gradientParams.angle) * gr);
  grad.setAttribute("y2", cy - Math.sin(gradientParams.angle) * gr);
  [0, 0.5, 1].forEach((offset, i) => {
    const stop = document.createElementNS(NS, "stop");
    stop.setAttribute("offset", `${offset * 100}%`);
    stop.setAttribute("stop-color", palette(gradientParams.stops[i]));
    stop.setAttribute("stop-opacity", "0.12");
    grad.appendChild(stop);
  });
  defs.appendChild(grad);

  // Noise filter — feTurbulence produces film-grain style texture
  const filter = document.createElementNS(NS, "filter");
  filter.setAttribute("id", "noise");
  filter.setAttribute("x", "0%");
  filter.setAttribute("y", "0%");
  filter.setAttribute("width", "100%");
  filter.setAttribute("height", "100%");
  const turb = document.createElementNS(NS, "feTurbulence");
  turb.setAttribute("type", "fractalNoise");
  turb.setAttribute("baseFrequency", "2.65");
  turb.setAttribute("numOctaves", "3");
  turb.setAttribute("stitchTiles", "stitch");
  const colorMatrix = document.createElementNS(NS, "feColorMatrix");
  colorMatrix.setAttribute("type", "saturate");
  colorMatrix.setAttribute("values", "0");
  filter.appendChild(turb);
  filter.appendChild(colorMatrix);
  defs.appendChild(filter);

  // Per-arc clip paths — each is an annular sector spanning the full offset range
  const clipIds = PARAMS.clipArcs
    ? arcs.map((arc, i) => {
        if (arc.type !== "arc") return null;
        const id = `clip-arc-${i}`;
        const maxOffset = PARAMS.steps * PARAMS.stepOffset;
        const outerR = arc.radius + maxOffset;
        const innerR = Math.max(0, arc.radius - maxOffset);
        const cp = document.createElementNS(NS, "clipPath");
        cp.setAttribute("id", id);
        const p = document.createElementNS(NS, "path");
        p.setAttribute("d", arcWedgePath(arc, innerR, outerR));
        cp.appendChild(p);
        defs.appendChild(cp);
        return id;
      })
    : arcs.map(() => null);

  svg.appendChild(defs);

  const bg = document.createElementNS(NS, "rect");
  bg.setAttribute("width", dimensions.x);
  bg.setAttribute("height", dimensions.y);
  bg.setAttribute("fill", "#1a1a2e");
  svg.appendChild(bg);

  const bgGrad = document.createElementNS(NS, "rect");
  bgGrad.setAttribute("width", dimensions.x);
  bgGrad.setAttribute("height", dimensions.y);
  bgGrad.setAttribute("fill", "url(#bg-grad)");
  svg.appendChild(bgGrad);

  const stepT = (step) =>
    PARAMS.steps > 0 ? (step + PARAMS.steps) / (2 * PARAMS.steps) : 0;

  const renderSegment = (arc, step, color, clipId = null) => {
    const distance = step * PARAMS.stepOffset;
    // Outward normals for clockwise and anticlockwise arcs are antiparallel at
    // every junction (tangent continuity forces startAngle(N+1) = endAngle(N) - π).
    // Negating distance for anticlockwise arcs keeps the offset on a consistent
    // side of the travel direction, so rings are continuous across direction changes.
    const effectiveDistance =
      arc.type === "arc" ? (arc.clockwise ? distance : -distance) : distance;
    const seg =
      effectiveDistance === 0 || arc.type === "line"
        ? arc
        : projectArc(arc, effectiveDistance);
    if (!seg) return;

    const el = document.createElementNS(NS, "path");
    el.setAttribute("d", arcToPath(seg));
    el.setAttribute("stroke", color);
    el.setAttribute("stroke-width", String(PARAMS.lineWidth));
    el.setAttribute("fill", "none");
    el.setAttribute("stroke-linecap", "round");
    if (clipId) el.setAttribute("clip-path", `url(#${clipId})`);
    svg.appendChild(el);
  };

  if (PARAMS.arcsFirst) {
    // Outer: arcs — each arc draws all its offset rings before moving to the next
    arcs.forEach((arc, i) => {
      for (let step = -PARAMS.steps; step <= PARAMS.steps; step++) {
        renderSegment(arc, step, palette(stepT(step)), clipIds[i]);
      }
    });
  } else {
    // Outer: steps — all arcs at the same radial offset share one colour,
    // making the rings read as contiguous lines across segments.
    for (let step = -PARAMS.steps; step <= PARAMS.steps; step++) {
      arcs.forEach((arc, i) =>
        renderSegment(arc, step, palette(stepT(step)), clipIds[i]),
      );
    }
  }

  // Debug: draw clip wedges as visible overlays
  if (PARAMS.clipArcs && PARAMS.debugClip) {
    arcs.forEach((arc) => {
      if (arc.type !== "arc") return;
      const maxOffset = PARAMS.steps * PARAMS.stepOffset;
      const outerR = arc.radius + maxOffset;
      const innerR = Math.max(0, arc.radius - maxOffset);
      const el = document.createElementNS(NS, "path");
      el.setAttribute("d", arcWedgePath(arc, innerR, outerR));
      el.setAttribute("fill", "rgba(255,220,0,0.08)");
      el.setAttribute("stroke", "rgba(255,220,0,0.6)");
      el.setAttribute("stroke-width", "1");
      svg.appendChild(el);
    });
  }

  // Noise overlay — sits on top of arcs for a film-grain feel
  const noiseRect = document.createElementNS(NS, "rect");
  noiseRect.setAttribute("width", dimensions.x);
  noiseRect.setAttribute("height", dimensions.y);
  noiseRect.setAttribute("filter", "url(#noise)");
  noiseRect.setAttribute("opacity", "0.15");
  svg.appendChild(noiseRect);

  // Debug: draw points and minimum-distance-for-no-overflow indicators.
  // Each arc has r = L / (2·cosA) where L is chord length and cosA is the
  // dot product of the unit chord direction with the unit normal (center−P1).
  // Rearranging: L_min = 2 · maxOffset · cosA — shown as a dashed circle at P1.
  // Green = arc radius is safe; red = arc radius < maxOffset (wedge overflows).
  if (PARAMS.debugPoints && arcs.length > 0) {
    const maxOffset = PARAMS.steps * PARAMS.stepOffset;

    // Build ordered point list from arcs
    const pts = [arcs[0].type === "arc" ? arcs[0].P1 : arcs[0].p1];
    arcs.forEach((arc) => pts.push(arc.type === "arc" ? arc.P2 : arc.p2));

    // Per-arc: min-distance indicator circle
    arcs.forEach((arc) => {
      if (arc.type !== "arc") return;
      const { P1, P2, center, radius } = arc;
      const overflowing = radius < maxOffset;

      // cosA = dot(chordUnitDir, normalDir); normalDir = (center - P1) / radius
      const cx = P2.x - P1.x,
        cy = P2.y - P1.y;
      const chordLen = Math.sqrt(cx * cx + cy * cy);
      const cosA =
        chordLen > 0
          ? ((center.x - P1.x) * cx + (center.y - P1.y) * cy) /
            (radius * chordLen)
          : 0;
      const minDist = cosA > 0 ? 2 * maxOffset * cosA : 0;

      if (minDist > 0) {
        const ring = document.createElementNS(NS, "circle");
        ring.setAttribute("cx", P1.x);
        ring.setAttribute("cy", P1.y);
        ring.setAttribute("r", minDist);
        ring.setAttribute("fill", "none");
        ring.setAttribute(
          "stroke",
          overflowing ? "rgba(255,90,50,0.85)" : "rgba(80,220,120,0.45)",
        );
        ring.setAttribute("stroke-width", "1");
        ring.setAttribute("stroke-dasharray", "5 4");
        svg.appendChild(ring);
      }
    });

    // Draw point dots, coloured by overflow status of adjacent arcs
    pts.forEach((pt, i) => {
      const inArc = i > 0 ? arcs[i - 1] : null;
      const outArc = i < arcs.length ? arcs[i] : null;
      const overflowing =
        (inArc?.type === "arc" && inArc.radius < maxOffset) ||
        (outArc?.type === "arc" && outArc.radius < maxOffset);

      const dot = document.createElementNS(NS, "circle");
      dot.setAttribute("cx", pt.x);
      dot.setAttribute("cy", pt.y);
      dot.setAttribute("r", 5);
      dot.setAttribute("fill", overflowing ? "#ff5a32" : "#50dc78");
      dot.setAttribute("stroke", "rgba(255,255,255,0.8)");
      dot.setAttribute("stroke-width", "1.5");
      dot.style.cursor = "grab";
      dot.addEventListener("pointerdown", (e) => {
        dragState = { active: true, pointIndex: i };
        svg.setPointerCapture(e.pointerId);
        svg.style.cursor = "grabbing";
        e.preventDefault();
      });
      svg.appendChild(dot);
    });
  }
}

function resize() {
  dimensions = { x: window.innerWidth, y: window.innerHeight };
  svg.setAttribute("width", dimensions.x);
  svg.setAttribute("height", dimensions.y);
  generatePoints();
  draw();
}

// Tweakpane
const pane = new Pane({ title: "Arcer" });

pane
  .addBinding(PARAMS, "stepOffset", {
    min: 1,
    max: 100,
    step: 1,
    label: "Offset (X)",
  })
  .on("change", () => draw());

pane
  .addBinding(PARAMS, "steps", { min: 1, max: 40, step: 1, label: "Steps (Y)" })
  .on("change", () => draw());

pane
  .addBinding(PARAMS, "pointCount", {
    min: 3,
    max: 20,
    step: 1,
    label: "Points",
  })
  .on("change", () => {
    generatePoints();
    draw();
  });

pane
  .addBinding(PARAMS, "lineWidth", {
    min: 0.5,
    max: 30,
    step: 0.5,
    label: "Line Width",
  })
  .on("change", () => draw());

pane
  .addBinding(PARAMS, "arcsFirst", { label: "Arcs First" })
  .on("change", () => draw());

pane
  .addBinding(PARAMS, "clipArcs", { label: "Clip Arcs" })
  .on("change", () => draw());

pane
  .addBinding(PARAMS, "debugClip", { label: "Debug Clip" })
  .on("change", () => draw());

pane
  .addBinding(PARAMS, "debugPoints", { label: "Edit Points" })
  .on("change", () => draw());

pane.addButton({ title: "Regenerate" }).on("click", () => {
  generatePoints();
  draw();
});

pane
  .addBinding(PARAMS, "palette", {
    label: "Palette",
    options: {
      Rainbow: "rainbow",
      Warm: "warm",
      Cool: "cool",
      Neon: "neon",
      Sunset: "sunset",
      Ice: "ice",
    },
  })
  .on("change", () => draw());
pane
  .addBinding(PARAMS, "paletteOffset", {
    label: "Palette Offset",
    min: 0,
    max: 3,
    step: 0.01,
  })
  .on("change", () => draw());
pane
  .addBinding(PARAMS, "paletteScale", {
    label: "Palette Scale",
    min: 0,
    max: 3,
    step: 0.01,
  })
  .on("change", () => draw());

pane.addButton({ title: "Download SVG" }).on("click", () => {
  const serialized = new XMLSerializer().serializeToString(svg);
  const blob = new Blob([serialized], { type: "image/svg+xml" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "arcer.svg";
  a.click();
  URL.revokeObjectURL(url);
});

pane.addButton({ title: "Download PNG" }).on("click", () => {
  const serialized = new XMLSerializer().serializeToString(svg);
  const blob = new Blob([serialized], { type: "image/svg+xml" });
  const url = URL.createObjectURL(blob);
  const img = new Image();
  img.onload = () => {
    const canvas = document.createElement("canvas");
    canvas.width = dimensions.x;
    canvas.height = dimensions.y;
    canvas.getContext("2d").drawImage(img, 0, 0);
    URL.revokeObjectURL(url);
    canvas.toBlob((pngBlob) => {
      const pngUrl = URL.createObjectURL(pngBlob);
      const a = document.createElement("a");
      a.href = pngUrl;
      a.download = "arcer.png";
      a.click();
      URL.revokeObjectURL(pngUrl);
    });
  };
  img.src = url;
});

window.addEventListener("resize", resize);
resize();

// Point drag — listeners live on the SVG so they survive draw() rebuilding the DOM
svg.addEventListener("pointermove", (e) => {
  if (!dragState.active) return;
  const rect = svg.getBoundingClientRect();
  points[dragState.pointIndex] = new Vec2(
    e.clientX - rect.left,
    e.clientY - rect.top,
  );
  rebuildArcs();
  draw();
});

svg.addEventListener("pointerup", () => {
  if (!dragState.active) return;
  dragState.active = false;
  svg.style.cursor = "";
});

svg.addEventListener("pointercancel", () => {
  dragState.active = false;
  svg.style.cursor = "";
});