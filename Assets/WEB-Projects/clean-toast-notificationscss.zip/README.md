# Clean Toast Notifications - CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/wvZzPQg](https://codepen.io/josetxu/pen/wvZzPQg).

Inspired by <strong>Pallavi's</strong> <a href="https://dribbble.com/shots/13674757-Toast-message">"Toast message"</a> Dribbble Shot.