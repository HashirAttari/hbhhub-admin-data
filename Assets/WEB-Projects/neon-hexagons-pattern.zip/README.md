# Neon Hexagons Pattern

A Pen created on CodePen.

Original URL: [https://codepen.io/AmeliaBR/pen/JdmpJx](https://codepen.io/AmeliaBR/pen/JdmpJx).

Design was mostly ripped off from  [the canvas-based pen Neon Hexagons](http://codepen.io/mariandev/pen/MwPrRm/) by Mihailescu Marian Valentin ([@mariandev](http://codepen.io/mariandev)).  

I used SVG patterns & filters, plus CSS animations, to create a similar effect, and then started tweaking stylistically.

If the filters are choking your computer, just hover the result frame to remove them and see the underlying animation!

<del>One thing I can't quite figure out: the light-colored hexagons should have a delayed animation so that the position of the stroke is at the opposite point as for the dark-colored shapes.  But that doesn't seem to be happening.  Any clue why?</del> <ins>Figured that out; I was setting the animation directly on the `<path>`, so changing the animation on the `<use>` wasn't having an effect!</ins>

See more #NeonHexagonsWeekend pens [in the blog post](http://codepen.io/tmrDevelops/blog/hexagons-in-neon) or [collection](http://codepen.io/collection/Xdbeaa/2/)!