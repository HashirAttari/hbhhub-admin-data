var Calculator = {
   
   init: function() {
      var c = Calculator;
      this.cacheDom(c);
      this.bindEvents(c);   
   },
   
   cache: {  
      calcStr: '0',
      calcArr: [],
      stateDefault: true,   //build expression
      lastArrItem: ''
   },
   
   cacheDom: function(c) {
      c.$el = $('#calcBody');
      c.$displayInp = c.$el.find('#displayInput');
      c.$number = c.$el.find('.number');
      c.$operator = c.$el.find('.operator');
      c.$decPoint = c.$el.find('.decPoint');
      c.$equals = c.$el.find('#keyEquals');
      c.$allClear = c.$el.find('#ac');
      c.$clearLast = c.$el.find('#ce');
   },
   
   bindEvents: function(c) {
      c.$number.on('click', this.processNumKey);
      c.$operator.on('click', this.processOperationKey);
      c.$decPoint.on('click', this.processDecimalPoint);
      c.$equals.on('click', this.calcResult);
      c.$allClear.on('click', this.clearAll);
      c.$clearLast.on('click', this.clearEntry);
   },
   
   //If display string is empty, first key entry can only be a number-- display number
   //If display not empty, concatenate entered number or operator to displayed string
   processNumKey: function() {
      var c = Calculator;                                   
      c.clickedKey = $(this);             
      var keyId = c.clickedKey.attr('id').toString(); 

      //Previous result on display; next key cannot be a number key
      //Reset display and show keyed number
      if (!c.cache.stateDefault) {     //false
         c.clearAll();  
      }
      
      c.updateString(keyId);      
      c.displayString();    
   },  
   
   processOperationKey: function() {
      var c = Calculator;
      c.clickedKey = $(this);             
      var keyId = c.clickedKey.attr('id');  
  
      c.cache.stateDefault = true;
      
      //Check last item in calcArr
      //If last calcArr item is a number update string and display result
      c.lastArrItem = c.findLastArrItem();
      if (!isNaN(c.lastArrItem)) {  
         c.updateString(keyId);         
         c.displayString();  
      }
   },
   
   processDecimalPoint: function() {
      var c = Calculator;
      c.clickedKey = $(this);             
      var keyId = c.clickedKey.attr('id');  
      c.lastArrItem = c.findLastArrItem();
      
      if (!c.cache.stateDefault) {  //false
         c.clearAll();  
      }
      
      //Add decimal point to string only if last calcArr item 
      //is not a decimal point
      if (c.lastArrItem !== '.') {
         c.updateString(keyId);
         c.displayString();   
      }
   },
   
   processEqualsKey: function() {
      var c = Calculator;
      c.calcResult();
      c.displayString();
   },
   
   findLastArrItem: function() {
      var c = Calculator;
      return c.cache.calcArr[c.cache.calcArr.length - 1];
   },
   
   updateString: function(idKey) {  
      var c = Calculator;
      c.cache.calcArr.push(idKey);
      c.cache.calcStr = c.cache.calcArr.join('');   
   },
   
   displayString: function() {
      var c = Calculator;
      c.$displayInp.text(c.cache.calcStr);
   },
   
   calcResult: function() {     //NB: when = entered stateDefault => false
      var c = Calculator;    
      var result = eval(c.cache.calcStr);
     
    //Function findNumberDecDigits() doesn't handle floating point precision when decimal numbers are multiplied (e.g. .1 *.2)
    //var significantDecimals = c.findNumberDecDigits(c.cache.calcArr);
    //result = result.toFixed(significantDecimals);   //round to largest significant decimals in expression
      c.$displayInp.text(result);     
      c.cache.calcArr.length = 0;    //empty array 
      c.cache.calcArr.push(result);
      
      c.cache.stateDefault = false;  
   },
   
   clearAll: function() {      
      var c = Calculator;    
      c.cache.stateDefault = true;       
      c.cache.calcArr.length = 0;       //empty array      
      c.cache.calcStr = '';
      c.$displayInp.text(c.cache.calcStr);
   },  
 
   clearEntry: function() {
      var c = Calculator;   
      c.cache.stateDefault = true;   
      c.cache.calcArr.pop();             //remove last digit
      c.cache.calcStr = c.cache.calcArr.join('');
      c.displayString();
   }, 
   
   findNumberDecDigits(arr) {
      var maxDigitCtr = 0;

      for (var i=0; i<arr.length; i++) { 
         var digitCtr = 0;
         var decPoint = "."; 

         if (arr[i] === ".") {           
            //Set j= i+1, otherwise arr[i] = arr[j] = "."   Go to next item (num)
            for (var j = i+1; j<arr.length; j++) { 
               if (!isNaN(arr[j])) {      //if arr[j] == number  
                  digitCtr += 1;   
               } else {
                  break;
               }   
            }

            //Increment i by value of digitCtr, so not looping though counted digits in digitCtr
            if (digitCtr > 0) {   
               i += digitCtr;

               if (digitCtr > maxDigitCtr)
                  maxDigitCtr = digitCtr;
            }
         } //end if "."
      }  
      return maxDigitCtr;
   }
   
}; //End Calculator object

$( document ).ready(
   Calculator.init()
);