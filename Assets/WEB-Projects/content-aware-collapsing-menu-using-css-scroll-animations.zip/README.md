# Content-aware collapsing menu using CSS scroll animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/gOEQmVW](https://codepen.io/giana/pen/gOEQmVW).

I found a weird behavior when it came to using the `view()` function for scroll-animations, so I thought I'd throw together a simple pen. And since I needed some content to demonstrate the behavior, I figured I'd do a short little write-up of what was going on.

That's when I realized I didn't understand what the hell was going on, so I had to do several more demos, some research, and explain the entire thing to *myself*. And this is the result.

Here's another demo expanding on it: https://codepen.io/giana/pen/gOEQWpR