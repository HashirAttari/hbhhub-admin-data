# Magical Winter - pure css - #02

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/GPmVBG](https://codepen.io/ig_design/pen/GPmVBG).

Inspiration - Envato Elements graphics: https://elements.envato.com/winter-in-city-LQWZHE