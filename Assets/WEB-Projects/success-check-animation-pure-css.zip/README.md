# Success Check Animation Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/istiaktridip/pen/BZqaOd](https://codepen.io/istiaktridip/pen/BZqaOd).

