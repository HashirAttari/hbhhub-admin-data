# Reversible Block Using CSS Grid

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/MWbbexa](https://codepen.io/yudizsolutions/pen/MWbbexa).

The reversible block design is very useful in timeline story layout. In this pen, we create a  Reversible Block design with a dynamic height and loop. for this, we use the CSS Grid property and some minor javascript.

 Made by Nirav nakrani  from Yudiz