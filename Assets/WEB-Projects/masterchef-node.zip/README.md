# Masterchef Node

A Pen created on CodePen.io. Original URL: [https://codepen.io/KikePuma/pen/jOyJVvo](https://codepen.io/KikePuma/pen/jOyJVvo).

An easy way to get started at CodePen with React 0.13 and ES6.