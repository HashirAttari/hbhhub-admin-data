# Background Line Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/LYBMowY](https://codepen.io/yudizsolutions/pen/LYBMowY).

Here's how to implement Vertical line animation for slider section and animate it using CSS. Nice transition effect for fullscreen slider.

Made by Radhika Bhadeliya from Yudiz