# Modal

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/YzyXBrM](https://codepen.io/havardob/pen/YzyXBrM).

Inspired by: https://dribbble.com/shots/8037387-New-Topic/attachments/533209?mode=media 