# Shining Badges w/ mix-blend-mode

A Pen created on CodePen.io. Original URL: [https://codepen.io/sparanoid/pen/YyKqJw](https://codepen.io/sparanoid/pen/YyKqJw).

mix-blend-mode rocks!