# Anamorphic Union Flag (CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/qBXpVYR](https://codepen.io/amit_sheen/pen/qBXpVYR).

