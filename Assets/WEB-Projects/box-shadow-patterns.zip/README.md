# Box Shadow Patterns

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/KKpJLvN](https://codepen.io/MananTank/pen/KKpJLvN).

