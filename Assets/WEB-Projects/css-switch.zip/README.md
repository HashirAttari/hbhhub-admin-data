# [CSS] switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/Raidez/pen/WwjYPx](https://codepen.io/Raidez/pen/WwjYPx).

Framework Bootstrap-oriented
v1.0.1 -> use ~ selector instead of + for more souplex works
v1.1 -> singleton element (webkit support)