# Pure CSS Animated Rubik's Cube

A Pen created on CodePen.io. Original URL: [https://codepen.io/thegreatercurve/pen/vXxvEb](https://codepen.io/thegreatercurve/pen/vXxvEb).

A pure CSS rubik's cube, made possible by some pretty hefty keyframe animations. The rows and columns of colored cells can bisect each other, meaning when one column turns, the relevant cells in the perpendicular row are made transparent.