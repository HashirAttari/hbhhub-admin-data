# Image into Particles (vanilla JS)

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/dyYGMwQ](https://codepen.io/franksLaboratory/pen/dyYGMwQ).

