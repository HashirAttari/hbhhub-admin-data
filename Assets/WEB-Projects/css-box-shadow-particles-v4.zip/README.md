# CSS box shadow particles v4

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/pgJGjw](https://codepen.io/giana/pen/pgJGjw).

Same as <a href="http://codepen.io/giana/pen/JGdbje">the first version</a>, only with different numbers.