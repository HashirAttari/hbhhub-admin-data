# Toggle Pill

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/OJqOVyO](https://codepen.io/alvaromontoro/pen/OJqOVyO).

A pill component coded using a checkbox as a base.

Ideally, instead of having a single element (input of type checkbox), we could have the input inside a label, apply the styles to the label itself, so the text is selectable too. That would require a little extra effort like having styles for focus (as it would be the input that is focused and not the label), but they wouldn't bee too complex.

Note about the previous paragraph: I created that label+checkbox version. You can see it on [this CodePen demo](https://codepen.io/alvaromontoro/pen/VwRygOp). I think that version is nicer because if the styles don't load for whatever reasons, it will display the label, so it will be more accessible for sighted users (in case of error loading the CSS).

Update 2024-02-05: added high-contrast styles.