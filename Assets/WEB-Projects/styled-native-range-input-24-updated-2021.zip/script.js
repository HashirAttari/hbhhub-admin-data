/* external resources *only* for displaying the info boxes */

/* this below is all the JS needed for the demo itself to work */
document.documentElement.classList.add('js');

addEventListener('input', e => {
	let _t = e.target, _p = _t.parentNode;
	
  if(_p.classList.contains('wrap--progr'))
	  _p.style.setProperty(`--val`, +_t.value)
}, false);