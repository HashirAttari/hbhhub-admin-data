# Daily Pen #13 - Valentine Flower

A Pen created on CodePen.

Original URL: [https://codepen.io/kelvinh111/pen/oEGxxw](https://codepen.io/kelvinh111/pen/oEGxxw).

