# Sliding Notifications card

A Pen created on CodePen.io. Original URL: [https://codepen.io/_Sabine/pen/GPwyro](https://codepen.io/_Sabine/pen/GPwyro).

100dayscss - 007
#Notifications card
###Sliding to show menu
Simple ui design, feed animation, hidden navigation
Burger icon micro-interaction + hover effect on nav items from @IanLunn 's amazing hover.css library
Just a touch of jquery to fire event on click