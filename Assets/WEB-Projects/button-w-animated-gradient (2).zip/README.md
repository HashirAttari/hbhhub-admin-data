# Button w/ animated gradient

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/eYXmqJO](https://codepen.io/aaroniker/pen/eYXmqJO).

