# 404 Console

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/YzWKgZL](https://codepen.io/benhatsor/pen/YzWKgZL).

