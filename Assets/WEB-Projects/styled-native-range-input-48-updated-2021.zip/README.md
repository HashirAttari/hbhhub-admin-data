# Styled native range input #48 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/MYVXMR](https://codepen.io/thebabydino/pen/MYVXMR).

**June 2021 update**

Major changes:

* got rid of Compass and Modernizr dependencies, neither of which was needed anyway

* ditched the 1 element restriction and, since I now know how to code a multi thumb slider (see my [article](https://css-tricks.com/multi-thumb-sliders-particular-two-thumb-case/) on CSS-Tricks for details), I added that feature to match the design too (the original 2015 version only had a single handle for both sliders, even though the original design showed two handles for the first one)

* got rid of the convoluted JS that was adding the fill/ progress (now range highlight) for the WebKit browsers and Firefox and switched to a simpler method based on CSS variables (thus reduced the JS to less than 15% of what it was before)

* made it degrade gracefully in the no JS case (the wrapper's `::after` pseudo that's used to create the range highlight gets `display: none` in the no JS case since the values it depends on don't get updated anyway)

* ditched `absolute` positioning in favour of using a `grid` layout now

* used smarter gradient techniques for the slider thumbs to better reproduce the design

* cleaned up the CSS and made it more maintainable by using CSS variables and the DRY switching technique, explained in this two part article I wrote for CSS-Tricks: [part one](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) and [part two](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/)

* made the whole wrapper greyscaled if not hovered no slider within is focused

* ensured it now behaves consistently in both WebKit browsers and Firefox

* not providing free IE/ pre-Chromium support anymore

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS and also has nicely rounded inner corners. Firefox and Chrome/ Opera rely on JS a bit for styling the range track. Fallback for no JS: simply display the same background for the entire track, both before and after the thumb.

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/bcu9IBp.png) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 