# Scroll-driven border drawing (Chrome only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/ZEPxZVe](https://codepen.io/giana/pen/ZEPxZVe).

