# Step by step register form

A Pen created on CodePen.io. Original URL: [https://codepen.io/JeromeRenders/pen/EPNxPv](https://codepen.io/JeromeRenders/pen/EPNxPv).

Hype hype hype ... this code finally works :D

Being a total newbie in Javascript I'm so happy I managed to create this (almost) all by myself. Thanks @Syltaen for guiding me through the last few bugs :3