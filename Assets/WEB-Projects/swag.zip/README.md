# Swag

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/bGgEQLL](https://codepen.io/ricardoolivaalonso/pen/bGgEQLL).

