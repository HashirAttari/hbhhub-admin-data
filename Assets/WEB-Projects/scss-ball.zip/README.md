# [Scss] Ball

A Pen created on CodePen.io. Original URL: [https://codepen.io/nguyenlong/pen/ZLPyYg](https://codepen.io/nguyenlong/pen/ZLPyYg).

