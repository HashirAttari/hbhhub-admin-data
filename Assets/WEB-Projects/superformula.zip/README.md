# Superformula

A Pen created on CodePen.io. Original URL: [https://codepen.io/PicturElements/pen/jLaLVN](https://codepen.io/PicturElements/pen/jLaLVN).

