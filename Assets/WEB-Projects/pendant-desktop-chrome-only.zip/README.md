# Pendant (Desktop Chrome only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/ExjwxQm](https://codepen.io/yuanchuan/pen/ExjwxQm).

