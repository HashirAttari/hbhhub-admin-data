/*

type anything which looks like a color string at the following link to see how they render...

http://davealger.com/color/

*/


// helper functions to get and set css variables
const getCssVar = k => getComputedStyle(document.documentElement).getPropertyValue(k)
const setCssVar = (k,v) => document.documentElement.style.setProperty(k,v)





let boom = (()=>{let h=200;let d=(n)=>Math.floor(Math.random()*n);let k=(c)=>{let s=document.createElement('style');if(!!(window.attachEvent && !window.opera)){s.styleSheet.cssText=c;}else{s.appendChild(document.createTextNode(c));}document.getElementsByTagName('head')[0].appendChild(s);};k('@keyframes u{0%{transform:rotate(0deg);}25%{transform:rotate(4deg);}50%{transform:rotate(0deg);}75%{transform:rotate(-4deg);}100%{transform:rotate(0deg);}};');k('@keyframes m{0%{margin-top:2vh;opacity:0;transform-style: preserve-3d;perspective: '+(d(20)+6)+'px;transform: rotateX(-80deg);}20%{opacity:1.0;margin-top:0vh;margin-left:0vw;transform-style: preserve-3d;perspective: '+(d(20)+6)+'px;transform: rotateX(0deg) rotate('+d(360)+'deg);}100%{opacity:0.4;margin-top:100vh;margin-left:'+d(4)+'vw;transform: rotateX(360deg) rotate(1080deg);}};');let w=document.createElement('div');w.id='daWorld';w.style='animation:u 60s ease-in infinite;position:fixed;top:0;right:0;bottom:0;left:0;pointer-events:none;';document.body.appendChild(w);while(h--){let o=document.createElement('div');o.style=`pointer-events:none;opacity:0;animation:m ${d(6)+2}s ease-in ${d(2000)}ms infinite;z-index:1000;position:fixed;top:${d(40)}vh;left:${d(100)}vw;font-size:${d(16)+8}px;color:${["#ED5565","#FC6E51","#FFCE54","#A0D468","#48CFAD","#4FC1E9","#5D9CEC","#4A89DC","#AC92EC","#EC87C0"][d(10)]};`;o.innerHTML=["▀","▃","▅","▇","▋","▗"][d(6)];w.appendChild(o);}});

let unboom = () => {
  document.getElementById('daWorld').remove();
}

boom();

setTimeout(unboom, 5000)