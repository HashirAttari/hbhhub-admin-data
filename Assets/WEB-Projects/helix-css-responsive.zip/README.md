# Helix (CSS & Responsive)

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/MWpmBBv](https://codepen.io/kitjenson/pen/MWpmBBv).

