# Css Grid Clock (Animated)

A Pen created on CodePen.io. Original URL: [https://codepen.io/flavio_amaral/pen/NWGromV](https://codepen.io/flavio_amaral/pen/NWGromV).

Css Clock made with Grid Layout

Design based on:
- https://dribbble.com/shots/4779256-Hickery-Dickery-Clock