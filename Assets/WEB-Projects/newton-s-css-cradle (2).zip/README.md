# Newton's CSS cradle 

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/XWMXwvJ](https://codepen.io/amit_sheen/pen/XWMXwvJ).

