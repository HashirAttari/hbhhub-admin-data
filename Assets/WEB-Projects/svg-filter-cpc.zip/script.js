const sceneElements = [
  {
    type: "image",
    src: "https://source.unsplash.com/random/800x800?1"
  },
  {
    type: "paragraph",
    text:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut porttitor ex. Nulla facilisi. Mauris dignissim ultrices urna, id varius justo ultricies a. Vestibulum gravida sem at vehicula posuere. Quisque gravida ante sit amet tellus varius, sit amet vehicula turpis consectetur. Fusce vitae nisi suscipit, accumsan purus sed, pharetra nisl. Nullam id tincidunt libero. Vivamus vel vestibulum enim."
  },
  {
    type: "image",
    src: "https://source.unsplash.com/random/800x800?2"
  },
  {
    type: "paragraph",
    text:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut porttitor ex. Nulla facilisi. Mauris dignissim ultrices urna, id varius justo ultricies a. Vestibulum gravida sem at vehicula posuere. Quisque gravida ante sit amet tellus varius, sit amet vehicula turpis consectetur. Fusce vitae nisi suscipit, accumsan purus sed, pharetra nisl. Nullam id tincidunt libero. Vivamus vel vestibulum enim."
  },
  {
    type: "image",
    src: "https://source.unsplash.com/random/800x800?3"
  },
  {
    type: "paragraph",
    text:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut porttitor ex. Nulla facilisi. Mauris dignissim ultrices urna, id varius justo ultricies a. Vestibulum gravida sem at vehicula posuere. Quisque gravida ante sit amet tellus varius, sit amet vehicula turpis consectetur. Fusce vitae nisi suscipit, accumsan purus sed, pharetra nisl. Nullam id tincidunt libero. Vivamus vel vestibulum enim."
  },
  {
    type: "image",
    src: "https://source.unsplash.com/random/800x800?4"
  },
  {
    type: "paragraph",
    text:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut porttitor ex. Nulla facilisi. Mauris dignissim ultrices urna, id varius justo ultricies a. Vestibulum gravida sem at vehicula posuere. Quisque gravida ante sit amet tellus varius, sit amet vehicula turpis consectetur. Fusce vitae nisi suscipit, accumsan purus sed, pharetra nisl. Nullam id tincidunt libero. Vivamus vel vestibulum enim."
  },
  {
    type: "image",
    src: "https://source.unsplash.com/random/800x800?5"
  }
];

let currentScene = 0;
const sceneContainer = document.getElementById("scene");
const prevButton = document.getElementById("prev-scene");
const nextButton = document.getElementById("next-scene");
const instructions = document.getElementById("instructions");

function applyFilterToElement(element, filterId, filterName) {
  if (element.type === "image") {
    element.element.style.filter = `url(#${filterId})`;
  } else if (element.type === "paragraph") {
    element.element.style.filter = `url(#${filterId})`;
  }
  element.element.parentNode.dataset.filter = filterName;
}

function createElement(elementData) {
  const sceneElementContainer = document.createElement("div");
  sceneElementContainer.classList.add("scene-element");

  if (elementData.type === "image") {
    const sceneImage = document.createElement("img");
    sceneImage.src = elementData.src;
    sceneImage.alt = "Scene Image";
    sceneElementContainer.appendChild(sceneImage);
    elementData.element = sceneImage;
  } else if (elementData.type === "paragraph") {
    const sceneParagraph = document.createElement("p");
    sceneParagraph.textContent = elementData.text;
    sceneElementContainer.appendChild(sceneParagraph);
    elementData.element = sceneParagraph;
  }

  sceneContainer.appendChild(sceneElementContainer);
}

function createScene() {
  sceneContainer.innerHTML = "";
  sceneElements.forEach((elementData, index) => {
    createElement(elementData);
  });
  applyFilterToScene();
  updateInstructions();
}

function applyFilterToScene() {
  sceneElements.forEach((elementData) => {
    const randomFilterId = getRandomFilterId();
    const filterName = getFilterName(randomFilterId);
    applyFilterToElement(elementData, randomFilterId, filterName);
  });
}

function getRandomFilterId() {
  const filters = [
    "default-filter",
    "blur-filter",
    "invert-filter",
    "sepia-filter",
    "grayscale-filter"
  ];
  const randomIndex = Math.floor(Math.random() * filters.length);
  return filters[randomIndex];
}

function getFilterName(filterId) {
  switch (filterId) {
    case "default-filter":
      return "Default";
    case "blur-filter":
      return "Blur";
    case "invert-filter":
      return "Invert";
    case "sepia-filter":
      return "Sepia";
    case "grayscale-filter":
      return "Grayscale";
    default:
      return "";
  }
}

function updateInstructions() {
  instructions.textContent =
    "Click 'Next' or 'Previous' to explore different filter effects";
}

function goToPrevScene() {
  currentScene =
    (currentScene - 1 + sceneElements.length) % sceneElements.length;
  applyFilterToScene();
  updateInstructions();
}

function goToNextScene() {
  currentScene = (currentScene + 1) % sceneElements.length;
  applyFilterToScene();
  updateInstructions();
}

prevButton.addEventListener("click", goToPrevScene);
nextButton.addEventListener("click", goToNextScene);

// Initialize with the default scene
createScene();