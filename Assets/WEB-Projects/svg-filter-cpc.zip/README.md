# svg-filter #cpc

A Pen created on CodePen.io. Original URL: [https://codepen.io/rkgith01/pen/wvbaGdR](https://codepen.io/rkgith01/pen/wvbaGdR).

This pen is an svg filter codepen challenge pen, user can see the svg filter applicable on all the tiles be it image or text and they can see this using the next and prev buttons 
#CSS
#HTML
#SVG-FILTERS
#JavaScript