# BG MixMaster 90 — CSS Background Grid /Pattern Generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/jasesmith/pen/YZEYRL](https://codepen.io/jasesmith/pen/YZEYRL).

I started out trying to make a background grid (like graph paper) using only one background gradient property and ended up with this killer mix tape for making all kinds of background grids and patterns.

Built in Chrome. Might be ok in Safari & Firefox. Not really tested anywhere else.