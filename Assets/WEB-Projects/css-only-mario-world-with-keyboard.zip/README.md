# CSS-only Mario World (with keyboard!)

A Pen created on CodePen.

Original URL: [https://codepen.io/t_afif/pen/JoKYwXO](https://codepen.io/t_afif/pen/JoKYwXO).

Not a real game but a nice CSS-only simulation of Mario world

⚠️ Chrome-only ⚠️