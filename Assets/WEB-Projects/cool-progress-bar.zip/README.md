# cool progress bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/Juxtopposed/pen/RwmKEzy](https://codepen.io/Juxtopposed/pen/RwmKEzy).

progress bar inspired by Fortnite's UI mentioned here: https://x.com/juxtopposed/status/1795920312149721590