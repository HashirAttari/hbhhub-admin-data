# Implementation of Animated Icons : Volume II

A Pen created on CodePen.io. Original URL: [https://codepen.io/pBun/pen/DrGLMP](https://codepen.io/pBun/pen/DrGLMP).

Implementation of Prathyush's "Animated Icons : Volume II" http://dribbble.com/shots/722794-Animated-Icons-Volume-II