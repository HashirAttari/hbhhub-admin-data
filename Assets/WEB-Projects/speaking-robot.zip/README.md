# Speaking Robot

A Pen created on CodePen.io. Original URL: [https://codepen.io/WithAnEs/pen/MJrMba](https://codepen.io/WithAnEs/pen/MJrMba).

Animated robot to speak using SpeechSynthesis API to speak a string of text (Fitter Happier).