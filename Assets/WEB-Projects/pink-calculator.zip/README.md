# Pink Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/francescacosta/pen/OgZZvP](https://codepen.io/francescacosta/pen/OgZZvP).

