# Fun with List Styles

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/YzpveEd](https://codepen.io/kitjenson/pen/YzpveEd).

Exploration of unique list-sets in CSS.

Emojis:  https://emojipedia.org/ 
Other HTML symbol codes: https://www.toptal.com/designers/htmlarrows/symbols/