# Angled toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/ExJMJYL](https://codepen.io/amit_sheen/pen/ExJMJYL).

