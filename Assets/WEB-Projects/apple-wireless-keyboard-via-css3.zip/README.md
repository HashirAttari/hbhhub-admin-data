# Apple Wireless Keyboard via CSS3

A Pen created on CodePen.

Original URL: [https://codepen.io/dustinliamc/pen/ALxBaA](https://codepen.io/dustinliamc/pen/ALxBaA).

Apple's wireless keyboard built entirely using css3. I could use code for the background, but currently gradients have really ugly banding. Regardless, enjoy! (: