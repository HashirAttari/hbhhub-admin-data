# Rainbow credit card using CSS filters

A Pen created on CodePen.io. Original URL: [https://codepen.io/cleveryeti/pen/GRLVLae](https://codepen.io/cleveryeti/pen/GRLVLae).

