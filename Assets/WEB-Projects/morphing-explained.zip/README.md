# Morphing explained

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/GRoXPrP](https://codepen.io/ainalem/pen/GRoXPrP).

