# Responsive Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/qejdpw](https://codepen.io/ricardoolivaalonso/pen/qejdpw).

