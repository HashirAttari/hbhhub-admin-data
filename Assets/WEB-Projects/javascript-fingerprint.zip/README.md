# JavaScript Fingerprint

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/XJNXWV](https://codepen.io/run-time/pen/XJNXWV).

This is a javascript only way to fingerprint a user with better than 90% accuracy in as few bytes as possible and no cookie storage!