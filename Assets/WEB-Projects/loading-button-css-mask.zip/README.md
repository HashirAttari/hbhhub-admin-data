# Loading Button CSS Mask

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/MWGLzbN](https://codepen.io/nicolasjesenberger/pen/MWGLzbN).

