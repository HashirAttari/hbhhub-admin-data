# Toggle Liquid (II)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/VwRaLPz](https://codepen.io/alvaromontoro/pen/VwRaLPz).

