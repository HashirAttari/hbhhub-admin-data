# Music Player UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/sowg/pen/abyZMGB](https://codepen.io/sowg/pen/abyZMGB).

Inspired by:

- https://dribbble.com/shots/10108195-Pastel-Neumorphism
- https://dribbble.com/shots/9517002--Light-Mode-Simple-Music-Player

*Picked by CodePen on 23rd October 2021*
