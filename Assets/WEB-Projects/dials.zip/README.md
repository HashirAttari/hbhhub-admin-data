# Dials

A Pen created on CodePen.io. Original URL: [https://codepen.io/fscode/pen/eYVrWJ](https://codepen.io/fscode/pen/eYVrWJ).

