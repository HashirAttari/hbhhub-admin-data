# 3D Walkman - Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/RwBZMGB](https://codepen.io/ricardoolivaalonso/pen/RwBZMGB).

