# Hexagon Buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/rNodvzd](https://codepen.io/nicolasjesenberger/pen/rNodvzd).

Design by [Sébastien Navizet](https://twitter.com/SebastienNvzt)

https://twitter.com/SebastienNvzt/status/1706343489045229782