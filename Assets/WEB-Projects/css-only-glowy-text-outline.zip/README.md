# CSS-only glowy text outline

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/NjBPxX](https://codepen.io/giana/pen/NjBPxX).

