let doodle = document.querySelector('css-doodle');
let button =  document.querySelector('#save');

button.addEventListener('click', async e => {
  await doodle.export({ 
    scale: 2,
    download: true
  });
});