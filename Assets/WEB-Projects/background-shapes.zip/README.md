# background shapes

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/oOgjYY](https://codepen.io/yuanchuan/pen/oOgjYY).

