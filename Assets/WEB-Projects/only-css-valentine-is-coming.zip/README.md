# Only CSS: Valentine is coming

A Pen created on CodePen.

Original URL: [https://codepen.io/YusukeNakaya/pen/vdOJgp](https://codepen.io/YusukeNakaya/pen/vdOJgp).

I need a chocolate ! :D