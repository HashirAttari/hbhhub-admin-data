# CSS LEGO Minifigure Maker

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshbader/pen/MZMzjr](https://codepen.io/joshbader/pen/MZMzjr).

Swap heads, change colors, take it apart, and rebuild it! #LegoLove