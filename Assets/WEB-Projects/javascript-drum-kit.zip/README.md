# JavaScript Drum Kit

A Pen created on CodePen.io. Original URL: [https://codepen.io/amdsouza92/pen/xdooWa](https://codepen.io/amdsouza92/pen/xdooWa).

JavaScript Drum Kit - based off of the javascript30 course by WesBos.