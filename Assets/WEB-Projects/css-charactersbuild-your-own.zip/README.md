# CSS Characters - Build your own

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pedro-Ondiviela/pen/jOJzgKb](https://codepen.io/Pedro-Ondiviela/pen/jOJzgKb).

Build your CSS character! With +100 options and millions of combinations, you can fully personalize it. 

Move the mouse over the frame to change the direction the character is looking to. 

Feel free to use the result, you just have to capture the screen!