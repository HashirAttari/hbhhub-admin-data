# Where's Waldo? 🔎

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/vYXjQZb](https://codepen.io/ykadosh/pen/vYXjQZb).

Can you find Waldo? Use the mouse to move around and zoom in/out. This pen was developed with Webrix.js - A set of powerful building blocks for React-based applications. For more information, visit https://webrix.amdocs.com/