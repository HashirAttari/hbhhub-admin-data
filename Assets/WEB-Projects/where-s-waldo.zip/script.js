import React, { useCallback, useState, useRef } from 'https://cdn.skypack.dev/react@17.0.2';
import ReactDOM from 'https://cdn.skypack.dev/react-dom@17.0.2';

// This pen was developed with Webrix.js - A set of 
// powerful building blocks for React-based applications. 
// For more information, visit https://webrix.amdocs.com/
import { Movable, Pannable, Scalable } from 'https://cdn.skypack.dev/webrix@1.4.0/components';


const MIN = 0.5,MAX = 1.5;
const clamp = (min, max, value) => Math.min(Math.max(value, min), max);

const Slider = ({ value, onChange }) => {
  const movable = useRef();
  const position = `${(value - MIN) / (MAX - MIN) * 90}%`; // 90 so the handle doesn't go beyond the track
  const handleOnMove = useCallback(({ y }) => {
    const { height, top } = movable.current.getBoundingClientRect();
    onChange(() => MIN + clamp(0, height, y - top) / height * (MAX - MIN));
  }, [onChange]);

  return /*#__PURE__*/(
    React.createElement(Movable, { className: "slider", ref: movable, onBeginMove: handleOnMove, onMove: handleOnMove }, /*#__PURE__*/
    React.createElement("div", { className: "value" }, Math.round(value * 100), "%"), /*#__PURE__*/
    React.createElement("div", { className: "handle", style: { top: position } })));


};

const App = () => {
  const [scale, setScale] = useState(0.75);

  return /*#__PURE__*/(
    React.createElement("div", { className: "image-container" }, /*#__PURE__*/
    React.createElement(Slider, { value: scale, onChange: setScale }), /*#__PURE__*/
    React.createElement(Pannable, null, /*#__PURE__*/
    React.createElement(Scalable, { scalex: scale, scaley: scale }, /*#__PURE__*/
    React.createElement("img", { src: "https://raw.githubusercontent.com/open-amdocs/webrix-docs/master/src/content/examples/WheresWaldo/image.jpeg" })))));




};

ReactDOM.render( /*#__PURE__*/
React.createElement(App, null),
document.body);