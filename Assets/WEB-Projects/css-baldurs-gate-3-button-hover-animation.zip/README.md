# CSS Baldurs Gate 3 Button Hover Animation ✨

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/XWoYByX](https://codepen.io/aaroniker/pen/XWoYByX).

Button with a subtle hover animation based on the Baldurs Gate 3 game UI - design is done by Rogie https://twitter.com/rogie/status/1707376313798140230