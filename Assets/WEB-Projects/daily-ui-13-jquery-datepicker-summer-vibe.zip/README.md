# Daily UI #13 | jQuery Datepicker summer vibe

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/WwWooB](https://codepen.io/havardob/pen/WwWooB).

Simple styling of the jQuery UI Datepicker. 

Image credit to: https://dribbble.com/PatrykW 

