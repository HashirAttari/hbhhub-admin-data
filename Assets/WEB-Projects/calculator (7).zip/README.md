# Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/IsaiahIruoha/pen/mdQLRam](https://codepen.io/IsaiahIruoha/pen/mdQLRam).

Calculator, this project allows the user to preform basic math operations on a responsive calculator built to appear similar to the IOS calculator app. FreeCodeCamp Front End Development Libraries Project #4 July 20 2023 Isaiah Iruoha