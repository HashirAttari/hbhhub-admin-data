# Minimal Envelope Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/visnuravichandran/pen/xxZQrmG](https://codepen.io/visnuravichandran/pen/xxZQrmG).

