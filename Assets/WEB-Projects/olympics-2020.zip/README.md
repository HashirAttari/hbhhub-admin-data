# Olympics 2020

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/ExYNYGp](https://codepen.io/ainalem/pen/ExYNYGp).

Low poly animation, CSS only and unfortunately only works in chrome. 306 animated triangles