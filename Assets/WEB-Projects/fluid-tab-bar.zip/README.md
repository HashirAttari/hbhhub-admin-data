# Fluid tab bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/KBvOWV](https://codepen.io/ainalem/pen/KBvOWV).

Remake of Fluid Tab Bar Interaction on dribbble https://dribbble.com/shots/4800174-Fluid-Tab-Bar-Interaction

Icons from the Nuon project 