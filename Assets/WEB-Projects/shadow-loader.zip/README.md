# Shadow Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/PoNaKYm](https://codepen.io/benhatsor/pen/PoNaKYm).

Simple shadow  loader