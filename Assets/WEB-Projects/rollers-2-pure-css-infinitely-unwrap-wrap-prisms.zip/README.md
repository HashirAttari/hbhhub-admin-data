# Rollers #2 (pure CSS infinitely unwrap/ wrap prisms)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/RwNzxN](https://codepen.io/thebabydino/pen/RwNzxN).

Pure CSS. Inspiration: 

![gif](http://1-ps.googleusercontent.com/x/www.bspcn.com/i.imgur.com/eTuC7RD.gif.pagespeed.ce.GkeNfVxNix.gif)