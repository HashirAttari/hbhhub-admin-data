const regl = createREGL();

const drawFrame = regl({
    frag: `
precision highp float;

uniform float ticks;
uniform float width;
uniform float height;

const float PI = 3.141592654;

float hue2rgb(float f1, float f2, float hue) {
    if (hue < 0.0)
        hue += 1.0;
    else if (hue > 1.0)
        hue -= 1.0;
    float res;
    if ((6.0 * hue) < 1.0)
        res = f1 + (f2 - f1) * 6.0 * hue;
    else if ((2.0 * hue) < 1.0)
        res = f2;
    else if ((3.0 * hue) < 2.0)
        res = f1 + (f2 - f1) * ((2.0 / 3.0) - hue) * 6.0;
    else
        res = f1;
    return res;
}

vec3 hsl2rgb(vec3 hsl) {
    vec3 rgb;
    
    if (hsl.y == 0.0) {
        rgb = vec3(hsl.z); // Luminance
    } else {
        float f2;
        
        if (hsl.z < 0.5)
            f2 = hsl.z * (1.0 + hsl.y);
        else
            f2 = hsl.z + hsl.y - hsl.y * hsl.z;
            
        float f1 = 2.0 * hsl.z - f2;
        
        rgb.r = hue2rgb(f1, f2, hsl.x + (1.0/3.0));
        rgb.g = hue2rgb(f1, f2, hsl.x);
        rgb.b = hue2rgb(f1, f2, hsl.x - (1.0/3.0));
    }   
    return rgb;
}

void main () {
  float x = gl_FragCoord.x;
  float y = gl_FragCoord.y;

  float t = (ticks * 0.05) / 10.0;

  float v = ((cos(x / 64.0) + sin(y / 64.0) + t) * 320.0);

  float h = mod(v, 360.0) / 360.0;
  float s = 90.0 / 100.0;
  float l = 50.0 / 100.0;

  gl_FragColor = vec4(hsl2rgb(vec3(h, s, l)), 1.0);
}
`,
    vert: `
precision highp float;
attribute vec2 position;

void main () {
  gl_Position = vec4(position, 0, 1);
}
`,
    attributes: {
        position: [[-1, -1], [-1, 1], [1, -1], [1, -1], [-1, 1], [1, 1]]
    },
    count: 6,
    uniforms: {
        width: ctx => ctx.viewportWidth,
        height: ctx => ctx.viewportHeight,
        ticks: ctx => ctx.tick
    }
});

regl.frame(ctx => {
    regl.clear({
        color: [1, 1, 1, 1],
        depth: 1
    });

    drawFrame();
});