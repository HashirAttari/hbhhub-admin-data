# Psychedelic Rainbow Circles

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/NZKoKx](https://codepen.io/agalliat/pen/NZKoKx).

Psychedelic rainbow circles drawn with WebGL shader using regl.js.