# CSS box shadow particles v6

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/WrvPEj](https://codepen.io/giana/pen/WrvPEj).

Same as <a href="http://codepen.io/giana/pen/JGdbje">the first version</a>, only with different numbers.