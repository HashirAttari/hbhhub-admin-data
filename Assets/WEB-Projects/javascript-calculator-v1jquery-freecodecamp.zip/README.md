# JavaScript Calculator V1 - jQuery | FreeCodeCamp

A Pen created on CodePen.io. Original URL: [https://codepen.io/IAmAlexJohnson/pen/OgmbRN](https://codepen.io/IAmAlexJohnson/pen/OgmbRN).

Built a JavaScript Calculator for freeCodeCamp advanced Front-End development projects using jQuery.