# Mesh Line Explosion

A Pen created on CodePen.io. Original URL: [https://codepen.io/jackrugile/pen/mxRJZQ](https://codepen.io/jackrugile/pen/mxRJZQ).

I used the following tools to create this:

- [Three.js](https://github.com/mrdoob/three.js/) - JavaScript 3D WebGL Library by [mrdoob](https://github.com/mrdoob)
- [THREE.MeshLine](https://github.com/spite/THREE.MeshLine) - Mesh replacement for THREE.Line by [spite](https://github.com/spite)
- [simplex-noise.js](https://github.com/jwagner/simplex-noise.js) - A fast simplex noise implementation in JavaScript by [jwagner](https://github.com/jwagner)
- [VariaBoard](https://github.com/jackrugile/variaboard) - A control interface that is a major work in progress by [me!](https://github.com/jackrugile)
