# Phish Music Player

A Pen created on CodePen.io. Original URL: [https://codepen.io/mattgreenberg/pen/EKQoEy](https://codepen.io/mattgreenberg/pen/EKQoEy).

Fun little UI music player experiment! 