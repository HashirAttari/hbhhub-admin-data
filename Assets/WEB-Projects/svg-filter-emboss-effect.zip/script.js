/*

// source:
// https://codepen.io/vainsan/pen/YzGWbXd

const svgNode = document.getElementById('svg-filter');
const fePointLightNode = svgNode.getElementById('fePointLight3');

svgNode.addEventListener('mousemove', handleMove);
//svgNode.addEventListener('touchmove', handleMove);

function handleMove(event) {
  fePointLightNode.setAttribute('x', event.clientX);
  fePointLightNode.setAttribute('y', event.clientY);
}
*/