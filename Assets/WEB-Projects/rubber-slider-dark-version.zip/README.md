# Rubber Slider (Dark version)

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/jONjVBQ](https://codepen.io/aaroniker/pen/jONjVBQ).

