# Infinite Context Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/Hyperplexed/pen/VwQaWWw](https://codepen.io/Hyperplexed/pen/VwQaWWw).

Try to find the end of the context menu! Good luck 