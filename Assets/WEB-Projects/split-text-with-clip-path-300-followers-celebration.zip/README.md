# Split text with clip-path | 300 followers 'celebration'

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/PoPaWaE](https://codepen.io/havardob/pen/PoPaWaE).

I'm trying to experiment with the clip-path-property and figured I could celebrate reaching 300 followers here on CodePen at the same time. 

Thank you! 