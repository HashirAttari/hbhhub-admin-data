# Bouncy Pagination

A Pen created on CodePen.io. Original URL: [https://codepen.io/cobra_winfrey/pen/PoXbbZO](https://codepen.io/cobra_winfrey/pen/PoXbbZO).

Bouncy SVG path pagination indicators, for your health