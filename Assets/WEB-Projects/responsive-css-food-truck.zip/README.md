# Responsive CSS Food Truck

A Pen created on CodePen.io. Original URL: [https://codepen.io/cobra_winfrey/pen/oNWRbBG](https://codepen.io/cobra_winfrey/pen/oNWRbBG).

Pure CSS food truck + menu