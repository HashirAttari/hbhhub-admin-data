# Styled native range input #27 (updated 2021,  no JS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/EaoqGJ](https://codepen.io/thebabydino/pen/EaoqGJ).

**May 2021 update**

Major changes:

* switched from absolute positioning (which produced broken results for some viewport sizes) to a responsive grid layout

* introduced CSS variables to make the code more compact and easier to maintain

* not providing free support for IE/ pre-Chromium Edge anymore

The external resources are only there to add the warning, which was sadly very necessary given a lot of people shared these saying that I designed them... which is not true.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8.

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/R5BnBxn.jpg) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/).