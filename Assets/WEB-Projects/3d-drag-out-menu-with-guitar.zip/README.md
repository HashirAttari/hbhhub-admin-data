# 3D Drag out menu with guitar

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/wLPZPM](https://codepen.io/jcoulterdesign/pen/wLPZPM).

A recreation of this pen  https://dribbble.com/shots/4773637-3D-flip-menu by Minh Pham