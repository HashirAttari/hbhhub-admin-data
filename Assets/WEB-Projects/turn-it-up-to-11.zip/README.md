# Turn it up to 11 🔈

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/LYOwdEZ](https://codepen.io/ykadosh/pen/LYOwdEZ).

A volume knob that is 1 louder!

Made as a tribute to England's loudest rock band - Spinal Tap!

https://www.youtube.com/watch?v=uMSV4OteqBE