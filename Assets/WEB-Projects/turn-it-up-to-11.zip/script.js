function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}import React, { useState } from 'https://cdn.skypack.dev/react';
import ReactDOM from 'https://cdn.skypack.dev/react-dom';
import { useDrag } from 'https://cdn.skypack.dev/react-use-gesture';

const map = (value, imin, imax, omin, omax) =>
(value - imin) / (imax - imin) * (omax - omin) + omin;


const clamp = (num, min, max) => {
  return Math.min(Math.max(num, min), max);
};

const getElementCenter = el => {
  const { top, left, width, height } = el.getBoundingClientRect();
  return [left + width / 2, top + height / 2];
};

const getAngle = ([x, y], [left, top], from, range) => {
  const adjacent = left - x;
  const opposite = top - y;
  const radians = Math.atan(opposite / adjacent) + (adjacent < 0 ? Math.PI : 0) + Math.PI / 2;
  let angle = radians * (180 / Math.PI); // Convert angle to degrees

  // Normalize the angle to start at 'from', so that the full circle starts
  // and ends at that point.
  angle = angle - from + (angle >= 0 && angle < from ? 360 : 0);

  // When the angle is outside of the given range, we want the angle to go either to the
  // start of the range, or to the end of the range, based on proximity to either end.
  if (angle > 180 + range / 2) {
    angle = 0;
  }

  return clamp(angle, 0, range);
};

const RadialSlider = () => {
  const [angle, setAngle] = useState(40);
  const bind = useDrag(({ values, event }) => {
    setAngle(getAngle(getElementCenter(event.target), values, 220, 280) + 40);
  });

  return /*#__PURE__*/(
    React.createElement("div", _extends({}, bind(), { className: "radial-slider" }), /*#__PURE__*/
    React.createElement("div", { className: "knob", style: { '--angle': `${angle}deg` } }, /*#__PURE__*/
    React.createElement("div", { className: "teeth" }), /*#__PURE__*/
    React.createElement("div", { className: "cap" }), /*#__PURE__*/
    React.createElement("div", { className: "indicator" })), /*#__PURE__*/

    React.createElement("div", { className: "numbers" },
    [...new Array(12)].map((_, i) => /*#__PURE__*/
    React.createElement("div", { className: "number", style: { '--angle': `${Math.round(i * (270 / 11)) - 45}deg` } }, /*#__PURE__*/React.createElement("div", { className: i % 2 && i !== 11 ? 'line' : '' }, i))))));




};

const App = () => /*#__PURE__*/
React.createElement("div", { className: "app" }, /*#__PURE__*/
React.createElement("div", { className: "label" }, "VOLUME"), /*#__PURE__*/
React.createElement(RadialSlider, null), /*#__PURE__*/
React.createElement("div", { className: "tribute" }, "A tribute to ", /*#__PURE__*/
React.createElement("a", { href: "https://www.youtube.com/watch?v=uMSV4OteqBE&ab_channel=dovenol", target: "_blank" })));




ReactDOM.render( /*#__PURE__*/
React.createElement(App, null),
document.body);