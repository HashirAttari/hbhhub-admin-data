# Solo.to Loader Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/eYWvPeM](https://codepen.io/ykadosh/pen/eYWvPeM).

I made this loader animation for the website https://solo.to after one of the co-founders contacted me and asked me if I could do it.

The logo is made of 2 non-closing circular paths with stroke.
The animation is based on the stroke-offset property.

I initially set a stroke-dasharray based on the total length of the path (retrieved using getTotalLength() ).

Then I animate the stroke offset from -1 * totalLength to 1 * totalLength.