# Snail | Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/VqgeyN](https://codepen.io/joshonweb/pen/VqgeyN).

