# HTML5 Before & After Comparison Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/dudleystorey/pen/DJqNKP](https://codepen.io/dudleystorey/pen/DJqNKP).

Uses customised range input for slider. More details [on my blog](http://thenewcode.com/819/A-Before-And-After-Image-Comparison-Slide-Control-in-HTML5)