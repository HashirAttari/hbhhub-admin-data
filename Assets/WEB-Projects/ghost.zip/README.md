# Ghost 👻 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/BazRQyj](https://codepen.io/havardob/pen/BazRQyj).

Halloween is upon us!