new Vue({
  el: '#app',
  data: function () {
    return {
      rims: 9,
      hueSteps: 360 / 10,
      hueLabelSteps: 360 / 10,
      bb: {},
      currentHue: 0,
      currentLight: 1,
      currentSat: .7,
      invertedSL: false };

  },
  computed: {
    conicgradient: function () {

      return new Array(this.hueSteps).
      fill('').
      map((_, i) => `hsl(${i / (this.hueSteps - 1) * 360}, calc(var(--s) * 100%), calc(var(--cd,0) * 100%))`)
      //.map((_,i) => `hsl(${i/(this.hueSteps-1) * 360}, calc(var(--s) * 100%), calc(var(--cd,0) * 100%) ) ${i/(this.hueSteps-1) * 100}% ${(i+1)/(this.hueSteps-1) * 100}%`)
      .join(',');

    },
    conicgradientinv: function () {
      return new Array(this.hueSteps).
      fill('').
      map((_, i) => `hsl(${i / (this.hueSteps - 1) * 360}, calc(var(--cd) * 100%), calc(var(--light,0) * 100%))`)
      //.map((_,i) => `hsl(${i/(this.hueSteps-1) * 360}, calc(var(--s) * 100%), calc(var(--cd,0) * 100%) ) ${i/(this.hueSteps-1) * 100}% ${(i+1)/(this.hueSteps-1) * 100}%`)
      .join(',');
    } },

  methods: {
    picker: function (event) {
      const { offsetX, offsetY } = event;
      const { height, width } = this.bb;
      const cy = height * .5;
      const cx = width * .5;
      const radians = Math.atan2(offsetY - cy, offsetX - cx);
      let deg = radians * (180 / Math.PI);
      deg = (deg + 90) % 360;

      const dist = Math.sqrt(Math.pow(offsetY - cy, 2) + Math.pow(offsetX - cx, 2));
      if (this.invertedSL) {
        this.currentSat = -.2 + dist / cx * 1.5;
      } else {
        this.currentLight = -.2 + dist / cx * 1.5;
      }

      this.currentHue = deg;
    },
    invertSL: function () {
      this.invertedSL = !this.invertedSL;
    },
    updateBB: function () {
      this.bb = this.$refs.wrap.getBoundingClientRect();
    } },

  mounted: function () {
    this.updateBB();
    window.addEventListener('resize', this.updateBB);

    const hamster = Hamster(window);
    hamster.wheel((event, delta, deltaX, deltaY) => {
      if (this.invertedSL) {
        this.currentLight += Math.sign(deltaY) / 250;
        this.currentLight = Math.min(Math.max(this.currentLight, 0), 1);
      } else {
        this.currentSat += Math.sign(deltaY) / 250;
        this.currentLight = Math.min(Math.max(this.currentSat, 0), 1);
      }
    });
  } });