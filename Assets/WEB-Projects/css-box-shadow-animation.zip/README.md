# CSS box shadow animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/rxVNKx](https://codepen.io/giana/pen/rxVNKx).

One div, a ton of box shadows, and a very loud CPU fan.