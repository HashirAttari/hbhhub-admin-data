# Music App Interaction GSAP

A Pen created on CodePen.io. Original URL: [https://codepen.io/shahidshaikhs/pen/xxZZPEG](https://codepen.io/shahidshaikhs/pen/xxZZPEG).

