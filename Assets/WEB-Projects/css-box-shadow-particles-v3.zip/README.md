# CSS box shadow particles v3

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/eJNxmy](https://codepen.io/giana/pen/eJNxmy).

Same as <a href="http://codepen.io/giana/pen/JGdbje">the first version</a>, only with different numbers.