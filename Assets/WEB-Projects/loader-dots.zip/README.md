# Loader dots

A Pen created on CodePen.io. Original URL: [https://codepen.io/desandro/pen/neRvZg](https://codepen.io/desandro/pen/neRvZg).

Lamer version of http://codepen.io/jshawl/pen/IFxBK