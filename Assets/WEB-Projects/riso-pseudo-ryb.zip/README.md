# Riso Pseudo RYB

A Pen created on CodePen.io. Original URL: [https://codepen.io/meodai/pen/LYaGbRL](https://codepen.io/meodai/pen/LYaGbRL).

