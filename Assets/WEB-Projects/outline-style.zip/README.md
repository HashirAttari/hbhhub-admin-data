# Outline-style

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/pQxyXG](https://codepen.io/yuanchuan/pen/pQxyXG).

CSS Challenge: https://twitter.com/yuanchuan23/status/1066555792122241024