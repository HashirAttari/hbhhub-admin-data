# Apple Keyboard

A Pen created on CodePen.

Original URL: [https://codepen.io/jkantner/pen/RJWrmE](https://codepen.io/jkantner/pen/RJWrmE).

Just another CSS grid demo. This time, it’s an interactive Apple USB keyboard (without the cable).

Update 10/28/24: Refactored code, centered the keyboard, improved accessibility