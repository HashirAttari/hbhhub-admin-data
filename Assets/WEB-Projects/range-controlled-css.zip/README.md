# range controlled css

A Pen created on CodePen.io. Original URL: [https://codepen.io/samuelhuth/pen/xxOJeyL](https://codepen.io/samuelhuth/pen/xxOJeyL).

