# Swipe detection (Up/Down)

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/wvpLEKq](https://codepen.io/benhatsor/pen/wvpLEKq).

