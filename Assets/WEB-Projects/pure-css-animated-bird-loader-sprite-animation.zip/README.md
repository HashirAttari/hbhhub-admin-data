# Pure CSS Animated Bird Loader (sprite animation)

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/wvKBEgZ](https://codepen.io/franksLaboratory/pen/wvKBEgZ).

