# CSS Only Resize Panels 🤙

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/abXyZbN](https://codepen.io/jh3y/pen/abXyZbN).

