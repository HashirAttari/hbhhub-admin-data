# 3D Glass Switch (Pure CSS, Neumorphic, Animation)

A Pen created on CodePen.io. Original URL: [https://codepen.io/konstantindenerz/pen/KKxeWKj](https://codepen.io/konstantindenerz/pen/KKxeWKj).

Best result in Chromium-based browsers (Houdini 🧙‍♂️ support) ✅ 

✅ CSS Variables
✅ @property-rule 🧙‍♂️
✅ gradients
✅ backdrop-filter
❌ no JS

Amazing Inspiration: https://dribbble.com/shots/19453000-3D-Glass-Switch