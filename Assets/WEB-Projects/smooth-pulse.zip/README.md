# Smooth Pulse

A Pen created on CodePen.io. Original URL: [https://codepen.io/Raphael/pen/DmvmdX](https://codepen.io/Raphael/pen/DmvmdX).

Easy job for sass+bourbon