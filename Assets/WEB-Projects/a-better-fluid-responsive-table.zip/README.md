# A Better Fluid Responsive Table

A Pen created on CodePen.io. Original URL: [https://codepen.io/dudleystorey/pen/WNQLyd](https://codepen.io/dudleystorey/pen/WNQLyd).

Based on previous work by [Geoff Yuen](http://codepen.io/geoffyuen/details/FCBEg/), improved with JavaScript and semantic markup. [More information on my blog](http://thenewcode.com/852/A-Fresh-Approach-to-Responsive-HTML5-Tables)