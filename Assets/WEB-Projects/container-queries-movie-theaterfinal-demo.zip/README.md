# Container Queries Movie Theater - final demo

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/gOQRgBP](https://codepen.io/amit_sheen/pen/gOQRgBP).

