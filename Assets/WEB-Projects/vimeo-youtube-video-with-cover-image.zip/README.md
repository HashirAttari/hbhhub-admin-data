# Vimeo/YouTube video with cover image

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/xmZpbo](https://codepen.io/ig_design/pen/xmZpbo).

