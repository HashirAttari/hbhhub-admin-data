# Celebrating 500 followers | Scoreboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/MWyaZMR](https://codepen.io/havardob/pen/MWyaZMR).

A CSS illustration of a scoreboard