var toCalc = [];
var last = "first";

function addToCalc(a){
  if(last === "first"){
    document.getElementById('calculator').innerHTML = a;
  }else{
  document.getElementById('calculator').innerHTML += a;
  }
  if(last === "first"){
    toCalc = "";
    toCalc += a;
    last = "firstNum";
  }else if(last === "dot" || last === "num"){
    toCalc += a;
    last = "num";
  }else{
    toCalc += a;
    last = "firstNum";
  }
}
function dot(a){
  if(last!=="dot" && last === "firstNum"){
    document.getElementById('calculator').innerHTML += a;
    toCalc += a;
    last = "dot";
  }
}
function addOp(op){
  if(last === "num" || last === "firstNum" || last === "first"){
    document.getElementById('calculator').innerHTML += op;
    toCalc += op;
    last = "op";
  }
}
function clearCalc(op){
  last = "first";
  toCalc = "";
  document.getElementById('calculator').innerHTML = "0";
}
function squareRoute(){
  if(last === "op"){
    toCalc = toCalc.substr(0, toCalc.length-1);
  }
  toCalc = Math.sqrt(eval(toCalc)).toString();
  if(toCalc.length <= 19){
    document.getElementById('calculator').innerHTML = toCalc;}
  else{
    document.getElementById('calculator').innerHTML = "Digit Limit Exceded"}
  last = "first";
}
function equals(){
  if(last === "op"){
    toCalc = toCalc.substr(0, toCalc.length-1);
  }
  toCalc = eval(toCalc).toString();
  if(toCalc.length <= 19){
    document.getElementById('calculator').innerHTML = toCalc;}
  else{
    document.getElementById('calculator').innerHTML = "Digit Limit Exceded"}
  last = "first";
}