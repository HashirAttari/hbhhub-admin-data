# Shop - Flat Design

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/xxKjWbY](https://codepen.io/ricardoolivaalonso/pen/xxKjWbY).

