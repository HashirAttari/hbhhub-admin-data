# Retro pre code console styling

A Pen created on CodePen.io. Original URL: [https://codepen.io/Designer023/pen/eYoMxb](https://codepen.io/Designer023/pen/eYoMxb).

Making a retro styled pre/code style with subtle animations.