# Cube Unfold Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/alexdevio/pen/dyLJMLg](https://codepen.io/alexdevio/pen/dyLJMLg).

Simple 3D Cube Rotation + Unfold Animation made with HTML & SCSS.