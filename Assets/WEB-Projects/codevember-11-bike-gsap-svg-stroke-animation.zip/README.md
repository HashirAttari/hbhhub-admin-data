# Codevember 11 #bike gsap svg stroke animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/AlaricBaraou/pen/vWxPyp](https://codepen.io/AlaricBaraou/pen/vWxPyp).

Starting from an svg representing a cyclist with multiple stroke i'm able to animate the dash offset of all of thoses at the same time using GSAP DrawSVG plugin and TimelineLite