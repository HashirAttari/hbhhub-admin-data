# Glassmorphic Modern Landing page with Squircle Buttons (Responsive)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Juxtopposed/pen/mdvaezM](https://codepen.io/Juxtopposed/pen/mdvaezM).

