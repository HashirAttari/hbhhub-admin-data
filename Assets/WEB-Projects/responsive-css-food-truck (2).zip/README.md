# Responsive CSS Food Truck

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/qBmzNME](https://codepen.io/benhatsor/pen/qBmzNME).

Pure CSS food truck + menu