# World Clock (pure js - no libraries)

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/RQNQeW](https://codepen.io/run-time/pen/RQNQeW).

