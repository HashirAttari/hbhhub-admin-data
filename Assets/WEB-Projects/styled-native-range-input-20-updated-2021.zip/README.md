# Styled native range input #20 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/myqzEp](https://codepen.io/thebabydino/pen/myqzEp).

**January 2021 update**

Major changes:

* eliminated the 1 element constraint and now used a range `input` tied to an `output` displaying its current value, both of them in a wrapper which stores the current value of the range input in a custom property - this greatly simplifies the JavaScript for updating the fake progress

* used `datalist` for tick marks/ tick labels (see [this twitter thread](https://twitter.com/anatudor/status/1225113768629325825))

* eliminated hacks like using the `-ms-` class for specifically targeting IE (which didn't even work in *pre-Chromium* Edge anyway, which got the `-webkit-` class instead) or the `track`'s `::after` pseudo-element for the progress text label (that's now done cleanly and in a cross-browser manner with the `output` element)

* got rid of `absolute` positioning in favour of a CSS `grid` layout

* made it degrade gracefully in the no JS case (check with JS disabled)/ no Houdini case (check in a browser that doesn't support registering custom properties like Firefox)

Hopefully accessible.

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling the range track. There's a bit of an extra in Chrome/ Opera with a nicely styled tooltip above (not a separate element, a pseudo on the thumb), end labels and a ruler below. This is done using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). Fallback for no JS: simply display the same background for the entire track, both before and after the thumb and no tooltip, end labels or ruler. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](https://pbs.twimg.com/media/B9aH4neCQAEU4BJ?format=png&name=large) 

The Sass code uses [Hugo's string replacement function](http://hugogiraudel.com/2014/01/13/sass-string-replacement-function/). The rest of the Sass code is written by me from scratch today and I'm pretty happy with how it turned out, even though yes, the ruler text thing is hacky and will break with another font.

/*
@function str-replace($string, $search, $replace: '') {
  $index: str-index($string, $search);
  
  @if $index {
    @return 
      str-slice($string, 1, $index - 1) + 
      $replace + 
      str-replace(
        str-slice($string, $index + str-length($search)), 
        $search, 
        $replace
      );
  }
  
  @return $string;
}



@function get-perc($map, $round: false) {
  $val: if(map-has-key($map, val), map-get($map, val), 50);
  $min: if(map-has-key($map, min), map-get($map, min), 0);
  $max: if(map-has-key($map, max), map-get($map, max), 100);
  
  $res: 100*($val - $min)/($max - $min);
  
  @return if($round, round($res), $res);
}



$data: 
  (val: 55, min: 1, s: ' 000 light years')
  (fill: 1, val: 35, s: ' 000 000 miles', ends: 1)
  (val: 0, max: 10, s: ' mm', ends: 1, 
    ruler: '0.0 2.5 5.0 7.5 10', 
    space: calc(#{nth($input-w, 2)/4} - 2.75em))
  (val: 0, min: -50, max: 50, s: '°', ends: 1, 
    ruler: '-50 -25 0.0 +25 +50', 
    space: calc(#{nth($input-w, 2)/4} - 2.875em))
  (fill: 1, val: 4000, max: 5000, p: '$', ends: 1, 
    ruler: '0 1250 2500 3750 5000', 
    space: calc(#{nth($input-w, 2)/4} - 2.75em), 
    back: -.25em)
  (fill: 1, min: 1, val: 90, s: ' 000 €', ends: 1, 
    ruler: '1000 25000 50000 75000 100000', 
    space: calc(#{nth($input-w, 2)/4} - 3.625em), 
    back: -1.2em);
$len: length($data);

/* mixins 
@mixin track() {
  padding: 0 $input-pad/4;
  height: $track-h;
  border-radius: $track-h/3;
  background: $theme-base;
}

@mixin track-lower($val) {
  box-shadow: 
    inset ($track-pad + $thumb-w/2) 0 $theme-highlight,
    inset (-$track-pad + $thumb-w/-2) 0 $theme-base;
  background-image: 
    linear-gradient($theme-highlight, $theme-highlight);
  background-repeat: no-repeat;
  background-clip: content-box;
  background-origin: content-box;
  background-size: $val*1% 100%;
}

@mixin thumb() {
  border: none;
  width: $thumb-w; height: $thumb-h; 
  background: $theme-highlight;
}

/* styling the elements 

html {
  font: 1em arial, sans-serif;
  text-align: center;
}

input[type='range'] {
  $thck: .125em;
  
  -webkit-appearance: none;
  
  display: inline-block;
  margin: .25em 4em;
  border-right: solid $input-pad transparent;
  border-left: solid $input-pad transparent;
  padding: 0;
  height: $input-h;   
  background: transparent;
  background-clip: content-box;
  background-origin: content-box;
  cursor: pointer;
  
  
  /* slider components 
  &::-webkit-slider-runnable-track {
    -webkit-appearance: none;
    position: relative;
    @include track();
  }
  
  &::-moz-range-track {
    @include track();
  }
  
  &::-ms-track {
    border: none;
    @include track();
    color: transparent;
  }
  
  &::-ms-fill-lower, &::-ms-fill-upper {
    background: transparent;
  }
  
  &::-webkit-slider-thumb {
    -webkit-appearance: none;
    position: relative;
    z-index: 1;
    @include thumb();
    margin-top: ($track-h - $thumb-h)/2;
  }
  
  &::-moz-range-thumb {
    @include thumb();
    border-radius: 0;
    
    /* Firefox-only, it won't work in IE 
       and it's messed up in Chrome 
    cursor: ew-resize;
  }
  
  &::-ms-thumb {
    @include thumb();
  }
  
  .js &:nth-of-type(n + 3) /deep/ :not(#track):not(#thumb) {
    position: relative;
    
    &:before, &:after {
      position: absolute;
      top: $input-h/2 + 2.5*$track-h;
      font: 1em courier, monospace;
      white-space: nowrap;
    }
  }
  
  .js & /deep/ #thumb, .js & /deep/ #track {
    &:before, &:after {
      position: absolute;
      font: 1em/1.75 arial, sans-serif;
    }
  }
  
  .js & /deep/ #track {
    &:before, &:after {
      z-index: 0;
      top: ($track-h - $thumb-h)/2;
      padding: 0 .5em;
      border-radius: .25em;
      transform: translate(0, -1.5*$thumb-h);
      background: $theme-base;
      color: $theme-base-txt;
    }
    
    &:before { left: 0; }
    
    &:after { right: 0; }
  }
  
  .js & /deep/ #thumb {
    &:before, &:after {
      left: 50%;
      background: $theme-highlight;
    }
    
    &:before {
      padding: 0 .5em;
      border-radius: .25em;
      transform: translate(-50%, -1.5*$thumb-h);
      color: $theme-highlight-txt;
      white-space: nowrap;
    }
    
    &:after {
      width: $thumb-h/4; height: $thumb-h/4;
      transform: translate(-50%, -.53*$thumb-h) rotate(-45deg);
      background: linear-gradient(45deg, 
        $theme-highlight 50%, transparent 50%);
      content: '';
    }
  }
  
  @for $i from 0 to $len {
    $idx: $i + 1;
    $map: nth($data, $idx);
    
    @if map-has-key($map, ruler) {
      .js &:nth-of-type(#{$idx}) /deep/ :not(#track):not(#thumb) {
        &:before {
          word-spacing: map-get($map, space);
          text-indent: map-get($map, back);
          content: map-get($map, ruler);
        }
      }
    }
    
    @if map-has-key($map, ends) {
      .js &:nth-of-type(#{$idx}) /deep/ #track {
        &:before {
          $txt_val: 
            if(map-has-key($map, p), map-get($map, p), '') + 
            if(map-has-key($map, min), map-get($map, min), 0) + 
            if(map-has-key($map, s), map-get($map, s), '');
          
          @if map-has-key($map, min) == false {
            $txt_val: str-replace($txt_val, ' 000');
          }

          content: $txt_val;
        }
        
        &:after {
          $txt_val: 
            if(map-has-key($map, p), map-get($map, p), '') + 
            if(map-has-key($map, max), map-get($map, max), 100) + 
            if(map-has-key($map, s), map-get($map, s), '');

          content: $txt_val;
        }
      }
    }
    
    .js &:nth-of-type(#{$idx}) /deep/ #thumb:before {
      $txt_val: 
        if(map-has-key($map, p), map-get($map, p), '') + 
        map-get($map, val) + 
        if(map-has-key($map, s), map-get($map, s), '');
      
      content: $txt_val;
    }
  }
  
  
  /* slider variations
  &:nth-child(-n + 2) {
    $w: nth($input-w, 1);
    width: $w;
    background-size: $w/4 $track-h, $w/20 $track-h/2;
  }
  
  &:nth-child(n + 3) {    
    $w: nth($input-w, 2);
    width: $w;
    background: 
      linear-gradient(90deg, 
        $theme-base $thck, transparent $thck), 
      linear-gradient(90deg, 
        $theme-base $thck, transparent $thck), 
      linear-gradient(-90deg, 
        $theme-base $thck/2, transparent $thck/2);
    background-repeat: repeat-x, repeat-x, no-repeat;
    background-clip: content-box;
    background-origin: content-box;
    background-position: 
      -$thck/2 $input-h/2 + $track-h, 
      -$thck/2 $input-h/2 + $track-h, 
      100% $input-h/2 + $track-h;
    background-size: $w/4 $track-h, $w/20 $track-h/2;
  }
  
  @at-root .fill {    
    @for $i from 0 to $len {
      $idx: $i + 1;
      $map: nth($data, $idx);
      
      @if map-has-key($map, fill) {
      
        &:nth-of-type(#{$idx}) {
          &::-webkit-slider-runnable-track {
            @include track-lower(get-perc($map));
          }

          &::-moz-range-track {
            @include track-lower(get-perc($map));
          }
          
          &::-ms-track {
            box-shadow: 
              inset ($input-pad/2 + $thumb-w)/3 0 $theme-highlight;
          }

          &::-ms-fill-lower {            
            background-color: $theme-highlight;
          }
        }
      }
    }
  }
  
/*
  &:focus {
    outline: none;
    border-color: rgba(whitesmoke, .5);
    background-color: rgba(whitesmoke, .5);
  }
}