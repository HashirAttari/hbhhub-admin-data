# Lava Lamp (cpc-liquid)

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/JjRwbmw](https://codepen.io/kitjenson/pen/JjRwbmw).

Here is my simple take on the lava lamp in html, css, javascript.