# Pagination with morphing numbers

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/BaNzPLr](https://codepen.io/ainalem/pen/BaNzPLr).

Pagination with morphing numbers. Morphing each index