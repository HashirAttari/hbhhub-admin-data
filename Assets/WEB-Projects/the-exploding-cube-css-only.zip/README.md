# The Exploding Cube (CSS only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/poZKRye](https://codepen.io/amit_sheen/pen/poZKRye).

