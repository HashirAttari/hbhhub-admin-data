/*
To the love!
If you like my ❤, please give it a ❤.
It's pure CSS (SCSS).
*/