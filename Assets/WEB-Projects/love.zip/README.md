# Love ❤❤❤

A Pen created on CodePen.

Original URL: [https://codepen.io/tiggr/pen/dMPJNo](https://codepen.io/tiggr/pen/dMPJNo).

To the love!
If you like my ❤, please give it a ❤.
It's pure CSS (SCSS).

By the way, if you are wondering how to color emoji (unicode symbols) as I did, when a while after making this heart in red Chrome started showing the particles in a bunch of different colors, you can do it like this:
  color: transparent;
  text-shadow: 0 0 0 red;