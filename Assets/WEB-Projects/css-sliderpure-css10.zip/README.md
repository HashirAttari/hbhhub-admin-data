# CSS Slider - pure css - #10

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/NWxwBvw](https://codepen.io/ig_design/pen/NWxwBvw).

