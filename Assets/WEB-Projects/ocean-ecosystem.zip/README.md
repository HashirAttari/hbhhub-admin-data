# Ocean Ecosystem

A Pen created on CodePen.io. Original URL: [https://codepen.io/fleemaja/pen/PzWjgd](https://codepen.io/fleemaja/pen/PzWjgd).

interactive canvas ecosystem demonstrating the biological principles of natural and sexual selection with genetic algorithms