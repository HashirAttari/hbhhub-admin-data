# Toggle Worm (I)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/WNWxegx](https://codepen.io/alvaromontoro/pen/WNWxegx).

Inspired by Josetxu's Worm Toggle: https://codepen.io/josetxu/pen/QWPNWNa