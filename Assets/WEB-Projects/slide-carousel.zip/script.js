// Variables
var slideIndex = 1;
var slides = ["Slide A", "Slide B", "Slide C", "Slide D"];
var slide = [document.querySelector('.a'), document.querySelector('.b'), document.querySelector('.c'), document.querySelector('.d')];

let slideTimeout;

// Slide Handler
showSlides(slideIndex);

function plusSlides(n) {
  
  if (slideTimeout) window.clearTimeout(slideTimeout);
  
  // Animate slides.
  slide[0].style.animation = "slideA .5s cubic-bezier(.79,.14,.15,.86)";
  slide[1].style.animation = "slideB .5s cubic-bezier(.79,.14,.15,.86)";
  slide[2].style.animation = "slideC .5s cubic-bezier(.79,.14,.15,.86)";
  slide[3].style.animation = "slideD .5s cubic-bezier(.79,.14,.15,.86)";
  
  slideIndex += n;
  
  // Handle slide overflow.
  if (slideIndex > (slides.length - 1)) {
    slideIndex = 0;
  }
  if (slideIndex < 0) {
    slideIndex = slides.length - 1;
  }
  
  // If reverse request:
  if (n < 0) {

    for (var i = 0; i < slide.length; i++) {
      slide[i].style.animationDirection = "reverse";
    }
    
    // Show slide names.
    showSlides(slideIndex);
    
  } else {
    
    for (var i = 0; i < slide.length; i++) {
      slide[i].style.animationDirection = "";
    }
    
  }
  
  // Reset animations when they end, to be able to play them again later.
  slideTimeout = window.setTimeout(function() {
    // Show slide names
    showSlides(slideIndex);
    for(var i = 0; i < slide.length; i++){
      slide[i].style.animation = "none";
    }
  }, 500);
}

function showSlides(n) {
  
  // Display slide names
  slide.forEach((slideEl, index) => {
    
    let currIndex = slideIndex < 0 ? slideIndex + index : slideIndex - index;
    
    slideEl.children[3].textContent = getSlideName(currIndex);
    
  });
  
}

function getSlideName(index) {
  
  if (index > slides.length) index -= slides.length;
  if (index < 0) index += slides.length;
  
  return slides[index];
  
}

// Handle left/right key requests.
document.onkeydown = function(event) {
  switch (event.keyCode) {
    case 37:
      plusSlides(-1);
      break;
    case 39:
      plusSlides(1);
      break;
  }
};