# Pixel Rainbow

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/MWjBPgB](https://codepen.io/franksLaboratory/pen/MWjBPgB).

