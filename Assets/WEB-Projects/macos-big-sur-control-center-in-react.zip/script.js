const Slider = window.ReactRangeslider.default;

const ConnectionModule = () => {

  const [connections, setConnections] = React.useState([
  {
    icon: 'wifi',
    name: 'Wi-Fi',
    status: 'Home',
    off: 'off',
    active: true },

  {
    icon: 'bluetooth',
    name: 'Bluetooth',
    active: false },

  {
    icon: 'rss',
    name: 'AirDrop',
    status: 'Contacts Only',
    off: 'off',
    active: true }]);



  const toggleActive = index => {
    const newConnections = [...connections];
    newConnections[index].active = !newConnections[index].active;
    setConnections(newConnections);
  };

  return /*#__PURE__*/(
    React.createElement("div", { className: "connection-controls rounded module-bg" },
    connections.map((connection, index) => /*#__PURE__*/
    React.createElement("div", { className: "module-wrapper" }, /*#__PURE__*/
    React.createElement("div", { className: "module" }, /*#__PURE__*/
    React.createElement("div", { className: "icon-wrapper" }, /*#__PURE__*/
    React.createElement("button", { type: "button", onClick: () => toggleActive(index), className: connection.active && 'active' }, /*#__PURE__*/React.createElement("i", { "data-feather": connection.icon }))), /*#__PURE__*/

    React.createElement("div", { className: "content-wrapper" }, /*#__PURE__*/
    React.createElement("div", { className: "content" }, /*#__PURE__*/
    React.createElement("p", { className: "name" }, connection.name),
    connection.status && /*#__PURE__*/React.createElement("p", { className: "status" }, !connection.active && connection.off ? connection.off : connection.status))))))));







};

const DoNotDisturb = () => {
  const [active, setActive] = React.useState(false);
  return /*#__PURE__*/(
    React.createElement("div", { className: "do-not-disturb rounded module-bg" }, /*#__PURE__*/
    React.createElement("div", { className: "button-wrapper" }, /*#__PURE__*/
    React.createElement("button", { type: "button", onClick: () => setActive(active => !active), className: active && 'active' }, /*#__PURE__*/React.createElement("i", { "data-feather": "moon" }))), /*#__PURE__*/

    React.createElement("div", { className: "content" }, /*#__PURE__*/React.createElement("p", null, "Do Not", /*#__PURE__*/React.createElement("br", null), "Disturb"))));


};

const SliderComponent = () => {
  const [value, setValue] = React.useState(0);
  return /*#__PURE__*/(
    React.createElement("div", { className: "range" }, /*#__PURE__*/
    React.createElement(Slider, {
      min: 0,
      max: 100,
      value: value,
      tooltip: false,
      orientation: "horizontal",
      onChange: value => setValue(value) })));



};

const FullWidthSlider = ({ text, icon }) => {
  return /*#__PURE__*/(
    React.createElement("div", { className: "slider rounded module-bg" }, /*#__PURE__*/
    React.createElement("p", null, text), /*#__PURE__*/
    React.createElement("div", { className: "slider-inner" }, /*#__PURE__*/
    React.createElement("div", { className: "icon" }, /*#__PURE__*/React.createElement("i", { "data-feather": icon })), /*#__PURE__*/
    React.createElement(SliderComponent, null))));



};

const MusicModule = () => {
  const [play, setPlay] = React.useState(true);

  const togglePlay = () => {
    setPlay(prevState => !prevState);
  };

  return /*#__PURE__*/(
    React.createElement("div", { className: "currently-playing rounded module-bg" }, /*#__PURE__*/
    React.createElement("div", { className: "image" }, /*#__PURE__*/
    React.createElement("img", { src: "https://i1.sndcdn.com/artworks-000596249969-hovmmz-t500x500.jpg", width: "80", alt: "cover art " })), /*#__PURE__*/

    React.createElement("div", { className: "content" }, /*#__PURE__*/
    React.createElement("div", { className: "text" }, /*#__PURE__*/
    React.createElement("h4", null, "SAINt JHN"), /*#__PURE__*/
    React.createElement("p", null, "Roses (Imanbek Remix)"))), /*#__PURE__*/


    React.createElement("div", { className: "controls" }, /*#__PURE__*/
    React.createElement("button", { type: "button", onClick: () => togglePlay() }, /*#__PURE__*/
    React.createElement("div", { style: { display: play ? 'inline-block' : 'none' } }, /*#__PURE__*/
    React.createElement("i", { "data-feather": "play" })), /*#__PURE__*/

    React.createElement("div", { style: { display: play ? 'none' : 'inline-block' } }, /*#__PURE__*/
    React.createElement("i", { "data-feather": "pause" }))))));





};

const App = () => /*#__PURE__*/
React.createElement("div", { className: "card-wrapper rounded" }, /*#__PURE__*/
React.createElement("div", { className: "half-modules-wrapper" }, /*#__PURE__*/
React.createElement(ConnectionModule, null), /*#__PURE__*/
React.createElement("div", { className: "other-connections" }, /*#__PURE__*/
React.createElement(DoNotDisturb, null), /*#__PURE__*/
React.createElement("div", { className: "keyboard-and-airplay" }, /*#__PURE__*/
React.createElement("div", { className: "module rounded module-bg" }, /*#__PURE__*/
React.createElement("i", { "data-feather": "sun" }), /*#__PURE__*/
React.createElement("p", null, "Keyboard Brightness")), /*#__PURE__*/

React.createElement("div", { className: "module rounded module-bg" }, /*#__PURE__*/
React.createElement("i", { "data-feather": "monitor" }), /*#__PURE__*/
React.createElement("p", null, "Airplay Display"))))), /*#__PURE__*/




React.createElement("div", { className: "full-width-modules" }, /*#__PURE__*/
React.createElement(FullWidthSlider, { text: "Display", icon: "sun" }), /*#__PURE__*/
React.createElement(FullWidthSlider, { text: "Sound", icon: "volume-2" }), /*#__PURE__*/
React.createElement(MusicModule, null)));




ReactDOM.render( /*#__PURE__*/React.createElement(App, null), document.getElementById('app'));

feather.replace();