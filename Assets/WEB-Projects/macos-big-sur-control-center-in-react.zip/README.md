# MacOS big sur control center in React

A Pen created on CodePen.io. Original URL: [https://codepen.io/ixahmedxi/pen/zYrdBKx](https://codepen.io/ixahmedxi/pen/zYrdBKx).

MacOS Big Sur introduces a new control center which allows the user to toggle and change various settings quickly. I have decided to implement the design and the interactivity of the control center in ReactJS. This concept could be modified and used in a website to control various aspects like themes and user preferences.  Hope you like this and checkout my other pens for more of my work!

- Follow me on twitter: https://twitter.com/ixahmedxii

- Follow me on github: https://github.com/ixahmedxi