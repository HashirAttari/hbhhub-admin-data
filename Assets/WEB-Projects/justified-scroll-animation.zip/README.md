# Justified Scroll Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/MWmGbVG](https://codepen.io/ykadosh/pen/MWmGbVG).

This pen has columns with varying heights.
By default, you can either align the columns to the top (so they all start at the same position) or to the bottom (so they all end at the same position).

However,  here I "justify" the columns vertically by scrolling each column at a different velocity. 