# CSS Olympic Rings & Torch Cursor

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/WNjzoXX](https://codepen.io/kitjenson/pen/WNjzoXX).

