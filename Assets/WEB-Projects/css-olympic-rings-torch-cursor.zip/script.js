var div = document.querySelector('div')
var torch = document.querySelector('.torch')
var halfW = window.innerWidth/2
var halfH = window.innerHeight/2

window.addEventListener('mousemove', function(e){
  var x = e.clientX;
  var y = e.clientY
  var rx = x < halfW ? -(1-(x/halfW)) : (1-(halfW/x))*2;
  var ry = y < halfH ? (1-(y/halfH)) : -(1-(halfH/y))*2;
    
  div.style.transform = "rotateY("+rx*50+"deg) rotateX("+ry*50+"deg)"
  div.style.filter = 'drop-shadow('+(-rx*100)+'px '+ry*100+'px 15px rgba(0,0,0,.35))'
  
  torch.style.left = x - window.innerWidth*.025 + 'px'
  torch.style.top = y + 'px'
 
})