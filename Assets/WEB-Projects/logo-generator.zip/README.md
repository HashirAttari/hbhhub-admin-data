# Logo Generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/qBpaKK](https://codepen.io/leenalavanya/pen/qBpaKK).

