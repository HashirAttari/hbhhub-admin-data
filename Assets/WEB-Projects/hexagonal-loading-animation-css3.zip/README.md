# Hexagonal Loading Animation (CSS3)

A Pen created on CodePen.io. Original URL: [https://codepen.io/nzbin/pen/eXLeXG](https://codepen.io/nzbin/pen/eXLeXG).

http://dribbble.com/shots/1299843-Hexagonal-Loading-Animation-CSS

http://kevinpaulmartin.com