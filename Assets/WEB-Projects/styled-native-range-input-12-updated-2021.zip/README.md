# Styled native range input #12 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/OPOmbo](https://codepen.io/thebabydino/pen/OPOmbo).

**May 2021 changes**

* removed Compass and Modernizr, both of which were never needed anyway and somehow had managed to stay in
* removed now useless workarounds for bugs that have been fixed in the meanwhile
* cleaned up and compacted the CSS a bit more
* made the fill part CSS-only in Firefox with `::-moz-range-progress`
* made it responsive
* not providing free support for IE/ pre-Chromium Edge anymore

---

**September 2020 update**

Major changes:

* eliminated the 1 element constraint and now used a range `input` tied to an `output` displaying its current value, both of them in a `form` which stores the current value of the range input in a custom property - this greatly simplifies the JavaScript for updating the fake progress

* eliminated hacks like using the `-ms-` class for specifically targeting IE (doesn't work in Edge, which gets the `-webkit-` class instead... yes, it's a crazy world we live in) or the `track`'s `::after` pseudo-element for the progress text label (that's now done cleanly and in a cross-browser manner with the `output` element)

* got rid of `absolute` positioning in favour of a CSS `grid` layout

* simplified the thumb `background`, which is now using 1 `conic-gradient()` layer instead of 8 `linear-gradient()` layers

* added some "blood" to it in the focused state

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling. There's a bit of an extra in Chrome/ Opera with a nicely styled tooltip displaying progress. This is done using `/deep/` - careful, experimental stuff, uncertain future ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)), [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator). No JS falback: simply display the same shade of grey for the entire track, both before and after the thumb and no tooltip. 

Inspiration:

![image](http://i.imgur.com/pL5mAHX.jpg) 