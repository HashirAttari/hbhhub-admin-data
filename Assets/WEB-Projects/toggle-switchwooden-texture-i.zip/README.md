# Toggle Switch - Wooden Texture (I)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/OJqgWRN](https://codepen.io/alvaromontoro/pen/OJqgWRN).

The wooden texture I had from a previous demo. Just tweaked a little. It is simple but a small pain in the neck... and it looks like plastic wood.