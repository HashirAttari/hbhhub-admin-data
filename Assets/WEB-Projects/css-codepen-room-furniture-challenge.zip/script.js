// CSS CodePen Room Furniture Challenge!!

// Fork this and put one piece of furniture in this room
// This room is responsive
// Your furniture must always 'fit' in this room
// All forks will be reviewed in a fun YouTube video next year... 
// The funnier and the more adventurous the better

// HTML and CSS only!

// Your time starts now 🧨