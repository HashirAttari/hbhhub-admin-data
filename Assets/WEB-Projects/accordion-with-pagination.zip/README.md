# Accordion with pagination

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisMaki/pen/JjRGLv](https://codepen.io/chrisMaki/pen/JjRGLv).

Mobile accordion with pagination and css animation. Needs some js clean up.  Css animation borrowed from http://www.justinaguilar.com/animations/index.html

