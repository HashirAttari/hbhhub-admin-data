# AI03: Papilio

A Pen created on CodePen.io. Original URL: [https://codepen.io/cjgammon/pen/vYzLjae](https://codepen.io/cjgammon/pen/vYzLjae).

Alien Interfaces: 03 - Designed by AI / ML with midjourney.  
See the process here: 
https://alieninterfaces.com/cases/papilio.html