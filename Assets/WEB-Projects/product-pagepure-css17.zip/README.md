# Product page - pure css - #17

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/eYJbaRB](https://codepen.io/ig_design/pen/eYJbaRB).

