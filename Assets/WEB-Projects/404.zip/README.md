# 404

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/DwvbyE](https://codepen.io/hakimel/pen/DwvbyE).

The 404 page from my site, full version: http://hakim.se/404

Inspired by http://bit.ly/P6733r