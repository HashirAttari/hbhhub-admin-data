# DUALITY - PURE CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/zYvYrrd](https://codepen.io/MananTank/pen/zYvYrrd).

