# ✅  UX Animation Principles: Duration | @keyframers 1.22.1

A Pen created on CodePen.io. Original URL: [https://codepen.io/team/keyframers/pen/gdJJZV](https://codepen.io/team/keyframers/pen/gdJJZV).

David Khourshid and Stephen Shaw bring examples from an outstanding article on UX animation to life, showcasing good and bad approaches to state animations. This week, they cover the importance of staggering & duration.

* ⏰ Streamed live on September 24, 2018 at https://twitch.tv/keyframers
* 💡Inspiration: https://uxdesign.cc/the-ultimate-guide-to-proper-use-of-animation-in-ux-10bd98614fa9
* 📺 Video: https://youtu.be/WLYaEohJgxE
* 💻 Stagger Code Example: https://cdpn.io/pen/GXaaNw/
* 💻 Duration Code Example: https://cdpn.io/pen/gdJJZV/

Additional Resources:

* Flipping https://github.com/davidkpiano/flipping

Like what we're doing? There are many ways you can support @keyframers so we can keep live coding awesome animations!

* Like & subscribe on YouTube at https://youtube.com/keyframers
* Follow & tweet us at https://twitter.com/keyframers.
* Join the live streams & subscribe on Twitch http://twitch.tv/keyframers 
* Support us on Patreon at https://patreon.com/keyframers 

Topics covered:

* CSS Animation
* Staggering
* Duration
* State machines
* CSS Grid
* Layering