# [Tailwind] - tabbed panels

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/MWdwbxe](https://codepen.io/cbolson/pen/MWdwbxe).

