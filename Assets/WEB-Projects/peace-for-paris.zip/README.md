# Peace for Paris

A Pen created on CodePen.io. Original URL: [https://codepen.io/davidkpiano/pen/jbXXdB](https://codepen.io/davidkpiano/pen/jbXXdB).

My thoughts and prayers go out to all those affected by the recent attacks in Paris.

\#PeaceForParis #BlackLinesWeekend