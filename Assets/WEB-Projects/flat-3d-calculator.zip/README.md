# Flat 3D Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/bennettfeely/pen/AqrvzK](https://codepen.io/bennettfeely/pen/AqrvzK).

Yes. I know flat 3D is a bit of an oxymoron.. Made with animations, transitions, flexbox, all CSS3 goodness. Click on the buttons! Note the calculator can't calculate anything right now...