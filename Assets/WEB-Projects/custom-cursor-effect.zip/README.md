# Custom Cursor Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/KKVjpXx](https://codepen.io/ig_design/pen/KKVjpXx).

