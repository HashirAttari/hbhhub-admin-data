TweenMax.set('svg', { visibility: 'visible'});
TweenMax.set(['#left clippath', '#right clippath', '#bg_1_', '#bg', '#mouth', '#mouthchin'], { transformOrigin: '50% 50%' });

function scene1() {
  var tl = new TimelineMax();
  
  var t = 0.5,
      step = 0.05, 
      y = 300;

  tl
    .staggerFrom(['#brow', '#eyes', '#shading'], t, {
      y: -y,
    ease: Power3.easeOut
    }, step, 0)
  .staggerFrom(['#mouth', '#chin'], t, {
      y: y,
    ease: Power3.easeOut
    }, step, 0);

  return tl;
}

function scene2() {
  var tl = new TimelineMax();
  
  var t = 0.5,
      step = t/8;

  tl
    .add('start')
    .staggerFrom('#lashes_1_ line', t, {
      drawSVG: '0%'
    }, -step, 'start')
    .staggerFrom('#lashes line', t, {
      drawSVG: '0%'
    }, -step, 'start');

  return tl;
}

function blink() {
  var tl = new TimelineMax({
    repeat: -1,
    repeatDelay: 2
      // yoyo: true
  });

  var t = 0.1;
  var eyes = ['#left clippath', '#right clippath', '#bg_1_', '#bg'];

  TweenMax.from(eyes, t, {
    scaleY: 0
  });

  tl
    .to(eyes, t, {
      scaleY: 0,
      yoyo: true,
      repeat: 2,
      delay: 0.3
    })
    .to(eyes, t, {
      scaleY: 1
    });

  return tl;
}

function heartbeat() {
  var tl = new TimelineMax();
  
  // tl
  // .to('.outline', 1, {scale: 2, strokeColor: 'grey'});
  
  return tl;
}

function drops() {
  var t = 1,
      step = 0.5,
      timing = t - step,
      timing2 = null;
  
  var tl = new TimelineMax({
    repeat: -1,
    repeatDelay: step
  });

  tl
  .set('#drops path', {
    opacity: 0
  })  
  .add('begin');
  
  // Opacity
  tl
  .staggerTo('#drops path', t/2, {
    opacity: 1
  }, step, 'begin')
  .staggerTo('#drops path', t/2, {
    opacity: 0
  }, step, 'begin+=0.5')
  
  // y move
  tl
  .staggerTo('#drops path', t, {
    y: 40
  }, step, 'begin');

  return tl;
}

// Loops
function loops(){
  var tl = new TimelineMax();
  
  // tl.add(heartbeat(), 0);
  tl.add(blink(), 0);
  tl.add(drops(), 0);

  return tl;
}

// Master Timeline

var master = new TimelineMax({
  onUpdate: controls.updateSlider,
  // repeat: -1,
  smoothChildTiming: true,
  delay: 2
});

master.add(scene1());
master.add(scene2());
master.add(loops());

/* controls */

// $('document').ready(controls());

function controls() {
  $('body').append('<div id="slider"></div><button class="replay">Replay?</button>');

  master
    .add('button', 1)
    .from('.replay', 0.2, {
      y: -20,
      opacity: 0
    }, 'button');

  $('button').click(function() {
    master.progress(0).play();
  });

  $("#slider").slider({
    range: false,
    min: 0,
    max: 1,
    step: .001,
    slide: function(event, ui) {
      master.progress(ui.value).pause();
    },
    stop: function() {
      master.play();
    }
  });

  var updateSlider = function() {
    $("#slider").slider("value", master.progress());
  }

  return updateSlider;
}