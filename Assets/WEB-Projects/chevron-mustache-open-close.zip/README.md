# Chevron Mustache Open/Close

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/bGmXbva](https://codepen.io/ainalem/pen/bGmXbva).

