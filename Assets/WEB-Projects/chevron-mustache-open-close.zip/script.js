let isExpanded = false;

const card = document.querySelector(".card");
const row = document.querySelector(".row");
const animate = document.querySelector(".animate");

// Keyframes
const values = [
  "M 20,35 C 32.444363,47.444363 49.363649,65 50,65 50.636351,65 66.559179,48.440821 80,35",
  "M 20,40.82089 C 32.444363,53.265253 48.158622,60 50,60 51.841378,60 66.559179,52.619931 80,39.17911",
  "M 20,45.443249 C 32.444363,57.887612 48.158622,55 50,55 51.841378,55 66.559179,56.850871 80,43.410051",
  "M 20,50.840831 C 32.444363,63.285194 48.158622,50 50,50 51.841378,50 66.559179,63.031289 80,49.590469",
  "M 20,55.625181 C 39.489889,69.635216 48.158622,45 50,45 51.841378,45 60.687908,69.381312 80,54.374819",
  "M 20,60.625181 C 38.046868,60.625181 48.158622,40 50,40 51.841378,40 58.628408,59.374819 80,59.374819",
  "M 20,65.625181 C 33.335406,52.289775 48.158622,35 50,35 51.841378,35 66.564635,50.939454 80,64.374819"
];

function handleClick() {
  isExpanded = row.getAttribute("aria-expanded") === "true";

  if (isExpanded) {
    card.classList.remove("active");
  } else {
    card.classList.add("active");
  }

  animate.setAttribute(
    "values",
    !isExpanded ? values.join("; ") : values.slice().reverse().join("; ")
  );
  animate.beginElement();

  row.setAttribute("aria-expanded", !isExpanded);
  row.setAttribute("aria-label", !isExpanded ? "Close Menu" : "Open Menu");
}

const path = document.querySelector(".path");
path.setAttribute("d", values[0]);

row.addEventListener("keydown", (event) => {
  if (event.key === "Enter" || event.key === " ") {
    event.preventDefault();
    row.click();
  }
});