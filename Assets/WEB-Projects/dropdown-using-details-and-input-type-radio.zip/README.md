# Dropdown using <details> and <input type="radio">

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/vYyVXRK](https://codepen.io/havardob/pen/vYyVXRK).

Recreation of this Dribbble shot https://dribbble.com/shots/15124959-Light-UI-Elements by Jan Hoffmann. 