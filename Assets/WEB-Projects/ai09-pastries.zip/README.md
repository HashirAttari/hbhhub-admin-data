# AI09: Pastries

A Pen created on CodePen.io. Original URL: [https://codepen.io/cjgammon/pen/poQEqRy](https://codepen.io/cjgammon/pen/poQEqRy).

Alien Interfaces: 09 - Designed by AI / ML with midjourney.  
See the process here: 
https://alieninterfaces.com/cases/pastries.html