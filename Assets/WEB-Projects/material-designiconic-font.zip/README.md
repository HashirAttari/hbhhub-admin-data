# Material Design - Iconic Font

A Pen created on CodePen.io. Original URL: [https://codepen.io/zavoloklom/pen/LYoavK](https://codepen.io/zavoloklom/pen/LYoavK).

Based on: 
Material Design Icons by Google (https://github.com/google/material-design-icons)

Tested on Win8.1 with browsers: Chrome 37, Firefox 32, Opera 25, IE 11, Safari 5.1.7

More information on: http://zavoloklom.github.io/material-design-iconic-font/