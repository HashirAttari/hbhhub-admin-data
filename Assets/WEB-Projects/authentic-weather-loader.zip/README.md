# Authentic Weather Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/tholman/pen/AvWXMr](https://codepen.io/tholman/pen/AvWXMr).

Loading animation for the new Authentic Weather website ~ http://authenticweather.com