var min = $(".lock").width();
var max = $(window).width();

$(window).resize(function () {
  var sizeNow = $(this).width();
  
  var num1 = 37;
  var num2 = 3;
  var num3 = 7;
  
  var calc = ((sizeNow - min) / (max - min) * 360) - 360;
  
  // last number is for fine tuning
  var c1 = Math.round( (((num1 * 9) * max) / 360)) + 6;
  var c2 = Math.round( (((num2 * 9) * max) / 360) + (((max - min) * 2) + min)) - 5;
  var c3 = Math.round( c2 - ( (max - min) - (num3 - num2) * 9 ));
  
  $(".lock").css("-webkit-transform", "rotate(" + -calc + "deg)");  
  
  if (sizeNow === c1) {
    $("body").addClass("gotFirst");
  } else {
    $("body").attr('data-content',sizeNow - c1);
  }

  if ($('body').hasClass('gotFirst')) {
    if (sizeNow === c2) {
      $("body").addClass("gotSecond");
    } else {
      $("body").attr('data-content',sizeNow - c2);
    }
    
    if ($('body').hasClass('gotSecond')) {
      
      if (sizeNow === c3) {
        $("body").addClass("gotThird");
      } else {
        $("body").attr('data-content',sizeNow - c3);
        if ($('body').hasClass("gotThird")) {
        } else {}
      }
    }
  }
});