# Combination Lock

A Pen created on CodePen.io. Original URL: [https://codepen.io/katydecorah/pen/ngLYaK](https://codepen.io/katydecorah/pen/ngLYaK).

Tug on that browser window: right, left (pass once), right. Get to crackin! p.s. It helps to start with a smallish browser width. Numbers are approximate, I'm werrrkin on it!