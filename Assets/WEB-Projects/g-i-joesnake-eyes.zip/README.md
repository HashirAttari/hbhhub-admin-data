# G.I. Joe - Snake Eyes

A Pen created on CodePen.io. Original URL: [https://codepen.io/tdullah/pen/zEjXao](https://codepen.io/tdullah/pen/zEjXao).

Looks kind of like the old Mii style version of Snake Eyes, huh?