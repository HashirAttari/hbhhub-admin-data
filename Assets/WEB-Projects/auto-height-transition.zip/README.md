# auto-height transition

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/mdQwyWW](https://codepen.io/MananTank/pen/mdQwyWW).

