import Legra from 'https://unpkg.com/legra?module'

const BRICK_SIZE = 12;

const ctx = document.querySelector('canvas').getContext('2d');
const legra = new Legra(ctx, BRICK_SIZE);

function translateRotation(center_x, center_y, radius, angle) {
    const x = center_x + Math.cos(angle * Math.PI / 180) * radius;
    const y = center_y + Math.sin(angle * Math.PI / 180) * radius;
    return {x: x, y: y};
}

function draw() {
    let date = new Date();
    let angleH = (date.getHours() % 12) * 30;
    let angleM = date.getMinutes() * 6;
    let angleS = date.getSeconds() * 6;

    const posH = translateRotation(15, 15,  8, angleH - 90);
    const posM = translateRotation(15, 15, 10, angleM - 90);
    const posS = translateRotation(15, 15, 12, angleS - 90);
    
    legra.circle(15, 15, 15, { filled: true, color: 'lightgray' });
    
    legra.line(15, 1, 15, 2);
    legra.line(15, 29, 15, 28);
    legra.line(1, 15, 2, 15);
    legra.line(29, 15, 28, 15);
    
    legra.line(15, 15, posH.x, posH.y);
    legra.line(15, 15, posM.x, posM.y);
    legra.line(15, 15, posS.x, posS.y);
}

function drawNext() {
    setTimeout(() => {
        ctx.clearRect(0, 0, 1600, 1200);
        draw();
        drawNext();
    }, 1000);
}

drawNext();