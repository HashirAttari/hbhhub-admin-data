# animated Lego Clock ... or ... Playing around with Lego (and LegraJS)

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/xxxeKVa](https://codepen.io/agalliat/pen/xxxeKVa).

