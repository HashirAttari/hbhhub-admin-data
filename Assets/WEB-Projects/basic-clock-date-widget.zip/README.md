# Basic Clock & Date Widget

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/jOYPGY](https://codepen.io/leenalavanya/pen/jOYPGY).

