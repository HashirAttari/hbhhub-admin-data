# Login Badge

A Pen created on CodePen.io. Original URL: [https://codepen.io/cgruber/pen/VwXWBj](https://codepen.io/cgruber/pen/VwXWBj).

