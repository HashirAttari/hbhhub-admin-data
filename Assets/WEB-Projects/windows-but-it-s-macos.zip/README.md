# Windows, but it’s MacOS

A Pen created on CodePen.io. Original URL: [https://codepen.io/cleveryeti/pen/rNQNPGY](https://codepen.io/cleveryeti/pen/rNQNPGY).

