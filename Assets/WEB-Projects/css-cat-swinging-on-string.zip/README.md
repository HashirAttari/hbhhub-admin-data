# CSS: Cat Swinging on String

A Pen created on CodePen.io. Original URL: [https://codepen.io/davidkpiano/pen/Xempjq](https://codepen.io/davidkpiano/pen/Xempjq).

Based on an adorable [Dribbble by Gal Shir](https://dribbble.com/shots/3807778-Swinging-Cat) 🐱