# Scroll based zipper effect : open page by scrolling

A Pen created on CodePen.io. Original URL: [https://codepen.io/josfabre/pen/ZEJmMWL](https://codepen.io/josfabre/pen/ZEJmMWL).

