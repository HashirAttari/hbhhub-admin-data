levels = 6;

speed = 1; // rotate this much degrees per frame
framesPerSecond = 30;

class Flake {
	constructor(rad, angle, level, move = true) {
		this.angle = angle;
		this.rad = rad;
		this.level = level;
		this.move = move;
		this.generateChildren();
	}

	generateChildren() {
		if (this.level <= 0) return;
		this.children = [];
		const step = 360 / this.level;
		for (let i = 0; i < this.level; i++) {
			const flake = new Flake(this.rad / 2, step * i, this.level - 1);
			this.children.push(flake);
		}
	}

	show() {
		push();
		if (this.move) {
			rotate(this.angle);

			if (this.level % 3 === 0) {
				translate(this.rad / 2, 0);
				this.angle += speed;
			} else {
				translate(this.rad / 2, 0);
				this.angle -= speed;
			}
		}

		strokeWeight((width / (levels * 70)) * this.level);
		point(0, 0);

		if (this.children) {
			this.children.forEach((c) => c.show());
		}

		pop();
	}
}

let r;

function reset() {
	r = new Flake(width / 1.3, 0, levels, false);
}

function setup() {
	createCanvas(innerWidth, innerHeight);
	frameRate(framesPerSecond);
	angleMode(DEGREES);
	reset();
	stroke(255);
}


function draw() {
	background(0);
	translate(width / 2, height / 2);
	r.show();
}

function windowResized() {
	resizeCanvas(innerWidth, innerHeight);
	reset();
}