# Animated Cat Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/myacode/pen/qBEvbWg](https://codepen.io/myacode/pen/qBEvbWg).

