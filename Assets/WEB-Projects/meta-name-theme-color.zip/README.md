# <meta name="theme-color">

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/abwjzEK](https://codepen.io/hakimel/pen/abwjzEK).

