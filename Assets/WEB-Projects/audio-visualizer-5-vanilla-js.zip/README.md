# Audio Visualizer 5 (vanilla JS)

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/wvoLVMr](https://codepen.io/franksLaboratory/pen/wvoLVMr).

