# 404 Error Message

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/KVOdOY](https://codepen.io/leenalavanya/pen/KVOdOY).

For my new site - not that 404's pages are really necessary...