# CSS only Animated Sandwatch loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/kh-mamun/pen/Vpozad](https://codepen.io/kh-mamun/pen/Vpozad).

