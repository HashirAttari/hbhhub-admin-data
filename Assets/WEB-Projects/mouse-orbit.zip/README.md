# Mouse Orbit

A Pen created on CodePen.io. Original URL: [https://codepen.io/isuttell/pen/raxRaJ](https://codepen.io/isuttell/pen/raxRaJ).

Chrome Canvas experiment with particles, blending modes and mouse interaction