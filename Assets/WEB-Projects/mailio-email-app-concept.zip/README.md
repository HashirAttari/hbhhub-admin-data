# Mailio – Email App Concept

A Pen created on CodePen.io. Original URL: [https://codepen.io/emilcarlsson/pen/eVNGWG](https://codepen.io/emilcarlsson/pen/eVNGWG).

