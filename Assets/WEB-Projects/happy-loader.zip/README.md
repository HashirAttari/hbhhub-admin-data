# Happy loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/bleepbloop/pen/ZEEWmv](https://codepen.io/bleepbloop/pen/ZEEWmv).

I saw this gif (http://jamesjeffers.tumblr.com/post/16310020460/polywhirl) and couldn't help myself from trying to create this little guy in CSS. He's just so happy!