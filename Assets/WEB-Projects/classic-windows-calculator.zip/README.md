# Classic Windows Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/zYNKPZW](https://codepen.io/jkantner/pen/zYNKPZW).

The Calculator icon from classic versions of Windows has been made interactive! Unfortunately, some buttons had to be left out.

Update 4/6/21: Tab and spacebar no longer misfire keys