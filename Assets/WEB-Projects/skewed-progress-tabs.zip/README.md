# Skewed progress tabs

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/PombeLZ](https://codepen.io/havardob/pen/PombeLZ).

Tilt. Those. Tabs. Or something like that. 