# Glass Progress Ring

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/qBgYzpM](https://codepen.io/jkantner/pen/qBgYzpM).

An SVG circular progress bar made of glass and a glowing fill.