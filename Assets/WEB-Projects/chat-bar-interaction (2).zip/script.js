var toggle = true;
var openAttachment = gsap.timeline({ paused: true });
openAttachment
  .to(".input-field", {
    duration: 0.1,
    ease: "linear",
    rotate: -45,
    transformOrigin: "center left"
  })
  .set(".input-field", { display: "none" })
  .set(".icon-wrapper", { display: "flex" })
  .to(".icon-wrapper", {
    duration: 0.2,
    ease: "linear",
    rotate: 0,
    transformOrigin: "center left"
  });

var addIconToggle = gsap.timeline({ paused: true });
addIconToggle.to(".add-icon", {
  duration: 0.2,
  rotate: 0,
  ease: "linear"
});

var chatBarTop = gsap.timeline({ paused: true });
chatBarTop
  .to(".chat-bar", {
    duration: 0.5,
    rotate: -5,
    transformOrigin: "center left",
    ease: "back"
  })
  .to(".chat-bar", {
    duration: 0.5,
    rotate: 0,
    ease: "back"
  });

var chatBarBottom = gsap.timeline({ paused: true });
chatBarBottom
  .to(".chat-bar", {
    duration: 0.5,
    rotate: 5,
    transformOrigin: "center left",
    ease: "back"
  })
  .to(".chat-bar", {
    duration: 0.5,
    rotate: 0,
    ease: "back"
  });

$(".add-icon").click(() => {
  if (toggle) {
    chatBarTop.restart();
    addIconToggle.play();
    openAttachment.play();
  } else {
    addIconToggle.reverse();
    openAttachment.reverse();
    chatBarBottom.restart();
  }
  toggle = !toggle;
});