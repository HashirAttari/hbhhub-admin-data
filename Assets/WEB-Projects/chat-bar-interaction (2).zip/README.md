# Chat Bar Interaction

A Pen created on CodePen.io. Original URL: [https://codepen.io/visnuravichandran/pen/wvMRxyd](https://codepen.io/visnuravichandran/pen/wvMRxyd).

