# Cookie warnings shouldn't be scary

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/wVdByB](https://codepen.io/havardob/pen/wVdByB).

