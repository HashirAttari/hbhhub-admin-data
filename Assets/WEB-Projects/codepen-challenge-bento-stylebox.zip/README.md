# CodePen Challenge: Bento Style - Box

A Pen created on CodePen.io. Original URL: [https://codepen.io/Azametzin/pen/PoVjRZy](https://codepen.io/Azametzin/pen/PoVjRZy).

https://codepen.io/challenges/2023/november/1