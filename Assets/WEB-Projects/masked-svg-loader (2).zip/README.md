# Masked SVG Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/BabVPVd](https://codepen.io/jh3y/pen/BabVPVd).

