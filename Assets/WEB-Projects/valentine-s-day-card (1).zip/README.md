# Valentine's Day Card

A Pen created on CodePen.

Original URL: [https://codepen.io/thestemdiaries/pen/RwBeVMV](https://codepen.io/thestemdiaries/pen/RwBeVMV).

Pink Valentine's Day letter with animated card

Inspired by @pokecoder