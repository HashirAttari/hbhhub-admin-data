# Low poly animals

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/dKLpBE](https://codepen.io/ainalem/pen/dKLpBE).

No animation framework this time, using raf (requestAnimationFrame) to animate between different low poly animals

Vectors from freepik by Patrickss