const paths = {
  1:    '1 0 2 0',
  10:   '1 0 0 0',
  100:  '1 3 2 3',
  1000: '1 3 0 3',

  2:    '1 1 2 1',
  20:   '1 1 0 1',
  200:  '1 2 2 2',
  2000: '1 2 0 2',

  3:    '1 0 2 1',
  30:   '1 0 0 1',
  300:  '1 3 2 2',
  3000: '1 3 0 2',

  4:    '1 1 2 0',
  40:   '1 1 0 0',
  400:  '1 2 2 3',
  4000: '1 2 0 3',

  5:    '1 0 2 0 1 1',
  50:   '1 0 0 0 1 1',
  500:  '1 2 2 3 1 3',
  5000: '1 2 0 3 1 3',

  6:    '2 0 2 1',
  60:   '0 0 0 1',
  600:  '2 2 2 3',
  6000: '0 2 0 3',

  7:    '1 0 2 0 2 1',
  70:   '1 0 0 0 0 1',
  700:  '1 3 2 3 2 2',
  7000: '1 3 0 3 0 2',

  8:    '1 1 2 1 2 0',
  80:   '1 1 0 1 0 0',
  800:  '1 2 2 2 2 3',
  8000: '1 2 0 2 0 3',

  9:    '1 0 2 0 2 1 1 1',
  90:   '1 0 0 0 0 1 1 1',
  900:  '1 2 2 2 2 3 1 3',
  9000: '1 2 0 2 0 3 1 3',
}

function render(number) {
  let path = String(number)
    .split('')
    .reverse()
    .map((n, i) => {
      let path = paths[n + '0'.repeat(i)];
      return path ? `M ${path}` : '';
    }).join('');
  return `
    <svg viewBox="-.12 -.12 2.24 3.24" role="img">
      <title>${number}</title>
      <path
        d="M 1 0 1 3 ${path}"
        stroke="currentColor"
        stroke-width=".2"
        stroke-linecap="round"
        stroke-linejoin="round"
        fill="none"
      />
    </svg>
  `
}

let svgs = '';
for (let i = 1; i <= 9999; ++i) {
  svgs += `<number>${render(i)}<span>${i}</span></number>`;
}
document.querySelector('main').innerHTML = svgs;