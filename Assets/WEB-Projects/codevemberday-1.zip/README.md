# #Codevember - Day 1

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/jbKgme](https://codepen.io/giana/pen/jbKgme).

Codevember and ten lines challenge. I have no idea why this looks different on Firefox vs Chrome.

Inspired by <a href="http://codepen.io/keithwyland/pen/vNrvem">Neon Orbit</a>.