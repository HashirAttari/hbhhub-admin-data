# Checkwave

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/GRvNmO](https://codepen.io/hakimel/pen/GRvNmO).

Here's a thing. With checkboxes. Because why not.