# No Div Animated Tor Icon

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/mdOPXqp](https://codepen.io/benhatsor/pen/mdOPXqp).

Animated version of [Nikita Hlopov](https://codepen.io/nikitahl)'s icon.