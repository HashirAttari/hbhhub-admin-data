# Apple Photos icon

A Pen created on CodePen.io. Original URL: [https://codepen.io/donotfold/pen/rNRQNej](https://codepen.io/donotfold/pen/rNRQNej).

