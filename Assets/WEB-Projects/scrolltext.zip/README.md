# Scrolltext

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/OJpMYJW](https://codepen.io/benhatsor/pen/OJpMYJW).

Playing around with scroll-based animations using the [Skrollr](https://github.com/Prinzhorn/skrollr) library.  
Tested on Chrome.