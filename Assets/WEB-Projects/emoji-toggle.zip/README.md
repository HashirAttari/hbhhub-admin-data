# Emoji Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/KKYZrRv](https://codepen.io/jkantner/pen/KKYZrRv).

A toggle switch with feelings! Watch the emoji roll from sad to happy and vice versa as you hit this switch!