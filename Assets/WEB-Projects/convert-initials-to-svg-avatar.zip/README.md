# Convert Initials to SVG Avatar

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/WyEdey](https://codepen.io/run-time/pen/WyEdey).

