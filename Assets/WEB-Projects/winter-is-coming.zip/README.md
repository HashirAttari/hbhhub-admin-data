# Winter is Coming

A Pen created on CodePen.io. Original URL: [https://codepen.io/Raphael/pen/DyRXLj](https://codepen.io/Raphael/pen/DyRXLj).

Pure CSS snow