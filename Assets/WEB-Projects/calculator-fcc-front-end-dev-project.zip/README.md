# Calculator (fCC Front End Dev Project)

A Pen created on CodePen.io. Original URL: [https://codepen.io/socraticslip/pen/NWeYrGm](https://codepen.io/socraticslip/pen/NWeYrGm).

Responsive calculator. 

Built with HTML, CSS, and vanilla JavaScript. 

