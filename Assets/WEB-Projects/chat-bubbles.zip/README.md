# chat bubbles

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/VNRBJd](https://codepen.io/run-time/pen/VNRBJd).

