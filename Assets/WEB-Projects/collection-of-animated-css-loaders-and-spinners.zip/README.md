# Collection of animated CSS Loaders and Spinners

A Pen created on CodePen.io. Original URL: [https://codepen.io/kh-mamun/pen/WpdJja](https://codepen.io/kh-mamun/pen/WpdJja).

Animated CSS loader concepts. Tried to make them realistic and small so that everyone can use them. 
Not any funky thing that would need thousand lines of codes and people would hesitate to use them.