# Gangnam Style Keyboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/martinstanicio/pen/dyMvbye](https://codepen.io/martinstanicio/pen/dyMvbye).

Minimal keyboard created using CSS Grid.
Colors from **CodePen's Gangnam Style challenge**.

Try this code:
```
↑ ↑ ↓ ↓ ← → ← → B A Enter
```