# More realistic CSS Dash Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/kh-mamun/pen/zjBvoq](https://codepen.io/kh-mamun/pen/zjBvoq).

Loading animation based on: https://dribbble.com/shots/3678774-Dash-loader