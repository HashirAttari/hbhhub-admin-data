# Toggle Dot/Dash (I)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/NWJZZXp](https://codepen.io/alvaromontoro/pen/NWJZZXp).

