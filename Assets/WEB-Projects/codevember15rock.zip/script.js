/*
**  davealger.info
*/