# CSS Heart Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/PowbEKp](https://codepen.io/aaroniker/pen/PowbEKp).

From https://dribbble.com/shots/8306407-I-heart-toggle