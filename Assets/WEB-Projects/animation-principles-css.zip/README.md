# Animation Principles CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/brianmontanaweb/pen/wpKYwP](https://codepen.io/brianmontanaweb/pen/wpKYwP).

Building basic animations principles concepted by Disney Studios