# 🍔 <-> ❌  (version 1)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Zaku/pen/vYReWM](https://codepen.io/Zaku/pen/vYReWM).

Live Version of this Dribbble shot: http://drbl.in/lUcg

All three versions so far:
1: https://codepen.io/Zaku/pen/vcaFr
2: https://codepen.io/Zaku/pen/JNzYXP
3: https://codepen.io/Zaku/pen/LyvZjY
