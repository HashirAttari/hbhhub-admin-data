# CSS LOGIC GATES

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/mdeJVVL](https://codepen.io/MananTank/pen/mdeJVVL).

So I recently started watching the computer science crash course series and came across [this video](https://www.youtube.com/watch?v=gI-qXk7XojA&list=PL8dPuuaLjXtNlUrzyH5r6jN9ulIgZBpdo&index=4) and I thought maybe boolean algebra can be done using CSS. Turns out CSS is Turing Complete!