# easylogic-colorpicker demo

A Pen created on CodePen.io. Original URL: [https://codepen.io/nzbin/pen/zYdPzyZ](https://codepen.io/nzbin/pen/zYdPzyZ).

https://github.com/easylogic/colorpicker