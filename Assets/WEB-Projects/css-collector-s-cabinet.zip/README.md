# CSS collector’s cabinet

A Pen created on CodePen.io. Original URL: [https://codepen.io/lynnandtonic/pen/LYGjqOo](https://codepen.io/lynnandtonic/pen/LYGjqOo).

Normally I illustrate with a single div, but this one has 50! Whew.