# Overlapping horizontal slideshow using position: sticky; 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/rNjdVjB](https://codepen.io/havardob/pen/rNjdVjB).

My contribution to this weeks CodePen challenge. 