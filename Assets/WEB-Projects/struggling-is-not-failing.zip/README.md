# Struggling is not failing

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/ZEQexLp](https://codepen.io/chrisgannon/pen/ZEQexLp).

