var xmlns = "http://www.w3.org/2000/svg",
  xlinkns = "http://www.w3.org/1999/xlink",
  select = function(s) {
    return document.querySelector(s);
  },
  selectAll = function(s) {
    return document.querySelectorAll(s);
  },
    allText = gsap.utils.toArray('.container p').reverse(),
    colorArray = ['#FFF','#D49C3D','#D14B3D','#CF52EB','#44A3F7','#5ACB3C','#DEBF40'],
    mySplitText = new SplitText('.container p', {type:"words,chars"}), 
    chars = mySplitText.chars

gsap.set('.container', {
 visibility: 'visible'
})
   
gsap.set(allText, {
 color: gsap.utils.wrap(colorArray),
 xPercent: 0,
 yPercent: -50,
	force3D: true,
 transformOrigin: '50% 50%'
})
var mainTl = gsap.timeline();
mainTl
.from(allText, {
 scale: 0,
 rotation: 180,
 duration: 2,
 stagger: {
  each: 0.03
 },
 ease: 'elastic(0.26, 0.57)'
})
 .fromTo(allText, {
 top: '50%' 
}, {
 duration: 0.51,
 top: '60%',
 ease: 'sine.inOut',
 stagger: {
  repeat: -1,
  yoyo: true,
  each: 0.0581
 }
}, '-=1')
.fromTo(allText, {
 left: '+=6%',
 
}, {
 duration: 0.431,
 left: '-=2%',
 ease: 'sine.inOut',
 stagger: {
  repeat: -1,
  yoyo: true,
  each: 0.031
 }
}, '-=' + mainTl.recent().duration())

document.onclick = () => mainTl.play(0)