# Beating Heart w/ CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/carltonstith/pen/kKYpJO](https://codepen.io/carltonstith/pen/kKYpJO).

Valentines Day will be here before we know it.