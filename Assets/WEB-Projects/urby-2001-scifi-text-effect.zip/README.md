# Urby 2001: Scifi Text Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/StephenScaff/pen/gOXrpM](https://codepen.io/StephenScaff/pen/gOXrpM).

