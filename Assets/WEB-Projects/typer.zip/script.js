(function() {
  var delete_speed, letters, next_delay, next_ticker, split, text_delete, text_write, write_speed;

  write_speed = 100; // Writing speed per letter

  delete_speed = 50; // Deletion speed per letter

  next_delay = 1000; // Delay at the end of each word;

  letters = ''; // Default letter count

  split = function() { // Wrap each letter in a span
    $('.ticker_item').each(function() {
      var i, text, words;
      // Each item
      i = void 0;
      text = void 0;
      words = void 0;
      words = $(this).text().split('');
// Split
      for (i in words) {
        i = i;
        if (window.CP.shouldStopExecution(1)) {
          break;
        }
        i = i;
        words[i] = '<span>' + words[i] + '</span>';
      }
      // Wrap each letter in a span
      window.CP.exitedLoop(1);
      text = words.join('');
      // Join letters
      $(this).html(text);
    });
  };

  // Move on to next item
  // Update html
  next_ticker = function() {
    if ($('.current_ticker').is(':last-child')) {
      // If this is the last item
      $('.current_ticker').removeClass('current_ticker').addClass('delete_ticker');
      // Delete
      $('.first_ticker').addClass('current_ticker');
    } else {
      // Start again
      $('.current_ticker').removeClass('current_ticker').addClass('delete_ticker').next().addClass('current_ticker');
    }
    // Move on to next item
    setTimeout((function() {
      $('.delete_ticker').appendTo('.ticker').removeClass('delete_ticker');
      // Move the item to the end
      text_write();
    // Start writing
    }), 40);
  };

  // Delete text
  text_delete = function() {
    setTimeout((function() {
      var text_delete_timer;
      text_delete_timer = setInterval((function() {
        if (letters > 0) {
          // If letters still remain
          $('.current_ticker span:nth-of-type(' + letters + ')').css('display', 'none');
          // Hide letter
          letters--;
        } else {
          // Decrease letter count
          clearInterval(text_delete_timer);
          // Clear interval
          next_ticker();
        }
      // Move on
      }), delete_speed);
    }), next_delay);
  };

  // Write text
  text_write = function() {
    var count, text_write_timer;
    count = 0;
    letters = $('.current_ticker span').length;
    // Set amount of letters in item
    text_write_timer = setInterval((function() {
      if (count - 1 < letters) {
        // If letters still remain
        $('.current_ticker span:nth-of-type(' + count + ')').css('display', 'inline');
        // Show
        count++;
      } else {
        // Increase shown count
        clearInterval(text_write_timer);
        // Clear interval
        text_delete();
      }
    // Start deleting
    }), write_speed);
  };

  split();

  text_write();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiPGFub255bW91cz4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLFlBQUEsRUFBQSxPQUFBLEVBQUEsVUFBQSxFQUFBLFdBQUEsRUFBQSxLQUFBLEVBQUEsV0FBQSxFQUFBLFVBQUEsRUFBQTs7RUFBQSxXQUFBLEdBQWMsSUFBZDs7RUFDQSxZQUFBLEdBQWUsR0FEZjs7RUFFQSxVQUFBLEdBQWEsS0FGYjs7RUFHQSxPQUFBLEdBQVUsR0FIVjs7RUFLQSxLQUFBLEdBQVEsUUFBQSxDQUFBLENBQUEsRUFBQTtJQUNOLENBQUEsQ0FBRSxjQUFGLENBQWlCLENBQUMsSUFBbEIsQ0FBdUIsUUFBQSxDQUFBLENBQUE7QUFDekIsVUFBQSxDQUFBLEVBQUEsSUFBQSxFQUFBLEtBQUE7O01BQ0ksQ0FBQSxHQUFJO01BQ0osSUFBQSxHQUFPO01BQ1AsS0FBQSxHQUFRO01BQ1IsS0FBQSxHQUFRLENBQUEsQ0FBRSxJQUFGLENBQU8sQ0FBQyxJQUFSLENBQUEsQ0FBYyxDQUFDLEtBQWYsQ0FBcUIsRUFBckIsRUFKWjs7TUFNSSxLQUFBLFVBQUE7UUFDRTtRQUNBLElBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxtQkFBVixDQUE4QixDQUE5QixDQUFIO0FBQ0UsZ0JBREY7O1FBRUEsQ0FBQSxHQUFJO1FBQ0osS0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLFFBQUEsR0FBVyxLQUFLLENBQUMsQ0FBRCxDQUFoQixHQUFzQjtNQUxuQyxDQU5KOztNQWFJLE1BQU0sQ0FBQyxFQUFFLENBQUMsVUFBVixDQUFxQixDQUFyQjtNQUNBLElBQUEsR0FBTyxLQUFLLENBQUMsSUFBTixDQUFXLEVBQVgsRUFkWDs7TUFnQkksQ0FBQSxDQUFFLElBQUYsQ0FBTyxDQUFDLElBQVIsQ0FBYSxJQUFiO0lBakJxQixDQUF2QjtFQURNLEVBTFI7Ozs7RUE4QkEsV0FBQSxHQUFjLFFBQUEsQ0FBQSxDQUFBO0lBQ1osSUFBRyxDQUFBLENBQUUsaUJBQUYsQ0FBb0IsQ0FBQyxFQUFyQixDQUF3QixhQUF4QixDQUFIOztNQUVFLENBQUEsQ0FBRSxpQkFBRixDQUFvQixDQUFDLFdBQXJCLENBQWlDLGdCQUFqQyxDQUFrRCxDQUFDLFFBQW5ELENBQTRELGVBQTVELEVBREo7O01BR0ksQ0FBQSxDQUFFLGVBQUYsQ0FBa0IsQ0FBQyxRQUFuQixDQUE0QixnQkFBNUIsRUFKRjtLQUFBLE1BQUE7O01BT0UsQ0FBQSxDQUFFLGlCQUFGLENBQW9CLENBQUMsV0FBckIsQ0FBaUMsZ0JBQWpDLENBQWtELENBQUMsUUFBbkQsQ0FBNEQsZUFBNUQsQ0FBNEUsQ0FBQyxJQUE3RSxDQUFBLENBQW1GLENBQUMsUUFBcEYsQ0FBNkYsZ0JBQTdGLEVBUEY7S0FBRjs7SUFTRSxVQUFBLENBQVcsQ0FBQyxRQUFBLENBQUEsQ0FBQTtNQUNWLENBQUEsQ0FBRSxnQkFBRixDQUFtQixDQUFDLFFBQXBCLENBQTZCLFNBQTdCLENBQXVDLENBQUMsV0FBeEMsQ0FBb0QsZUFBcEQsRUFBSjs7TUFFSSxVQUFBLENBQUEsRUFIVTs7SUFBQSxDQUFELENBQVgsRUFNRyxFQU5IO0VBVlksRUE5QmQ7OztFQW1EQSxXQUFBLEdBQWMsUUFBQSxDQUFBLENBQUE7SUFDWixVQUFBLENBQVcsQ0FBQyxRQUFBLENBQUEsQ0FBQTtBQUNkLFVBQUE7TUFBSSxpQkFBQSxHQUFvQixXQUFBLENBQVksQ0FBQyxRQUFBLENBQUEsQ0FBQTtRQUMvQixJQUFHLE9BQUEsR0FBVSxDQUFiOztVQUVFLENBQUEsQ0FBRSxtQ0FBQSxHQUFzQyxPQUF0QyxHQUFnRCxHQUFsRCxDQUFzRCxDQUFDLEdBQXZELENBQTJELFNBQTNELEVBQXNFLE1BQXRFLEVBRFI7O1VBR1EsT0FBQSxHQUpGO1NBQUEsTUFBQTs7VUFPRSxhQUFBLENBQWMsaUJBQWQsRUFBUjs7VUFFUSxXQUFBLENBQUEsRUFURjtTQUQrQjs7TUFBQSxDQUFELENBQVosRUFhakIsWUFiaUI7SUFEVixDQUFELENBQVgsRUFnQkcsVUFoQkg7RUFEWSxFQW5EZDs7O0VBeUVBLFVBQUEsR0FBYSxRQUFBLENBQUEsQ0FBQTtBQUNiLFFBQUEsS0FBQSxFQUFBO0lBQUUsS0FBQSxHQUFRO0lBQ1IsT0FBQSxHQUFVLENBQUEsQ0FBRSxzQkFBRixDQUF5QixDQUFDLE9BRHRDOztJQUdFLGdCQUFBLEdBQW1CLFdBQUEsQ0FBWSxDQUFDLFFBQUEsQ0FBQSxDQUFBO01BQzlCLElBQUcsS0FBQSxHQUFRLENBQVIsR0FBWSxPQUFmOztRQUVFLENBQUEsQ0FBRSxtQ0FBQSxHQUFzQyxLQUF0QyxHQUE4QyxHQUFoRCxDQUFvRCxDQUFDLEdBQXJELENBQXlELFNBQXpELEVBQW9FLFFBQXBFLEVBRE47O1FBR00sS0FBQSxHQUpGO09BQUEsTUFBQTs7UUFPRSxhQUFBLENBQWMsZ0JBQWQsRUFBTjs7UUFFTSxXQUFBLENBQUEsRUFURjtPQUQ4Qjs7SUFBQSxDQUFELENBQVosRUFhaEIsV0FiZ0I7RUFKUjs7RUFvQmIsS0FBQSxDQUFBOztFQUNBLFVBQUEsQ0FBQTtBQTlGQSIsInNvdXJjZXNDb250ZW50IjpbIndyaXRlX3NwZWVkID0gMTAwICMgV3JpdGluZyBzcGVlZCBwZXIgbGV0dGVyXG5kZWxldGVfc3BlZWQgPSA1MCAjIERlbGV0aW9uIHNwZWVkIHBlciBsZXR0ZXJcbm5leHRfZGVsYXkgPSAxMDAwICMgRGVsYXkgYXQgdGhlIGVuZCBvZiBlYWNoIHdvcmQ7XG5sZXR0ZXJzID0gJycgIyBEZWZhdWx0IGxldHRlciBjb3VudFxuXG5zcGxpdCA9IC0+ICMgV3JhcCBlYWNoIGxldHRlciBpbiBhIHNwYW5cbiAgJCgnLnRpY2tlcl9pdGVtJykuZWFjaCAtPlxuICAgICMgRWFjaCBpdGVtXG4gICAgaSA9IHVuZGVmaW5lZFxuICAgIHRleHQgPSB1bmRlZmluZWRcbiAgICB3b3JkcyA9IHVuZGVmaW5lZFxuICAgIHdvcmRzID0gJCh0aGlzKS50ZXh0KCkuc3BsaXQoJycpXG4gICAgIyBTcGxpdFxuICAgIGZvciBpIG9mIHdvcmRzXG4gICAgICBgaSA9IGlgXG4gICAgICBpZiB3aW5kb3cuQ1Auc2hvdWxkU3RvcEV4ZWN1dGlvbigxKVxuICAgICAgICBicmVha1xuICAgICAgaSA9IGlcbiAgICAgIHdvcmRzW2ldID0gJzxzcGFuPicgKyB3b3Jkc1tpXSArICc8L3NwYW4+J1xuICAgICAgIyBXcmFwIGVhY2ggbGV0dGVyIGluIGEgc3BhblxuICAgIHdpbmRvdy5DUC5leGl0ZWRMb29wIDFcbiAgICB0ZXh0ID0gd29yZHMuam9pbignJylcbiAgICAjIEpvaW4gbGV0dGVyc1xuICAgICQodGhpcykuaHRtbCB0ZXh0XG4gICAgIyBVcGRhdGUgaHRtbFxuICAgIHJldHVyblxuICByZXR1cm5cblxuIyBNb3ZlIG9uIHRvIG5leHQgaXRlbVxuXG5uZXh0X3RpY2tlciA9IC0+XG4gIGlmICQoJy5jdXJyZW50X3RpY2tlcicpLmlzKCc6bGFzdC1jaGlsZCcpXG4gICAgIyBJZiB0aGlzIGlzIHRoZSBsYXN0IGl0ZW1cbiAgICAkKCcuY3VycmVudF90aWNrZXInKS5yZW1vdmVDbGFzcygnY3VycmVudF90aWNrZXInKS5hZGRDbGFzcyAnZGVsZXRlX3RpY2tlcidcbiAgICAjIERlbGV0ZVxuICAgICQoJy5maXJzdF90aWNrZXInKS5hZGRDbGFzcyAnY3VycmVudF90aWNrZXInXG4gICAgIyBTdGFydCBhZ2FpblxuICBlbHNlXG4gICAgJCgnLmN1cnJlbnRfdGlja2VyJykucmVtb3ZlQ2xhc3MoJ2N1cnJlbnRfdGlja2VyJykuYWRkQ2xhc3MoJ2RlbGV0ZV90aWNrZXInKS5uZXh0KCkuYWRkQ2xhc3MgJ2N1cnJlbnRfdGlja2VyJ1xuICAgICMgTW92ZSBvbiB0byBuZXh0IGl0ZW1cbiAgc2V0VGltZW91dCAoLT5cbiAgICAkKCcuZGVsZXRlX3RpY2tlcicpLmFwcGVuZFRvKCcudGlja2VyJykucmVtb3ZlQ2xhc3MgJ2RlbGV0ZV90aWNrZXInXG4gICAgIyBNb3ZlIHRoZSBpdGVtIHRvIHRoZSBlbmRcbiAgICB0ZXh0X3dyaXRlKClcbiAgICAjIFN0YXJ0IHdyaXRpbmdcbiAgICByZXR1cm5cbiAgKSwgNDBcbiAgcmV0dXJuXG5cbiMgRGVsZXRlIHRleHRcblxudGV4dF9kZWxldGUgPSAtPlxuICBzZXRUaW1lb3V0ICgtPlxuICAgIHRleHRfZGVsZXRlX3RpbWVyID0gc2V0SW50ZXJ2YWwoKC0+XG4gICAgICBpZiBsZXR0ZXJzID4gMFxuICAgICAgICAjIElmIGxldHRlcnMgc3RpbGwgcmVtYWluXG4gICAgICAgICQoJy5jdXJyZW50X3RpY2tlciBzcGFuOm50aC1vZi10eXBlKCcgKyBsZXR0ZXJzICsgJyknKS5jc3MgJ2Rpc3BsYXknLCAnbm9uZSdcbiAgICAgICAgIyBIaWRlIGxldHRlclxuICAgICAgICBsZXR0ZXJzLS1cbiAgICAgICAgIyBEZWNyZWFzZSBsZXR0ZXIgY291bnRcbiAgICAgIGVsc2VcbiAgICAgICAgY2xlYXJJbnRlcnZhbCB0ZXh0X2RlbGV0ZV90aW1lclxuICAgICAgICAjIENsZWFyIGludGVydmFsXG4gICAgICAgIG5leHRfdGlja2VyKClcbiAgICAgICAgIyBNb3ZlIG9uXG4gICAgICByZXR1cm5cbiAgICApLCBkZWxldGVfc3BlZWQpXG4gICAgcmV0dXJuXG4gICksIG5leHRfZGVsYXlcbiAgcmV0dXJuXG5cbiMgV3JpdGUgdGV4dFxuXG50ZXh0X3dyaXRlID0gLT5cbiAgY291bnQgPSAwXG4gIGxldHRlcnMgPSAkKCcuY3VycmVudF90aWNrZXIgc3BhbicpLmxlbmd0aFxuICAjIFNldCBhbW91bnQgb2YgbGV0dGVycyBpbiBpdGVtXG4gIHRleHRfd3JpdGVfdGltZXIgPSBzZXRJbnRlcnZhbCgoLT5cbiAgICBpZiBjb3VudCAtIDEgPCBsZXR0ZXJzXG4gICAgICAjIElmIGxldHRlcnMgc3RpbGwgcmVtYWluXG4gICAgICAkKCcuY3VycmVudF90aWNrZXIgc3BhbjpudGgtb2YtdHlwZSgnICsgY291bnQgKyAnKScpLmNzcyAnZGlzcGxheScsICdpbmxpbmUnXG4gICAgICAjIFNob3dcbiAgICAgIGNvdW50KytcbiAgICAgICMgSW5jcmVhc2Ugc2hvd24gY291bnRcbiAgICBlbHNlXG4gICAgICBjbGVhckludGVydmFsIHRleHRfd3JpdGVfdGltZXJcbiAgICAgICMgQ2xlYXIgaW50ZXJ2YWxcbiAgICAgIHRleHRfZGVsZXRlKClcbiAgICAgICMgU3RhcnQgZGVsZXRpbmdcbiAgICByZXR1cm5cbiAgKSwgd3JpdGVfc3BlZWQpXG4gIHJldHVyblxuXG5zcGxpdCgpXG50ZXh0X3dyaXRlKCkiXX0=
//# sourceURL=coffeescript