//https://github.com/Wlada/vue-carousel-3d
new Vue({
  el: "#carousel",

  data: {
    slides: 7
  },
  components: {
    'carousel-3d': window['carousel-3d'].Carousel3d,
    'slide': window['carousel-3d'].Slide
  }
})