# vue-carousel-3d

A Pen created on CodePen.io. Original URL: [https://codepen.io/diomed/pen/OmmEaK](https://codepen.io/diomed/pen/OmmEaK).

vue carousel in 3d

https://github.com/Wlada/vue-carousel-3d