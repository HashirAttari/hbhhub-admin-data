# Zürich Tonhalle (1955)

A Pen created on CodePen.io. Original URL: [https://codepen.io/jonyablonski/pen/Dorevq](https://codepen.io/jonyablonski/pen/Dorevq).

Josef Müller-Brockmann / 1955

From the Swiss In CSS Project: http://swissincss.com/zurich-tonhalle-1955.html