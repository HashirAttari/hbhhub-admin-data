# CSS loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/KMGGvL](https://codepen.io/havardob/pen/KMGGvL).

