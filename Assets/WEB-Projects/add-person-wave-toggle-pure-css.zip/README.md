# Add person wave toggle (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/jOWzzBr](https://codepen.io/benhatsor/pen/jOWzzBr).

A pure CSS toggle with a Neomorpism wave and SVG animations.