# Alesis V25

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/RwKyeEg](https://codepen.io/ricardoolivaalonso/pen/RwKyeEg).

