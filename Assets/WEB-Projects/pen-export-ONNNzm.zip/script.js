var e = {
  A: ["", 30],
  B: ["A", 7],
  C: ["B", 7],
  D: ["C", 15],
  E: ["C", 17],
  F: ["C", 12],
  G: ["D", 4],
  H: ["E,G", 40],
  I: ["F,H", 17],
  J: ["F,H", 16],
  K: ["F,H", 17],
  L: ["I,J,K", 15],
  M: ["H", 7],
  N: ["L,M", 10],
  O: ["N", 3],
};
for (var i in e) {
  var k = document.createElement("div");

  var $k = $(k);
  var z = document.createElement("input");
  var $z = $(z);
  var y = document.createElement("input");
  var $y = $(y);
  
  $y.addClass("ust").val(0);
  $z.addClass("alt").val(0);
  
  $k.text(i).attr("time", e[i][1]).attr("id", "nd"+i).addClass("nd");
  $k.append($y).append($z);
  $("#container").append($k);

}
for (var i in e) {
  e[i][0].split(",").forEach(function(a,b){
    
    var t = document.createElement("div");
    var $t = $(t);
    var $o = $(document.createElement("div"));
    if(a !== "")
    $o.addClass("okseyi").text(e[a][1]);
    
    $t.addClass("ar").attr("id", "ar"+i+a).data("from",i).data("to",a).append($o);
    $("#container").append($t);
  });
  if (i === "A") {
     $("#nd"+i)
       .css("top", "200px")
     	 .css("left", "300px");
  } else if (i === "O") {
     $("#nd"+i)
       .css("top", "200px")
     	 .css("left", "800px");
  } else {
     $("#nd"+i).css("top", Math.random()*500+"px").css("left", Math.random()*0+(i.charCodeAt(0)-60)*40+ 0+"px");

  }
}
$(".nd").on("mousedown",function(event){
  $(event.currentTarget).addClass("startdrag");
});
$("body").on("mousemove",function(event){
  if(true){
    $(".startdrag").css("top",event.clientY-25).css("left",event.clientX-25);
  };
});
$("body").on("mouseup",function(event){
  $(".nd").removeClass("startdrag");
});
setInterval(function(){
  $(".ar").each(function(k,v){
   var from = $("#nd"+$(v).data("from"));
   var to = $("#nd"+$(v).data("to"))
   var x = parseFloat(to.css("left"));
   var y = parseFloat(to.css("top"));
   var ox = parseFloat(from.css("left"));
   var oy = parseFloat(from.css("top"));
	     
    $(v).css("top",y+25)
    		.css("left",x+25)
      	.css("height", ds(ox,oy,x,y)-30)
    		.css("transform", "rotate("+((Math.atan2(y-oy,x-ox)+Math.PI/2)*180/Math.PI)+"deg)");
    $(v).find(".okseyi").css("transform","rotate("+(-(Math.atan2(y-oy,x-ox)+Math.PI/2)*180/Math.PI)+"deg)")
  })
    	
  ;
},200);
function ds (x,y,x2,y2) {
  x -= x2;
  y -= y2;
  if(x === 0 && y === 0) {
    return 0.000001;
  }
  return Math.sqrt(x*x + y*y);
}