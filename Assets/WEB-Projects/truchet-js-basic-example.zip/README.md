# Truchet.js Basic Example

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/KJewZq](https://codepen.io/ykadosh/pen/KJewZq).

