# An Animated Blobby Gooey Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/aXMXvz](https://codepen.io/leenalavanya/pen/aXMXvz).

it's just a button though.<br/>
disclaimer: works in chrome. not sure about other browsers