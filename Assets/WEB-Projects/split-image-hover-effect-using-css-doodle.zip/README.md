# Split Image | Hover Effect  Using <css-doodle />

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/zdBJXd](https://codepen.io/yuanchuan/pen/zdBJXd).

Original pen by Dimitra Vasilopoulou: 
https://codepen.io/mimikos/pen/rzNzVP