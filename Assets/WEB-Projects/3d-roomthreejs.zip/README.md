# 3D Room - ThreeJS

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/KKbWGNZ](https://codepen.io/ricardoolivaalonso/pen/KKbWGNZ).

