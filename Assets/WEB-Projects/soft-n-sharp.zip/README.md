# Soft'n'sharp!

A Pen created on CodePen.io. Original URL: [https://codepen.io/j4rl/pen/gOqJRWJ](https://codepen.io/j4rl/pen/gOqJRWJ).

This pen is a very simple example of a transition from ultra soft to soft-ish to sharp.
User hover and active states. (hover with mouse and press'n'hold left mouse)