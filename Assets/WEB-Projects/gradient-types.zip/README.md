# gradient types

A Pen created on CodePen.io. Original URL: [https://codepen.io/meodai/pen/PooZWvG](https://codepen.io/meodai/pen/PooZWvG).

