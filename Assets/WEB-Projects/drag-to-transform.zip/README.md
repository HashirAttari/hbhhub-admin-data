# Drag to transform

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/ONzqbp](https://codepen.io/mselmany/pen/ONzqbp).

Allows you to figure out the CSS matrix3d transform for an element in a WYSIWYG fashion.

Blog post: http://franklinta.com/2014/09/08/computing-css-matrix3d-transforms/

Alternative usage: http://codepen.io/fta/pen/LHonf

Forked from [Franklin Ta](http://codepen.io/fta/)'s Pen [Drag to transform](http://codepen.io/fta/pen/ifnqH/).