# SVG Cronometer stroke-dasharray 

A Pen created on CodePen.io. Original URL: [https://codepen.io/enxaneta/pen/LeYbgg](https://codepen.io/enxaneta/pen/LeYbgg).

