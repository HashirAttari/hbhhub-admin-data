/*

Special thanks to 'Rachel Nabors'
for the inspiration and technique 

*/