# Interactive Particle Typography for my Daughter

A Pen created on CodePen.

Original URL: [https://codepen.io/micjamking/pen/bqNQGZ](https://codepen.io/micjamking/pen/bqNQGZ).

Interactive particle mesh from typographic image reference, with springing back to original position (mouse over). Particle gradient color based on Y coordinate of the particle.

Mahalo to Rachel Smith ([@rachsmith](http://codepen.io/rachsmith/)) for the pixel coordinate technique using `context.getImageData`:
http://codepen.io/rachsmith/post/getting-getimagedata