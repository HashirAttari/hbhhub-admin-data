# Bézier

A Pen created on CodePen.io. Original URL: [https://codepen.io/PicturElements/pen/mPNYyV](https://codepen.io/PicturElements/pen/mPNYyV).

I learned how Bézier curves work last week, and I frickin' love them! They're so cool! 