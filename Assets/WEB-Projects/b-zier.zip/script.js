/*Lots and lots of global variables*/
var nos="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
var ptsX=[],ptsY=[];
var defaultNo=10,hoverId=-1;  //-1=no hover
var pressed=0,step=0;
var diff=0.002,perc=0,points=1/diff;
var resultX,resultY,prevX=0,prevY=0;
var alreadyLoaded=0;
var thread;
var ctx;

//Button-related variables
var paused=0;
var speed=1;
var lines=0;
var collapsed=0,collapsed2=1;

function init(){
  ctx=document.getElementById("canvas").getContext("2d")
  basicSetup();
  var offset=0.1,tot=1-offset*2;
  var top=(1/3*tot/(defaultNo-1))*window.innerWidth;
  if (top>window.innerHeight/3){top=window.innerHeight/3;}
  if (!window.location.href.startsWith("https://codepen.io/PicturElements/pen/mPNYyV")||window.location.href.endsWith("mPNYyV")||alreadyLoaded==1){
    for (i=0;i<defaultNo;i++){
      ptsX.push((offset+(tot/(defaultNo-1))*i)*window.innerWidth);
      ptsY.push(window.innerHeight/2-top+i%2*top*2);
    }
  }else{
    defaultNo=0;
    var inUrl=window.location.href;
    var foundEqual=0,at=0;
    for (a=0;a<inUrl.length;a++){
      if (inUrl.charAt(a)=='='){
        foundEqual=1;
      }else if(foundEqual==1){
        ptsX.push(toInt(inUrl.charAt(a))*62+toInt(inUrl.charAt(a+1)));
        ptsY.push(toInt(inUrl.charAt(a+2))*62+toInt(inUrl.charAt(a+3)));
        a+=3;
        defaultNo++;
      }
    }
  }
  paint();
  thread=setInterval(setStep,25);
  document.getElementById("pointsin").value=defaultNo;
  alreadyLoaded=1;
}

function toInt(inChar){
  var converted=inChar.charCodeAt(0);
  if (converted>=97){
    return converted-87;
  }else if (converted>=65){
    return converted-29;
  }else{
    return converted-48;
  }
}

function stepper(inId){
  perc+=inId*diff;
  step=1;
  paint();
}

function basicSetup(){
  var canvas=document.getElementById("canvas");
  canvas.width=window.innerWidth;
  canvas.height=window.innerHeight;
  canvas.style.width=window.innerWidth;
  canvas.style.height=window.innerHeight;
  paint();
}

window.onresize = function(event) {
  basicSetup();
};

function press(inId){
  pressed=inId;
  if (inId==1){
    var tmX=event.clientX,tmY=event.clientY;
    if (prevX==tmX&&prevY==tmY){
      var onpoint=-1;
      for (a=0;a<ptsX.length;a++){
        if (Math.hypot(tmX-ptsX[a],tmY-ptsY[a])<8){
          onpoint=a;
          break;
        }
      }
      if (onpoint==-1&&defaultNo<100){
        var minLength=0,midLength=0,maxLength=0,offset=10;
        var placeAt=-1;
        for (a=0;a<ptsX.length-1;a++){
          minLength=Math.hypot(ptsY[a+1]-ptsY[a],ptsX[a+1]-ptsX[a]);
          maxLength=Math.sqrt(offset*offset+minLength*minLength)+offset;
          midLength=Math.hypot(tmY-ptsY[a],tmX-ptsX[a])+Math.hypot(ptsY[a+1]-tmY,ptsX[a+1]-tmX);
          if (midLength>=minLength&&midLength<=maxLength){
            placeAt=a+1;
            break;
          }
        }
        if (placeAt==-1){
          if (Math.hypot(ptsY[0]-tmY,ptsX[0]-tmX)<Math.hypot(ptsY[ptsX.length-1]-tmY,ptsX[ptsX.length-1]-tmX)){
            ptsX.splice(0,0,prevX);
            ptsY.splice(0,0,prevY);
          }else{
            ptsX.push(tmX);
            ptsY.push(tmY);
          }
        }else{
          ptsX.splice(placeAt,0,prevX);
          ptsY.splice(placeAt,0,prevY);
        }
        defaultNo++;
        tmX=-100;
      }else if(defaultNo>2){
        ptsX.splice(onpoint,1);
        ptsY.splice(onpoint,1);
        defaultNo--;
        tmX=-100;
      }
      document.getElementById("pointsin").value=defaultNo;
    }
    prevX=tmX;
    prevY=tmY;
    paint();
  }
}

function setHover(e){
  if (pressed==0){
    hoverId=-1;
    for (i=0;i<ptsX.length;i++){
      if (Math.hypot(e.clientX-ptsX[i],e.clientY-ptsY[i])<8){
        hoverId=i;
        break;
      }
    }
    if (hoverId>-1){
      document.getElementById("canvas").style.cursor="pointer";
    }else{
      document.getElementById("canvas").style.cursor="default";
    }
  }else if(hoverId>-1){
    ptsX[hoverId]=e.clientX;
    ptsY[hoverId]=e.clientY;
    paint();
  }
}

function setStep(){
  step=1;
  if (paused==0){paint();}
}

function paint(){
  var w=window.width,h=window.height;
  ctx.clearRect(0,0,10000,10000);
  if (lines<2||lines==3){
    ctx.beginPath();
    ctx.lineWidth=2;
    ctx.strokeStyle="#777";
    if (lines==3){
      ctx.strokeStyle="#bbb";
      ctx.lineWidth=1;
    }
    ctx.moveTo(ptsX[0],ptsY[0]);
    for (i=1;i<ptsX.length;i++){
      ctx.lineTo(ptsX[i],ptsY[i]);
    }
    ctx.stroke();
  }
  calcBezier();
  step=0;

  ctx.lineWidth=3;
  ctx.strokeStyle="red";
  ctx.beginPath();
  ctx.moveTo(ptsX[0],ptsY[0]);
  for (a=0;a<points;a++){
    if (a==Math.floor(perc*points)){
      ctx.lineTo(resultX,resultY);
      ctx.stroke();
      ctx.strokeStyle="rgba(255,0,0,0.25)";
      ctx.beginPath();
    }
    var tmpX=[],tmpY=[];
    for (b=0;b<ptsX.length;b++){
      tmpX.push(ptsX[b]);
      tmpY.push(ptsY[b]);
    }
    for (m=tmpX.length-1;m>1;m--){
      for (o=0;o<m;o++){
        var tX=tmpX[o]+(tmpX[o+1]-tmpX[o])*(a/points);
        var tY=tmpY[o]+(tmpY[o+1]-tmpY[o])*(a/points);
        tmpX[o]=tX;
        tmpY[o]=tY;
      }
    }
    ctx.lineTo(tmpX[0]+(tmpX[1]-tmpX[0])*(a/points),tmpY[0]+(tmpY[1]-tmpY[0])*(a/points));
  }
  ctx.lineTo(ptsX[ptsX.length-1],ptsY[ptsX.length-1]);
  ctx.stroke();
  if (lines<3){
    for (i=0;i<ptsX.length;i++){
      ctx.fillStyle="#606";
      ctx.beginPath();
      ctx.arc(ptsX[i],ptsY[i],5,0,2*Math.PI);
      ctx.fill();
    }
  }
  ctx.fillStyle="red";
  ctx.beginPath();
  ctx.arc(resultX,resultY,5,0,2*Math.PI);
  ctx.fill();
}

function calcBezier(){
  var tmpX=[],tmpY=[];
  for (m=0;m<ptsX.length;m++){
    tmpX.push(ptsX[m]);
    tmpY.push(ptsY[m]);
  }
  if (step==1&&paused==0){perc+=diff;}
  ctx.fillStyle="#222";
  ctx.strokeStyle="#bbb";
  ctx.lineWidth=1;
  for (m=tmpX.length-1;m>1;m--){
    for (o=0;o<m;o++){
      var tX=tmpX[o]+(tmpX[o+1]-tmpX[o])*perc;
      var tY=tmpY[o]+(tmpY[o+1]-tmpY[o])*perc;
      //ctx.beginPath();
      //ctx.arc(tX,tY,3,0,2*Math.PI);
      //ctx.fill();
      tmpX[o]=tX;
      tmpY[o]=tY;
      if (lines<1||lines==3){
        if (o==0){
          ctx.beginPath();
          ctx.moveTo(tX,tY);
        }else{
          ctx.lineTo(tX,tY);
        }
      }
    }
    if (lines<1||lines==3){ctx.stroke();}
  }
  resultX=tmpX[0]+(tmpX[1]-tmpX[0])*perc;
  resultY=tmpY[0]+(tmpY[1]-tmpY[0])*perc;
  /*for (n=0;n<ptsX.length-1;n++){
          ctx.beginPath();
          ctx.fillStyle="#222";
          //ctx.arc(ptsX[n]+(ptsX[n+1]-ptsX[n])*perc,ptsY[n]+(ptsY[n+1]-ptsY[n])*perc,3,0,2*Math.PI);
          ctx.fill();
        }*/
  if (perc>1||perc<0){
    diff*=-1;
    if (perc>1){perc=1;}
    else{perc=0;}
  }
}

function pause(){
  paused=Math.abs(paused-1);
  var btns=document.getElementsByClassName("btn");
  btns[0].style.backgroundPositionX=""+(-50*paused)+"px";
  if (paused==1){
    btns[1].style.height="50px";
    btns[2].style.height="50px";
    btns[1].style.marginTop="10px";
    btns[2].style.marginTop="10px";
  }else{
    btns[1].style.height="0";
    btns[2].style.height="0";
    btns[1].style.marginTop="0";
    btns[2].style.marginTop="0";
  }
}

function toggleLines(){
  lines++;
  if (lines==5){lines=0;}
  paint();
}

function setSpeed(){
  speed++;
  var rev=0;
  if (diff<0){rev=1;}
  if (speed%3==0){
    diff=0.0005;
  }else if (speed%3==1){
    diff=0.002;
  }else{
    diff=0.01;
  }
  if (rev==1){diff*=-1;}
  document.getElementsByClassName("btn")[5].style.backgroundPositionX=""+(-50*(speed%3))+"px";
}

function slide(){
  collapsed=Math.abs(collapsed-1);
  if (paused==1){
    document.getElementById("menubar").style.marginTop=""+(-430*collapsed)+"px";
  }else{
    document.getElementById("menubar").style.marginTop=""+(-310*collapsed)+"px";
  }
}

function setPoints(x){
  if (collapsed2==1){
    x.style.width="154px";
    var inp=document.getElementById("pointsin");
    inp.style.pointerEvents="auto";
    inp.style.backgroundColor="white";
    inp.focus();
  }else{
    x.style.width="50px";
    collapsed2=1;
  }
}

function confirm(){
  collapsed2=0;
  ptsX=[];
  ptsY=[];
  val=document.getElementById("pointsin").value;
  if (val<2){
    defaultNo=2;
    val=2;
  }else if (val>100){
    defaultNo=100;
    val=100;
  }else{
    defaultNo=val; 
  }
  clearInterval(thread);
  var inp=document.getElementById("pointsin");
  inp.style.pointerEvents="none";
  inp.style.backgroundColor="transparent";
  init();
}

function dostuff(e){
  var key=e.keyCode;
  if (key==13){
    confirm();
    setPoints(document.getElementsByClassName("btn")[6]);
  }else if(key==27){
    collapse();
    setPoints(document.getElementsByClassName("btn")[6]);
  }
}

function collapse(){
  document.getElementsByClassName("btn")[6].style.width="50px";
  var inp=document.getElementById("pointsin");
  inp.value=defaultNo;
  inp.style.pointerEvents="none";
  inp.style.backgroundColor="transparent";
  collapsed2=0;
}

function createUrl(){
  var encoded="";
  for (a=0;a<ptsX.length;a++){
    encoded+=""+intToChar(ptsX[a]/62)+""+intToChar(ptsX[a]%62)+""+intToChar(ptsY[a]/62)+""+intToChar(ptsY[a]%62)+"";
  }
  document.getElementById("urlout").value="https://codepen.io/PicturElements/full/mPNYyV?constellation="+encoded;
  document.getElementById("overlay").style.display="block";
  document.getElementById("urlout").select();
}

function closeShare(){
  document.getElementById("overlay").style.display="none";
}

function intToChar(no){
  return nos.charAt(no);
}