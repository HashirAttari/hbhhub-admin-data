# Toggle Spin (I)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/vYMBMNY](https://codepen.io/alvaromontoro/pen/vYMBMNY).

