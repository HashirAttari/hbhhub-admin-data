# Piggy Bank - pure css - #01

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/xmdwGe](https://codepen.io/ig_design/pen/xmdwGe).

