# Liquid Constellations Mouse Trail (vanilla JS)

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/zYvGWMY](https://codepen.io/franksLaboratory/pen/zYvGWMY).

