# JavaScript Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/jethrohazelhurst/pen/NvVJMq](https://codepen.io/jethrohazelhurst/pen/NvVJMq).

This project was created as my entry for the FreeCodeCamp "Build a JavaScript Calculator" challenge.