# CSS Typing animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/raubaca/pen/rxLwPq](https://codepen.io/raubaca/pen/rxLwPq).

Typing animation with CSS