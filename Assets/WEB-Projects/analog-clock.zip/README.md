# Analog Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/YOqbrZ](https://codepen.io/ykadosh/pen/YOqbrZ).

A pure CSS analog clock (JS is only used to rotate the hands based on the current time). Hand crafted. Fully responsive. Enjoy!

Colors used from the flat UI palette: https://flatuicolors.com/palette/defo
