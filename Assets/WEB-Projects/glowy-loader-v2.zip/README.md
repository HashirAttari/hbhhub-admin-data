# Glowy loader v2

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/NGJNev](https://codepen.io/giana/pen/NGJNev).

Forked from <a href="http://codepen.io/giana/pen/meoeqM">Glowy loader</a>.