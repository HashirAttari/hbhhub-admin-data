# Pure CSS Halloween zipper 🎃🦇🕸️🕷️🧙‍♀️🧹

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/abZmLWN](https://codepen.io/thebabydino/pen/abZmLWN).

[See me code this](https://youtu.be/R6lbhfvMNGk) in 10 minutes.

---

If the work I've been putting out since the spring of 2012 has helped you in any way or you just like it and you wish me to be able to continue making stuff, please consider one of the following:

* being a cool cat 😼🎩 and becoming a patron on Patreon

[![become a patron button](https://assets.codepen.io/2017/btn_patreon.png)](https://www.patreon.com/anatudor)

* making a one time donation via Ko-fi

[![ko-fi](https://assets.codepen.io/2017/btn_kofi.svg)](https://ko-fi.com/anatudor)

* getting me something off my Amazon WishList 

[🎁 🇺🇸](https://www.amazon.com/gp/registry/wishlist/2Y3C4722GXH0I/) / [🎁 🇬🇧](https://www.amazon.co.uk/gp/registry/wishlist/2I25W7U0KADSR/)

* or at least sharing this to show the rest of the world what can be done with CSS these days

Thank you!

---

[Radius computation explainer demo](https://codepen.io/thebabydino/pen/rVgeva).

[Original .gif](https://borrachas.tumblr.com/post/129909963734/27).

![the gif itself](https://64.media.tumblr.com/f4feb0adfce805ddb9473f31b1db4cbe/tumblr_nvab8cEah61rlkdy0o1_r1_640.gifv)

Palette: [Trick or Treat](https://www.colourlovers.com/palette/54697/Trick_or_Treat).

---

Dedicated to the memory of someone dear who passed away in 2019. Missing you every day.