# Splashed Toast Notifications - CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/OJGXdzY](https://codepen.io/josetxu/pen/OJGXdzY).

Inspired by <strong>Anastasia Dolenko's</strong> <a href="https://dribbble.com/shots/15509869-Free-pack-of-Flash-Messages">"Free pack of Flash Messages"</a> Dribbble Shot.