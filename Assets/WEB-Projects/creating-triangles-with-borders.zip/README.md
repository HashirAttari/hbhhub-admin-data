# Creating Triangles with borders !

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/NWqMxbz](https://codepen.io/MananTank/pen/NWqMxbz).

Css Draws border weirdly, this hack(s) exploit that fact