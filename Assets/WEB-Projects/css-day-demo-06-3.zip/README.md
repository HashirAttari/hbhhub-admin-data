# CSS DAY demo 06.3

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/jOZegJj](https://codepen.io/amit_sheen/pen/jOZegJj).

