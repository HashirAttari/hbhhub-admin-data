# 📊 Budging Bars | CSS-only Line Bar Navigation Tutorial | @keyframers 2.15.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/team/keyframers/pen/aboBjar](https://codepen.io/team/keyframers/pen/aboBjar).

David Khourshid and Stephen Shaw build a colorful line bar navigation animation with CSS.

* ⏰ Streamed live on August 21, 2019 at https://twitch.tv/keyframers
* 💡 Inspiration: https://dribbble.com/shots/7019024-A-WQ-Young-Lab-Stories-Slider-Animation
* 📺 Video: https://youtu.be/WuE_w_sLTSY
* 💻 Code: https://cdpn.io/pen/aboBjar


Like what we're doing? There are many ways you can support @keyframers so we can keep live coding awesome animations!

* Support us on Patreon at https://patreon.com/keyframers 
* Like & subscribe on YouTube at https://youtube.com/keyframers
* Follow & tweet us at https://twitter.com/keyframers.
* Join the live streams & subscribe on Twitch http://twitch.tv/keyframers