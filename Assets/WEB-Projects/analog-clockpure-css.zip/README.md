# Analog Clock - Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/JavaScriptJunkie/pen/gOYvPMv](https://codepen.io/JavaScriptJunkie/pen/gOYvPMv).

A simple analog clock made with pure CSS. No scripts. No images. No SVG.

Design => https://dribbble.com/shots/6118476-Did-You/