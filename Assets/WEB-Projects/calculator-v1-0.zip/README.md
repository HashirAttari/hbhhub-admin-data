# Calculator V1.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/AhmedEmadAtia/pen/XaqRmb](https://codepen.io/AhmedEmadAtia/pen/XaqRmb).

Simple Calculator depend on typing the number 