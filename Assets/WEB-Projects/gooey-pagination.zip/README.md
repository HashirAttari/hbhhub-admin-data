# Gooey Pagination

A Pen created on CodePen.io. Original URL: [https://codepen.io/sparanoid/pen/GJJLVj](https://codepen.io/sparanoid/pen/GJJLVj).

Gooey pagination effect based on a dribbble by Kreativa Studio: https://dribbble.com/shots/1676635-Page-scroll-concept

Forked from [Lucas Bebber](http://codepen.io/lbebber/)'s Pen [Gooey Pagination](http://codepen.io/lbebber/pen/lFdHu/).