# Text On Fire

A Pen created on CodePen.

Original URL: [https://codepen.io/sakri/pen/eYgNBR](https://codepen.io/sakri/pen/eYgNBR).

Creates a particle for every pixel in given text and attempts to animate them like fire.  Too grainy for my likings but ok for now.   "SAKRI" uses 150K particles, runs at 60FPS on my PC, 13fps on my iPad2.