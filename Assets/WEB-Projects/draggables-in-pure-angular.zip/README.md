# Draggables in pure angular

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/EPLeEL](https://codepen.io/mselmany/pen/EPLeEL).

Bounded click and drag solution implemented using angularjs.

Forked from [rlo206](http://codepen.io/rlo206/)'s Pen [Draggables in pure angular](http://codepen.io/rlo206/pen/adEXJZ/).