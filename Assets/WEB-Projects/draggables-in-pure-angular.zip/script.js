var DragModule = angular.module('dragModule', ['ngSanitize']);

DragModule.factory('dragService', function() {
    var s = {};
    
    /*********************** Setup and Render ***********************/
    
    s.setup = function($scope, element, attrs) {
        $scope.element = element[0];
        $scope.elementParent = angular.element($scope.element).parent()[0];
        
        s.setupPosition($scope, attrs);
        s.setupSize($scope);
        s.setupColor($scope, attrs);
        
        $scope.$on('global-mouse-up', function(eventName, $event) { 
            s.onMouseUp($scope, $event); 
        });
        
        $scope.$on('global-mouse-move', function(eventName, $event) { 
            if (!$scope.state.selected) return;
            s.updatePosition($scope, $event); 
        });
    };
    
    s.setupPosition = function($scope, attrs) {
        angular.extend($scope.position, $scope.defaults.position);
        if (attrs.startx) $scope.position.startx = parseFloat(attrs.startx);
        if (attrs.starty) $scope.position.starty = parseFloat(attrs.starty);
        $scope.position.x = $scope.position.startx;
        $scope.position.y = $scope.position.starty;
    };
    
    s.setupSize = function($scope) {
        $scope.size.width = $scope.element.offsetWidth;
        $scope.size.height = $scope.element.offsetHeight;
        
        $scope.size.containerWidth = $scope.elementParent.offsetWidth;
        $scope.size.containerHeight = $scope.elementParent.offsetHeight;
        
        s.setupMarginOffsets($scope, $scope.elementParent);
    };
    
    s.setupMarginOffsets = function($scope, $parent) {
        var style = $parent.currentStyle || window.getComputedStyle($parent);
        $scope.offsets.top = Math.ceil(parseFloat(style.marginTop));
        $scope.offsets.left = Math.ceil(parseFloat(style.marginLeft));
        $scope.offsets.bottom = Math.ceil(parseFloat(style.marginBottom));
        $scope.offsets.right = Math.ceil(parseFloat(style.marginRight));
    };
    
    s.setupColor = function($scope, attrs) {
        if (attrs.color) $scope.color.box = attrs.color;
    };
    
    /*********************** Event Handling ***********************/
    
    s.onMouseDown = function($scope, $event) {
        $scope.state.mousedown = true;
        $scope.state.selected = true;
        $scope.$emit('draggable-box-selected', $scope.state);
        s.updatePosition($scope, $event);
    };
    
    s.onMouseUp = function($scope, $event) {
        $scope.state.mousedown = false;
        $scope.state.selected = false;
        $scope.$emit('draggable-box-selected', null);
    };
    
    s.onMouseLeave = function($scope, $event) {
        if (!$scope.state.selected) {
            $scope.state.hover = false;
        }
    };
    
    /*********************** Position Updating ***********************/
    
    s.updatePosition = function($scope, $event) {
        s.updateTopPosition($scope, $event);
        s.updateLeftPosition($scope, $event);
    };
    
    s.updateTopPosition = function($scope, $event) {
        var newY = $event.pageY - ($scope.size.height / 2) - $scope.offsets.top;
        newY = s.getBoundedY($scope, $event, newY);
        angular.element($scope.element).css('top', [newY, 'px'].join(''));
    };
    
    s.updateLeftPosition = function($scope, $event) {
        var newX = $event.pageX - ($scope.size.width / 2) - $scope.offsets.left;
        newX = s.getBoundedX($scope, $event, newX);
        angular.element($scope.element).css('left', [newX, 'px'].join(''));
    };
    
    s.getBoundedX = function($scope, $event, newX) {
        if (newX < 0) return 0;
        var newXRight = $event.pageX + ($scope.size.width / 2) - $scope.offsets.left + 6;
        if (newXRight > $scope.elementParent.offsetWidth) return ($scope.elementParent.offsetWidth - $scope.size.width) - 4;
        return newX;
    };
    
    s.getBoundedY = function($scope, $event, newY) {
        if (newY < 0) return 0;
        var newYBottom = $event.pageY + ($scope.size.height / 2) - $scope.offsets.top + 6;
        if (newYBottom > $scope.elementParent.offsetHeight) return ($scope.elementParent.offsetHeight - $scope.size.height) - 4;
        return newY;
    };
    
    return s;
});

DragModule.directive('draggableBox', function($timeout) {
    return {
        restrict: 'E',
        replace: true,
        scope: { startx: '@', starty: '@', classname: '@' },
        controller: function($scope, dragService) {
            $scope.service = dragService;
            
            $scope.defaults = {
                position: {
                    startx: 10,
                    starty: 10,
                    x: 10,
                    y: 10
                }
            };
            
            $scope.offsets = {
                top: 0, left: 0, bottom: 0, right: 0
            };
            
            $scope.state = {
                hover: false,
                mousedown: false,
                selected: false
            };
            
            $scope.size = {};
            $scope.position = {};
            $scope.color = { box: '#fff' };
        },
        template: [
            '<div class="draggable-box {{classname}}" style="top: {{position.y}}em; left: {{position.x}}em; background-color: {{color.box}}"',
                'ng-class="{ hover: state.hover, mousedown: state.mousedown }"',
                'ng-mouseover="state.hover = true" ',
                'ng-mouseleave="service.onMouseLeave(this, $event)" ',
                'ng-mousedown="service.onMouseDown(this, $event)" ',
                '>',
            '</div>'
        ].join(''),
        link: function(scope, element, attrs) {
            $timeout(function() { scope.service.setup(scope, element, attrs); });
        }
    };
});

var PageApp = angular.module('draggableContainer', ['ngSanitize', 'dragModule']);

PageApp.controller('draggableContainerCtrl', function($scope) {
    $scope.state = {
        selectedBox: null
    };
    
    $scope.$on('draggable-box-selected', function(eventName, box) {
        $scope.state.selectedBox = box;
    });
    
    $scope.onGlobalMouseUp = function($event) {
        $scope.$broadcast('global-mouse-up', $event);
        $scope.state.selectedBox = null;
    };
    
    $scope.onGlobalMouseMove = function($event) {
        if ($scope.state.selectedBox === null) return;
        $scope.$broadcast('global-mouse-move', $event);
    };
});