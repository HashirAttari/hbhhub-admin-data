# Eletric Wave (SVG)

A Pen created on CodePen.io. Original URL: [https://codepen.io/konstantindenerz/pen/eYLyqNe](https://codepen.io/konstantindenerz/pen/eYLyqNe).

A demonstration of animated wave with SVG.