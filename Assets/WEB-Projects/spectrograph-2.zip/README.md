# Spectrograph #2

A Pen created on CodePen.io. Original URL: [https://codepen.io/munkholm/pen/jOORwNZ](https://codepen.io/munkholm/pen/jOORwNZ).

