# Hulk - Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/GRNGxKg](https://codepen.io/josetxu/pen/GRNGxKg).

Hulk animated with CSS only.