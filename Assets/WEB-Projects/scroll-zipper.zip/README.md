# Scroll Zipper

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/OJWoRvG](https://codepen.io/josetxu/pen/OJWoRvG).

