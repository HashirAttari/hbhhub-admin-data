# Floating social icon buttons | CSS Only

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/zNPjeg](https://codepen.io/havardob/pen/zNPjeg).

