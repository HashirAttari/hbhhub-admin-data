const leaf_box = document.querySelector('#leaf_container')
var blower = document.querySelector('#leaf_blower')
var blower_box = document.querySelector('#blower_box')
const html = document.querySelector('html')
const on_off = document.querySelector('#on_off')
var leafs = 40
var power = 0

var cln = blower_box.cloneNode(true)
blower_box.remove()
leaf_box.appendChild(cln)
var blower = document.querySelector('#leaf_blower')
var blower_box = document.querySelector('#blower_box')
var bb_loc = blower_box.getBoundingClientRect()
var bb_top = bb_loc.top
var bb_left = bb_loc.left
// console.log(bb_top + ' / ' + bb_left)

for(var i=0;i<leafs;i++){
  var l = document.createElement('div')
  l.className = 'leaf fall_on'
  l.style.left = Math.random()*100 + '%'
  l.style.top = Math.random()*100 + '%'
  var bg_x = Math.floor(Math.random()*3)*50
  var bg_y = Math.floor(Math.random()*3)*50
  l.style.backgroundPosition = (-1)*bg_x+'px '+(-1)*bg_y+'px'
  l.style.animationDelay = Math.random()*3 + 's'
  l.onmouseenter = function(e){
    if(!document.querySelector('.blower_off')){
      var lx = parseInt(this.style.left)
      var ly = parseInt(this.style.top)
      // console.log(lx+' / '+ ly)
      this.classList.add('caught')
    }
  }
  leaf_box.appendChild(l)   
}

function moveBlowerMobile(e){
  if(!document.querySelector('.blower_off')){
    var touch = e.touches[0];
    // get the DOM element
    var leaf = document.elementFromPoint(touch.clientX, touch.clientY);
    if(leaf.classList.contains('leaf')) {
      var lx = parseInt(leaf.style.left)
      var ly = parseInt(leaf.style.top)
      // console.log(lx+' / '+ ly)
      // var x = Math.random() < .5 ? lx + 10 : lx - 10
      // var y = ly - 10
      // leaf.style.left = x + '%'
      // leaf.style.top = y + '%'
      leaf.style.transform = 'rotate('+Math.random()*720+'deg)' 
      leaf.classList.add('caught')
    } 

    var bx = touch.clientX - bb_left + 30
    var by = touch.clientY - bb_top + 125

    blower.style.left = bx + 'px'
    blower.style.top = by + 'px'  

    if(document.querySelector('.caught')) {
      var c = document.querySelectorAll('.caught')
      c.forEach(function(elm) {
        elm.style.left = bx + 10 + 'px'
        elm.style.top = by + 'px' 
      })
    }
  }
}

function moveBlower(e){
  if(!document.querySelector('.blower_off')) {
    var bx = e.clientX - bb_left - 25
    var by = e.clientY - bb_top

    blower.style.left = bx + 'px'
    blower.style.top = by + 'px'  
  }

  if(document.querySelector('.caught')) {
    var c = document.querySelectorAll('.caught')
    c.forEach(function(elm) {
      elm.style.left = bx + 10 + 'px'
      elm.style.top = by + 'px' 
    })
  }
}

function resetLeafs() {
  var fs = document.querySelectorAll('.leaf')
  fs.forEach(function(elm){
    elm.style.left = Math.random()*100 + '%'
    elm.style.top = Math.random()*100 + '%'
    elm.style.transform = 'none'
    if(elm.classList.contains('caught')) {
      elm.classList.remove('caught')
    }
  })
}

blower.addEventListener('click', function() { 
  resetLeafs()
  blower.classList.toggle('blower_off')
  html.style.touchAction = 'none'
  power = 0
  document.documentElement.style.setProperty('--power-perc', power+'%')
  document.documentElement.style.setProperty('--power-color', 'limeGreen')
  on_off.innerText = 'ON'
  window.addEventListener('mousemove', moveBlower)
  window.addEventListener('touchmove', moveBlowerMobile)
  function powerDrain() {
    power = power + 6.6667
    document.documentElement.style.setProperty('--power-perc', power+'%')
    if(power > 79) {
      document.documentElement.style.setProperty('--power-color', 'yellow')      
    }
    if(power > 99) {
      clearInterval(power_track)      
      blower.classList.toggle('blower_off')
      html.style.touchAction = ''
      blower.style.left = ''
      blower.style.top = ''
      on_off.innerText = 'OFF'
      window.removeEventListener('mousemove', moveBlower)
      window.removeEventListener('touchmove', moveBlowerMobile)
      document.documentElement.style.setProperty('--power-color', 'red')   

      if(document.querySelector('.caught')) {
        var c = document.querySelectorAll('.caught')
        c.forEach(function(elm) {
          elm.style.left = '85%'
          elm.style.top = '0%' 
        })
      }
    }
  }
  moveBlower
  var power_track = setInterval(powerDrain, 1000)  
  })

setTimeout(function(){
  var fs = document.querySelectorAll('.leaf')
  fs.forEach(function(elm){
    elm.classList.remove('fall_on')
  })
},4000)