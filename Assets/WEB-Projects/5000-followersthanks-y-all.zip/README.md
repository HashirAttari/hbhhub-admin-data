# 5000 Followers - Thanks Y'all!

A Pen created on CodePen.io. Original URL: [https://codepen.io/cobra_winfrey/pen/QWYGwYe](https://codepen.io/cobra_winfrey/pen/QWYGwYe).

Lil CSS/SVG animation to celebrate crossing the 5000 follower mark @ my fave online community- thanks folks :)