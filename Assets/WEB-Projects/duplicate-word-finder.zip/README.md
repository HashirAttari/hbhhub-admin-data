# Duplicate Word Finder

A Pen created on CodePen.io. Original URL: [https://codepen.io/finnhvman/pen/oPwXRa](https://codepen.io/finnhvman/pen/oPwXRa).

Brand new and updated Duplicate Word Finder: https://duplicateword.com/

A little productivity tool to help avoiding unintentional word repetitions in your writings. Enjoy!