// Find your root SVG element
const svg = document.querySelector("svg");

// Create an SVGPoint for future math
let pt = new DOMPoint();

// Get point in global SVG space
function cursorPoint(evt) {
	pt.x = evt.clientX;
	pt.y = evt.clientY;
	return pt.matrixTransform(svg.getScreenCTM().inverse());
}

svg.addEventListener(
	"mousemove",
	function (evt) {
		let loc = cursorPoint(evt);
		// Use loc.x and loc.y here
		changeCursor(evt.target, loc.x.toFixed(1), loc.y.toFixed(1));
	},
	false
);

let xx = 500;
let yy = 281;
function changeCursor(evt, x, y) {
	xx = x;
	yy = y;
	document
		.querySelector("#p")
		.setAttribute(
			"d",
			`M${x} ${y} m -200 0 a 1 1 0 0 0 200 0 a 1 1 0 0 0 200 0 a 1 1 0 0 0 -200 0 a 1 1 0 0 0 -200 0`
		);
	document
		.querySelector("#g")
		.setAttribute(
			"d",
			`M${x} ${y} m -225 0 c 0 132 133 144 189 96 c 30 -21 41 -21 71 0 c 57 49 190 33 189 -96 c -2 -132 -51 -122 -148 -123 c -57 -35 -95 -35 -150 -2 c -87 0 -150 -10 -151 125`
		);
	document.querySelector("#knob").setAttribute("cx", x);
	document.querySelector("#knob").setAttribute("cy", y - 100);
	document
		.querySelector("#knob")
		.setAttribute("transform", `rotate(${-140 + mult * 10} ${xx} ${yy - 100})`);
	document.querySelector("#knob2").setAttribute("cx", x);
	document.querySelector("#knob2").setAttribute("cy", y - 100);
}

let mult = 2;
// Function to handle zoom
function handleIntensity(event) {
	event.preventDefault();

	// Calculate the zoom factor based on the scroll wheel delta
	const intensityFactor = event.deltaY;
	if (intensityFactor >= 0) {
		mult -= 0.25;
	} else {
		mult += 0.25;
	}

	// Update the slider value
	intensityFactor.value = mult.toFixed(1);

	// Ensure the zoom level stays within the limits
	if (mult < 0.25) {
		mult = 0.25;
	} else if (mult > 10) {
		mult = 10;
	}
	let iElts = document.querySelector(".intensity").children;
	for (let i = 0; i < iElts.length; i++) {
		iElts[i].setAttribute("slope", mult);
	}
	document
		.querySelector("#knob")
		.setAttribute("transform", `rotate(${-140 + mult * 10} ${xx} ${yy - 100})`);
	console.log(mult);
}

// Add wheel event listener to handle zoom
svg.addEventListener("wheel", handleIntensity);