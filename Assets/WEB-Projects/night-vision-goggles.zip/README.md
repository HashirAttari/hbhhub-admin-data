# Night Vision Goggles

A Pen created on CodePen.io. Original URL: [https://codepen.io/leimapapa/pen/vYwgbVP](https://codepen.io/leimapapa/pen/vYwgbVP).

Using an SVG filter to simulate night vision goggles.

(Technically a CSS filter on the original image and an SVG filter on the goggles)