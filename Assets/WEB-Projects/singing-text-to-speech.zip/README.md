# Singing Text To Speech

A Pen created on CodePen.io. Original URL: [https://codepen.io/abergin/pen/xZWada](https://codepen.io/abergin/pen/xZWada).

Still a WIP but it's fun to play with.
Only tested in chrome.