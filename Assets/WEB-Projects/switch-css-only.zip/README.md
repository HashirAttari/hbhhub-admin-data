# Switch | CSS only 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/EKMZbG](https://codepen.io/havardob/pen/EKMZbG).

Stylish switch design. 

Inspired by this Dribbble shot: https://dribbble.com/shots/299416-Simple-Switch

