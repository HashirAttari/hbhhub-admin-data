# Digital Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/zastrow/pen/QNJOYo](https://codepen.io/zastrow/pen/QNJOYo).

