function clock() {
  var h = (moment().format('hh')).split(''),
      m = (moment().format('mm')).split('');

  function addClass(el,n) {
    var newClass = 'time-' + n;
    if (el.classList) {
      el.setAttribute('class', newClass);
    }
  }
  addClass(d1,h[0]);
  addClass(d2,h[1]);
  addClass(d3,m[0]);
  addClass(d4,m[1]);  
}

var timerDisplay = setInterval('clock()', 1000);