# Configurable LED Matrix

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/YzgRBpp](https://codepen.io/jh3y/pen/YzgRBpp).

