# emojifuck

A Pen created on CodePen.io. Original URL: [https://codepen.io/PicturElements/pen/PpaRGy](https://codepen.io/PicturElements/pen/PpaRGy).

