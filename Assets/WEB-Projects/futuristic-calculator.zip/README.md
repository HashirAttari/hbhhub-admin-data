# Futuristic Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/azureowl/pen/BjKQRX](https://codepen.io/azureowl/pen/BjKQRX).

It's futuristic because it's thin and transparent. Ooooo. What does it run on? Batteries? Solar? Nuclear fusion? This is the calculator Commander Shepard would have used if his omni-tool was broken.