# Glitchy CSS background (CPU warning)

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/BvRoWd](https://codepen.io/giana/pen/BvRoWd).

Tip: There are a million cool things you can do when you generate multiple gradient backgrounds and set background-blend-mode: difference. One of them is crashing your browser.