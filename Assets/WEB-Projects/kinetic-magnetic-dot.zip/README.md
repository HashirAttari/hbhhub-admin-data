# Kinetic Magnetic Dot

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/dBajPG](https://codepen.io/ykadosh/pen/dBajPG).

An interactive animation using GSAPTweenMax and some Trigonometry fun. Move your cursor around the screen to manually control the dot!