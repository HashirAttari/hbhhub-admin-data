# Image Hover Effect - pure css - #18

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/WNrWezW](https://codepen.io/ig_design/pen/WNrWezW).

