# Creek

A Pen created on CodePen.io. Original URL: [https://codepen.io/atzedent/pen/yLxRzeL](https://codepen.io/atzedent/pen/yLxRzeL).

Procedural noise this time creates the impression of flowing water of a small creek. Turn on the sound and dive in.