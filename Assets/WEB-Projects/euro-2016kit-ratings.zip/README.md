# Euro 2016 - Kit ratings

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/vKyyXN](https://codepen.io/havardob/pen/vKyyXN).

A friend of mine demanded that I rated all the Euro home kits on a scale from 1 to 6, so I made this just for fun 