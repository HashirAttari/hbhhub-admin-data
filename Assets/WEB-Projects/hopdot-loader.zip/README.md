# Hopdot Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/bGwMGMw](https://codepen.io/chrisgannon/pen/bGwMGMw).

A little loader animation to ease myself back into working. Happy new year 2021!