# Expand Social Links with Toast Machine Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaltatan/pen/dyqgyrP](https://codepen.io/aaltatan/pen/dyqgyrP).

Expand Social Links with Toast Machine Effect , made by CSS (SCSS) and few lines of JavaScript