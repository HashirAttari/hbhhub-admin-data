# Button Ripple Effect - VanillaJS

A Pen created on CodePen.io. Original URL: [https://codepen.io/tomma5o/pen/zwyKya](https://codepen.io/tomma5o/pen/zwyKya).

### Here a simple ripple effect in vanilla js, ready to use for your project !
works in mobile too ;)