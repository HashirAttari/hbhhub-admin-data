# Jelly Effect in Card on hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/zebateira/pen/zrvwGR](https://codepen.io/zebateira/pen/zrvwGR).

Jelly Effect in Card concept: http://www.materialup.com/posts/jelly-effect-in-card 