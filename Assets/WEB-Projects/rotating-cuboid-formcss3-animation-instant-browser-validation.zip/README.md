# Rotating Cuboid Form - CSS3 Animation, Instant Browser Validation 💜

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/rNaYZJN](https://codepen.io/leenalavanya/pen/rNaYZJN).

The horizontally-rotating-cuboid form. It's use case is when you want to include a form with six inputs but you only have the space for one. Doesn't allow for users to edit their previous answers, but does validate each answer onkeyup. Comes with a progress indicator, gradient buttons and error animation.
Disclaimer: It's only been tested on chrome. And it's validation (.validity.valid == true) is only client-side.