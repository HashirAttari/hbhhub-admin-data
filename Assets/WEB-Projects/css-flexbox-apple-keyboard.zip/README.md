# CSS Flexbox Apple Keyboard

A Pen created on CodePen.

Original URL: [https://codepen.io/tholex/pen/LYmEMj](https://codepen.io/tholex/pen/LYmEMj).

If you want the details on what all the properties do, check out http://slides.com/tholex/flexbox

Really wanted to push my flexbox knowledge, and thought this keyboard layout would be a good test-bed. The best part of flexbox *by far* has been the flex-grow stuff, e.g. try changing the spacebar flex value! Everything stays on the same line. It's awesome. Flexbox is the future.

All the top row icons were custom-made for this project.

Really happy that the font they used (VAG rounded) is available for the web! Enjoy!