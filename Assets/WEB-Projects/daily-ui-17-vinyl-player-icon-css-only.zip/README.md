# Daily UI #17 | Vinyl player icon | CSS only

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/XKrWgX](https://codepen.io/havardob/pen/XKrWgX).

Based on this Dribbble-shot: https://dribbble.com/shots/1755436-VinylPlayer-Icon

