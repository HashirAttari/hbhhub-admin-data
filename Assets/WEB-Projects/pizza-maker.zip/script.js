function Onion() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://2.bp.blogspot.com/-49DqQAh1e7w/U5_e6VlodAI/AAAAAAAAAHI/FDQovqdRhqI/s1600/Onion.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
  ctx.drawImage(onion, x, y,70,70);};}
    
function Olive() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://1.bp.blogspot.com/-hYPUL5Tk-Q0/U6An0rIMAPI/AAAAAAAAAIk/C2MT_AToEt0/s1600/Olive.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,40,25);};}
    
function RedChilli() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://1.bp.blogspot.com/-W-jXozLHyG4/U6An1aQDnII/AAAAAAAAAIw/yOuKTNjfP60/s1600/Red+Chilli.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,70,40);};}
    
function GreenChilli() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://3.bp.blogspot.com/-tmbjmlSiqOM/U6An0jFPzDI/AAAAAAAAAIg/9MIQWCsbIVg/s1600/Green+Chilli.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,70,40);};}  
    
function Mushroom() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://2.bp.blogspot.com/-jqxIXlnV1Rk/U6An0vTodVI/AAAAAAAAAIo/y7AzFscBr6k/s1600/Mushroom.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/30,
        y = evt.offsetY - onion.height/30;
    ctx.drawImage(onion, x, y,55,55);};}
    
function Tomato() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://3.bp.blogspot.com/-fVSxDyyKyc8/U6An1vRaQRI/AAAAAAAAAJA/CrANVelB_eg/s1600/Tomato.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/35,
        y = evt.offsetY - onion.height/35;
    ctx.drawImage(onion, x, y,70,70);};}
    
function Salami() {
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://3.bp.blogspot.com/-TJN0wRbXs1E/U6a-cvkFEhI/AAAAAAAAAKk/zbm_SHbL_68/s1600/Salami.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,55,55);};}
    
function Pepperoni() {
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://3.bp.blogspot.com/-KCO0bORA8cM/U6a-cLn-cBI/AAAAAAAAAKY/eY4MU5i0wyY/s1600/Pepperoni.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,55,55);};}
       
function Chicken() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://3.bp.blogspot.com/-V3XsGrifceE/U6qs4BgYuII/AAAAAAAAAL0/nqU6UAH3-Vs/s1600/Chicken.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/35,
        y = evt.offsetY - onion.height/35;
    ctx.drawImage(onion, x, y,65,40);};}
    
function Ham() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://4.bp.blogspot.com/-vK6Xn_88jlk/U6vyr5zEbXI/AAAAAAAAAMM/hrtfCzs2FuY/s1600/Ham.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/31,
        y = evt.offsetY - onion.height/31;
    ctx.drawImage(onion, x, y,80,50);};}

function BlackPepper() {
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://2.bp.blogspot.com/-3w_9h627Reo/U6a-c0L6x8I/AAAAAAAAAKo/DiolUj_W4CY/s1600/black+pepper.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/8,
        y = evt.offsetY - onion.height/8;
    ctx.drawImage(onion, x, y,75,75);};}
    
function CheeseSprinkles() {
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://4.bp.blogspot.com/-p80w_TSr9Do/U6a-cLWYh9I/AAAAAAAAAKc/f7Vz40DjsGw/s1600/Cheese+Slices.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/19,
        y = evt.offsetY - onion.height/19;
    ctx.drawImage(onion, x, y,65,65);};}
    
function Bacon() {
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://2.bp.blogspot.com/-220WftxhT5Q/U6a-cDC-z-I/AAAAAAAAAKg/wu95XlaHvno/s1600/Bacon.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/19,
        y = evt.offsetY - onion.height/19;
    ctx.drawImage(onion, x, y,95,45);};}
       
function RedPepper() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://3.bp.blogspot.com/-KlvYKUjFqQs/U6vywVdqeeI/AAAAAAAAAMo/v53aCk1lZ3k/s1600/RedPepper.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,70,70);};}
	
function YellowPepper() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://3.bp.blogspot.com/-oAFw1HK6udw/U6vyw29zJfI/AAAAAAAAAM0/JzsBZtSklAo/s1600/YellowPepper.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,70,70);};}

function GreenPepper() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://3.bp.blogspot.com/-AYIa_wfvl2w/U6vyvQgnQUI/AAAAAAAAAMc/qUSJYhueuQE/s1600/GreenPepper.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,70,70);};}
	
function Basil() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://1.bp.blogspot.com/-GofsCZ8zW5s/U6vyvEyS2AI/AAAAAAAAAMU/MERdE85nY5Y/s1600/Basil.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,70,70);};}
	
function Sausage() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://4.bp.blogspot.com/-MD72EKSk1p8/U6vywnUKABI/AAAAAAAAAMw/jgWwzYKdYio/s1600/Sausage.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,90,40);};}
	
function Pineapple() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://3.bp.blogspot.com/-chNeBYmt08M/U6vywD07HbI/AAAAAAAAAMk/K0Br4ITOCpQ/s1600/Pineapple.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,70,70);};}
	
function Broccoli() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://2.bp.blogspot.com/-P6wwIhUH_A0/U6vyvfgycFI/AAAAAAAAAMY/jv0Vxg75Dn0/s1600/Broccoli.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,70,70);};}
	
function Jalepeno() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://2.bp.blogspot.com/-945buNWvZYs/U6vyvyghIdI/AAAAAAAAAMg/2-370-KqmGo/s1600/Jalepeno.png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/10,
        y = evt.offsetY - onion.height/10;
    ctx.drawImage(onion, x, y,70,70);};}

function ClearCanvas() {
var plate = new Image();
plate.src = "https://3.bp.blogspot.com/-ptpus-J6iVc/U57NoYQd0eI/AAAAAAAAAGc/9e83ygx66nw/s1600/Pizza.png";
    
var c=document.getElementById("painter");
var context=c.getContext("2d");
context.drawImage(plate, 0, 0, 700, 700);
}

function RedChiliSauce() {
var sauce1 = new Image();
sauce1.src = "https://1.bp.blogspot.com/---M27YA3Jhk/U6E_2SsXahI/AAAAAAAAAJg/95I7R5K_XRQ/s1600/Pizza+Sos+1.png";
    
var c=document.getElementById("painter");
var context=c.getContext("2d");
var width = 700;
var height =700;
context.drawImage(sauce1, 0, 0, width, height);
}

function TomatoSauce() {
var sauce1 = new Image();
sauce1.src = "https://2.bp.blogspot.com/-Ebke1sTgVko/U6FEseMSDcI/AAAAAAAAAJ0/weqtyFmlpHU/s1600/Pizza+Sos+3.png";
    
var c=document.getElementById("painter");
var context=c.getContext("2d");
var width = 700;
var height = 700;
context.drawImage(sauce1, 0, 0, width, height);
}

function Mustard() {
var sauce1 = new Image();
sauce1.src = "https://3.bp.blogspot.com/-jaJ1s3MtGqU/U6FEsenQRsI/AAAAAAAAAJ4/DbkoCldZxl8/s1600/Pizza+Sos+2.png";
    
var c=document.getElementById("painter");
var context=c.getContext("2d");
var width = 700;
var height = 700;
context.drawImage(sauce1, 0, 0, width, height);
}

function Cheese() {
var sauce1 = new Image();
sauce1.src = "https://2.bp.blogspot.com/-jsz1Yv-UkCk/U6FEsbReNfI/AAAAAAAAAJw/rM2k-QkAbfE/s1600/Pizza+Sos+4.png";
    
var c=document.getElementById("painter");
var context=c.getContext("2d");
var width = 700;
var height = 700;
context.drawImage(sauce1, 0, 0, width, height);
}

function Mayonnaise() {
var sauce1 = new Image();
sauce1.src = "https://2.bp.blogspot.com/-kyb63YutMa8/U6FEtB4KEtI/AAAAAAAAAKE/j4mOrlZNiKo/s1600/Pizza+Sos+5.png";
    
var c=document.getElementById("painter");
var context=c.getContext("2d");
var width = 700;
var height = 700;
context.drawImage(sauce1, 0, 0, width, height);
}

function Eat() {    
var can = document.getElementById("painter"),
    ctx = can.getContext('2d'),
    onion = new Image();
onion.src = 'https://2.bp.blogspot.com/-uFI9quPRfYs/U6gB1ylkSVI/AAAAAAAAALQ/x5h0Qgdom1Y/s1600/Eat().png';
can.onclick= function(evt) {
    var x = evt.offsetX - onion.width/5,
        y = evt.offsetY - onion.height/5;
    ctx.drawImage(onion, x, y,115,95);};}