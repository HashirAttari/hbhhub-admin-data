# rounded 3D edge

A Pen created on CodePen.io. Original URL: [https://codepen.io/BarbWire/pen/ZENpKax](https://codepen.io/BarbWire/pen/ZENpKax).

