# Inflatable Bubbles Auto Path

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/MWzyYOG](https://codepen.io/franksLaboratory/pen/MWzyYOG).

