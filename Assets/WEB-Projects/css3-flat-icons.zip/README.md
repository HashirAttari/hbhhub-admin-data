# CSS3 flat icons

A Pen created on CodePen.io. Original URL: [https://codepen.io/elrumordelaluz/pen/AoWYvv](https://codepen.io/elrumordelaluz/pen/AoWYvv).

Fully CSS3 flat icons Google style.