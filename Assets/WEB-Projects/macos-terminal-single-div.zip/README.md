# macOS Terminal (Single Div) 🍏

A Pen created on CodePen.io. Original URL: [https://codepen.io/dark_mefody/pen/KRXbxX](https://codepen.io/dark_mefody/pen/KRXbxX).

