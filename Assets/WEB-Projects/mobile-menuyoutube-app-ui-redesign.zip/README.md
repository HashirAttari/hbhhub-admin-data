# Mobile Menu - Youtube App/ UI redesign

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/JjoMmYE](https://codepen.io/ricardoolivaalonso/pen/JjoMmYE).

