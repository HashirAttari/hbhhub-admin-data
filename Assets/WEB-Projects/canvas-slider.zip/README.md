# canvas slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nvagelis/pen/LRKVEv](https://codepen.io/Nvagelis/pen/LRKVEv).

