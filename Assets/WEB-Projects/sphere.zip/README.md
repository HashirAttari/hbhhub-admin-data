# Sphere

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/DmdKXX](https://codepen.io/hakimel/pen/DmdKXX).

A tiny nugget of JavaScript to generate a particle sphere.