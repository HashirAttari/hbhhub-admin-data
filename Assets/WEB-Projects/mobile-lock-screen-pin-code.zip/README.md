# Mobile lock screen pin code

A Pen created on CodePen.io. Original URL: [https://codepen.io/codesuey/pen/LZwbxz](https://codepen.io/codesuey/pen/LZwbxz).

Full working example of a lock screen made with awesome HTML, jQuery and CSS.
It's not really safe, but JSFuck made it safe for a "normal" user.