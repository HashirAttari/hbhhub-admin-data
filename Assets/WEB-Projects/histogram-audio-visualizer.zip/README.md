# Histogram Audio Visualizer

A Pen created on CodePen.io. Original URL: [https://codepen.io/tkluge/pen/QEvWRZ](https://codepen.io/tkluge/pen/QEvWRZ).

I wanted something similar to wavesurfer.js, but with the bar graph visualization