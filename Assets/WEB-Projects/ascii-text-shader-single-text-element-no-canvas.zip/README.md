# Ascii Text Shader (single text element, no canvas)

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/GRoQQRd](https://codepen.io/agalliat/pen/GRoQQRd).

