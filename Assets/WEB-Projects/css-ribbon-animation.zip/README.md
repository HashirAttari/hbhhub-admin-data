# CSS Ribbon animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/YzgvKmz](https://codepen.io/amit_sheen/pen/YzgvKmz).

