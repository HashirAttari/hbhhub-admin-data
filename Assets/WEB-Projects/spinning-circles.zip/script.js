var s = new Snap('#surface');

var colors = [
  '#e9edef', '#efad42', '#e9435a', '#4aadad', '#83cead'
];
var circles = s.selectAll('circle');
var circleGroups = [];

for (var i = 0; i < circles.length; i += 1) {
  var group = [];
  
  for (var j = 0; j < colors.length; j += 1) {
    var c = circles[i].clone();
    c.attr({
      stroke: colors[j]
    });
    
    var startPos = Math.random() * 1000; 
    var endPos = Math.random() * 100;
    
    var startLength = 3;
    var endLength = 10 + Math.random() * 30;
    
    var startLine = startPos + " " + startPos + startLength;
    var endLine = endPos + "% " + (endPos + endLength) + "%";
    var delay = (colors.length - j) / 10;
    
    TweenMax.fromTo(c.node, 3, {drawSVG: startLine}, {
      drawSVG: endLine, 
      delay: delay,
      ease: Quint.easeInOut,
      repeat: -1,
      repeatDelay: 0.25,
      yoyo: true
    });
    
    TweenMax.to(c.node, 3, {
      transformOrigin: '50% 50%', 
      rotation: '360deg', 
      ease: Back.easeInOut,
      delay: delay,
      repeat: -1, 
      repeatDelay: 0.25,
      yoyo: true
    });
    group.push(c);
  }
  
  circleGroups.push(group);
  circles[i].remove();
}