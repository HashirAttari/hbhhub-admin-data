# spinning circles

A Pen created on CodePen.io. Original URL: [https://codepen.io/cjgammon/pen/YGvgLe](https://codepen.io/cjgammon/pen/YGvgLe).

Spinning circle segments with greensock's drawSVG plug in.

Inspired by https://www.pinterest.com/pin/585397651533559558/