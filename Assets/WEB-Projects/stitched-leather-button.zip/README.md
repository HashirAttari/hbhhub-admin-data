# Stitched leather button

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/ZEqBzNJ](https://codepen.io/nicolasjesenberger/pen/ZEqBzNJ).

