# border-radius

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/dBroLP](https://codepen.io/yuanchuan/pen/dBroLP).

https://twitter.com/yuanchuan23/status/1136446325501911040
