# Fluent Design Keyboard Hover Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/Gorus/pen/wrREPM](https://codepen.io/Gorus/pen/wrREPM).

