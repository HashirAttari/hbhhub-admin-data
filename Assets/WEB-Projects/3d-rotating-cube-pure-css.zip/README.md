# 3D Rotating Cube (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/LJbmag](https://codepen.io/ykadosh/pen/LJbmag).

A pure CSS 3D rotating cube, with face shading and shadow.
The shading is achieved by animating the background color of the face, starting from a different point in the animation for each face.