# Pop-up without JavaScript

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/yLbVrzM](https://codepen.io/havardob/pen/yLbVrzM).

Use <details> and <summary> + a simple animation to create a pop-up without Javascript