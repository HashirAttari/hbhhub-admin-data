# React Profile Card with image upload

A Pen created on CodePen.io. Original URL: [https://codepen.io/OlgaKoplik/pen/ZdyKGY](https://codepen.io/OlgaKoplik/pen/ZdyKGY).

React Profile Card with image upload