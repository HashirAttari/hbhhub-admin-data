# Search Input with options

A Pen created on CodePen.io. Original URL: [https://codepen.io/emilcarlsson/pen/bRQgQW](https://codepen.io/emilcarlsson/pen/bRQgQW).

