var style_el = document.createElement('style'), 
    slider_els = document.querySelectorAll('.fill'), 
    n_sliders = slider_els.length, 
    styles = [], 
    pp = ['-webkit-slider-runnable-', '-moz-range-'], 
    n_pp = pp.length;

document.body.appendChild(style_el);

for(var i = 0; i < n_sliders; i++) {
  styles.push('');
  
  slider_els[i].dataset.idx = i + 1;
  
  slider_els[i].addEventListener('input', function() {
    var str = '', 
        idx = this.dataset.idx, 
        sel = '.js .fill[data-idx="' + idx + '"]::', 
        val = this.value + '% 100%';
    
    for(var j = 0; j < n_pp; j++) {
      str += sel + pp[j] + 'track{background-size:' + val + '}';
    }
    
    console.log(str);
    
    styles[i] = str;
    style_el.textContent = styles.join('');
  }, false);
}