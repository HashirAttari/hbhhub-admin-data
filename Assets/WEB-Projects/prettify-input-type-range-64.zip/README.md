# prettify `<input type=range>` #64

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/JoBrRv](https://codepen.io/thebabydino/pen/JoBrRv).

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 36, 39 (nightly), Chrome 40, 43 (canary)/ Opera 28, IE 11 on Windows 8. Looks ugly in Chrome because of [a `repeating-linear-gradient` bug](https://twitter.com/thebabydino/status/571150764132970496). IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for updating the fill of the range track for the third section.  Fallback for no JS: display the same background for the tracks, both before and after the thumbs. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/fBbII9O.png) 
You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 