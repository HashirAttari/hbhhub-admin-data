# Daily UI #002 Credit Card Checkout

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/yOOvmG](https://codepen.io/mselmany/pen/yOOvmG).



Forked from [Pavel Laptev](http://codepen.io/PavelLaptev/)'s Pen [Daily UI #002 Credit Card Checkout](http://codepen.io/PavelLaptev/pen/BKBQdB/).