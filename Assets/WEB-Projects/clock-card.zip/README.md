# Clock card

A Pen created on CodePen.io. Original URL: [https://codepen.io/ph1p/pen/WOxxZR](https://codepen.io/ph1p/pen/WOxxZR).

A quick css copy of https://www.instagram.com/p/BVEcuWcFKwq/ ... not a 100% percent equal,  but it has a working clock.