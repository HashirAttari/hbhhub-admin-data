# 404 Animated Character

A Pen created on CodePen.io. Original URL: [https://codepen.io/WithAnEs/pen/abNGxX](https://codepen.io/WithAnEs/pen/abNGxX).

Created for the 404 section for my portfolio site. Wanted something a pretty animated to add interest to this often forgottent page.