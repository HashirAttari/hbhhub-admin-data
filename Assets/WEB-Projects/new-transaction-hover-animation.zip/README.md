# New Transaction Hover Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/TurkAysenur/pen/wvaGqXW](https://codepen.io/TurkAysenur/pen/wvaGqXW).

Inspired by
https://dribbble.com/shots/9990744-New-Transaction-Hover (Mauricio Bucardo)