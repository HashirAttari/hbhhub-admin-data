# Toggle lever

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/yLwyRzb](https://codepen.io/alvaromontoro/pen/yLwyRzb).

