const $ = document.querySelector.bind(document);

const width = 400;
const height = 400;

const canvas = document.createElement('canvas');
const context = canvas.getContext('2d');

const stage = $('.stage');

canvas.width = width;
canvas.height = height;

stage.appendChild(canvas);

const visualizer = {
  bar: {
    width: 1,
    height: 40,
    color: 'white' },

  radius: 60 };


const pieces = 400;
let audio = Array(pieces).fill(null).map((x, i) => Math.random());

const update = () => {
  audio = audio.
  map((x) =>
  Math.random() > 0.5 ?
  Math.max(x - 0.01, 0.02) :
  Math.min(x + 0.01, 1));
};

const render = () => {
  const spacing = 360 / audio.length;
  const origin = {
    x: width / 2 - visualizer.bar.width / 2,
    y: height / 2 - visualizer.bar.height };


  context.fillStyle = '#fff';
  context.clearRect(0, 0, width, height);

  for (const [i, piece] of audio.entries()) {
    const degrees = i * spacing;
    const radians = degrees / 180 * Math.PI;

    context.save();
    context.translate(origin.x, origin.y);
    context.rotate(radians);
    context.fillRect(visualizer.bar.width / -2, visualizer.radius, visualizer.bar.width, visualizer.bar.height * piece);
    context.restore();
  }

  update();
  requestAnimationFrame(render);
};

render();