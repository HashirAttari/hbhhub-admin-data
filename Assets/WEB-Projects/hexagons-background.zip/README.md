# Hexagons Background

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/qBBMMGa](https://codepen.io/yuanchuan/pen/qBBMMGa).

Answer to https://stackoverflow.com/a/58847086/742959