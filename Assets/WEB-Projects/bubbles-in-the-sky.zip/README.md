# Bubbles in the Sky

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/ZQVXab](https://codepen.io/leenalavanya/pen/ZQVXab).

Something like 'bokeh'. Keep watching for a better effect..