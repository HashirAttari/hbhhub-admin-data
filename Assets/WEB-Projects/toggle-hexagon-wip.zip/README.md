# Toggle Hexagon (WIP)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/vYPONbg](https://codepen.io/alvaromontoro/pen/vYPONbg).

