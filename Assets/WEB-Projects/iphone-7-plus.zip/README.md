# iPhone 7 Plus

A Pen created on CodePen.io. Original URL: [https://codepen.io/robinsavemark/pen/MpKLeO](https://codepen.io/robinsavemark/pen/MpKLeO).

An iPhone made in pure CSS. :) Hover it, baby!

Edit: Made a few modifications 3/3. Try to unlock the iPhone and see what happens! ;)
Also made some detail changes. 

Enjoy!