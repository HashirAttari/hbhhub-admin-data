# CSS Grid Keyboard

A Pen created on CodePen.

Original URL: [https://codepen.io/coreybruyere/pen/VMVaqM](https://codepen.io/coreybruyere/pen/VMVaqM).

A mechanical keyboard built with CSS Grid. 