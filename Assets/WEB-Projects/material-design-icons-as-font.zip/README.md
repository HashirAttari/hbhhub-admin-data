# Material Design icons ( as font )

A Pen created on CodePen.io. Original URL: [https://codepen.io/LukyVj/pen/MYaKpY](https://codepen.io/LukyVj/pen/MYaKpY).

