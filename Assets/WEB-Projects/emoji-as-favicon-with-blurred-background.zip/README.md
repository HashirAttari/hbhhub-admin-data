# Emoji as Favicon with Blurred Background

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/jOMvGMZ](https://codepen.io/markmead/pen/jOMvGMZ).

