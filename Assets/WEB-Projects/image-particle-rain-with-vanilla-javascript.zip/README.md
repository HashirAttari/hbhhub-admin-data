# Image Particle Rain with Vanilla JavaScript

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/vYKRpvE](https://codepen.io/franksLaboratory/pen/vYKRpvE).

