# 150 Animated SVG Icons

A Pen created on CodePen.io. Original URL: [https://codepen.io/jhoward/pen/AgEYGj](https://codepen.io/jhoward/pen/AgEYGj).

