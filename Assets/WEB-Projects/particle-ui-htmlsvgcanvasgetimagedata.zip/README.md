# Particle UI. HTML -> SVG -> Canvas -> getImageData

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/VJyWNx](https://codepen.io/jcoulterdesign/pen/VJyWNx).

Just experimenting with canvas getImageData. In this instance, i wanted it to be easy to update the html and particles to be dynamic. In the past i have simply drawn an image onto canvas and then split it up into particles. This time however ive converted the html of an element into SVG (Using foreignObject), created a BLOB etc. Then drawn to a fresh canvas and split up into pixel. Looks pretty good, slightly slow performance wise with each canvas consisting of about 7000 pixels