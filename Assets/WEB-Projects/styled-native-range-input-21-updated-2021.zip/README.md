# Styled native range input #21 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/ZYaPvJ](https://codepen.io/thebabydino/pen/ZYaPvJ).

**May 2021**

* minor CSS cleanups, , in particular made most of the code for `::-moz-range-track` and `::-moz-range-progress` common to slash a few more lines of code

* minor accessibility tweak: give the `output` elements `display: none` in the no JS case since they can't get updated on dragging the handles anyway

---

**January 2021 update**

Major changes:

* eliminated the 1 element constraint and now used a range `input` tied to an `output` displaying its current value, both of them in a wrapper which stores the current value of the range input in a custom property - this greatly simplifies the JavaScript for updating the fake progress

* used `datalist` for tick marks/ tick labels (see [this twitter thread](https://twitter.com/anatudor/status/1225113768629325825))

* eliminated hacks like using the `-ms-` class for specifically targeting IE (which didn't even work in *pre-Chromium* Edge anyway, which got the `-webkit-` class instead) or the `track`'s `::after` pseudo-element for the progress text label (that's now done cleanly and in a cross-browser manner with the `output` element)

* got rid of `absolute` positioning in favour of a CSS `grid` layout

* made it degrade gracefully in the no JS case (check with JS disabled)/ no Houdini case (check in a browser that doesn't support registering custom properties like Firefox)

Hopefully accessible.

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling the range track. There's a bit of an extra in Chrome/ Opera with a tooltip above (not a separate element, a pseudo on the thumb) and a ruler below. This is done using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). Fallback for no JS: simply display the same background for the entire track, both before and after the thumb and no tooltip or ruler. 

**Disclaimer in case the above wasn't clear enough.** The `/deep/` part is extremely experimental code. Does it work? \_(ツ)_/¯ . Should you reuse it? ಠ_ಠ 

[Thanks to Addy Osmani for the disclaimer text](https://twitter.com/addyosmani/status/538271562215223297).

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](https://pbs.twimg.com/media/B9bzKkhIcAE5XlH?format=png&name=large) 