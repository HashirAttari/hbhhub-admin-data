# Pure css slider animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/Wujek_Greg/pen/PRVXJK](https://codepen.io/Wujek_Greg/pen/PRVXJK).

