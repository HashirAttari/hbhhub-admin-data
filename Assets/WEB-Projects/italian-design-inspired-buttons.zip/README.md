# Italian design inspired buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/devilishalchemist/pen/mBYXeQ](https://codepen.io/devilishalchemist/pen/mBYXeQ).

Inspired by the article about Italian design: https://blog.prototypr.io/google-and-the-resurgence-of-italian-design-e9234cf3d073

Relevant gif of the Divisumma 18 calculator: https://cdn-images-1.medium.com/max/800/1*Yt_8Pgp5PR9Xo_2lHwqVmA.gif