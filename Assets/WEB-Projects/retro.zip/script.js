/*
	Designed by: Gigantic
	Original Image: https://dribbble.com/shots/6846372-Simple-Animation-Tutorial-In-After-Effects-Game-Design
*/


const score = document.querySelector('#score');
let con = 0;

let sto = (event) => {
	setInterval(() => {
		con ++;
		score.innerText = `${con}M`
	}, 250);
}

sto();