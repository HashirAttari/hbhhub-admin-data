# Digital Clock w/ Animation ⏰

A Pen created on CodePen.io. Original URL: [https://codepen.io/annampawl/pen/yLKLbaY](https://codepen.io/annampawl/pen/yLKLbaY).

A digital clock with a hover animation 