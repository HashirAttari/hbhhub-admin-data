# Strawberry

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/aNGqXy](https://codepen.io/hakimel/pen/aNGqXy).

