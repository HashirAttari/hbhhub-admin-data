# Lightning

A Pen created on CodePen.io. Original URL: [https://codepen.io/akm2/pen/DbNJXr](https://codepen.io/akm2/pen/DbNJXr).

http://jsdo.it/akm2/pQbM

Lightning Points (Lightning 2)
http://codepen.io/akm2/pen/LuDba