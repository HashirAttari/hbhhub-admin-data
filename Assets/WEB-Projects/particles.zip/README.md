# Particles

A Pen created on CodePen.

Original URL: [https://codepen.io/sakri/pen/rNBdxo](https://codepen.io/sakri/pen/rNBdxo).

Particles from an emitter moving behind some text. FPS counter  included to measure performance. Select from two strategies : using fillRect() and setting pixels with get/putImageData().  There is a widget to change the number of particles. I get 60fps using fillrect on 10,000 particles, with putImageData I get 100,000 with 55fps.