/* external resources *only* for displaying the info boxes */

/* this below is all the JS needed for the demo itself to work */
document.documentElement.classList.add('js');

addEventListener('input', e => {
	let _t = e.target, i = _t.dataset.i, 
			_p = i ? _t.parentNode : _t;
	
	_p.style.setProperty(`--v${i || ''}`, +_t.value)
})