# Photorealistic pure CSS mobile phone

A Pen created on CodePen.io. Original URL: [https://codepen.io/Wujek_Greg/pen/LmrweG](https://codepen.io/Wujek_Greg/pen/LmrweG).

Pure CSS mobile phone, based on iphone X mockup. Everything is made byc CSS, no svg, no base64