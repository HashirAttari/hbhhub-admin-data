// Pure CSS photorealistic mobile phone
// Based on https://dribbble.com/shots/4449159-Crypto-Market 
// and on https://dribbble.com/shots/3900867-Yota-Future-Plan-Overview