# Google Search - Redesign

A Pen created on CodePen.io. Original URL: [https://codepen.io/Hyperplexed/pen/xxJaxJj](https://codepen.io/Hyperplexed/pen/xxJaxJj).

