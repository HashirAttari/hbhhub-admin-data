# Canvas Global Composite Operation

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/bPymrX](https://codepen.io/agalliat/pen/bPymrX).

Learn about this code on MDN: https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D/globalCompositeOperation