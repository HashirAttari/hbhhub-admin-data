# clip-path

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/KjBJpY](https://codepen.io/yuanchuan/pen/KjBJpY).

https://twitter.com/yuanchuan23/status/1136446325501911040
