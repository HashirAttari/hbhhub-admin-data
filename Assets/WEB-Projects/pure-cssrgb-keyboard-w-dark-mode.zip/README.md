# [Pure CSS] - RGB Keyboard w/ Dark Mode

A Pen created on CodePen.

Original URL: [https://codepen.io/schwiiiii/pen/BarVMxq](https://codepen.io/schwiiiii/pen/BarVMxq).

