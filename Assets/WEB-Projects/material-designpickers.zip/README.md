# Material Design - Pickers

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/pbmJVw](https://codepen.io/leenalavanya/pen/pbmJVw).

As shown here: [will add support for year selection soon :) ]
<br/>
<br/>
<img src="https://material-design.storage.googleapis.com/publish/material_v_9/0B3321sZLoP_HVWZOVkdRQlJEdDg/components_pickers_date1.png"></img>