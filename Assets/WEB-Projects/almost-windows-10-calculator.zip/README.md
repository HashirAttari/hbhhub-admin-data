# Almost Windows 10 Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/Killuminati/pen/grQxXE](https://codepen.io/Killuminati/pen/grQxXE).

