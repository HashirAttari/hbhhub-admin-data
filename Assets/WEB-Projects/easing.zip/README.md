# Easing

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/KKxMddM](https://codepen.io/yuanchuan/pen/KKxMddM).

