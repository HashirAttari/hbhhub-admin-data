# css valentine bear

A Pen created on CodePen.

Original URL: [https://codepen.io/majchi/pen/qByepoz](https://codepen.io/majchi/pen/qByepoz).

