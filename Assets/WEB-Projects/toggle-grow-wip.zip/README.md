# Toggle grow (WIP)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/abMOvRo](https://codepen.io/alvaromontoro/pen/abMOvRo).

