# Daily UI #004 - USSR Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/PavelLaptev/pen/GZgKvX](https://codepen.io/PavelLaptev/pen/GZgKvX).

