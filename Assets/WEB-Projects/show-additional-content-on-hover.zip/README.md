# Show additional content on hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/QWKYeJo](https://codepen.io/benhatsor/pen/QWKYeJo).

A card that shows additional content on hover.