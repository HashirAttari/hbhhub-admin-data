# CSS rainbow in the clouds

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/GRLERoM](https://codepen.io/amit_sheen/pen/GRLERoM).

