# 3D card 

A Pen created on CodePen.io. Original URL: [https://codepen.io/robin-dela/pen/jVddbq](https://codepen.io/robin-dela/pen/jVddbq).

Background from a project I've worked on : https://www.hpsoundincolor.com/