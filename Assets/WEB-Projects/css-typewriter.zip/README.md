# CSS Typewriter 📄

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/XWWPbep](https://codepen.io/aaroniker/pen/XWWPbep).

From https://dribbble.com/shots/7084258-Type