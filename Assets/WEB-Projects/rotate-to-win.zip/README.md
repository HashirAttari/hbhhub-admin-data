# Rotate To Win

A Pen created on CodePen.io. Original URL: [https://codepen.io/ripter/pen/WPeWWK](https://codepen.io/ripter/pen/WPeWWK).

WASD Keys to rotate the "camera"
Press "i" to invert the colors.

Libraries Used: lighterHTML