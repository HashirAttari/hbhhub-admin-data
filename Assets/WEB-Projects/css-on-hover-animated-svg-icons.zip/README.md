# CSS (on hover) animated SVG icons

A Pen created on CodePen.io. Original URL: [https://codepen.io/EntropyReversed/pen/ZVPKoq](https://codepen.io/EntropyReversed/pen/ZVPKoq).

