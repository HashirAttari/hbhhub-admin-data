# [CSS] Cat loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/Rplus/pen/PWZYRM](https://codepen.io/Rplus/pen/PWZYRM).

source image:  
![](https://media.giphy.com/media/3o7TKtbdY5oZuiyucg/giphy.gif)


> inspired from [domaso](https://dribbble.com/domaso)'s dribbble: [Loading cat](https://dribbble.com/shots/3197970-Loading-cat)  
fork from [林天翼](https://www.facebook.com/tenyoku8478)'s [load cat](https://www.csie.ntu.edu.tw/~b02902062/load_cat/) via [FB comment](https://www.facebook.com/groups/f2e.tw/permalink/1180443255326371/?comment_id=1180487985321898)