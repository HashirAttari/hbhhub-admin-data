# Loading dot animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/gcazin/pen/NoOEKj](https://codepen.io/gcazin/pen/NoOEKj).

