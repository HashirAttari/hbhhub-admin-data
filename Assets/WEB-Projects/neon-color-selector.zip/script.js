// if the pen is in thumbnail view, scale it up
if (location.pathname.match(/fullcpgrid/i) ? true : false) {
  document.documentElement.style.fontSize = "32px"
}


const colorsEl = document.querySelector(".colors")

function selectcolor(el) {
  if (el.classList.contains("active")) {return} 
  document.querySelector(".active").classList.remove("active")
  el.classList.add("active")
  document.querySelectorAll(".leftbar").forEach(barEl => barEl.style.animation = "leftOut 400ms ease forwards")
  document.querySelectorAll(".rightbar").forEach(barEl => barEl.style.animation = "rightOut 400ms ease forwards")
  
  const el1 = document.createElement("div");
  el1.classList.add("leftbar");
  el1.style.setProperty("--gradient", el.style.getPropertyValue("--gradient"))
  colorsEl.appendChild(el1)
  const el2 = document.createElement("div");
  el2.classList.add("rightbar");
  el2.style.setProperty("--gradient", el.style.getPropertyValue("--gradient"))
  colorsEl.appendChild(el2)
}