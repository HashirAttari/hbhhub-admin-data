import { trilerp, converter, formatCss, formatHex, easingSmoothstep } from 'https://cdn.skypack.dev/culori';

console.clear();

const rgb = converter('rgb');

const RYB_CUBE = [
{ mode: 'rgb', r: 248 / 255, g: 237 / 255, b: 220 / 255 }, // white
{
  "mode": "rgb",
  "r": 0.8901960784313725,
  "g": 0.1411764705882353,
  "b": 0.12941176470588237 },
// red
{
  "mode": "rgb",
  "r": 0.9529411764705882,
  "g": 0.9019607843137255,
  "b": 0 },
// yellow
{
  "mode": "rgb",
  "r": 0.9411764705882353,
  "g": 0.5568627450980392,
  "b": 0.10980392156862745 },
// orange
{
  "mode": "rgb",
  "r": 0.08627450980392157,
  "g": 0.6,
  "b": 0.8549019607843137 },
// blue
{
  "mode": "rgb",
  "r": 0.47058823529411764,
  "g": 0.13333333333333333,
  "b": 0.6666666666666666 },
// violet
{
  "mode": "rgb",
  "r": 0,
  "g": 0.5568627450980392,
  "b": 0.3568627450980392 },
// green
{ mode: 'rgb', r: 29 / 255, g: 28 / 255, b: 28 / 255 } // black
];

const RYB_CUBE_ALT = [
{ mode: 'rgb', r: 1, g: 1, b: 1 }, // white
{ mode: 'rgb', r: 1, g: 0, b: 0 }, // red
{ mode: 'rgb', r: 1, g: 1, b: 0 }, // yellow
{ mode: 'rgb', r: 1, g: 0.5, b: 0 }, // orange
{ mode: 'rgb', r: 0.163, g: 0.373, b: 0.6 }, // blue
{ mode: 'rgb', r: 0.5, g: 0, b: 0.5 }, // violet
{ mode: 'rgb', r: 0, g: 0.66, b: 0.2 }, // green
{ mode: 'rgb', r: 0.2, g: 0.094, b: 0 } // black
];

/*
  r: trilerp(1, 1, 1, 1, .163, .5, 0, .2, r, y, b),
  g: trilerp(1, 0, 1, .5, .373, 0, .66, .094, r, y, b),
  b: trilerp(1, 0, 0, 0, .6, .5, .2, 0, r, y, b)
*/

function ryb2rgb(coords) {
  //const biased_coords = coords.map(t => t * t * (3 - 2 * t));
  const r = easingSmoothstep(coords[0]);
  const y = easingSmoothstep(coords[1]);
  const b = easingSmoothstep(coords[2]);
  return {
    mode: 'rgb',
    r: trilerp(...RYB_CUBE.map(it => it.r), r, y, b),
    g: trilerp(...RYB_CUBE.map(it => it.g), r, y, b),
    b: trilerp(...RYB_CUBE.map(it => it.b), r, y, b) };

}

function hsl2farbrad(h, s, l) {
  const rgbColor = rgb({
    mode: 'hsl',
    h: (h + 360) % 360, s, l: 1 - l });

  return ryb2rgb([
  rgbColor.r,
  rgbColor.g,
  rgbColor.b]);

}

const getColorsHSL = (amount = 12, s = 1, l = .5) => new Array(amount).fill('').map((_, i) =>
formatCss(hsl2farbrad((1 - i / amount) * 360 + 120, s, l)));



const getColorsVert = (amount = 48, s = 1) => new Array(amount).fill('').map((_, i) => {
  const half = amount / 2;
  const rgbColor = rgb({
    mode: 'hsl',
    h: ((1 - i / amount) * 360 + 120) % 360, s, l: Math.abs((i + half / 2) % amount - half) / half });


  const color = ryb2rgb([rgbColor.r, rgbColor.g, rgbColor.b]);
  return formatCss(color);
});

const colorsToHardStopGradients = cls => cls.map((c, i) => `${c} ${i / cls.length * 100}% ${(i + 1) / cls.length * 100}%`).join();


/// canvas
const canvas = document.querySelector('[data-canvas]');
const ctx = canvas.getContext('2d');
let image = new Image();

const recolor = () => {
  if (!image.src) return;
  ctx.drawImage(image, 0, 0);
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    const nrxb = ryb2rgb([
    data[i + 0] / 255,
    data[i + 1] / 255,
    data[i + 2] / 255]);


    data[i] = Math.round(nrxb.r * 255); // red
    data[i + 1] = Math.round(nrxb.g * 255); // green
    data[i + 2] = Math.round(nrxb.b * 255); // blue


    // luminance conversion
    /*
    const min = Math.min(data[i + 0], data[i + 1], data[i + 2])
    const max = Math.max(data[i + 0], data[i + 1], data[i + 2])
    
    let val = (min + max) / 2
    data[i] = val; // red
    data[i + 1] = val; // green
    data[i + 2] = val; // blue
    */
  }
  ctx.putImageData(imageData, 0, 0);
};

const doIt = () => {
  document.documentElement.style.setProperty('--stops-3', colorsToHardStopGradients(getColorsHSL(3)));
  document.documentElement.style.setProperty('--stops-6', colorsToHardStopGradients(getColorsHSL(6).filter((c, i) => i % 2)));
  document.documentElement.style.setProperty('--stops-12', colorsToHardStopGradients(getColorsHSL(12)));
  document.documentElement.style.setProperty('--stops-24', colorsToHardStopGradients(getColorsHSL(24)));
  document.documentElement.style.setProperty('--stops-48', colorsToHardStopGradients(getColorsHSL(48)));
  document.documentElement.style.setProperty('--stops-vert', colorsToHardStopGradients(getColorsVert()));

  document.documentElement.style.setProperty('--w', formatHex(RYB_CUBE)[0]);
  document.documentElement.style.setProperty('--b', formatHex(RYB_CUBE.at(-1)));
  recolor();
};

doIt();

const $w = document.querySelector('[data-c="w"]');
$w.value = formatHex(RYB_CUBE[7]);
const $r = document.querySelector('[data-c="r"]');
$r.value = formatHex(RYB_CUBE[1]);
const $y = document.querySelector('[data-c="y"]');
$y.value = formatHex(RYB_CUBE[2]);
const $o = document.querySelector('[data-c="o"]');
$o.value = formatHex(RYB_CUBE[3]);
const $b = document.querySelector('[data-c="b"]');
$b.value = formatHex(RYB_CUBE[4]);
const $v = document.querySelector('[data-c="v"]');
$v.value = formatHex(RYB_CUBE[5]);
const $g = document.querySelector('[data-c="g"]');
$g.value = formatHex(RYB_CUBE[6]);
const $black = document.querySelector('[data-c="0"]');
$black.value = formatHex(RYB_CUBE[0]);

const els = [$black, $r, $y, $o, $b, $v, $g, $w];

document.querySelector('[data-edges]').addEventListener('input', e => {
  const $target = e.target;
  const value = $target.value;
  const $tarInEls = els.find(($el, i) => $el.isEqualNode($target));
  const index = els.indexOf($tarInEls);
  if (index > -1) {
    RYB_CUBE[index] = rgb(value);
    doIt();
  }
});



document.querySelector('[data-file]').addEventListener('change', ev => {
  if (!ev.target.files) return;
  const file = ev.target.files[0];
  var reader = new FileReader();

  reader.onloadend = function (e) {
    image = new Image();
    image.src = e.target.result;
    image.onload = function (ev) {
      canvas.width = image.width;
      canvas.height = image.height;
      recolor();
    };
  };

  reader.readAsDataURL(file);
});