# Trampoline loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pedro-Ondiviela/pen/WNmWjYO](https://codepen.io/Pedro-Ondiviela/pen/WNmWjYO).

Simple CSS animation of a jumping loader, done with CSS keyframes.

Done for weekly Codepen challenges.