# Pure CSS Spin Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/sparanoid/pen/kXWpGE](https://codepen.io/sparanoid/pen/kXWpGE).

