# Elastic stroke CSS + SVG

A Pen created on CodePen.io. Original URL: [https://codepen.io/orhanveli/pen/KwVGKP](https://codepen.io/orhanveli/pen/KwVGKP).



Forked from [yoksel](http://codepen.io/yoksel/)'s Pen [Elastic stroke CSS + SVG](http://codepen.io/yoksel/pen/XJbzrO/).