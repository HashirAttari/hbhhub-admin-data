# Shattering Images

A Pen created on CodePen.

Original URL: [https://codepen.io/zadvorsky/pen/abaeOK](https://codepen.io/zadvorsky/pen/abaeOK).

I tried to make a gallery, but the images keep shattering when I click on them... I'll need to use more sturdy materials next time.

(Delaunay triangulation part 2)

