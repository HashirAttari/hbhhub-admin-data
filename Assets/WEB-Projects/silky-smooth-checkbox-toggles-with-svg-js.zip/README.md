# Silky smooth checkbox toggles with SVG.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/jdillon/pen/PoLBVmV](https://codepen.io/jdillon/pen/PoLBVmV).

