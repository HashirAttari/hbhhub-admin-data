# iOS 7 Toggle Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/WithAnEs/pen/nyRMmV](https://codepen.io/WithAnEs/pen/nyRMmV).

Animating toggle switch like the one in iOS7. CSS Animations.