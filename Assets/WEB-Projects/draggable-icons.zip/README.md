# Draggable Icons

A Pen created on CodePen.io. Original URL: [https://codepen.io/KikePuma/pen/KKKoMEO](https://codepen.io/KikePuma/pen/KKKoMEO).

