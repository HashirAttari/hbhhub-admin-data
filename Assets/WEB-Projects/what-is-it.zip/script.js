$(document).ready(function () {

//mselmany
//copy free
  
  

var i = 1;
var l = $(".square.inner").length;
var last = $(".inner:nth-child("+l+")");
var first = $(".inner:nth-child("+1+")");
var query = "next";
 

autoLoop = setInterval(function(){
    
    if(first.hasClass("current")) query = "next";
    else if ( last.hasClass("current") ) query = "prev";
    
    if( query === "next" ){
        i++;
        $(".inner:nth-child("+(i)+")").prevAll(".inner").removeClass("current forward").addClass("behind");
        $(".inner:nth-child("+(i)+")").removeClass("behind forward").addClass("current");
        $(".inner:nth-child("+(i)+")").nextAll(".inner").removeClass("current behind").addClass("forward");
    }else if( query === "prev" ){
        i--;
        $(".inner:nth-child("+(i)+")").prevAll(".inner").removeClass("current forward").addClass("behind");
        $(".inner:nth-child("+(i)+")").removeClass("behind forward").addClass("current");
        $(".inner:nth-child("+(i)+")").nextAll(".inner").removeClass("current behind").addClass("forward");
    }
    
    
},500);


});