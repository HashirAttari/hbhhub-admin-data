# EP-133 K.O.II Buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/gOqzJed](https://codepen.io/nicolasjesenberger/pen/gOqzJed).

Buttons from EP-133 K.O.II by Teenage Engineering, made in CSS