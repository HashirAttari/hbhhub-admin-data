# #codevember - 28 - Piano keyboard

A Pen created on CodePen.

Original URL: [https://codepen.io/ricardoolivaalonso/pen/zYxGrdR](https://codepen.io/ricardoolivaalonso/pen/zYxGrdR).

