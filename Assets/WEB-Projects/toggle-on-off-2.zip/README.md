# Toggle On/Off 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/OJqPrRw](https://codepen.io/alvaromontoro/pen/OJqPrRw).

