# Yin and Yang  (pure CSS)

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/ZEGWdZO](https://codepen.io/agalliat/pen/ZEGWdZO).

