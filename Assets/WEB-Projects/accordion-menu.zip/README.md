# Accordion Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/ahmadbassamemran/pen/BPbVPe](https://codepen.io/ahmadbassamemran/pen/BPbVPe).

Accordion Menu