# One element loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/Raphael/pen/AZwvNg](https://codepen.io/Raphael/pen/AZwvNg).

another loader with sass+bourbon