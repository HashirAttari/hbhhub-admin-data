let select = s => document.querySelector(s),
		mainSVG = select('#mainSVG'),
		allRipples = gsap.utils.toArray('#waterRipplePattern path')

gsap.set('svg', {
	visibility: 'visible'
})

let mainTl = gsap.timeline();

allRipples.forEach((target, count) => {

	let tl = gsap.timeline({
		defaults: {
			duration: 2,
			ease: 'expo.inOut'
		}
	});
	tl.fromTo(target, {
		opacity: 0,
	}, {		
		opacity: 1,
		ease: 'expo',
		repeat: -1,
		yoyo: true
	})
.fromTo(target, {
		drawSVG: '50% 50%',
		opacity: 0,
	}, {		
		drawSVG: '0% 100%',
		opacity: 1,
		ease: 'power1.inOut',
		repeat: -1,
		yoyo: true
	}, 0)
.to(target, {		
		y: 'random(3, 5)',
		ease: 'sine.inOut',
		repeat: -1,
		yoyo: true
	}, 0)
.to(target, {		
		x: 'random(-8, 9)',
		ease: 'sine.inOut',
		repeat: -1,
		yoyo: true,
		duration: 4,
	}, 0)
	
	mainTl.add(tl, count/2)
})

mainTl.seek(1000)