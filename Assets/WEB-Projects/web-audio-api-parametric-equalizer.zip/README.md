# Web Audio API: parametric equalizer

A Pen created on CodePen.io. Original URL: [https://codepen.io/gregh/pen/jyXMYY](https://codepen.io/gregh/pen/jyXMYY).

Parametric equalizer created using Web Audio API. It uses the following filters and params: High-shelf [frequency, gain], Low-shelf [frequency, gain], High-pass [frequency, Q-factor], Low-pass [frequency, Q-factor]