# Interactive 60% Keyboard

A Pen created on CodePen.

Original URL: [https://codepen.io/32bitkid/pen/LKZzMR](https://codepen.io/32bitkid/pen/LKZzMR).

