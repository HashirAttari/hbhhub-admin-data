/*
CSS SPINNER!

Got the idea from Dan on Dribbble, check it out: 
http://dribbble.com/shots/688188-RSS-Loader

His twitter: @dan__h
My twitter : @monstasaurous

It's basically just a triangle using css borders and rounded corners, that spins using animation with a box shodow for the border. Didn't even have to use pseudo elements.

Sorry it doesn't work too well in Firefox, if anybody can figure out what's up with that please let me know! :D
*/