# Single Element Spinner (CSS Sans Pseudos)

A Pen created on CodePen.io. Original URL: [https://codepen.io/sparanoid/pen/nVwpPw](https://codepen.io/sparanoid/pen/nVwpPw).

Made a spinner with only one element and no pseudo elements either, using box shadow. 