// Inspired by https://dribbble.com/shots/14172039-3D-Red-Switch

// some js for the click sound and vibration on Android devices
document.querySelector('.switch-checkbox').addEventListener('change', () => {
  const audio = new Audio('https://assets.codepen.io/4175254/click.mp3');
  audio.play();
  
  if (navigator.vibrate) navigator.vibrate(50);
});