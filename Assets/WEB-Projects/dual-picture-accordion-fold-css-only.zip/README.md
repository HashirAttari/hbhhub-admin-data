# Dual Picture Accordion Fold (css only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/PodVLMr](https://codepen.io/amit_sheen/pen/PodVLMr).

