# Eletric Spinner ⚡️ (CSS, SVG:Gooey)

A Pen created on CodePen.io. Original URL: [https://codepen.io/konstantindenerz/pen/XWQWYVW](https://codepen.io/konstantindenerz/pen/XWQWYVW).

Can't get enough of the gooey effect 😍⚡️ Check out my latest #CodePen creation: a spinner with an electrifying twist! Built with CSS and featuring a SVG filter for that extra gooeyness. Perfect for adding a spark to your projects! 🔌🌀

ℹ️  Try different scales (1x, 0.5x 0.25x)

✅ Chrome & Firefox
