# Particle Text

A Pen created on CodePen.

Original URL: [https://codepen.io/seanfree/pen/bGGyBYE](https://codepen.io/seanfree/pen/bGGyBYE).

## Particle Text

Canvas pixel manipulation using typed arrays

Particles react to mouse movement