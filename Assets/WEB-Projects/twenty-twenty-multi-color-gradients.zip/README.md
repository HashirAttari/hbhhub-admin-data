# Twenty Twenty & Multi-Color Gradients ❤

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/jOEGRLR](https://codepen.io/leenalavanya/pen/jOEGRLR).

Multi-colour gradients clipped with CSS, blended with SVG's feGaussianBlur.

Font: Modak by Ek Type (https://fonts.google.com/specimen/Modak)