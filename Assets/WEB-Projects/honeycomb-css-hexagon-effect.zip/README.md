# Honeycomb CSS Hexagon effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/r34h87fh/pen/oNraPG](https://codepen.io/r34h87fh/pen/oNraPG).

My very pointless grid of hexagons that randomise in colour to create a honeycomb effect. It will fit any screen height or width. 

Working with Javascript