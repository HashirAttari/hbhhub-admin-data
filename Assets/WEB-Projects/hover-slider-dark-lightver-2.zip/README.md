# Hover slider (dark/light) - ver 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/gqRJNW](https://codepen.io/ig_design/pen/gqRJNW).

