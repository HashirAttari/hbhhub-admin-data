# Spinning, v3

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/rLVPpz](https://codepen.io/giana/pen/rLVPpz).

