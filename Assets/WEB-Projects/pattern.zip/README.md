# Pattern

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/vYXLprw](https://codepen.io/yuanchuan/pen/vYXLprw).

https://twitter.com/anatudor/status/1334525245844320261