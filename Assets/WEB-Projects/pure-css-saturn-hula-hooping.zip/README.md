# Pure CSS Saturn Hula Hooping

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/BrdPaw](https://codepen.io/jcoulterdesign/pen/BrdPaw).

Titan watches Saturn hula hoop! A conversion of this gif into pure CSS https://dribbble.com/shots/4252236-Saturn-Hula-Hooping