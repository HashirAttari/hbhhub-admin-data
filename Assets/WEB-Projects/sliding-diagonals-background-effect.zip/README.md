# Sliding Diagonals Background Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/chris22smith/pen/RZogMa](https://codepen.io/chris22smith/pen/RZogMa).

An animated background under the content.