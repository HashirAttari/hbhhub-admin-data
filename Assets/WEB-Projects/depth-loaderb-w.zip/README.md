# Depth Loader - B&W

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/VwjVVLV](https://codepen.io/benhatsor/pen/VwjVVLV).

Black and white perspective loader. Uses skew to give an effect of depth.