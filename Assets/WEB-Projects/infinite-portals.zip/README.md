# Infinite Portals

A Pen created on CodePen.io. Original URL: [https://codepen.io/Yakudoo/pen/PogJvGv](https://codepen.io/Yakudoo/pen/PogJvGv).

A birdhouse inside a sand castle inside a birdhouse... Dive into these recursive worlds and enjoy the infinite transition.
A webgl demo made with Three.js and Gsap.