# 3D Block - CSS Box Shadow

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/MWyYQBm](https://codepen.io/benhatsor/pen/MWyYQBm).

3D Block created with CSS `box-shadow`. [Responsive]