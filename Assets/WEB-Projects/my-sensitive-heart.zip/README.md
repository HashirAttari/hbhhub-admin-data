# My Sensitive Heart

A Pen created on CodePen.

Original URL: [https://codepen.io/2Mogs/pen/XpygZZ](https://codepen.io/2Mogs/pen/XpygZZ).

Valentine's Day animation
-
Particle system with avoidance and spring behaviours. 
Uses custom SVG shape morphing to control the particle's base shapes.

Made for workplace competition to make a Valentine's Day card. 

Now set to run in interactive playground mode, but set RUN_AS_ANIMATION = true; // line 1
to see the original linear animation.