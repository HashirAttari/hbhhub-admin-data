# EVEN or ODD

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/jOqVreJ](https://codepen.io/run-time/pen/jOqVreJ).

what is even and what is odd?