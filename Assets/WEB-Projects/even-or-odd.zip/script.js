const isEven = (n) => {
  return n % 2 === 0
}
function getBox(label, value) {
  const type = isEven(value) ? 'EVEN' : 'ODD'
  
  return `<div class="box"><div class="box-label box-label_${type}">${label} is ${type}</div><div class="box-value box-value_${type}">${value}</div></div>`
}

function update () {
  const now = moment();
  const seconds = now.second();
  const minutes = now.minute();
  const hours = now.hour();
  const days = now.date();
  const weeks = now.week();
  const months = now.month()+1;
  const years = now.year();
  
  let h = ``
  
  h += getBox('Second', seconds)
  h += getBox('Minute', minutes)
  h += getBox('Hour', hours)
  h += getBox('Day', days)
  h += getBox('Week', weeks)
  h += getBox('Month', months)
  h += getBox('Year', years)
  
  document.querySelector('#out').innerHTML = h
}

function init () {
  setInterval(update, 200)
}

init()