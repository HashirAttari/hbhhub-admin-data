# Responsive CSS3 Side Navigation Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/SaraSoueidan/pen/AWvpev](https://codepen.io/SaraSoueidan/pen/AWvpev).

Media Queries Transitions (resize the window slowly to see the transitions), nav items slide out on hover when it collapses on smaller screens. 