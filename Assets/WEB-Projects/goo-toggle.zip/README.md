# Goo Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/ExPmdgz](https://codepen.io/chrisgannon/pen/ExPmdgz).

