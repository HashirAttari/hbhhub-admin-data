let select = s => document.querySelector(s),
  selectAll = s =>  document.querySelectorAll(s),
		mainSVG = select('#mainSVG'),
		container = select('#container'),
		dark = '#5DB1FF',
		light = '#FA454F'

gsap.set('svg', {
	visibility: 'visible'
})
gsap.set('circle', {
	transformOrigin: '50% 50%'
})


function onClick(e) {
	container.appendChild(select(`#${e.target.id}`));
	
	let tl = gsap.timeline({
		defaults: {
			ease: 'elastic(0.5, 0.5)'
		}
	}).timeScale(0.75);
	switch(e.target.id) {
			
		case 'left':
			select('#left').style.cursor = 'auto'
			select('#right').style.cursor = 'pointer'
			tl.to('#left', {
				scaleY: 1,
				x: 0,
				fill: light
			})
		.to('#left', {
				scaleX: 1,
				duration: 0.86,
				ease: 'elastic(0.5, 0.45)'
			}, 0)			
			.to('#right', {
				scaleY: 0.55,
				x: -40,
				fill: dark
			}, 0)
			.to('#right', {
				scaleX: 0.55,
				duration: 0.86,
				ease: 'elastic(0.5, 0.45)'
			}, 0)	
			.to('.whole', {
				duration: 0.6,
				x: 80
			}, 0)
		.to('#icon', {
				//rotation: 180,
				transformOrigin: '50% 50%',
				morphSVG: {
					shape: "M433,300c0,18.2-14.8,33-33,33s-33-14.8-33-33s14.8-33,33-33S433,281.8,433,300z"
				},
				//ease: 'expo',
				ease: 'elastic(1, 0.8)',
				stroke:'#FF858B',
				duration: 1
			}, 0)	
			break;
		case 'right':
		select('#left').style.cursor = 'pointer'
		select('#right').style.cursor = 'auto'
			
			tl.to('#right', {
				scaleY: 1,
				x: 0,
				fill: dark
			})
		.to('#right', {
				scaleX: 1,
				duration: 0.86,
				ease: 'elastic(0.5, 0.45)'
			}, 0)				
			.to('#left', {
				scaleY: 0.55,
				x: 40,
				fill: light
			}, 0)
			.to('#left', {
				scaleX: 0.55,
				duration: 0.86,
				ease: 'elastic(0.5, 0.45)'
			}, 0)
			.to('.whole', {
				duration: 0.6,
				x: -80
			}, 0)	
		.to('#icon', {
				//rotation: -180,
				transformOrigin: '50% 50%',
				stroke:'#99D1FF',
				morphSVG: {
					shape: "M433,300c0,0-14.8,0-33,0s-33,0-33,0s14.8,0,33,0S433,300,433,300z"
				},
				//ease: 'expo',
				ease: 'elastic(1, 0.8)',
				duration: 1
			}, 0)			
			break;
	}
}

document.addEventListener('click', onClick)
onClick({target: {id: 'left'}})