# CSS is Awesome (CSS Motion Path)

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/OJPvRRR](https://codepen.io/yuanchuan/pen/OJPvRRR).

