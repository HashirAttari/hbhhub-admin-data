# Custom Range Slider with values

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/NWqewBO](https://codepen.io/MananTank/pen/NWqewBO).

