var xPos=[],yPos=[],stps=[],fireCols=[],checks=[0,0,0,0],showCursor=1,points=10,sinusoid=0.1,dissipate=0.3,dragging,expanded=0;
var ids=["info","settings"];
var pointFld=[],sine=[],stepNo=[],fade,size=25;

window.onresize = function(event) {
  resize();
};

//I'm just avoiding to use CSS in this one...
function enter(id){
  document.getElementById(ids[id]).style.opacity="1";
  document.getElementById("setup").style.display="block";
}
function leave(id){
  document.getElementById(ids[id]).style.opacity="0.2";
  if (expanded==0){document.getElementById("setup").style.display="none";}
}

function expand(){
  if (expanded==0){
    document.getElementById("setup").style.left="80px";
    document.getElementById("setup").style.opacity="1";
    expanded=1;
  }else{
    collapse();
  }
}

function collapse(){
  document.getElementById("setup").style.left="50px";
  document.getElementById("setup").style.opacity="0";
  expanded=0;
}

function hide(){
  document.getElementById("setup").style.display="none";
}

function change(id){
  if (id==0){
    points=document.getElementById("points").value;
  }else if (id==1){
    checks[0]=Math.abs(checks[0]-1);
  }else if (id==2){
    sinusoid=document.getElementById("sine").value;
  }else if (id==3){
    checks[1]=Math.abs(checks[1]-1);
  }else if (id==4){
    dissipate=document.getElementById("fade").value;
    if (dissipate<0.15){dissipate=0.15;}
    if (dissipate>1){dissipate=1;}
  }else if (id==5){
    checks[2]=Math.abs(checks[2]-1);
  }else if (id==6){
    if (showCursor==1){
      document.getElementById("canvas").style.cursor="none";
      showCursor=0;
    }else{
      document.getElementById("canvas").style.cursor="crosshair";
      showCursor=1;
    }
  }else if (id==7){
    size=document.getElementById("size").value;
  }else{
    checks[3]=Math.abs(checks[3]-1);
  }
}

function resize(){
  document.getElementById("canvas").width=window.innerWidth;
  document.getElementById("canvas").height=window.innerHeight;
  paint();
}

function toggleDrag(id){
  dragging=id;
  setPos();
}

function setPos(){
  if (dragging==1){
    xPos.push(event.clientX);
    yPos.push(event.clientY);
    var tmpSize;
    if (checks[3]==0){tmpSize=size;}
    else{tmpSize=Math.random()*size*0.5+0.5*size;}
    stepNo.push(tmpSize);
    stps.push(tmpSize);
    if (checks[0]==0){pointFld.push(points);}
    else{pointFld.push(Math.floor(Math.random()*(points+1)+1));}
    if (checks[1]==0){sine.push(sinusoid);}
    else{sine.push(Math.random()*sinusoid);}
    if (checks[2]==0){fade=dissipate;}
    else{fade=Math.random()*dissipate*0.85+0.15;}
    fireCols.push(Math.floor(Math.random()*155+100),Math.floor(Math.random()*155+100),Math.floor(Math.random()*155+100));
    if (expanded==1){
      collapse();
      setTimeout(hide,500);
    }
  }
}

function paint(){
  var ctx=document.getElementById("canvas").getContext("2d");
  ctx.fillStyle="rgba(0,0,0,"+fade+")";
  ctx.fillRect(0,0,window.innerWidth,window.innerHeight);
  /*for (i=0;i<firePos.length/2;i++){
    ctx.fillStyle="rgb("+fireCols[i*3]+","+fireCols[i*3+1]+","+fireCols[i*3+2]+")";
    ctx.fillRect(firePos[i*2]-5,firePos[i*2+1]-5,10,10);
  }*/
  for (i=0;i<xPos.length;i++){
    var rot=i%(360/points)*Math.PI/18;
    if (stps[i]>0){
      ctx.fillStyle="rgb("+fireCols[i*3]+","+fireCols[i*3+1]+","+fireCols[i*3+2]+")";
      for (n=0;n<pointFld[i];n++){
        ctx.beginPath();
        ctx.arc(xPos[i]+Math.cos(n*2*Math.PI/pointFld[i]+rot+sine[i]*Math.sin(Math.pow((stepNo[i]-stps[i])+1.45,3)/100)*(-1/stepNo[i]*(stepNo[i]-stps[i])+1))*(stepNo[i]-stps[i])*5,yPos[i]+Math.sin(n*2*Math.PI/pointFld[i]+rot+sine[i]*Math.sin(Math.pow((stepNo[i]-stps[i])+1.45,3)/100)*(-1/stepNo[i]*(stepNo[i]-stps[i])+1))*(stepNo[i]-stps[i])*5,stps[i],0,2*Math.PI);
        ctx.fill();
      }
      stps[i]--;
    }
  }
}

setInterval(paint,20);