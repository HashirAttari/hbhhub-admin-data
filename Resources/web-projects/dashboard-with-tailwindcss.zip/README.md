# Dashboard with tailwindcss

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/JjYjZjw](https://codepen.io/joshonweb/pen/JjYjZjw).

