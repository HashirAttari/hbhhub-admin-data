/*jshint esnext: true*/

function getButtons(){
  var numbers = []; 
  var arr = [];
  var clicks = 0;
  var first;
  var second;
  var ans = 0;
  for(let i = 0; i < 10; i++){
    var button = $("#"+i).html();
    numbers.push(button);
  $("#"+numbers[i]).on('click', function(e){
    if(clicks === 0){
     $("#display").html(numbers[i]);
      console.log(numbers[i]);
      arr.push(numbers[i]);
      first = arr[0];
      ++clicks; 
    }else if(clicks == 1){
      $("#display").html(numbers[i]);
      console.log(numbers[i]);
      arr.push(numbers[i]);
      second = arr[1];  
      $("#equal").on('click', function(){
        add(first, second);
        console.log(arr[0]+" "+arr[1]+" "+clicks);
      });
      clicks = 0;
    } 
  });
  }
  function add(num1, num2){
    ans = parseInt(num1) + parseInt(num2);
    $("#display").html(ans);
    arr = [];
  }

}
getButtons();