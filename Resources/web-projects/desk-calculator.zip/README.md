# Desk Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/WillThornton/pen/ybNJNX](https://codepen.io/WillThornton/pen/ybNJNX).

I found an old solar powered calculator at work and I thought it would be cool to recreate it to practice my CSS. The number buttons and equal button work and it only sums two numbers.