# Toggle Liquid (III) - WIP

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/dyrMGxO](https://codepen.io/alvaromontoro/pen/dyrMGxO).

