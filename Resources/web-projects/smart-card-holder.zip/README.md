# Smart Card Holder

A Pen created on CodePen.io. Original URL: [https://codepen.io/visnuravichandran/pen/wvGvpwX](https://codepen.io/visnuravichandran/pen/wvGvpwX).

Smart Card Holder 🗃️

Animation is implemented using GSAP !

---------  Design Inspired from Alexander Plyuto  ----------https://dribbble.com/shots/6725201-Smart-Cardholder
-----------------------------------------------------------------------