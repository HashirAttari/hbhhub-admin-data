// Pute CSS animation
// Based on https://dribbble.com/shots/3841895-Conundrum