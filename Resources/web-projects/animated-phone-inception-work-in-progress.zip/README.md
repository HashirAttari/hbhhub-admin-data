# Animated phone inception || Work in progress

A Pen created on CodePen.io. Original URL: [https://codepen.io/Wujek_Greg/pen/jxxMGJ](https://codepen.io/Wujek_Greg/pen/jxxMGJ).

