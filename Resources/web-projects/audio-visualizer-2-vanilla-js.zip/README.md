# Audio Visualizer 2 (vanilla JS)

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/XWNOaee](https://codepen.io/franksLaboratory/pen/XWNOaee).

