# ice cream stick

A Pen created on CodePen.io. Original URL: [https://codepen.io/Wujek_Greg/pen/YVBwdB](https://codepen.io/Wujek_Greg/pen/YVBwdB).

