// https://codepen.io/pascaloliv/pen/LVZaeE
var Nodes = [];

var mouse = {
  currentInput: null
}

var canvas = document.getElementById('canvas');
var context = document.getElementById('context');
context.ns = "http://www.w3.org/2000/svg";

function reorderByZIndex(array)
{
  return array.sort(function(a,b)
  {
      return a.nodeDOM.style.zIndex > b.nodeDOM.style.zIndex;
  })
}

function calculatePath(start, end)
{
  return `M ${start.x} ${start.y} L ${end.x} ${end.y}`;
}

function Node(icon)
{
  var name = icon;
  var pos = { x: 0, y: 0 };
  var ppos = { x: 0, y: 0 };
  var nodeDOM = document.createElement('div');
  
  this.nodeDOM = nodeDOM;
  this.nodeDOM.classList.add('node');
  this.nodeDOM.classList.add('fa');
  this.nodeDOM.classList.add(`fa-${icon}`);
  this.nodeDOM.style.zIndex = Nodes.length;
  this.nodeDOM.onmousedown = drag; 
  
  function drag(event)
  {
    nodeDOM.style.zIndex = Nodes.length + 10;
    ppos = { x: event.clientX, y: event.clientY };
    canvas.onmousemove = move;
    canvas.onmouseup = undrag;
  }
  function move(event)
  {
    // https://codepen.io/shubham-pol/pen/vomvYR?editors=0010
    pos.x = ppos.x - event.clientX;
    pos.y = ppos.y - event.clientY;
    ppos = { x: event.clientX, y: event.clientY };
    nodeDOM.style.left = (nodeDOM.offsetLeft - pos.x) + "px";
    nodeDOM.style.top = (nodeDOM.offsetTop - pos.y) + "px";
  }
  function undrag(event)
  { 
    canvas.onmouseup = null;
    canvas.onmousemove = null;
    
    nodeDOM.style.zIndex = 9;
    Nodes = reorderByZIndex(Nodes);
    for(var i = 0; i < Nodes.length; i++)
    { Nodes[i].nodeDOM.style.zIndex = i + 10; }
  }
}

Node.prototype.appendOutput = function()
{
  var output = new Output();
  this.nodeDOM.appendChild(output.outputDOM);
}

function Output()
{
  var that = this;
  
  this.outputDOM = document.createElement('div');
  this.outputDOM.classList.add('output');
  
  this.outputDOM.onmousedown = createPath;
    
  function createPath(event)
  {
    if(!that.path)
    {
      that.path = document.createElementNS(context.ns, 'path');
      that.path.setAttributeNS(null, 'd', calculatePath(
        {x: 0, y: 0},
        {x: event.pageX, y: event.pageY}
      ));
      context.appendChild(that.path);
      // TODO: Extend path on move
    }
    event.stopPropagation();
  }
}

Node.prototype.show = function()
{
  canvas.appendChild(this.nodeDOM);
}

Nodes.push(new Node("twitter"));
Nodes.push(new Node("dribbble"));
Nodes.push(new Node("facebook"));

for(var node of Nodes)
{
  node.appendOutput();
  node.show();
}