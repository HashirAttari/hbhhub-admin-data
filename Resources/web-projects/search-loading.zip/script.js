$('.search').on('click touch', function(e) {

    var self = $(this);

    self.addClass('loading');
    setTimeout(function() {
        self.removeClass('loading');
    }, 3000)

});