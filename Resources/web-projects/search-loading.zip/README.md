# Search loading

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/vQNbjZ](https://codepen.io/aaroniker/pen/vQNbjZ).

From https://dribbble.com/shots/2832877-Search-Progress-Animation