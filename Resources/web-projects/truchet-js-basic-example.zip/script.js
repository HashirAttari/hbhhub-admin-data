// This pen was developed using Truchet.js https://ykadosh.github.io/truchet.js/
const TILE_SIZE = 40;
const target = document.createElementNS("http://www.w3.org/2000/svg", 'svg');
const truchet = new Truchet(target, TILE_SIZE, TILE_SIZE);
const render = (row, col, prevProps) => ({
  id: 'arc',
  x: col * TILE_SIZE,
  y: row * TILE_SIZE,
  rotate: prevProps ? prevProps.rotate : [0, 90][Math.floor(Math.random() * 2)] });


class Tile {

  createNode(n, v = {}) {
    n = document.createElementNS("http://www.w3.org/2000/svg", n);
    Object.keys(v).forEach(p => {
      n.setAttributeNS(null, p, v[p]);
    });
    return n;
  }

  mount(target) {
    this.container = this.createNode('g');
    this.container.appendChild(this.createNode('path', { d: `M 0,${TILE_SIZE / 2} A ${TILE_SIZE / 2},${TILE_SIZE / 2} 0 0 0 ${TILE_SIZE / 2} 0` }));
    this.container.appendChild(this.createNode('path', { d: `M ${TILE_SIZE / 2},${TILE_SIZE} A ${TILE_SIZE / 2},${TILE_SIZE / 2} 0 0 1 ${TILE_SIZE} ${TILE_SIZE / 2}` }));
    this.container.style.setProperty('transform-origin', `${TILE_SIZE / 2}px ${TILE_SIZE / 2}px`);
    target.appendChild(this.container);

  }

  render({ x, y, rotate }) {
    this.container.style.setProperty('transform', `translate(${x}px, ${y}px) rotate(${rotate}deg)`);
  }}


document.body.appendChild(target);

truchet.addTile('arc', Tile);
truchet.render(render);

// Update the truchet instance when the window is resized to add/remove tiles
// when applicable. Since our render function uses the previous props when they are
// available, existing tiles will not be rerendered.
window.addEventListener('resize', () => {
  truchet.render(render);
});

// The refresh button
const button = document.createElement('DIV');
button.classList.add('button');
button.addEventListener('click', () => {
  truchet.render((row, col, prevProps) => ({
    ...prevProps,
    rotate: [0, 90][Math.floor(Math.random() * 2)] }));

});
document.body.appendChild(button);