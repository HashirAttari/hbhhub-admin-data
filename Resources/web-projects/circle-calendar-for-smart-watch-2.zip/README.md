# Circle Calendar for Smart Watch 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/dyZeLVy](https://codepen.io/kitjenson/pen/dyZeLVy).

