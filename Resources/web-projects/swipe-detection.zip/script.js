var currentX;
var initialX;
var xOffset = 0;

var active = false;
var click = false;
var swiped = false;

var direction = 0;
var message = document.querySelector('.message');

document.addEventListener("touchstart", dragStart, false);
document.addEventListener("touchend", dragEnd, false);
document.addEventListener("touchmove", drag, false);

document.addEventListener("mousedown", dragStart, false);
document.addEventListener("mouseup", dragEnd, false);
document.addEventListener("mousemove", drag, false);

function dragStart(e) {
  if (e.type === "touchstart") {
    initialX = e.touches[0].clientX - xOffset;
  } else {
    initialX = e.clientX - xOffset;
  }

  active = true;
  click = true;
  swiped = false;
}

function dragEnd() {
  initialX = currentX;

  if (click == true) {
    message.innerHTML = 'Clicked';
  } else {
    message.innerHTML = 'Idle';
  }
  
  xOffset = 0;
  active = false;
}

function drag(e) {
  if (active) {
    e.preventDefault();

    if (e.type === "touchmove") {
      currentX = e.touches[0].clientX - initialX;
    } else {
      currentX = e.clientX - initialX;
    }

    xOffset = currentX;

    if (xOffset < 0) {
      direction = -1;
    }
    else {
      direction = 1;
    }
    
    if (Math.abs(xOffset) < 30) {
      direction = 0;
    }
    
    if (direction == 1 && swiped == false) {
      message.innerHTML = 'Swiped right';
      swiped = true;
    } else if (direction == -1 && swiped == false) {
      message.innerHTML = 'Swiped left';
      swiped = true;
    }
    
    if (swiped == false) {
      message.innerHTML = xOffset;
    }
    
    click = false;
  }
}