const zipper = document.getElementById("zip-zipper");
const handle = document.getElementById("zipper-handle");
const zipTrack = document.getElementById("zip-track");
const main = document.getElementsByTagName('main')[0];
const touch = "ontouchstart" in window ||
(window.DocumentTouch && document instanceof DocumentTouch);
let offsetX = 0;
let offsetY = 0;
let timer;
const mouse = {
	x: 0, y: 0, down: false, a: { z: 0, x: 0 }
};
const cache = {
	viewport: {},
	rects: [],
	node: {},
	top: 0,
	teeth: {
		l: [],
		r: []
	}
};


// init
window.addEventListener("load", init);

function init() {
	// update the cache and check scroll position
	recache();
	
	// hide the scrollbar
	const barWidth = getScrollBarWidth();
	main.style.paddingRight = `${barWidth}px`;
	
	// allow dragging
	handle.addEventListener(touch ? "touchstart" : "mousedown", down);
	
	// throttle the scroll callback for performance
	main.addEventListener("scroll", touch ? scrollCheck : throttle(scrollCheck), 10);
	
	// debounce the resize callback for performance
	window.addEventListener("resize", debounce(recache, 50));
};

const move = (e) => {
	let go = false;
	const x = (touch ? e.touches[0].pageX : e.pageX);
	const y = (touch ? e.touches[0].pageY : e.pageY);
	const offset = getScrollOffset();
	const height = cache.document.height - cache.viewport.height;
	const width = cache.viewport.height - cache.node.height;
	const progress = ((y - offsetY) / width) * height;
	
	var ax = 0;
	var az = Math.atan2((mouse.origin.top + (y - mouse.y)) - y, (mouse.origin.left + (mouse.origin.width / 2)) - x) * 180 / Math.PI;
	
	if ( mouse.down ) {
		
		if ( mouse.last > progress ) {
			// ax = 
		} else {
			//
		}
		
		mouse.a.z = Math.min(az + 90, 20);
		handle.style.transform = `rotateZ(${mouse.a.z}deg)`;
		
// 		if ( mouse.last > progress ) {
// 			if ( mouse.a >= 135 ) {
// 				go = true;
// 			}
// 		} else {
// 			go = true;
// 		}
		
// 		if ( go ) {
			main.scrollTop = progress;
// 		}
	}
	
	mouse.last = progress;
}

const up = (e) => {
	
	mouse.down = false;
	
	main.style.scrollBehavior = "";
	zipper.classList.remove("active");
	handle.classList.remove("active");
	handle.style.transform = `rotate(0deg)`;
	// swing(mouse.a);
	
	
	
	if (touch) {
		document.removeEventListener("touchmove", move);
		document.removeEventListener("touchend", up);
		document.removeEventListener("touchcancel", up);
	} else {
		document.removeEventListener("mousemove", move);
		document.removeEventListener("mouseup", up);
	}	
}

function swing(angle) {
	var dAng = 10,
			ddAng = .5,
			dir  = 1;
	setAng(angle)
	function setAng(ang){
			handle.style.transform =  'rotate('+ang+'deg)';
			dir = -dir;
			if (dAng > 1)
					dAng -= ddAng;

			if (Math.abs(ang) > 0)
					timer = setTimeout(setAng, 1000, dir * (Math.abs(ang)-dAng));
	};
}

const down = (e) => {
	recache(true);
	
	mouse.down = true;
	
	clearTimeout(timer);
	
	offsetX = (touch ? e.touches[0].pageX : e.pageX);
	offsetY = (touch ? e.touches[0].pageY : e.pageY) - cache.node.top;
	
	mouse.x = touch ? e.touches[0].pageX : e.pageX;
	mouse.y = touch ? e.touches[0].pageY : e.pageY;
	
	// setting scrollTop/Left with "scroll-behavior: smooth" causes monster jank
	main.style.scrollBehavior = "auto";
	handle.classList.add("active");
	zipper.classList.add("active");
	
	mouse.origin = handle.getBoundingClientRect();
	
	if (touch) {
		document.addEventListener("touchmove", move);
		document.addEventListener("touchend", up);
		document.addEventListener("touchcancel", up);
	} else {
		document.addEventListener("mousemove", move);
		document.addEventListener("mouseup", up);
	}	
	
	e.preventDefault();
}

// update the cache and check scroll position
function recache(mouse) {
	// cache the viewport dimensions
	cache.viewport = {
			width: window.innerWidth,
			height: window.innerHeight
	};
	
	cache.document = {
		height: main.scrollHeight,
		width: main.scrollWidth,
	};
	
	cache.node = zipper.getBoundingClientRect();
	
	if ( !mouse ) {
		renderTeeth();
	}
	
	scrollCheck();
}

function scrollCheck() {
	const offset = getScrollOffset();
	const height = cache.document.height - cache.viewport.height;
	const width = cache.viewport.height - cache.node.height;
	const progress = (offset.y / height) * width;
	
	cache.top = cache.viewport.height - progress;
	cache.progress = progress;
	
	zipper.style.transform = `translate3d(0, ${cache.progress}px,0)`;
	
	positionTeeth();
}

function renderTeeth() {
	const n = 18;
	let y1 = 0;
	let y2 = -9;
	
	const count = Math.round(cache.viewport.height / 18) + 1;
	
	const frag = document.createDocumentFragment();
	
	cache.teeth.l = [];
	cache.teeth.r = [];
	
	for ( let i = 0; i < count; i++ ) {
		const l = document.createElement("div");
		const r = document.createElement("div");
		
		l.classList.add("zip-tooth", "left");
		r.classList.add("zip-tooth", "right");
		l.style.top = `${y1}px`;
		r.style.top = `${y2}px`;
		
		frag.appendChild(l);
		frag.appendChild(r);
		
		cache.teeth.l.push(l);
		cache.teeth.r.push(r);
		
		y1 += n;
		y2 += n;
	}
	
	zipTrack.innerHTML = "";
	zipTrack.appendChild(frag);
}

function positionTeeth() {
	const max = 30;
	
	const count = Math.round(cache.progress / 18) + 2;
	
	for ( let i = 0; i < cache.teeth.l.length; i++ ) {
		let a = 0;
		let inc = (count - i) * 10;
		
		if ( i <= count ) {

			if ( inc > max ) {
				inc = max;
			}

			a = 45 - (45 * (inc / max));
		} else {
			inc = 10;
			a = 0;
		}
		
		cache.teeth.l[i].style.transform = `translate3d(-${inc - 10}px, 0, 0) rotate(${-a}deg)`;
		cache.teeth.l[i].style.transformOrigin = `0 100%`;

		cache.teeth.r[i].style.transform = `translate3d(${inc - 10}px, 0, 0) rotate(${a}deg)`;
		cache.teeth.r[i].style.transformOrigin = `100% 100%`;		
	}
}

// get the scroll offsets
function getScrollOffset() {
	return {
		x: main.scrollLeft,
		y: main.scrollTop
	};
};

// throttler
function throttle(fn, limit, context) {
	let wait;
	return function() {
		context = context || this;
		if (!wait) {
			fn.apply(context, arguments);
			wait = true;
			return setTimeout(function() {
				wait = false;
			}, limit);
		}
	};
};

// debouncer
function debounce(fn, limit, u) {
	let e;
	return function() {
		const i = this;
		const o = arguments;
		const a = u && !e;
		clearTimeout(e),
			(e = setTimeout(function() {
			(e = null), u || fn.apply(i, o);
		}, limit)),
			a && fn.apply(i, o);
	};
}

/**
 * Get native scrollbar width
 * @return {Number} Scrollbar width
 */
function getScrollBarWidth() {
	const db = document.body;
	const div = document.createElement("div");
	let t = 0;
	return div.style.cssText = "width: 100; height: 100; overflow: scroll; position: absolute; top: -9999;", document.body.appendChild(div), t = div.offsetWidth - div.clientWidth, document.body.removeChild(div), t
};