# Zipper Scroll Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/Mobius1/pen/YoORyj](https://codepen.io/Mobius1/pen/YoORyj).

Animated zipper scrollbar.

It would've been easier to just to use two bg images of the opened and closed track and place them above and below the handle. However, I wanted to show the teeth animating.