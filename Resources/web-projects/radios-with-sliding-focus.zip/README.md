# Radios With Sliding Focus

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/GReNrrQ](https://codepen.io/jkantner/pen/GReNrrQ).

CSS `:has()` made this radio button effect possible without JS!