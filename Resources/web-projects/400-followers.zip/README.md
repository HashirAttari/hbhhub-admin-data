# 400 Followers 🎉

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/dyRvMWN](https://codepen.io/ykadosh/pen/dyRvMWN).

In this pen i'm layring 6 spans with different gradients, masks and filters to create this blue chrome text effect.