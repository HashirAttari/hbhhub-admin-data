# Animating Charts Grid

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/MdYmWx](https://codepen.io/joshonweb/pen/MdYmWx).

Using the Flip technique and grid used in the @keyframers video https://www.youtube.com/watch?v=sAIKjqYn6Xg&t=4085s
added my own charts and svg s I am using from something else.