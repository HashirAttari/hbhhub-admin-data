Vue.component("my-tree", {
  template: "#tree-template",
  props: {
    model: {
      type: [Array, Object],
      default: null
    }
  },
  computed: {
    isFolder() {
      return this.model.list && this.model.list.length
    }
  },
  data() {
    return {
      open: false
    };
  },
  methods: {
    toggle() {
      if (this.isFolder) {
        this.open = !this.open;
      }
    }
  }
});

const Data = {
  name: "Дерево ролей",
  startItem: true,
  groupid: 0,
  list: [
    { groupid: 1, name: "Гости" },
    { groupid: 2, name: "Админы", list: [
      { groupid: 3, name: "Суперадмин" },
      { groupid: 4, name: "Мегаадмин" },
      { groupid: 5, name: "Богадмин" }
    ]},
    { groupid: 6, name: "Кассир" },
    {
      groupid: 100,
      name: "Сотрудники",
      list: [
        { groupid: 101, name: "Куратор" },
        { groupid: 102, name: "Управляющий" },
        { groupid: 103, name: "Администратор" },
        { groupid: 104, name: "Бармен" },
        { groupid: 105, name: "Официантка" },
        { groupid: 106, name: "Хостес" },
        { groupid: 107, name: "Оператор" },
        { groupid: 108, name: "Уборщик" }
      ]
    },
    { groupid: 1000, name: "Партнеры" }
  ]
};

const vm = new Vue({
  el: "#app",
  data: {
    tree: Data
  },
  computed: {}
});