# CSS Gradient Border Demo

A Pen created on CodePen.io. Original URL: [https://codepen.io/jlengstorf/pen/WNPZrRv](https://codepen.io/jlengstorf/pen/WNPZrRv).

