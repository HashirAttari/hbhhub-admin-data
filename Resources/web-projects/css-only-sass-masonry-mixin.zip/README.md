# CSS Only Sass Masonry Mixin

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/ojrrxa](https://codepen.io/mselmany/pen/ojrrxa).

Supports gap indication in Pixels, Rems and PERCENTAGES.
Percent gaps are not supported by css columns by default.
The mixin will simulate that behaviour for you.

Forked from [Michael Fischer](http://codepen.io/doptrois/)'s Pen [CSS Only Sass Masonry Mixin](http://codepen.io/doptrois/pen/JoyzKw/).