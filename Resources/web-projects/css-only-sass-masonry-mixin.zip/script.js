// MODERNIZR ENABLED

// modernizr is used to check browser capability against css columns.
// If it is'nt supported, the browser will show up a fallback with "text-align: justify" and "display: inline-block;"