# Terrazzo elements

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/LYMOxBo](https://codepen.io/nicolasjesenberger/pen/LYMOxBo).

