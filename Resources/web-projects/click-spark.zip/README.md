# Click Spark

A Pen created on CodePen.io. Original URL: [https://codepen.io/hexagoncircle/pen/bGZdWyw](https://codepen.io/hexagoncircle/pen/bGZdWyw).

Add a lil' spark to your click. <a href="https://ryanmulligan.dev/blog/click-spark/">Read a blog post</a> about it.