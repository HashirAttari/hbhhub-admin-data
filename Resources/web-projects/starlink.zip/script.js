let speed = 1;
let totalStars = 200;
let nearness = 70



class Star {
	constructor() {
		this.x = this.resetCordinate(width)
		this.y = this.resetCordinate(height)
		this.size = random(5, 10);
		this.show();
		this.z = random(width);
	}
	
	resetCordinate(max) {
		return random(-max / 3, max / 3);
	}

	show() {
		this.zx = map(this.x / this.z, 0, 1, 0, width);
		this.zy = map(this.y / this.z, 0, 1, 0, height);
		circle(this.zx, this.zy, map(this.z, 0, width, 10, 0));
	}

	move() {
		this.z = this.z - speed;
		this.show();
		if (this.z < 1) {
			this.z = width;
			this.x = random(-width / 3, width / 3);
		this.y = random(-height / 3, height / 3);
			this.col = random(100);
		}
	}
}

// -------------------------------------


let stars = [];

function setup() {
	createCanvas(innerWidth, innerHeight);
	stroke(100)
	fill(255)

	for (let i = 0; i < totalStars; i++) {
		stars.push(new Star());
	}
}

function draw() {
	background(0);
	translate(width / 2, height / 2);
	stars.forEach(s => s.move());
	speed = map(mouseX, 0, width, 0.5, 20);
	for(let i=0; i<stars.length; i++) {
	 	for(let j=0; j<stars.length; j++) {
	 	if (dist(stars[i].zx, stars[i].zy, stars[j].zx, stars[j].zy) < nearness)
	 		line(stars[i].zx, stars[i].zy, stars[j].zx, stars[j].zy)
	 }
	}

}

function windowResized() {
  resizeCanvas(innerWidth, innerHeight);
}