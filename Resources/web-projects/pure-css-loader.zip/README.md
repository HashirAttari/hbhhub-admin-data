# Pure CSS Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/myacode/pen/gObdXJz](https://codepen.io/myacode/pen/gObdXJz).

