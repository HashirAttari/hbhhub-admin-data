# Rolling ball on a colorful Mobius strip (#CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/QWPppKG](https://codepen.io/amit_sheen/pen/QWPppKG).

