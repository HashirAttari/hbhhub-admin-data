let select = s => document.querySelector(s),
  selectAll = s =>  document.querySelectorAll(s),
		mainSVG = select('#mainSVG'),
		mid = gsap.utils.toArray('#mid *').reverse()

gsap.set('svg', {
	visibility: 'visible'
})

let fatTl = gsap.timeline();
fatTl.fromTo('#fat *', {
	drawSVG: '0% 20%'
}, {
		drawSVG: '40% 69%',
	stagger: {
		each: 0.05,
		repeat: -1,
		yoyo: true
	},
	duration: 0.75,
	ease: 'sine.inOut'
})

let midTl = gsap.timeline();
midTl.fromTo(mid, {
	drawSVG: '0% 20%'
}, {
		drawSVG: '56% 86%',
	stagger: {
		each: 0.08,
		repeat: -1,
		yoyo: true
	},
	duration: 0.81,
	ease: 'sine.inOut'
})

let thinTl = gsap.timeline();
thinTl.fromTo('#thin *', {
	drawSVG: '20% 51%'
}, {
		drawSVG: '40% 80%',
	stagger: {
		each: 0.092,
		repeat: -1,
		yoyo: true
	},
	duration: 1.4,
	ease: 'sine.inOut'
})

let bgTl = gsap.timeline();
/* bgTl.fromTo('#bg *', {
	drawSVG: '20% 81%'
}, {
		drawSVG: '50% 99%',
	stagger: {
		each: 0.0925,
		repeat: -1,
		yoyo: true
	},
	duration: 0.51,
	ease: 'sine.inOut'
}) */

let mainTl = gsap.timeline();
mainTl.add([fatTl, midTl, thinTl, bgTl], 0).seek(100)
//ScrubGSAPTimeline(mainTl)