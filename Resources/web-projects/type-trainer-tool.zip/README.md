# Type Trainer Tool

A Pen created on CodePen.io. Original URL: [https://codepen.io/worenga/pen/nMVKOP](https://codepen.io/worenga/pen/nMVKOP).

just wanted to learn english keyboard layout so i wrote this for myself