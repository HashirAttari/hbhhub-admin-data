$("input:checkbox").on('click', function() {
   $(this).parents(".main-content").toggleClass("checked");
 });
 $(document).ready(function() {
   var audio = document.getElementById("myAudio");
   $('input').change(function() {
     if (!$(this).is(':checked')) {
       audio.play();
     } else {
       audio.pause();
     }
   });
 });