# Toggle Mic On / Mic Off

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/YzNRgpo](https://codepen.io/yudizsolutions/pen/YzNRgpo).

Click the toggle microphone button to make your audio playing in the background mute and unmute. 

Codepen Challenge (on/off microinteraction.):
We have build a toggle  audio button.

We have use free audio from https://file-examples.com.

Made by Kinnari Vasavada and Rajnee from Yudiz