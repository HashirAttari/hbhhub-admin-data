# Vertical accordion menu using jQuery and CSS3

A Pen created on CodePen.io. Original URL: [https://codepen.io/arkev/pen/ANRzrV](https://codepen.io/arkev/pen/ANRzrV).

A sleek vertical accordion menu for your next website/app.

The headings use Font Awesome icon font. CSS3 gradients, transitions, and shadows have been used in the demo along with minimalistic use of jQuery for sliding the link lists.

Degrades gracefully upto IE8. Works in all major browsers.