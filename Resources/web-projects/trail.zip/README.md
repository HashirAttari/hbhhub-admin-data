# Trail

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/DKKxeo](https://codepen.io/hakimel/pen/DKKxeo).

A set of rotating particles that leave a silky smooth trail as you move your mouse. One of my first canvas experiments :D