# Hover to Reveal Password

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/RwOedLa](https://codepen.io/jh3y/pen/RwOedLa).

