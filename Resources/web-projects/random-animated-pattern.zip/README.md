# Random animated pattern

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/pjGZWY](https://codepen.io/giana/pen/pjGZWY).

Randomize all the things. Inspired by @mknadler's SassConf talk.