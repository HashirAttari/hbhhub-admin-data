# Fan (CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/yLozzvZ](https://codepen.io/amit_sheen/pen/yLozzvZ).

