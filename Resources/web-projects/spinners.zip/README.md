# Spinners

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/poyWvJw](https://codepen.io/ainalem/pen/poyWvJw).

A spinner or a sausage? Getting creative with the old spinner