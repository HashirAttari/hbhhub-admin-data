# Toggle Toothed (II)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/XWQKWZo](https://codepen.io/alvaromontoro/pen/XWQKWZo).

inspired by Josetxu's https://codepen.io/josetxu/pen/NWEPmGz