import SimplexNoise from "https://cdn.skypack.dev/simplex-noise@3.0.0";

const simplex = new SimplexNoise();
let time = 0;
const panels = [];

init();
function init() {
  [...document.querySelectorAll('.panel')].forEach((div, ix) => {
    panels[ix] = {
      div: div,
      x: ((ix % 7) - 3) * 0.1,
      y: ((Math.floor(ix / 7) % 7) - 3) * 0.1,
      z: ((Math.floor(ix / 49) % 7) - 3) * 0.1
    }    
  }); 
  render();
}

function render() {

  for (let i = 0 ; i < 343 ; i++) {
    const panel = panels[i];
    const noise = simplex.noise4D(panel.x, panel.y, panel.z, time);
    panel.div.style.setProperty('--ts', (noise + 1) / 2);
    time += 0.00005;
  }

  requestAnimationFrame(render);
}