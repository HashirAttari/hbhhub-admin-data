# muson.css

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/GRWoqba](https://codepen.io/benhatsor/pen/GRWoqba).

Muson toy synth drawn entirely in HTML & CSS.

 Tutorials: https://fossheim.io
 Patreon: https://patreon.com/fossheim
 Buy Me A Coffee: https://buymeacoffee.com/fossheim
 
 Inspired by the Muson toy synth.