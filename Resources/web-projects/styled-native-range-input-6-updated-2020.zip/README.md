# Styled native range input #6 (updated 2020)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/YPEqVY](https://codepen.io/thebabydino/pen/YPEqVY).

**February 2020 description**

Since I now know how to code a multi thumb slider ([article](https://css-tricks.com/multi-thumb-sliders-particular-two-thumb-case/)), I added that one too. Cleaned the code a bit to make it more logical, modern and maintainable.

---

If the work I've been putting out since early 2012 has helped you in any way or you just like it and you wish me to be able to continue putting out stuff, please consider one of the following:

* being a cool cat 😼🎩 and becoming a patron on Patreon

[![become a patron button](https://assets.codepen.io/2017/btn_patreon.png)](https://www.patreon.com/anatudor)

* making a one time donation via Ko-fi

[![ko-fi](https://assets.codepen.io/2017/btn_kofi.svg)](https://ko-fi.com/anatudor)

* getting me something off my Amazon WishList 

[🎁 🇺🇸](https://www.amazon.com/gp/registry/wishlist/2Y3C4722GXH0I/) / [🎁 🇬🇧](https://www.amazon.co.uk/gp/registry/wishlist/2I25W7U0KADSR/)

* or at least sharing this to show the rest of the world what can be done with CSS these days

Thank you!

---

**Original description**

Goal: create a nicely styled crossbrowser 1 element slider. IE needs  no JS. Firefox and Chrome/ Opera need a little JS help when it comes to styling the slider track. Inspiration:

![image](http://i.imgur.com/3rADjrV.jpg) 