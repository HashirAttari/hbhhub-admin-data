/*
Inspired by a multiple Pendulum video from youtube.

Here's another single pendulum animation

https://codepen.io/kh-mamun/pen/PWgzJe
*/