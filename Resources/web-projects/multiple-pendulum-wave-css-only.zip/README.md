# Multiple pendulum wave (CSS only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/kh-mamun/pen/xWmrJN](https://codepen.io/kh-mamun/pen/xWmrJN).

Multiple pendulum wave might not be used in any real life project but I just got an idea from a youtube video and ended up creating this animation.