# Switch animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/oaQdQZ](https://codepen.io/aaroniker/pen/oaQdQZ).

From https://dribbble.com/shots/5429846-Switcher-XLIV