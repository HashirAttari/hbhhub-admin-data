# Daily UI #05 | Login with rainbow-border 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/zqjXPQ](https://codepen.io/havardob/pen/zqjXPQ).

Simple login with rainbow-coloured top