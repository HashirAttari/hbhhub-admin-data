function generateRotatedEllipse() {
  /*
𝑥(𝛼)=𝑅𝑥cos(𝛼)cos(𝜃)−𝑅𝑦sin(𝛼)sin(𝜃)+𝐶𝑥
𝑦(𝛼)=𝑅𝑥cos(𝛼)sin(𝜃)+𝑅𝑦sin(𝛼)cos(𝜃)+𝐶𝑦
  
where
  𝐶𝑥 is the 𝑥-coordinate of the center
  𝐶𝑦 is the 𝑦-coordinate of the center
  𝑅𝑥 is the major radius
  𝑅𝑦 is the minor radius
  𝛼 is the variable angle, which ranges from 0 to 360deg
  𝜃 is the ellipse rotation angle.

https://math.stackexchange.com/a/2647450
*/
  const points = [];

  for (let i = 0; i < 360; i = i + 10) {
    points.push(`calc(var(--center-x) + (cos(${i}deg) * cos(var(--rotation)) * var(--radius-x)) - (sin(${i}deg) * sin(var(--rotation)) * var(--radius-y)))
    calc(var(--center-y) + (cos(${i}deg) * sin(var(--rotation)) * var(--radius-x)) + (sin(${i}deg) * cos(var(--rotation)) * var(--radius-y)))`);
  }

  console.log(points.join(","));
}

function generateMoon() {
  const points = [];

  for (let i = 60; i <= 300; i = i + 10) {
    points.push(`calc(var(--center) + (cos(${i}deg) * var(--outer-x)))
    calc(var(--center) + (sin(${i}deg) * var(--outer-y)))`);
  }
  for (let i = 300; i >= 60; i = i - 10) {
    points.push(`calc(var(--center-inner-x) + (cos(${i}deg) * var(--inner-x)))
    calc(var(--center) + (sin(${i}deg) * var(--inner-y)))`);
  }

  document
    .querySelector(".moon")
    .style.setProperty("--clipped", `polygon(${points.join(",")})`);

  console.log(`polygon(${points.join(",")})`);
}

generateMoon();