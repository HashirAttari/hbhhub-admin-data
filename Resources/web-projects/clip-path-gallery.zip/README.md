# Clip Path Gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/danwilson/pen/eYLQPbz](https://codepen.io/danwilson/pen/eYLQPbz).

