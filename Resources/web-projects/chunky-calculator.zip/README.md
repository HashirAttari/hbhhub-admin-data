# Chunky Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/Thibaut/pen/nZQZzE](https://codepen.io/Thibaut/pen/nZQZzE).

By [CSSFlow](http://www.cssflow.com): free UI elements and widgets coded with HTML5, CSS3, and Sass.  

View the original article and download the Sass source at:  
[cssflow.com/snippets/chunky-calculator](http://www.cssflow.com/snippets/chunky-calculator)

Original PSD by [Zack Smith](http://www.premiumpixels.com/freebies/chunky-calculator-psd/).

Tested in Firefox 4, Safari 4, Chrome 15, Opera 10, IE 6 (and newer).