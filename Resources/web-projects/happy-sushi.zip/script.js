/*
		Designed by: Miguel E.
		Original image: https://dribbble.com/shots/5819150-
*/