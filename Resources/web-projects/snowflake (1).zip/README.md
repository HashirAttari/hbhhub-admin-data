# Snowflake

A Pen created on CodePen.io. Original URL: [https://codepen.io/waldo/pen/wyZWzm](https://codepen.io/waldo/pen/wyZWzm).

The last snowflake dance, creative  processing perfect loop with pure css