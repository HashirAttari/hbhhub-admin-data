# :)

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/qBNgZEO](https://codepen.io/yuanchuan/pen/qBNgZEO).

https://twitter.com/beesandbombs/status/1327239927080345600