function g(a, n) {
  var divs = "";
  for (var s = 0; s < 50; s++) {
    divs += '<div class="div ball"  id="' + getRandom() + '"></div>';
  }
  document.getElementById(a).innerHTML += divs;
}
g('h1');g('h2');g('h3');

function f(x, n, a) {
  var t = 0;
  setInterval(function() {
    if (t < 50) {
      x.style.bottom = (46 * t * n - t * t) + 20 + 'px';
      x.style.height = 10 - t / 4.6 + 'px';
      x.style.width = 10 - t / 4.6 + 'px';
      if (t > 15) {
        x.style.left = (a * t + 150) + 'px';
        x.style.bottom = (46 * t * n * n - t * t) + 20 + 'px';
      }
      t += 1.3
    }
  }, 50)
}

function Launch() {
  var i;
  for (i = 0; i < 150; i++) {
    var x = document.getElementsByClassName('div')[i];
    var a = parseInt(x.id);
    x.style.left = '150px';
    f(x, 1 + ((Math.random() * 5) + 1) / 100, a)
  }
}

function LaunchC() {
  var i;
  var v = 0;
  var s2 = setInterval(function() {
    for (i = 0; i < 50; i++) {
      var x = document.getElementsByClassName('div')[v];
      var a = parseInt(x.id);
      x.style.left = '150px';
      f(x, 1 + ((Math.random() * 5) + 1) / 100, a);
      v++;
    }
    document.getElementById('r').value = parseInt(document.getElementById('r').value) + 40;
    c(document.getElementById('r').value);
    if (v == 150) {
      clearInterval(s2);
    }
  }, 500);
}

function c(a) {
  var i;
  for (i = 0; i < 150; i++) {
    var x = document.getElementsByClassName('div')[i];
    x.style.background = getRandomColor(a)
  }
  document.getElementById('r').style.boxShadow = '0 0 20px 1.5px hsl(' + document.getElementById('r').value + ', 100%,50%)';
}
function getRandom() {
  return Math.random() * 10 - 5
}
function getRandomColor(n) {
  var hue = Math.random() * 60 + parseInt(n - 30);
  return 'hsl(' + hue + ',100%,50%)'
}

c(document.getElementById('r').value);