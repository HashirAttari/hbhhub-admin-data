# Pseudo 3D text

A Pen created on CodePen.

Original URL: [https://codepen.io/funxer/pen/KBmRoZ](https://codepen.io/funxer/pen/KBmRoZ).

I'm using pseudo 3D techniques to form text out of particles. Horizontal movement is automatic, but you can change the vertical angle by moving the mouse.