# CSS Image Shimmer

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/gOwvdee](https://codepen.io/benhatsor/pen/gOwvdee).

