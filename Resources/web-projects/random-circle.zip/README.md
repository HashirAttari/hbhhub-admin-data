# Random circle

A Pen created on CodePen.io. Original URL: [https://codepen.io/Raphael/pen/DyRVzo](https://codepen.io/Raphael/pen/DyRVzo).

Some fun with random()