# Checky

A Pen created on CodePen.io. Original URL: [https://codepen.io/ekrembk/pen/eYYOry](https://codepen.io/ekrembk/pen/eYYOry).

Checkbox, toggle, switch. Whatever you say.

Inspiration: http://codepen.io/andreasstorm/pen/peCbd