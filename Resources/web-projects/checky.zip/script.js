$('.checky').click(function() {
  $(this).toggleClass('selected'); 
});