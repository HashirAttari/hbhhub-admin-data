# Skin Colors Scheme (Gigantic)

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/eLdwZq](https://codepen.io/markmead/pen/eLdwZq).

Inspired by Gigantic's work on Dribbble