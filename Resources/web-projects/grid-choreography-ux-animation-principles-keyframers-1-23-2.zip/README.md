# Grid Choreography | ✅ UX Animation Principles | @keyframers 1.23.2

A Pen created on CodePen.io. Original URL: [https://codepen.io/team/keyframers/pen/bmVejm](https://codepen.io/team/keyframers/pen/bmVejm).

Stephen Shaw, with some help from a disembodied David Khourshid, showcase more UX animation principles. Using Taras' wonderful guide as a reference, we turn the GIFs into code so you can see some practical implementations of these concepts. In this episode, we talk through the importance of acceleration/deceleration easing and choreography in animation across one and two axes.

* ⏰ Streamed live on October 1, 2018 at https://twitch.tv/keyframers
* 💡Inspiration: https://uxdesign.cc/the-ultimate-guide-to-proper-use-of-animation-in-ux-10bd98614fa9
* 📺 Video: https://youtu.be/QcJwKqYhxPc
* 💻 Acceleration/Deceleration Demo: https://cdpn.io/pen/ZqbWao/
* 💻 Choreography Demo: https://cdpn.io/pen/yRYJPr/
* 💻 Grid Choreography Demo: https://cdpn.io/pen/bmVejm/


Skip around:
1:00 Animation overview
6:00 Start coding
1:00:00 Keyflections

Additional Resources:

* Splitting.js https://splitting.js.org

Like what we're doing? There are many ways you can support @keyframers so we can keep live coding awesome animations!

* Like & subscribe on YouTube at https://youtube.com/keyframers
* Follow & tweet us at https://twitter.com/keyframers.
* Join the live streams & subscribe on Twitch http://twitch.tv/keyframers 
* Support us on Patreon at https://patreon.com/keyframers 

Topics covered:

* Animation
* Staggering
* Choreography
* Easing
* Grid layout