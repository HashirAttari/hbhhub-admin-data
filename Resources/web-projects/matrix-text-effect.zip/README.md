# Matrix Text Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/syropian/pen/nJjZaE](https://codepen.io/syropian/pen/nJjZaE).

A simulation of the Matrix "Code Rain" effect.