var snowmax = 270;
var snowcolor = ["rgba(255,255,255,0.6)"];
var snowletter = ["|"];
var sinkspeed = 10;
var snowmaxsize = 10;
var snowminsize = 8;
var snow = [];
var marginbottom = window.innerHeight;
var marginright = window.innerWidth;
var x_mv = [];
var crds = [];
var lftrght = [];

function randommaker(range) {
  rand = Math.floor(range * Math.random());
  return rand;
}
window.onload = function() {
  var snowsizerange = snowmaxsize - snowminsize;
  for (var i = 0; i <= snowmax; i++) {
    crds[i] = 0;
    lftrght[i] = Math.random() * 15;
    x_mv[i] = 0.03 + Math.random() / 10;
    var flake = document.createElement('span');
    flake.size = randommaker(snowsizerange) + snowminsize;
    flake.sink = sinkspeed;
    flake.style.position = 'absolute';
    flake.style.fontSize = flake.size + 'px';
    flake.style.color = snowcolor[randommaker(snowcolor.length)];
    flake.innerHTML = snowletter[randommaker(snowletter.length)];
    flake.posx = randommaker(marginright - flake.size);
    flake.posy = randommaker(marginbottom - 2 * flake.size);
    flake.style.left = flake.posx + 'px';
    flake.style.top = flake.posy + 'px';
    flake.id = 's' + i;
    flake.className = 'flake';
    snow[i] = flake;
    document.getElementsByClassName('snow')[0].appendChild(flake);
  }
};

function movesnow() {
  for (var i = 0; i <= snowmax; i++) {
    crds[i] += x_mv[i];
    snow[i].posy += snow[i].sink;
    var posx = snow[i].posx + lftrght[i] * Math.sin(crds[i])/6;
    var posy = snow[i].posy;
    snow[i].style.left = posx + 'px';
    snow[i].style.top = posy + 'px';
    if (snow[i].posy >= marginbottom - 2 * snow[i].size || parseInt(snow[i].style.left) > (marginright - 3 * lftrght[i])) {
      snow[i].posx = randommaker(marginright - snow[i].size);
      snow[i].posy = 0;
    }
  }
}
var Rain;
function rain() {
  Rain = setInterval(movesnow, 20);
}
function stop() {
clearInterval(Rain)
}