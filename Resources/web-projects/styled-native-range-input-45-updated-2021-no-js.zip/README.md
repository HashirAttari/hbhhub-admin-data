# Styled native range input #45 (updated 2021, no JS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/pvLPOQ](https://codepen.io/thebabydino/pen/pvLPOQ).

**June 2021 update**

Major changes:

* got rid of Compass and Modernizr dependencies, neither of which was needed anyway anymore

* generated the HTML in a logical manner with Pug that also helps me pass some custom properties to the CSS

* ditched `absolute` positioning in favour of using a `grid` layout now

* ditched the 1 element restriction to make it functional again (the hacky `/deep/` technique from early 2015 had stopped working within the same year, so I've now eliminated all that completely useless code) and accessible - the ruler values are now `option` elements within a `datalist` tied to the range inputs and the labels are... well, `label` elements

* actually bothered to look for a font that would match the original design

* made the whole thing greyscaled if not hovered and no focus on the slider

* ensured it now behaves consistently in both WebKit browsers and Firefox

* corrected thumb motion behaviour using the [track wrapper](https://codepen.io/thebabydino/pen/NWpNGpo) in Chrome (the way it [behaves in Firefox](https://css-tricks.com/sliding-nightmare-understanding-range-input/#the-range-thumb-component), within the `content-box` of the `actual input`, causes no problems)

* not providing IE/ pre-Chromium support anymore

The external resources are only there to add the warning, which was sadly very necessary given a lot of people shared these saying that I designed them... which is not true.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. Chrome/Opera have a bit of an extra, the labels at the bottom. These are created using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). 

---

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/yTgRRnM.png) 