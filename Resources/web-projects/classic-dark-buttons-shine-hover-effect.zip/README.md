# Classic Dark Buttons + Shine Hover Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/mGWeKm](https://codepen.io/markmead/pen/mGWeKm).

