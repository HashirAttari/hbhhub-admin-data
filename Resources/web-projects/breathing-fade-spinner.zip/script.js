let root = document.documentElement
const dark = document.querySelector('#dark_button')
const light = document.querySelector('#light_button')

const fgColors = ['#396AB1', '#82A3DB', '#3E9651', '#94CA6B', '#948B3D', '#DCD280', '#DA7C30', '#F1A75C', '#922428', '#B68570', '#CC2529', '#E36E90', '#6B4C9A', '#B087C7', '#535154', '#909595', '#FFFFFF', '#000000', '#2B91AF']
const bgColors = ['#396AB144', '#82A3DB44', '#3E965144', '#94CA6B44', '#948B3D44', '#DCD28044', '#DA7C3044', '#F1A75C44', '#92242844', '#B6857044', '#CC252944', '#E36E9044', '#6B4C9A44', '#B087C744', '#53515444', '#90959544', '#FFFFFF44', '#00000044', 'transparent']

let fgIndex = 0
let bgIndex = 0

dark.addEventListener("mouseup", handleDarkClick, false)
function handleDarkClick() {
  // const fg = fgColors[fgColors.length * Math.random() | 0]
  fgIndex = fgIndex % fgColors.length
  const fg = fgColors[fgIndex]
  root.style.setProperty('--spin-color', fg)
  fgIndex++
}

light.addEventListener("mouseup", handleLightClick, false)
function handleLightClick() {
  // const bg = bgColors[bgColors.length * Math.random() | 0]
  bgIndex = bgIndex % bgColors.length
  const bg = bgColors[bgIndex]
  root.style.setProperty('--spin-background', bg)
  bgIndex++
}