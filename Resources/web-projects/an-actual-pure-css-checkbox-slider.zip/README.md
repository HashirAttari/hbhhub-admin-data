# An Actual Pure CSS Checkbox Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/rbXygL](https://codepen.io/markmead/pen/rbXygL).

Lotta people use JS for the text changes but you don't need to.