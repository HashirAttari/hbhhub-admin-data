"use strict";
const json1 = {
    "type": "GROUP",
    "id": "1:108",
    "name": "section1",
    "x": 0,
    "y": -6,
    "width": 2206,
    "height": 1338,
    "visible": true,
    "locked": false,
    "opacity": 1,
    "blendMode": "PASS_THROUGH",
    "isMask": false,
    "rotation": 0,
    "layoutAlign": "INHERIT",
    "layoutGrow": 0,
    "layoutPositioning": "AUTO",
    "exportSettings": [],
    "relativeTransform": [
        [
            1,
            0,
            0
        ],
        [
            0,
            1,
            -6
        ]
    ],
    "absoluteRenderBounds": {
        "x": 3344,
        "y": 746,
        "width": 1728,
        "height": 1332
    },
    "effects": [],
    "children": [
        {
            "type": "RECTANGLE",
            "id": "1:85",
            "name": "Rectangle 1",
            "x": 0,
            "y": 0,
            "width": 1728,
            "height": 1332,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    0
                ],
                [
                    0,
                    1,
                    0
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3344,
                "y": 746,
                "width": 1728,
                "height": 1332
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L1728 0L1728 1332L0 1332L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "GRADIENT_LINEAR",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "gradientStops": [
                        {
                            "color": {
                                "r": 0.529411792755127,
                                "g": 0.95686274766922,
                                "b": 0.9372549057006836,
                                "a": 1
                            },
                            "position": 0
                        },
                        {
                            "color": {
                                "r": 0.3333333432674408,
                                "g": 0.7647058963775635,
                                "b": 0.7764706015586853,
                                "a": 1
                            },
                            "position": 1
                        }
                    ],
                    "gradientTransform": [
                        [
                            6.123234262925839e-17,
                            1,
                            0
                        ],
                        [
                            -1,
                            6.123234262925839e-17,
                            1
                        ]
                    ]
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:52",
            "name": "pastries_0004_Layer-5",
            "x": 1362,
            "y": 192,
            "width": 74,
            "height": 70,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1362
                ],
                [
                    0,
                    1,
                    192
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4706,
                "y": 938,
                "width": 74,
                "height": 70
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L74 0L74 70L0 70L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "8b7e2e97c2896f8f60ca8ccf8102e1009c30baf9",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:50",
            "name": "pastries_0002_Layer-3",
            "x": 1041,
            "y": 101,
            "width": 179,
            "height": 182,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1041
                ],
                [
                    0,
                    1,
                    101
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4385,
                "y": 847,
                "width": 179,
                "height": 182
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L179 0L179 182L0 182L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "7217ea840724bcb9e1a511be99c453dc3ab7cdfe",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:79",
            "name": "pastries_0031_Layer-32",
            "x": 770,
            "y": 921,
            "width": 223,
            "height": 320,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    770
                ],
                [
                    0,
                    1,
                    921
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4114,
                "y": 1667,
                "width": 223,
                "height": 320
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L223 0L223 320L0 320L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "58c0b0c6a491b03c53e06a9c6dfea274fa13c887",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:80",
            "name": "pastries_0032_Layer-33",
            "x": 993,
            "y": 935,
            "width": 265,
            "height": 318,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    993
                ],
                [
                    0,
                    1,
                    935
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4337,
                "y": 1681,
                "width": 265,
                "height": 318
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L265 0L265 318L0 318L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "c19f6ab9454f4d73f2e23f168272dd185f665da8",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:46",
            "name": "01",
            "x": 0,
            "y": -6,
            "width": 573,
            "height": 507,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    0
                ],
                [
                    0,
                    1,
                    -6
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3344,
                "y": 746,
                "width": 573,
                "height": 501
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L573 0L573 507L0 507L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "90375c8145e1705320b4f4415da7987751482009",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:47",
            "name": "02",
            "x": 1160,
            "y": 0,
            "width": 429,
            "height": 153,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1160
                ],
                [
                    0,
                    1,
                    0
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4504,
                "y": 746,
                "width": 429,
                "height": 153
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L429 0L429 153L0 153L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "2c92f7c8893df2c58a6f79ec944170562029337e",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:48",
            "name": "03",
            "x": 1375,
            "y": 87,
            "width": 353,
            "height": 521,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1375
                ],
                [
                    0,
                    1,
                    87
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4719,
                "y": 833,
                "width": 353,
                "height": 521
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L353 0L353 521L0 521L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "67e41e6287c77a762a63235a850be13b344d41af",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:49",
            "name": "pastries_0001_Layer-2",
            "x": 566,
            "y": 135,
            "width": 100,
            "height": 113,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    566
                ],
                [
                    0,
                    1,
                    135
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3910,
                "y": 881,
                "width": 100,
                "height": 113
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L100 0L100 113L0 113L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "0c7ddc2321a406e3d0765ff8e3f2417b7713bba3",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:51",
            "name": "pastries_0003_Layer-4",
            "x": 2113,
            "y": 415,
            "width": 93,
            "height": 86,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    2113
                ],
                [
                    0,
                    1,
                    415
                ]
            ],
            "absoluteRenderBounds": null,
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L93 0L93 86L0 86L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "46749bcd808f25ad11aa8479a10f553f1f73075a",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:53",
            "name": "pastries_0005_Layer-6",
            "x": 1194,
            "y": 299,
            "width": 215,
            "height": 222,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1194
                ],
                [
                    0,
                    1,
                    299
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4538,
                "y": 1045,
                "width": 215,
                "height": 222
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L215 0L215 222L0 222L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "1ba65e8c67259dfaf39c3e6a9ca7fea6ef90fac4",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:54",
            "name": "pastries_0006_Layer-7",
            "x": 1067,
            "y": 415,
            "width": 96,
            "height": 79,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1067
                ],
                [
                    0,
                    1,
                    415
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4411,
                "y": 1161,
                "width": 96,
                "height": 79
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L96 0L96 79L0 79L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "43cea946c2b695b85ce56d63913ec3f73c2ac4ad",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:55",
            "name": "pastries_0007_Layer-8",
            "x": 1053,
            "y": 553,
            "width": 110,
            "height": 93,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1053
                ],
                [
                    0,
                    1,
                    553
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4397,
                "y": 1299,
                "width": 110,
                "height": 93
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L110 0L110 93L0 93L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "7a0feff62c033ccbda38a322528c0d466f9cba42",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:84",
            "name": "pastries_0007_Layer-8",
            "x": 1251.019287109375,
            "y": 153,
            "width": 110,
            "height": 93,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": -13.695823318975464,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    0.971566379070282,
                    -0.23676732182502747,
                    1251.019287109375
                ],
                [
                    0.23676732182502747,
                    0.971566379070282,
                    153
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4573,
                "y": 899,
                "width": 128.8916015625,
                "height": 116.40008544921875
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L110 0L110 93L0 93L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "7a0feff62c033ccbda38a322528c0d466f9cba42",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:56",
            "name": "pastries_0008_Layer-9",
            "x": 1194,
            "y": 531,
            "width": 129,
            "height": 112,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1194
                ],
                [
                    0,
                    1,
                    531
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4538,
                "y": 1277,
                "width": 129,
                "height": 112
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L129 0L129 112L0 112L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "e64eec4b932fb5d66f7e76687ab5a1931765f298",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:57",
            "name": "pastries_0009_Layer-10",
            "x": 931,
            "y": 596,
            "width": 74,
            "height": 79,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    931
                ],
                [
                    0,
                    1,
                    596
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4275,
                "y": 1342,
                "width": 74,
                "height": 79
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L74 0L74 79L0 79L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "152200f7fd79136e292bce5719f9f7024102a8ad",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:58",
            "name": "pastries_0010_Layer-11",
            "x": 1440,
            "y": 553,
            "width": 117,
            "height": 122,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1440
                ],
                [
                    0,
                    1,
                    553
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4784,
                "y": 1299,
                "width": 117,
                "height": 122
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L117 0L117 122L0 122L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "2fc493947a9b5d035785f8a5dd5855689e71819b",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:59",
            "name": "pastries_0011_Layer-12",
            "x": 1313,
            "y": 596,
            "width": 67,
            "height": 69,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1313
                ],
                [
                    0,
                    1,
                    596
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4657,
                "y": 1342,
                "width": 67,
                "height": 69
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L67 0L67 69L0 69L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "c74399691746a0a9d2910f8dc850b2d1cd0d23cc",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:60",
            "name": "pastries_0012_Layer-13",
            "x": 1597,
            "y": 6,
            "width": 88,
            "height": 81,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1597
                ],
                [
                    0,
                    1,
                    6
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4941,
                "y": 752,
                "width": 88,
                "height": 81
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L88 0L88 81L0 81L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "8a6fe084544a902720e1087ae7e6e6eeedb2d02c",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:61",
            "name": "pastries_0013_Layer-14",
            "x": 301,
            "y": 592,
            "width": 48,
            "height": 43,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    301
                ],
                [
                    0,
                    1,
                    592
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3645,
                "y": 1338,
                "width": 48,
                "height": 43
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L48 0L48 43L0 43L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "c6000728a342e9d2ea86531c2d7302e2e1f760ba",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:62",
            "name": "pastries_0014_Layer-15",
            "x": 488,
            "y": 329,
            "width": 155,
            "height": 186,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    488
                ],
                [
                    0,
                    1,
                    329
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3832,
                "y": 1075,
                "width": 155,
                "height": 186
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L155 0L155 186L0 186L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "95acbbef968f26102f2af0724b2129d9a1e5b2b2",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:63",
            "name": "pastries_0015_Layer-16",
            "x": 578,
            "y": 914,
            "width": 38,
            "height": 40,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    578
                ],
                [
                    0,
                    1,
                    914
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3922,
                "y": 1660,
                "width": 38,
                "height": 40
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L38 0L38 40L0 40L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "d7219d37180f85aa6311b1d352d39932f6b65c08",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:64",
            "name": "pastries_0016_Layer-17",
            "x": 535,
            "y": 569,
            "width": 83,
            "height": 78,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    535
                ],
                [
                    0,
                    1,
                    569
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3879,
                "y": 1315,
                "width": 83,
                "height": 78
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L83 0L83 78L0 78L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "951c6f9fbb2c95f44db3459954454688fbd94db7",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:65",
            "name": "pastries_0017_Layer-18",
            "x": 369,
            "y": 374,
            "width": 74,
            "height": 71,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    369
                ],
                [
                    0,
                    1,
                    374
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3713,
                "y": 1120,
                "width": 74,
                "height": 71
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L74 0L74 71L0 71L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "d5fe7e3221550384a87d322dbd630c4270a47d0b",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:66",
            "name": "pastries_0018_Layer-19",
            "x": 392,
            "y": 515,
            "width": 101,
            "height": 107,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    392
                ],
                [
                    0,
                    1,
                    515
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3736,
                "y": 1261,
                "width": 101,
                "height": 107
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L101 0L101 107L0 107L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "7452700abf465eb72137f43728a64eb1ed089056",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:67",
            "name": "pastries_0019_Layer-20",
            "x": 258,
            "y": 435,
            "width": 107,
            "height": 103,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    258
                ],
                [
                    0,
                    1,
                    435
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3602,
                "y": 1181,
                "width": 107,
                "height": 103
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L107 0L107 103L0 103L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "50d53857fc05846b374c0d10aac4229013249524",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:68",
            "name": "pastries_0020_Layer-21",
            "x": 600,
            "y": 65,
            "width": 53,
            "height": 43,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    600
                ],
                [
                    0,
                    1,
                    65
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3944,
                "y": 811,
                "width": 53,
                "height": 43
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L53 0L53 43L0 43L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "c6477ae67da167290f9d54c02c3fe3265c2decd9",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:69",
            "name": "pastries_0021_Layer-22",
            "x": 62,
            "y": 476,
            "width": 196,
            "height": 397,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    62
                ],
                [
                    0,
                    1,
                    476
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3406,
                "y": 1222,
                "width": 196,
                "height": 397
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L196 0L196 397L0 397L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "3d7742bac8fc216aedc75d745eb6f5f3bbdc6bbe",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:70",
            "name": "pastries_0022_Layer-23",
            "x": 310,
            "y": 675,
            "width": 201,
            "height": 194,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    310
                ],
                [
                    0,
                    1,
                    675
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3654,
                "y": 1421,
                "width": 201,
                "height": 194
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L201 0L201 194L0 194L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "b2d0eb860b0054c8cfd7c5b5f7576d34899f4a27",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:71",
            "name": "pastries_0023_Layer-24",
            "x": 550,
            "y": 675,
            "width": 199,
            "height": 189,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    550
                ],
                [
                    0,
                    1,
                    675
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3894,
                "y": 1421,
                "width": 199,
                "height": 189
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L199 0L199 189L0 189L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "8b227cbb5d29a76fd1878c656ccfc57e53bcf672",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:72",
            "name": "pastries_0024_Layer-25",
            "x": 772,
            "y": 643,
            "width": 227,
            "height": 220,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    772
                ],
                [
                    0,
                    1,
                    643
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4116,
                "y": 1389,
                "width": 227,
                "height": 220
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L227 0L227 220L0 220L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "54d11f7d7982de1fab8ee3815748d8249a85d295",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:73",
            "name": "pastries_0025_Layer-26",
            "x": 1002,
            "y": 649,
            "width": 226,
            "height": 244,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1002
                ],
                [
                    0,
                    1,
                    649
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4346,
                "y": 1395,
                "width": 226,
                "height": 244
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L226 0L226 244L0 244L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "b6fdd44669a4fecd1fa8ad34a455739bfa8af9f5",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:74",
            "name": "pastries_0026_Layer-27",
            "x": 1251,
            "y": 655,
            "width": 232,
            "height": 232,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1251
                ],
                [
                    0,
                    1,
                    655
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4595,
                "y": 1401,
                "width": 232,
                "height": 232
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L232 0L232 232L0 232L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "0c40d045f925399f3f334579110287504c5e0441",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:75",
            "name": "pastries_0027_Layer-28",
            "x": 1483,
            "y": 665,
            "width": 227,
            "height": 211,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1483
                ],
                [
                    0,
                    1,
                    665
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4827,
                "y": 1411,
                "width": 227,
                "height": 211
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L227 0L227 211L0 211L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "2315483f8b5f1ec4aac611c111531eef0602997e",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:76",
            "name": "pastries_0028_Layer-29",
            "x": 42,
            "y": 957,
            "width": 236,
            "height": 244,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    42
                ],
                [
                    0,
                    1,
                    957
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3386,
                "y": 1703,
                "width": 236,
                "height": 244
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L236 0L236 244L0 244L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "bf97b7962a08acfe7ce8af0731e1e0465d5c0400",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:77",
            "name": "pastries_0029_Layer-30",
            "x": 284,
            "y": 939,
            "width": 242,
            "height": 265,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    284
                ],
                [
                    0,
                    1,
                    939
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3628,
                "y": 1685,
                "width": 242,
                "height": 265
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L242 0L242 265L0 265L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "c32114941ffb65f5d28ec34fcf944dfb82707799",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:78",
            "name": "pastries_0030_Layer-31",
            "x": 533,
            "y": 928,
            "width": 239,
            "height": 273,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    533
                ],
                [
                    0,
                    1,
                    928
                ]
            ],
            "absoluteRenderBounds": {
                "x": 3877,
                "y": 1674,
                "width": 239,
                "height": 273
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L239 0L239 273L0 273L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "14b6bb554fd5cde97ec190be586ed8f57c93efe2",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:81",
            "name": "pastries_0033_Layer-34",
            "x": 1251,
            "y": 928,
            "width": 232,
            "height": 317,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1251
                ],
                [
                    0,
                    1,
                    928
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4595,
                "y": 1674,
                "width": 232,
                "height": 317
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L232 0L232 317L0 317L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "9e77711c719cfef428bc7d6f43e7bdac187d9e59",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:82",
            "name": "pastries_0034_Layer-35",
            "x": 1473,
            "y": 921,
            "width": 248,
            "height": 317,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    1473
                ],
                [
                    0,
                    1,
                    921
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4817,
                "y": 1667,
                "width": 248,
                "height": 317
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L248 0L248 317L0 317L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [
                            1,
                            0,
                            0
                        ],
                        [
                            0,
                            1,
                            0
                        ]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "cadff656f76d36cae2667f705654b2e5d973f58a",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:86",
            "name": "Rectangle 2",
            "x": 688,
            "y": 172,
            "width": 336,
            "height": 222,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 83,
            "cornerSmoothing": 0,
            "topLeftRadius": 83,
            "topRightRadius": 83,
            "bottomLeftRadius": 83,
            "bottomRightRadius": 83,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    688
                ],
                [
                    0,
                    1,
                    172
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4027,
                "y": 916,
                "width": 348,
                "height": 234
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 83C0 37.1604 37.1604 0 83 0L253 0C298.84 0 336 37.1604 336 83L336 139C336 184.84 298.84 222 253 222L83 222C37.1604 222 0 184.84 0 139L0 83Z"
                }
            ],
            "fills": [
                {
                    "type": "SOLID",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "color": {
                        "r": 0.9882352948188782,
                        "g": 0.9843137264251709,
                        "b": 0.95686274766922
                    }
                }
            ],
            "strokes": [],
            "effects": [
                {
                    "type": "DROP_SHADOW",
                    "color": {
                        "r": 0,
                        "g": 0,
                        "b": 0,
                        "a": 0.25
                    },
                    "offset": {
                        "x": 1,
                        "y": 4
                    },
                    "radius": 4,
                    "spread": 2,
                    "visible": true,
                    "blendMode": "NORMAL",
                    "showShadowBehindNode": false
                }
            ]
        },
        {
            "type": "TEXT",
            "id": "1:87",
            "name": "CALKLY COIOILS",
            "x": 740,
            "y": 212,
            "width": 247,
            "height": 142,
            "visible": true,
            "locked": false,
            "rangeAllFontNames": [
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Black"
                    }
                ]
            ],
            "rangeFontSize": [
                59,
                59,
                59,
                59,
                59,
                59,
                59,
                59,
                59,
                59,
                59,
                59,
                59,
                59
            ],
            "rangeFills": [
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 0.9490196108818054,
                            "g": 0.38823530077934265,
                            "b": 0.4274509847164154
                        }
                    }
                ]
            ],
            "rangeLineHeight": [
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                }
            ],
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "OUTSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "characters": "CALKLY\nCOIOILS",
            "textAlignHorizontal": "LEFT",
            "textAlignVertical": "TOP",
            "textAutoResize": "WIDTH_AND_HEIGHT",
            "paragraphIndent": 0,
            "paragraphSpacing": 0,
            "autoRename": true,
            "fontSize": 59,
            "fontName": {
                "family": "Inter",
                "style": "Black"
            },
            "textCase": "ORIGINAL",
            "textDecoration": "NONE",
            "letterSpacing": {
                "unit": "PERCENT",
                "value": 0
            },
            "lineHeight": {
                "unit": "AUTO"
            },
            "textStyleId": "",
            "hyperlink": null,
            "relativeTransform": [
                [
                    1,
                    0,
                    740
                ],
                [
                    0,
                    1,
                    212
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4086.597900390625,
                "y": 971.5042724609375,
                "width": 242.338134765625,
                "height": 115.0823974609375
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M42.8253 30.1818L31.0085 30.1818C30.9247 29.2041 30.7012 28.3171 30.3381 27.521C29.9889 26.7248 29.5 26.0404 28.8714 25.4677C28.2569 24.881 27.5096 24.4341 26.6296 24.1268C25.7496 23.8055 24.7509 23.6449 23.6335 23.6449C21.678 23.6449 20.0228 24.1198 18.668 25.0696C17.3271 26.0194 16.3074 27.3813 15.609 29.1552C14.9246 30.9291 14.5824 33.0592 14.5824 35.5455C14.5824 38.1714 14.9316 40.3713 15.63 42.1452C16.3423 43.9052 17.369 45.2321 18.7099 46.1261C20.0508 47.006 21.6641 47.446 23.5497 47.446C24.6252 47.446 25.589 47.3133 26.4411 47.0479C27.2931 46.7686 28.0334 46.3705 28.6619 45.8537C29.2905 45.3369 29.8003 44.7153 30.1914 43.989C30.5965 43.2487 30.8688 42.4176 31.0085 41.4957L42.8253 41.5795C42.6856 43.3954 42.1758 45.2461 41.2958 47.1317C40.4158 49.0034 39.1657 50.7354 37.5455 52.3278C35.9392 53.9061 33.9487 55.1772 31.5742 56.141C29.1997 57.1048 26.4411 57.5866 23.2983 57.5866C19.3594 57.5866 15.8255 56.7416 12.6967 55.0515C9.58191 53.3614 7.1166 50.8751 5.30078 47.5927C3.49893 44.3102 2.59801 40.2945 2.59801 35.5455C2.59801 30.7685 3.51989 26.7457 5.36364 23.4773C7.20739 20.1948 9.69366 17.7156 12.8224 16.0394C15.9512 14.3493 19.4432 13.5043 23.2983 13.5043C26.0081 13.5043 28.5013 13.8744 30.7781 14.6147C33.0548 15.355 35.0522 16.4375 36.7702 17.8622C38.4883 19.273 39.8711 21.012 40.9187 23.0792C41.9663 25.1464 42.6018 27.514 42.8253 30.1818ZM57.9315 57L45.3604 57L59.5238 14.0909L75.4471 14.0909L89.6104 57L77.0394 57L67.6531 25.9077L67.3178 25.9077L57.9315 57ZM55.5849 40.071L79.2184 40.071L79.2184 48.7869L55.5849 48.7869L55.5849 40.071ZM93.7432 57L93.7432 14.0909L105.392 14.0909L105.392 47.6136L122.74 47.6136L122.74 57L93.7432 57ZM127.449 57L127.449 14.0909L139.098 14.0909L139.098 31.4389L139.685 31.4389L152.591 14.0909L166.168 14.0909L151.669 33.1989L166.503 57L152.591 57L142.953 40.9091L139.098 45.9375L139.098 57L127.449 57ZM169.625 57L169.625 14.0909L181.274 14.0909L181.274 47.6136L198.622 47.6136L198.622 57L169.625 57ZM193.793 14.0909L206.783 14.0909L215.164 31.5227L215.499 31.5227L223.879 14.0909L236.869 14.0909L221.114 43.5071L221.114 57L209.548 57L209.548 43.5071L193.793 14.0909ZM42.8253 101.182L31.0085 101.182C30.9247 100.204 30.7012 99.3171 30.3381 98.521C29.9889 97.7248 29.5 97.0404 28.8714 96.4677C28.2569 95.881 27.5096 95.4341 26.6296 95.1268C25.7496 94.8055 24.7509 94.6449 23.6335 94.6449C21.678 94.6449 20.0228 95.1198 18.668 96.0696C17.3271 97.0194 16.3074 98.3813 15.609 100.155C14.9246 101.929 14.5824 104.059 14.5824 106.545C14.5824 109.171 14.9316 111.371 15.63 113.145C16.3423 114.905 17.369 116.232 18.7099 117.126C20.0508 118.006 21.6641 118.446 23.5497 118.446C24.6252 118.446 25.589 118.313 26.4411 118.048C27.2931 117.769 28.0334 117.37 28.6619 116.854C29.2905 116.337 29.8003 115.715 30.1914 114.989C30.5965 114.249 30.8688 113.418 31.0085 112.496L42.8253 112.58C42.6856 114.395 42.1758 116.246 41.2958 118.132C40.4158 120.003 39.1657 121.735 37.5455 123.328C35.9392 124.906 33.9487 126.177 31.5742 127.141C29.1997 128.105 26.4411 128.587 23.2983 128.587C19.3594 128.587 15.8255 127.742 12.6967 126.051C9.58191 124.361 7.1166 121.875 5.30078 118.593C3.49893 115.31 2.59801 111.295 2.59801 106.545C2.59801 101.768 3.51989 97.7457 5.36364 94.4773C7.20739 91.1948 9.69366 88.7156 12.8224 87.0394C15.9512 85.3493 19.4432 84.5043 23.2983 84.5043C26.0081 84.5043 28.5013 84.8744 30.7781 85.6147C33.0548 86.355 35.0522 87.4375 36.7702 88.8622C38.4883 90.273 39.8711 92.012 40.9187 94.0792C41.9663 96.1464 42.6018 98.514 42.8253 101.182ZM89.6785 106.545C89.6785 111.322 88.7497 115.352 86.892 118.635C85.0342 121.903 82.527 124.382 79.3703 126.072C76.2136 127.749 72.6937 128.587 68.8106 128.587C64.8997 128.587 61.3658 127.742 58.2091 126.051C55.0663 124.347 52.5661 121.861 50.7084 118.593C48.8646 115.31 47.9427 111.295 47.9427 106.545C47.9427 101.768 48.8646 97.7457 50.7084 94.4773C52.5661 91.1948 55.0663 88.7156 58.2091 87.0394C61.3658 85.3493 64.8997 84.5043 68.8106 84.5043C72.6937 84.5043 76.2136 85.3493 79.3703 87.0394C82.527 88.7156 85.0342 91.1948 86.892 94.4773C88.7497 97.7457 89.6785 101.768 89.6785 106.545ZM77.6942 106.545C77.6942 103.975 77.352 101.81 76.6675 100.05C75.9971 98.2765 74.9984 96.9356 73.6714 96.0277C72.3585 95.1058 70.7382 94.6449 68.8106 94.6449C66.8831 94.6449 65.2558 95.1058 63.9289 96.0277C62.6159 96.9356 61.6172 98.2765 60.9328 100.05C60.2623 101.81 59.9271 103.975 59.9271 106.545C59.9271 109.116 60.2623 111.288 60.9328 113.061C61.6172 114.821 62.6159 116.162 63.9289 117.084C65.2558 117.992 66.8831 118.446 68.8106 118.446C70.7382 118.446 72.3585 117.992 73.6714 117.084C74.9984 116.162 75.9971 114.821 76.6675 113.061C77.352 111.288 77.6942 109.116 77.6942 106.545ZM106.718 85.0909L106.718 128L95.0684 128L95.0684 85.0909L106.718 85.0909ZM153.806 106.545C153.806 111.322 152.878 115.352 151.02 118.635C149.162 121.903 146.655 124.382 143.498 126.072C140.342 127.749 136.822 128.587 132.939 128.587C129.028 128.587 125.494 127.742 122.337 126.051C119.194 124.347 116.694 121.861 114.836 118.593C112.993 115.31 112.071 111.295 112.071 106.545C112.071 101.768 112.993 97.7457 114.836 94.4773C116.694 91.1948 119.194 88.7156 122.337 87.0394C125.494 85.3493 129.028 84.5043 132.939 84.5043C136.822 84.5043 140.342 85.3493 143.498 87.0394C146.655 88.7156 149.162 91.1948 151.02 94.4773C152.878 97.7457 153.806 101.768 153.806 106.545ZM141.822 106.545C141.822 103.975 141.48 101.81 140.795 100.05C140.125 98.2765 139.126 96.9356 137.799 96.0277C136.486 95.1058 134.866 94.6449 132.939 94.6449C131.011 94.6449 129.384 95.1058 128.057 96.0277C126.744 96.9356 125.745 98.2765 125.061 100.05C124.39 101.81 124.055 103.975 124.055 106.545C124.055 109.116 124.39 111.288 125.061 113.061C125.745 114.821 126.744 116.162 128.057 117.084C129.384 117.992 131.011 118.446 132.939 118.446C134.866 118.446 136.486 117.992 137.799 117.084C139.126 116.162 140.125 114.821 140.795 113.061C141.48 111.288 141.822 109.116 141.822 106.545ZM170.845 85.0909L170.845 128L159.196 128L159.196 85.0909L170.845 85.0909ZM176.366 128L176.366 85.0909L188.015 85.0909L188.015 118.614L205.363 118.614L205.363 128L176.366 128ZM233.203 98.5C233.091 97.1032 232.567 96.0137 231.632 95.2315C230.71 94.4493 229.306 94.0582 227.42 94.0582C226.219 94.0582 225.234 94.2049 224.466 94.4982C223.712 94.7776 223.153 95.1617 222.79 95.6506C222.427 96.1394 222.238 96.6982 222.224 97.3267C222.196 97.8435 222.287 98.3114 222.497 98.7305C222.72 99.1355 223.069 99.5057 223.544 99.8409C224.019 100.162 224.627 100.455 225.367 100.721C226.107 100.986 226.987 101.224 228.007 101.433L231.527 102.188C233.901 102.69 235.934 103.354 237.624 104.178C239.314 105.002 240.697 105.973 241.772 107.09C242.848 108.194 243.637 109.437 244.14 110.82C244.657 112.202 244.922 113.711 244.936 115.345C244.922 118.167 244.217 120.555 242.82 122.511C241.423 124.466 239.426 125.954 236.828 126.973C234.244 127.993 231.136 128.503 227.504 128.503C223.775 128.503 220.52 127.951 217.741 126.848C214.975 125.744 212.824 124.047 211.287 121.756C209.765 119.452 208.997 116.505 208.983 112.915L220.045 112.915C220.115 114.228 220.443 115.331 221.03 116.225C221.617 117.119 222.441 117.797 223.502 118.257C224.578 118.718 225.856 118.949 227.336 118.949C228.58 118.949 229.62 118.795 230.458 118.488C231.296 118.181 231.932 117.755 232.365 117.21C232.798 116.665 233.021 116.044 233.035 115.345C233.021 114.689 232.805 114.116 232.386 113.627C231.981 113.124 231.31 112.677 230.374 112.286C229.439 111.881 228.175 111.504 226.582 111.155L222.308 110.233C218.509 109.409 215.513 108.033 213.32 106.105C211.141 104.164 210.058 101.517 210.072 98.1648C210.058 95.441 210.785 93.0595 212.251 91.0202C213.732 88.967 215.778 87.3677 218.39 86.2223C221.016 85.0769 224.026 84.5043 227.42 84.5043C230.884 84.5043 233.88 85.0839 236.409 86.2432C238.937 87.4026 240.885 89.0368 242.254 91.146C243.637 93.2411 244.335 95.6925 244.349 98.5L233.203 98.5Z"
                }
            ],
            "fills": [
                {
                    "type": "SOLID",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "color": {
                        "r": 0.9490196108818054,
                        "g": 0.38823530077934265,
                        "b": 0.4274509847164154
                    }
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "1:88",
            "name": "Rectangle 3",
            "x": 742,
            "y": 502,
            "width": 228,
            "height": 72,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 72,
            "cornerSmoothing": 0,
            "topLeftRadius": 72,
            "topRightRadius": 72,
            "bottomLeftRadius": 72,
            "bottomRightRadius": 72,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [
                    1,
                    0,
                    742
                ],
                [
                    0,
                    1,
                    502
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4079,
                "y": 1243,
                "width": 250,
                "height": 94
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 36C0 16.1178 16.1177 0 36 0L192 0C211.882 0 228 16.1178 228 36L228 36C228 55.8823 211.882 72 192 72L36 72C16.1177 72 0 55.8823 0 36L0 36Z"
                }
            ],
            "fills": [
                {
                    "type": "SOLID",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "color": {
                        "r": 0.9921568632125854,
                        "g": 0.5254902243614197,
                        "b": 0.5098039507865906
                    }
                }
            ],
            "strokes": [],
            "effects": [
                {
                    "type": "DROP_SHADOW",
                    "color": {
                        "r": 0,
                        "g": 0,
                        "b": 0,
                        "a": 0.38999998569488525
                    },
                    "offset": {
                        "x": 4,
                        "y": 6
                    },
                    "radius": 9,
                    "spread": 2,
                    "visible": true,
                    "blendMode": "NORMAL",
                    "showShadowBehindNode": false
                }
            ]
        },
        {
            "type": "TEXT",
            "id": "1:157",
            "name": "sdfasd",
            "x": 823,
            "y": 526,
            "width": 65,
            "height": 24,
            "visible": true,
            "locked": false,
            "rangeAllFontNames": [
                [
                    {
                        "family": "Inter",
                        "style": "Medium"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Medium"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Medium"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Medium"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Medium"
                    }
                ],
                [
                    {
                        "family": "Inter",
                        "style": "Medium"
                    }
                ]
            ],
            "rangeFontSize": [
                20,
                20,
                20,
                20,
                20,
                20
            ],
            "rangeFills": [
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 1,
                            "g": 1,
                            "b": 1
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 1,
                            "g": 1,
                            "b": 1
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 1,
                            "g": 1,
                            "b": 1
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 1,
                            "g": 1,
                            "b": 1
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 1,
                            "g": 1,
                            "b": 1
                        }
                    }
                ],
                [
                    {
                        "type": "SOLID",
                        "visible": true,
                        "opacity": 1,
                        "blendMode": "NORMAL",
                        "color": {
                            "r": 1,
                            "g": 1,
                            "b": 1
                        }
                    }
                ]
            ],
            "rangeLineHeight": [
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                },
                {
                    "unit": "AUTO"
                }
            ],
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "OUTSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "characters": "sdfasd",
            "textAlignHorizontal": "CENTER",
            "textAlignVertical": "TOP",
            "textAutoResize": "WIDTH_AND_HEIGHT",
            "paragraphIndent": 0,
            "paragraphSpacing": 0,
            "autoRename": true,
            "fontSize": 20,
            "fontName": {
                "family": "Inter",
                "style": "Medium"
            },
            "textCase": "ORIGINAL",
            "textDecoration": "NONE",
            "letterSpacing": {
                "unit": "PERCENT",
                "value": 0
            },
            "lineHeight": {
                "unit": "AUTO"
            },
            "textStyleId": "",
            "hyperlink": null,
            "relativeTransform": [
                [
                    1,
                    0,
                    823
                ],
                [
                    0,
                    1,
                    526
                ]
            ],
            "absoluteRenderBounds": {
                "x": 4167.98388671875,
                "y": 1275.772705078125,
                "width": 62.37353515625,
                "height": 15.46875
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M9.64134 10.7543L7.71662 11.0952C7.63613 10.849 7.50829 10.6146 7.3331 10.392C7.16264 10.1695 6.93063 9.98722 6.63707 9.84517C6.34351 9.70312 5.97656 9.6321 5.53622 9.6321C4.9349 9.6321 4.433 9.76705 4.03054 10.0369C3.62808 10.3021 3.42685 10.6454 3.42685 11.0668C3.42685 11.4313 3.56179 11.7249 3.83168 11.9474C4.10156 12.17 4.53717 12.3523 5.13849 12.4943L6.87145 12.892C7.87524 13.1241 8.62334 13.4815 9.11577 13.9645C9.60819 14.4474 9.8544 15.0748 9.8544 15.8466C9.8544 16.5 9.66501 17.0824 9.28622 17.5938C8.91217 18.1004 8.38897 18.4981 7.71662 18.7869C7.04901 19.0758 6.27486 19.2202 5.39418 19.2202C4.17259 19.2202 3.1759 18.9598 2.40412 18.4389C1.63234 17.9134 1.15885 17.1676 0.983665 16.2017L3.03622 15.8892C3.16406 16.4242 3.42685 16.8291 3.82457 17.1037C4.2223 17.3736 4.74077 17.5085 5.37997 17.5085C6.07599 17.5085 6.63234 17.3641 7.04901 17.0753C7.46567 16.7817 7.67401 16.4242 7.67401 16.0028C7.67401 15.6619 7.54616 15.3755 7.29048 15.1435C7.03954 14.9115 6.65365 14.7363 6.13281 14.6179L4.28622 14.2131C3.26823 13.9811 2.51539 13.6117 2.0277 13.1051C1.54474 12.5985 1.30327 11.9569 1.30327 11.1804C1.30327 10.5365 1.48319 9.97301 1.84304 9.49006C2.20289 9.0071 2.70005 8.63068 3.33452 8.3608C3.96899 8.08617 4.69579 7.94886 5.51491 7.94886C6.69389 7.94886 7.62192 8.20455 8.29901 8.71591C8.97609 9.22254 9.42353 9.90199 9.64134 10.7543ZM16.2731 19.2131C15.3924 19.2131 14.6064 18.9882 13.9151 18.5384C13.2286 18.0838 12.6888 17.4375 12.2958 16.5994C11.9076 15.7566 11.7134 14.7457 11.7134 13.5668C11.7134 12.3878 11.9099 11.3793 12.3029 10.5412C12.7006 9.70312 13.2451 9.06155 13.9364 8.61648C14.6277 8.1714 15.4113 7.94886 16.2873 7.94886C16.9644 7.94886 17.5089 8.0625 17.9208 8.28977C18.3375 8.51231 18.6594 8.77273 18.8867 9.07102C19.1187 9.36932 19.2987 9.6321 19.4265 9.85938L19.5543 9.85938L19.5543 4.45455L21.6779 4.45455L21.6779 19L19.604 19L19.604 17.3026L19.4265 17.3026C19.2987 17.5346 19.114 17.7997 18.8725 18.098C18.6358 18.3963 18.3091 18.6567 17.8924 18.8793C17.4757 19.1018 16.936 19.2131 16.2731 19.2131ZM16.7418 17.402C17.3526 17.402 17.8687 17.241 18.2901 16.919C18.7163 16.5923 19.0382 16.1402 19.256 15.5625C19.4786 14.9848 19.5898 14.3125 19.5898 13.5455C19.5898 12.7879 19.4809 12.125 19.2631 11.5568C19.0453 10.9886 18.7257 10.5459 18.3043 10.2287C17.8829 9.91146 17.3621 9.75284 16.7418 9.75284C16.1026 9.75284 15.57 9.91856 15.1438 10.25C14.7177 10.5814 14.3957 11.0336 14.1779 11.6065C13.9648 12.1795 13.8583 12.8258 13.8583 13.5455C13.8583 14.2746 13.9672 14.9304 14.185 15.5128C14.4028 16.0952 14.7248 16.5568 15.1509 16.8977C15.5818 17.2339 16.1121 17.402 16.7418 17.402ZM29.9006 8.09091L29.9006 9.79545L23.7358 9.79545L23.7358 8.09091L29.9006 8.09091ZM25.4261 19L25.4261 6.8267C25.4261 6.14489 25.5753 5.57907 25.8736 5.12926C26.1719 4.67472 26.5672 4.33617 27.0597 4.11364C27.5521 3.88636 28.0871 3.77273 28.6648 3.77273C29.0909 3.77273 29.4555 3.80824 29.7585 3.87926C30.0616 3.94555 30.2865 4.0071 30.4332 4.06392L29.9361 5.78267C29.8366 5.75426 29.7088 5.72112 29.5526 5.68324C29.3963 5.64062 29.2069 5.61932 28.9844 5.61932C28.4683 5.61932 28.099 5.74716 27.8764 6.00284C27.6586 6.25852 27.5497 6.62784 27.5497 7.1108L27.5497 19L25.4261 19ZM34.9343 19.2415C34.243 19.2415 33.618 19.1136 33.0593 18.858C32.5006 18.5975 32.0579 18.2211 31.7312 17.7287C31.4092 17.2363 31.2482 16.6326 31.2482 15.9176C31.2482 15.3021 31.3666 14.7955 31.6033 14.3977C31.8401 14 32.1597 13.6851 32.5621 13.4531C32.9646 13.2211 33.4144 13.0459 33.9116 12.9276C34.4087 12.8092 34.9154 12.7192 35.4315 12.6577C36.0849 12.5819 36.6152 12.5204 37.0224 12.473C37.4296 12.4209 37.7255 12.3381 37.9102 12.2244C38.0948 12.1108 38.1871 11.9261 38.1871 11.6705L38.1871 11.6207C38.1871 11.0005 38.012 10.5199 37.6616 10.179C37.3159 9.83807 36.7998 9.66761 36.1133 9.66761C35.3983 9.66761 34.8349 9.82623 34.4229 10.1435C34.0157 10.456 33.734 10.804 33.5778 11.1875L31.582 10.733C31.8188 10.0701 32.1644 9.53504 32.619 9.12784C33.0782 8.71591 33.6062 8.41761 34.2028 8.23295C34.7994 8.04356 35.4267 7.94886 36.0849 7.94886C36.5205 7.94886 36.9821 8.00095 37.4698 8.10511C37.9622 8.20455 38.4215 8.3892 38.8477 8.65909C39.2785 8.92898 39.6313 9.31487 39.9059 9.81676C40.1805 10.3139 40.3178 10.9602 40.3178 11.7557L40.3178 19L38.244 19L38.244 17.5085L38.1587 17.5085C38.0214 17.7831 37.8155 18.053 37.5408 18.3182C37.2662 18.5833 36.9135 18.8035 36.4826 18.9787C36.0517 19.1539 35.5356 19.2415 34.9343 19.2415ZM35.396 17.5369C35.9831 17.5369 36.485 17.4209 36.9016 17.1889C37.323 16.9569 37.6426 16.6539 37.8604 16.2798C38.083 15.901 38.1942 15.4962 38.1942 15.0653L38.1942 13.6591C38.1185 13.7348 37.9717 13.8059 37.7539 13.8722C37.5408 13.9337 37.297 13.9882 37.0224 14.0355C36.7477 14.0781 36.4802 14.1184 36.2198 14.1562C35.9594 14.1894 35.7416 14.2178 35.5664 14.2415C35.1545 14.2936 34.7781 14.3812 34.4371 14.5043C34.101 14.6274 33.8311 14.8049 33.6275 15.0369C33.4286 15.2642 33.3292 15.5672 33.3292 15.946C33.3292 16.4716 33.5233 16.8693 33.9116 17.1392C34.2998 17.4044 34.7946 17.5369 35.396 17.5369ZM51.321 10.7543L49.3963 11.0952C49.3158 10.849 49.188 10.6146 49.0128 10.392C48.8423 10.1695 48.6103 9.98722 48.3168 9.84517C48.0232 9.70312 47.6562 9.6321 47.2159 9.6321C46.6146 9.6321 46.1127 9.76705 45.7102 10.0369C45.3078 10.3021 45.1065 10.6454 45.1065 11.0668C45.1065 11.4313 45.2415 11.7249 45.5114 11.9474C45.7812 12.17 46.2169 12.3523 46.8182 12.4943L48.5511 12.892C49.5549 13.1241 50.303 13.4815 50.7955 13.9645C51.2879 14.4474 51.5341 15.0748 51.5341 15.8466C51.5341 16.5 51.3447 17.0824 50.9659 17.5938C50.5919 18.1004 50.0687 18.4981 49.3963 18.7869C48.7287 19.0758 47.9545 19.2202 47.0739 19.2202C45.8523 19.2202 44.8556 18.9598 44.0838 18.4389C43.312 17.9134 42.8385 17.1676 42.6634 16.2017L44.7159 15.8892C44.8438 16.4242 45.1065 16.8291 45.5043 17.1037C45.902 17.3736 46.4205 17.5085 47.0597 17.5085C47.7557 17.5085 48.312 17.3641 48.7287 17.0753C49.1454 16.7817 49.3537 16.4242 49.3537 16.0028C49.3537 15.6619 49.2259 15.3755 48.9702 15.1435C48.7192 14.9115 48.3333 14.7363 47.8125 14.6179L45.9659 14.2131C44.9479 13.9811 44.1951 13.6117 43.7074 13.1051C43.2244 12.5985 42.983 11.9569 42.983 11.1804C42.983 10.5365 43.1629 9.97301 43.5227 9.49006C43.8826 9.0071 44.3797 8.63068 45.0142 8.3608C45.6487 8.08617 46.3755 7.94886 47.1946 7.94886C48.3736 7.94886 49.3016 8.20455 49.9787 8.71591C50.6558 9.22254 51.1032 9.90199 51.321 10.7543ZM57.9528 19.2131C57.0721 19.2131 56.2861 18.9882 55.5948 18.5384C54.9083 18.0838 54.3685 17.4375 53.9755 16.5994C53.5872 15.7566 53.3931 14.7457 53.3931 13.5668C53.3931 12.3878 53.5896 11.3793 53.9826 10.5412C54.3803 9.70312 54.9248 9.06155 55.6161 8.61648C56.3074 8.1714 57.091 7.94886 57.967 7.94886C58.6441 7.94886 59.1886 8.0625 59.6005 8.28977C60.0172 8.51231 60.3391 8.77273 60.5664 9.07102C60.7984 9.36932 60.9783 9.6321 61.1062 9.85938L61.234 9.85938L61.234 4.45455L63.3576 4.45455L63.3576 19L61.2837 19L61.2837 17.3026L61.1062 17.3026C60.9783 17.5346 60.7937 17.7997 60.5522 18.098C60.3155 18.3963 59.9888 18.6567 59.5721 18.8793C59.1554 19.1018 58.6157 19.2131 57.9528 19.2131ZM58.4215 17.402C59.0323 17.402 59.5484 17.241 59.9698 16.919C60.396 16.5923 60.7179 16.1402 60.9357 15.5625C61.1583 14.9848 61.2695 14.3125 61.2695 13.5455C61.2695 12.7879 61.1606 12.125 60.9428 11.5568C60.725 10.9886 60.4054 10.5459 59.984 10.2287C59.5626 9.91146 59.0418 9.75284 58.4215 9.75284C57.7823 9.75284 57.2496 9.91856 56.8235 10.25C56.3974 10.5814 56.0754 11.0336 55.8576 11.6065C55.6445 12.1795 55.538 12.8258 55.538 13.5455C55.538 14.2746 55.6469 14.9304 55.8647 15.5128C56.0825 16.0952 56.4045 16.5568 56.8306 16.8977C57.2615 17.2339 57.7918 17.402 58.4215 17.402Z"
                }
            ],
            "fills": [
                {
                    "type": "SOLID",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "color": {
                        "r": 1,
                        "g": 1,
                        "b": 1
                    }
                }
            ],
            "strokes": [],
            "effects": []
        }
    ]
};
const json2 = {
    "type": "FRAME",
    "id": "162:47",
    "name": "section2",
    "x": 0,
    "y": 1332,
    "width": 1728,
    "height": 654,
    "visible": true,
    "locked": false,
    "opacity": 1,
    "blendMode": "PASS_THROUGH",
    "isMask": false,
    "cornerRadius": 0,
    "cornerSmoothing": 0,
    "topLeftRadius": 0,
    "topRightRadius": 0,
    "bottomLeftRadius": 0,
    "bottomRightRadius": 0,
    "fillStyleId": "",
    "strokeStyleId": "",
    "strokeWeight": 1,
    "strokeTopWeight": 1,
    "strokeBottomWeight": 1,
    "strokeLeftWeight": 1,
    "strokeRightWeight": 1,
    "strokeJoin": "MITER",
    "strokeAlign": "INSIDE",
    "dashPattern": [],
    "strokeCap": "NONE",
    "strokeMiterLimit": 4,
    "rotation": 0,
    "layoutAlign": "INHERIT",
    "layoutGrow": 0,
    "layoutPositioning": "AUTO",
    "constraints": {
        "horizontal": "MIN",
        "vertical": "MIN"
    },
    "exportSettings": [],
    "relativeTransform": [
        [1, 0, 0],
        [0, 1, 1332]
    ],
    "absoluteRenderBounds": {
        "x": 640,
        "y": -2610,
        "width": 1728,
        "height": 654
    },
    "fillGeometry": [
        {
            "windingRule": "NONZERO",
            "data": "M0 0L1728 0L1728 654L0 654L0 0Z"
        }
    ],
    "guides": [],
    "fills": [],
    "strokes": [],
    "effects": [],
    "children": [
        {
            "type": "RECTANGLE",
            "id": "162:48",
            "name": "Rectangle 4",
            "x": 0,
            "y": 0,
            "width": 1728,
            "height": 654,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 0],
                [0, 1, 0]
            ],
            "absoluteRenderBounds": {
                "x": 640,
                "y": -2610,
                "width": 1728,
                "height": 654
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L1728 0L1728 654L0 654L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "GRADIENT_LINEAR",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "gradientStops": [
                        {
                            "color": {
                                "r": 0.9960784316062927,
                                "g": 0.9803921580314636,
                                "b": 0.8941176533699036,
                                "a": 1
                            },
                            "position": 0
                        },
                        {
                            "color": {
                                "r": 0.9921568632125854,
                                "g": 0.7137255072593689,
                                "b": 0.6627451181411743,
                                "a": 1
                            },
                            "position": 1
                        }
                    ],
                    "gradientTransform": [
                        [1.3288785219192505, 0.31139692664146423, -0.24279651045799255],
                        [-0.31139692664146423, 0.19035018980503082, 0.5375683903694153]
                    ]
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "162:50",
            "name": "pastries_0000_Layer-1",
            "x": 893.412109375,
            "y": 107,
            "width": 176,
            "height": 168,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": -48.288172589922,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [0.6653844714164734, -0.7465008497238159, 893.412109375],
                [0.7465008497238159, 0.6653844714164734, 107]
            ],
            "absoluteRenderBounds": {
                "x": 1408,
                "y": -2503,
                "width": 242.519775390625,
                "height": 243.168701171875
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L176 0L176 168L0 168L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "ddd8cc327abed285dd372ed98c71bb88e1a2f473",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "162:51",
            "name": "pastries_0001_Layer-2",
            "x": 799,
            "y": 330,
            "width": 130,
            "height": 86,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 799],
                [0, 1, 330]
            ],
            "absoluteRenderBounds": {
                "x": 1439,
                "y": -2280,
                "width": 130,
                "height": 86
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L130 0L130 86L0 86L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "ca2df52839e604a85b6614c8a7a0feae5e2882be",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "162:52",
            "name": "pastries_0002_Layer-3",
            "x": 852,
            "y": 416,
            "width": 159,
            "height": 139,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 852],
                [0, 1, 416]
            ],
            "absoluteRenderBounds": {
                "x": 1492,
                "y": -2194,
                "width": 159,
                "height": 139
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L159 0L159 139L0 139L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "f9c5962d42a6482385015de517f90fa524eb5c3c",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "162:53",
            "name": "pastries_0003_Layer-4",
            "x": 516,
            "y": 135,
            "width": 112,
            "height": 116,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 516],
                [0, 1, 135]
            ],
            "absoluteRenderBounds": {
                "x": 1156,
                "y": -2475,
                "width": 112,
                "height": 116
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L112 0L112 116L0 116L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "0a7f5d49bb2aebf0d9f92f457e7b04346808d746",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "162:54",
            "name": "pastries_0004_Layer-5",
            "x": 469,
            "y": 461,
            "width": 94,
            "height": 92,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 469],
                [0, 1, 461]
            ],
            "absoluteRenderBounds": {
                "x": 1109,
                "y": -2149,
                "width": 94,
                "height": 92
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L94 0L94 92L0 92L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "cd5b56acbf8a91150a1ec5418d88d7b517fe9004",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "162:55",
            "name": "pastries_0005_Layer-6",
            "x": 428,
            "y": 307,
            "width": 145,
            "height": 143,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 428],
                [0, 1, 307]
            ],
            "absoluteRenderBounds": {
                "x": 1068,
                "y": -2303,
                "width": 145,
                "height": 143
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L145 0L145 143L0 143L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "be6e11c3054f771ab9fa5279ce20b79f2b70dc69",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "162:56",
            "name": "pastries_0006_Layer-7",
            "x": 592.337890625,
            "y": 327,
            "width": 161,
            "height": 261,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": -7.117259986052678,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [0.9922946691513062, -0.123900406062603, 592.337890625],
                [0.123900406062603, 0.9922946691513062, 327]
            ],
            "absoluteRenderBounds": {
                "x": 1199.9998779296875,
                "y": -2283,
                "width": 192.097412109375,
                "height": 278.9368896484375
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L161 0L161 261L0 261L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "103920a6cdc2e3db1dbdf27c3b19965fe5633a8a",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "162:57",
            "name": "pastries_0007_Layer-8",
            "x": 709.30224609375,
            "y": -10,
            "width": 205,
            "height": 227,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": -41.12618720088457,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [0.7532628774642944, -0.657719612121582, 709.30224609375],
                [0.657719612121582, 0.7532628774642944, -10]
            ],
            "absoluteRenderBounds": {
                "x": 1199.9998779296875,
                "y": -2610,
                "width": 303.7213134765625,
                "height": 295.8232421875
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L205 0L205 227L0 227L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "4e1386c56b0758e3913115b005cea1fbaed453f5",
                }
            ],
            "strokes": [],
            "effects": []
        }
    ]
};
const json3 = {
    "type": "FRAME",
    "id": "189:346",
    "name": "Frame 1",
    "x": -464,
    "y": -2048,
    "width": 394,
    "height": 644,
    "visible": true,
    "locked": false,
    "opacity": 1,
    "blendMode": "PASS_THROUGH",
    "isMask": false,
    "cornerRadius": 0,
    "cornerSmoothing": 0,
    "topLeftRadius": 0,
    "topRightRadius": 0,
    "bottomLeftRadius": 0,
    "bottomRightRadius": 0,
    "fillStyleId": "",
    "strokeStyleId": "",
    "strokeWeight": 1,
    "strokeTopWeight": 1,
    "strokeBottomWeight": 1,
    "strokeLeftWeight": 1,
    "strokeRightWeight": 1,
    "strokeJoin": "MITER",
    "strokeAlign": "INSIDE",
    "dashPattern": [],
    "strokeCap": "NONE",
    "strokeMiterLimit": 4,
    "rotation": 0,
    "layoutAlign": "INHERIT",
    "layoutGrow": 0,
    "layoutPositioning": "AUTO",
    "constraints": {
        "horizontal": "MIN",
        "vertical": "MIN"
    },
    "exportSettings": [],
    "relativeTransform": [
        [1, 0, -464],
        [0, 1, -2048]
    ],
    "absoluteRenderBounds": {
        "x": -464,
        "y": -2048,
        "width": 394,
        "height": 644
    },
    "fillGeometry": [
        {
            "windingRule": "NONZERO",
            "data": "M0 0L394 0L394 644L0 644L0 0Z"
        }
    ],
    "guides": [],
    "fills": [
        {
            "type": "SOLID",
            "visible": true,
            "opacity": 1,
            "blendMode": "NORMAL",
            "color": {
                "r": 1,
                "g": 1,
                "b": 1
            }
        }
    ],
    "strokes": [],
    "effects": [],
    "children": [
        {
            "type": "RECTANGLE",
            "id": "189:339",
            "name": "pastries_0000_Layer-1",
            "x": 31,
            "y": 75,
            "width": 146,
            "height": 123,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 31],
                [0, 1, 75]
            ],
            "absoluteRenderBounds": {
                "x": -433,
                "y": -1973,
                "width": 146,
                "height": 123
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L146 0L146 123L0 123L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "47ce11fa99290cb42ae5c83c74bd53ba73435fdf",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "189:340",
            "name": "pastries_0001_Layer-2",
            "x": 213,
            "y": 30,
            "width": 140,
            "height": 151,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 213],
                [0, 1, 30]
            ],
            "absoluteRenderBounds": {
                "x": -251,
                "y": -2018,
                "width": 140,
                "height": 151
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L140 0L140 151L0 151L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "2574438388af26f547b022e4ba049f728212132c",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "189:341",
            "name": "pastries_0002_Layer-3",
            "x": 177,
            "y": 196,
            "width": 156,
            "height": 165,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 177],
                [0, 1, 196]
            ],
            "absoluteRenderBounds": {
                "x": -287,
                "y": -1852,
                "width": 156,
                "height": 165
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L156 0L156 165L0 165L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "7a3a995f6e281d8baba9feb2f95970b00c57459e",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "189:342",
            "name": "pastries_0003_Layer-4",
            "x": 17,
            "y": 255,
            "width": 177,
            "height": 145,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 17],
                [0, 1, 255]
            ],
            "absoluteRenderBounds": {
                "x": -447,
                "y": -1793,
                "width": 177,
                "height": 145
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L177 0L177 145L0 145L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "da64a415504fe306551212ffbe4dbe37dcdc1f8a",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "189:343",
            "name": "pastries_0004_Layer-5",
            "x": 108,
            "y": 379,
            "width": 123,
            "height": 126,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 108],
                [0, 1, 379]
            ],
            "absoluteRenderBounds": {
                "x": -356,
                "y": -1669,
                "width": 123,
                "height": 126
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L123 0L123 126L0 126L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "f7fc24a3e1d6deff5056878d8042e67d574e2eb9",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "189:344",
            "name": "pastries_0005_Layer-6",
            "x": 17,
            "y": 477,
            "width": 182,
            "height": 137,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 17],
                [0, 1, 477]
            ],
            "absoluteRenderBounds": {
                "x": -447,
                "y": -1571,
                "width": 182,
                "height": 137
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L182 0L182 137L0 137L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "cf9db6290028006cfdeb160d84c987b992887b66",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "189:345",
            "name": "pastries_0006_Layer-7",
            "x": 311,
            "y": 379,
            "width": 56,
            "height": 235,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 311],
                [0, 1, 379]
            ],
            "absoluteRenderBounds": {
                "x": -153,
                "y": -1669,
                "width": 56,
                "height": 235
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L56 0L56 235L0 235L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "c8de521809d93e6c93c4d6131fe127163110b792",
                }
            ],
            "strokes": [],
            "effects": []
        }
    ]
};
const json4 = {
    "type": "FRAME",
    "id": "198:369",
    "name": "Frame 2",
    "x": -1025,
    "y": -1073,
    "width": 349,
    "height": 642,
    "visible": true,
    "locked": false,
    "opacity": 1,
    "blendMode": "PASS_THROUGH",
    "isMask": false,
    "cornerRadius": 0,
    "cornerSmoothing": 0,
    "topLeftRadius": 0,
    "topRightRadius": 0,
    "bottomLeftRadius": 0,
    "bottomRightRadius": 0,
    "fillStyleId": "",
    "strokeStyleId": "",
    "strokeWeight": 1,
    "strokeTopWeight": 1,
    "strokeBottomWeight": 1,
    "strokeLeftWeight": 1,
    "strokeRightWeight": 1,
    "strokeJoin": "MITER",
    "strokeAlign": "INSIDE",
    "dashPattern": [],
    "strokeCap": "NONE",
    "strokeMiterLimit": 4,
    "rotation": 0,
    "layoutAlign": "INHERIT",
    "layoutGrow": 0,
    "layoutPositioning": "AUTO",
    "constraints": {
        "horizontal": "MIN",
        "vertical": "MIN"
    },
    "exportSettings": [],
    "relativeTransform": [
        [1, 0, -1025],
        [0, 1, -1073]
    ],
    "absoluteRenderBounds": {
        "x": -1025,
        "y": -1073,
        "width": 349,
        "height": 642
    },
    "fillGeometry": [
        {
            "windingRule": "NONZERO",
            "data": "M0 0L349 0L349 642L0 642L0 0Z"
        }
    ],
    "guides": [],
    "fills": [
        {
            "type": "SOLID",
            "visible": true,
            "opacity": 1,
            "blendMode": "NORMAL",
            "color": {
                "r": 1,
                "g": 1,
                "b": 1
            }
        }
    ],
    "strokes": [],
    "effects": [],
    "children": [
        {
            "type": "RECTANGLE",
            "id": "198:352",
            "name": "pastries_0007_Layer-8",
            "x": 32,
            "y": 94,
            "width": 140,
            "height": 126,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 32],
                [0, 1, 94]
            ],
            "absoluteRenderBounds": {
                "x": -993,
                "y": -979,
                "width": 140,
                "height": 126
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L140 0L140 126L0 126L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "e2a5cf3634a05f6cc053e07b501acb2f268b5e27",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:353",
            "name": "pastries_0008_Layer-9",
            "x": 148,
            "y": 106,
            "width": 134,
            "height": 101,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 148],
                [0, 1, 106]
            ],
            "absoluteRenderBounds": {
                "x": -877,
                "y": -967,
                "width": 134,
                "height": 101
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L134 0L134 101L0 101L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "b6192ef6a8c57ceb59bff67b1d2a42f1b35e15d2",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:354",
            "name": "pastries_0009_Layer-10",
            "x": 32,
            "y": 218,
            "width": 146,
            "height": 109,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 32],
                [0, 1, 218]
            ],
            "absoluteRenderBounds": {
                "x": -993,
                "y": -855,
                "width": 146,
                "height": 109
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L146 0L146 109L0 109L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "46dd129293525461aba8c8fcdc9849c1863d6c63",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:355",
            "name": "pastries_0010_Layer-11",
            "x": 154,
            "y": 215,
            "width": 154,
            "height": 115,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 154],
                [0, 1, 215]
            ],
            "absoluteRenderBounds": {
                "x": -871,
                "y": -858,
                "width": 154,
                "height": 115
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L154 0L154 115L0 115L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "a6acad2a4c654d750f74ae9ff6e337b4e25e4380",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:356",
            "name": "pastries_0011_Layer-12",
            "x": 32,
            "y": 324,
            "width": 157,
            "height": 115,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 32],
                [0, 1, 324]
            ],
            "absoluteRenderBounds": {
                "x": -993,
                "y": -749,
                "width": 157,
                "height": 115
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L157 0L157 115L0 115L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "affd8799543048bf797e223925ecb58813c64860",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:357",
            "name": "pastries_0012_Layer-13",
            "x": 173,
            "y": 325,
            "width": 137,
            "height": 126,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 173],
                [0, 1, 325]
            ],
            "absoluteRenderBounds": {
                "x": -852,
                "y": -748,
                "width": 137,
                "height": 126
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L137 0L137 126L0 126L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "fe54a04671f8e24317c37e3443e627b28dee6664",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:358",
            "name": "pastries_0013_Layer-14",
            "x": 46,
            "y": 435,
            "width": 143,
            "height": 112,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 46],
                [0, 1, 435]
            ],
            "absoluteRenderBounds": {
                "x": -979,
                "y": -638,
                "width": 143,
                "height": 112
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L143 0L143 112L0 112L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "c48f51deeb99c5f75712e91be53b01f2e23229fb",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:359",
            "name": "pastries_0014_Layer-15",
            "x": 168,
            "y": 433,
            "width": 148,
            "height": 115,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 168],
                [0, 1, 433]
            ],
            "absoluteRenderBounds": {
                "x": -857,
                "y": -640,
                "width": 148,
                "height": 115
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L148 0L148 115L0 115L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "f7bc75f0409da2474043e740268473e71dbbe7a4",
                }
            ],
            "strokes": [],
            "effects": []
        }
    ]
};
const json5 = {
    "type": "FRAME",
    "id": "198:371",
    "name": "Frame 3",
    "x": -464,
    "y": -1073,
    "width": 415,
    "height": 642,
    "visible": true,
    "locked": false,
    "opacity": 1,
    "blendMode": "PASS_THROUGH",
    "isMask": false,
    "cornerRadius": 0,
    "cornerSmoothing": 0,
    "topLeftRadius": 0,
    "topRightRadius": 0,
    "bottomLeftRadius": 0,
    "bottomRightRadius": 0,
    "fillStyleId": "",
    "strokeStyleId": "",
    "strokeWeight": 1,
    "strokeTopWeight": 1,
    "strokeBottomWeight": 1,
    "strokeLeftWeight": 1,
    "strokeRightWeight": 1,
    "strokeJoin": "MITER",
    "strokeAlign": "INSIDE",
    "dashPattern": [],
    "strokeCap": "NONE",
    "strokeMiterLimit": 4,
    "rotation": 0,
    "layoutAlign": "INHERIT",
    "layoutGrow": 0,
    "layoutPositioning": "AUTO",
    "constraints": {
        "horizontal": "MIN",
        "vertical": "MIN"
    },
    "exportSettings": [],
    "relativeTransform": [
        [1, 0, -464],
        [0, 1, -1073]
    ],
    "absoluteRenderBounds": {
        "x": -464,
        "y": -1073,
        "width": 415,
        "height": 642
    },
    "fillGeometry": [
        {
            "windingRule": "NONZERO",
            "data": "M0 0L415 0L415 642L0 642L0 0Z"
        }
    ],
    "guides": [],
    "fills": [
        {
            "type": "SOLID",
            "visible": true,
            "opacity": 1,
            "blendMode": "NORMAL",
            "color": {
                "r": 1,
                "g": 1,
                "b": 1
            }
        }
    ],
    "strokes": [],
    "effects": [],
    "children": [
        {
            "type": "RECTANGLE",
            "id": "198:361",
            "name": "pastries_0015_Layer-16",
            "x": 95,
            "y": 126,
            "width": 104,
            "height": 98,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 95],
                [0, 1, 126]
            ],
            "absoluteRenderBounds": {
                "x": -369,
                "y": -947,
                "width": 104,
                "height": 98
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L104 0L104 98L0 98L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "07965863bc0004fb9e41a47d4b9fea5c5b23eda1",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:362",
            "name": "pastries_0016_Layer-17",
            "x": 181,
            "y": 123,
            "width": 128,
            "height": 98,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 181],
                [0, 1, 123]
            ],
            "absoluteRenderBounds": {
                "x": -283,
                "y": -950,
                "width": 128,
                "height": 98
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L128 0L128 98L0 98L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "129e81a0424b45f0903d0acab2d6eac17b9cfcb0",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:363",
            "name": "pastries_0017_Layer-18",
            "x": 83,
            "y": 224,
            "width": 112,
            "height": 115,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 83],
                [0, 1, 224]
            ],
            "absoluteRenderBounds": {
                "x": -381,
                "y": -849,
                "width": 112,
                "height": 115
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L112 0L112 115L0 115L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "8ff559fece62ed7c5fbe11f7cccf9d33e6d57eb1",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:364",
            "name": "pastries_0018_Layer-19",
            "x": 74,
            "y": 323,
            "width": 121,
            "height": 112,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 74],
                [0, 1, 323]
            ],
            "absoluteRenderBounds": {
                "x": -390,
                "y": -750,
                "width": 121,
                "height": 112
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L121 0L121 112L0 112L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                    "imageHash": "8f3bd1546016a9f076b2fed56cbc5522f01f29ec",
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:365",
            "name": "pastries_0019_Layer-20",
            "x": 181,
            "y": 221,
            "width": 120,
            "height": 112,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 181],
                [0, 1, 221]
            ],
            "absoluteRenderBounds": {
                "x": -283,
                "y": -852,
                "width": 120,
                "height": 112
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L120 0L120 112L0 112L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:366",
            "name": "pastries_0020_Layer-21",
            "x": 195,
            "y": 324,
            "width": 112,
            "height": 118,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 195],
                [0, 1, 324]
            ],
            "absoluteRenderBounds": {
                "x": -269,
                "y": -749,
                "width": 112,
                "height": 118
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L112 0L112 118L0 118L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:367",
            "name": "pastries_0021_Layer-22",
            "x": 82,
            "y": 445,
            "width": 126,
            "height": 106,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 82],
                [0, 1, 445]
            ],
            "absoluteRenderBounds": {
                "x": -382,
                "y": -628,
                "width": 126,
                "height": 106
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L126 0L126 106L0 106L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                }
            ],
            "strokes": [],
            "effects": []
        },
        {
            "type": "RECTANGLE",
            "id": "198:368",
            "name": "pastries_0022_Layer-23",
            "x": 195,
            "y": 434,
            "width": 129,
            "height": 126,
            "visible": true,
            "locked": false,
            "opacity": 1,
            "blendMode": "PASS_THROUGH",
            "isMask": false,
            "cornerRadius": 0,
            "cornerSmoothing": 0,
            "topLeftRadius": 0,
            "topRightRadius": 0,
            "bottomLeftRadius": 0,
            "bottomRightRadius": 0,
            "fillStyleId": "",
            "strokeStyleId": "",
            "strokeWeight": 1,
            "strokeTopWeight": 1,
            "strokeBottomWeight": 1,
            "strokeLeftWeight": 1,
            "strokeRightWeight": 1,
            "strokeJoin": "MITER",
            "strokeAlign": "INSIDE",
            "dashPattern": [],
            "strokeCap": "NONE",
            "strokeMiterLimit": 4,
            "rotation": 0,
            "layoutAlign": "INHERIT",
            "layoutGrow": 0,
            "layoutPositioning": "AUTO",
            "constraints": {
                "horizontal": "MIN",
                "vertical": "MIN"
            },
            "exportSettings": [],
            "relativeTransform": [
                [1, 0, 195],
                [0, 1, 434]
            ],
            "absoluteRenderBounds": {
                "x": -269,
                "y": -639,
                "width": 129,
                "height": 126
            },
            "fillGeometry": [
                {
                    "windingRule": "NONZERO",
                    "data": "M0 0L129 0L129 126L0 126L0 0Z"
                }
            ],
            "fills": [
                {
                    "type": "IMAGE",
                    "visible": true,
                    "opacity": 1,
                    "blendMode": "NORMAL",
                    "scaleMode": "FILL",
                    "imageTransform": [
                        [1, 0, 0],
                        [0, 1, 0]
                    ],
                    "scalingFactor": 0.5,
                    "rotation": 0,
                    "filters": {
                        "exposure": 0,
                        "contrast": 0,
                        "saturation": 0,
                        "temperature": 0,
                        "tint": 0,
                        "highlights": 0,
                        "shadows": 0
                    },
                }
            ],
            "strokes": [],
            "effects": []
        }
    ]
};
window.onload = () => {
    load(json1, 0, "header", "#section1Bg", () => animate1("#section1Bg .img"));
    load(json2, 1, "section2", "#carousel", () => animate2("#carousel"));
    load(json3, 2, "section3", "#section3B", () => animate3("#section3B", ".img"));
    load(json4, 3, "section4", "#sectionC1", () => animate3("#sectionC1", ".img"));
    load(json5, 4, "section5", "#sectionC2", () => animate3("#sectionC2", ".img"));
    setTimeout(() => {
        gsap.to(window, { duration: 1, scrollTo: 100, repeat: 1, yoyo: true, ease: 'quad.inout' });
    }, 600);
};
function load(url, index, dir, selector, callback) {
    const parent = document.querySelector(selector);
    //fetch(url)
    //  .then((response) => response.json())
    // .then((data) => {
    const data = url;
    for (let i = 0; i < data.children.length; i++) {
        const child = data.children[i];
        const fills = child.fills;
        for (let j = 0; j < fills.length; j++) {
            const fill = fills[j];
            const type = fill.type;
            if (type === "IMAGE") {
                const img = document.createElement("img");
                img.src = `https://alieninterfaces.com/static/pages/09-pastries/assets/${dir}/${child.name}.png`;
                img.classList.add("img");
                img.id = `img${index}_${i + 1}`;
                const docWidth = data.absoluteRenderBounds.width;
                const docHeight = data.absoluteRenderBounds.height;
                const parentWidth = parent.offsetWidth;
                const parentHeight = parent.offsetHeight;
                const normalizedScaleX = parentWidth / docWidth;
                const normalizedScaleY = parentHeight / docHeight;
                let x = child.x / parentWidth;
                let y = child.y / parentHeight;
                x *= 100;
                y *= 100;
                x *= normalizedScaleX;
                y *= normalizedScaleY;
                let width = child.width / parentWidth;
                width *= 100;
                width *= normalizedScaleX;
                img.style.left = `${x}%`;
                img.style.top = `${y}%`;
                img.style.width = `${width}%`;
                img.style.minWidth = `${child.width / 2}px`;
                parent.appendChild(img);
            }
        }
    }
    // })
    // .then(() => {
    callback();
    // });
}
function animate1(selector) {
    // Ensure gsap and ScrollTrigger are available
    if (typeof gsap === "undefined" || typeof ScrollTrigger === "undefined") {
        console.log("GSAP or ScrollTrigger is not loaded");
        return;
    }
    // Define the class of the elements to animate
    // Get the elements
    let elements = document.querySelectorAll(selector);
    const centerX = window.innerWidth / 2;
    const centerY = window.innerHeight / 2;
    let tl = gsap.timeline({
        scrollTrigger: {
            trigger: "#section1",
            start: "top top",
            end: "bottom top",
            scrub: true, // smooth scrubbing, takes 1 second to "catch up" to the scrollba
        },
    });
    // For each element
    elements.forEach((element) => {
        // Get the element's current position
        let rect = element.getBoundingClientRect();
        const elementX = rect.left + rect.width / 2;
        const directionX = elementX - centerX > 0 ? "+=" : "-=";
        const directionY = "-=";
        const goalX = directionX + Math.abs(elementX - centerX);
        const goalY = directionY + (600 - Math.abs(elementX - centerX));
        // Create the gsap animation
        tl.to(element, {
            x: goalX,
            y: goalY,
            duration: 1,
            ease: "power1.out",
        }, 0);
    });
}
function animate2(selector) {
    // get the container element
    let container = document.querySelector(selector);
    // get all child elements
    let children = container.querySelectorAll(".img");
    console.log(container, children);
    // create a timeline for the container rotation
    let containerTimeline = gsap.timeline({
        scrollTrigger: {
            trigger: document.body,
            start: "top top",
            end: "bottom top",
            scrub: true,
        },
    });
    // rotate the container 360 degrees as the user scrolls
    containerTimeline.to(container, {
        rotation: 360,
        duration: 1,
        ease: "none",
    });
    // create a timeline for each child
    children.forEach((child) => {
        let childTimeline = gsap.timeline({
            scrollTrigger: {
                trigger: document.body,
                start: "top top",
                end: "bottom top",
                scrub: true,
            },
        });
        // rotate the child -360 degrees (opposite direction to the container) as the user scrolls
        childTimeline.to(child, {
            rotation: -360,
            duration: 1,
            ease: "none",
        });
    });
}
function animate3(selector, childSelector) {
    // get the parent element
    let parent = document.querySelector(selector);
    const parentRect = parent.getBoundingClientRect();
    // get all child elements
    let children = parent.querySelectorAll(childSelector);
    // get the center of the parent
    let centerX = parent.offsetWidth / 2;
    let centerY = parent.offsetHeight / 2;
    // animate each child
    children.forEach((child) => {
        // get the child's default position
        let rect = child.getBoundingClientRect();
        let childX = rect.left + rect.width / 2 - parentRect.left;
        let childY = rect.top + rect.height / 2 - parentRect.top;
        // calculate the direction to animate
        let directionX = childX - centerX > 0 ? "+=" : "-=";
        let directionY = childY - centerY > 0 ? "+=" : "-=";
        const goalX = directionX + Math.abs((childX - centerX) * 10);
        const goalY = directionY + Math.abs((childY - centerY) * 10);
        // set the child's initial position to be out of the center of the parent
        gsap.set(child, {
            x: goalX,
            y: goalY,
        });
        // create a timeline for the child
        let childTimeline = gsap.timeline({
            scrollTrigger: {
                trigger: document.body,
                start: "top bottom",
                end: "bottom bottom",
                scrub: true,
            },
        });
        // animate the child to its default position as the user scrolls
        childTimeline.to(child, {
            x: 0,
            y: 0,
            duration: 1,
            ease: "none",
        });
    });
}
function animate() { }