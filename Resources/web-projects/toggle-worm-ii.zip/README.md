# Toggle Worm (II)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/bGJegbe](https://codepen.io/alvaromontoro/pen/bGJegbe).

Inspired by Josetxu's Worm Toggle: https://codepen.io/josetxu/pen/QWPNWNa