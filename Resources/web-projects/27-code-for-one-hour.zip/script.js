const canvas = document.getElementById("hourOfCode");
const ctx = canvas.getContext("2d");
const font = "3em VT323";
const txtColor = "#00ff00";
const cols = 200;
const delay = 30;
const spacingY = 30;

let txtCols = [];

class Txt {
  constructor() {
    this.size = Math.floor(Math.random() * 3) + 1;
    this.blurFactor = 20;
    this.length = Math.floor(Math.random() * 10) + 20;
    this.txt = this.generateRandomText();
    this.x = Math.random() * canvas.width;
    this.y = this.newHeight();
    this.height = Math.floor(Math.random() * 5) + 1;
    this.speed = Math.random() * 5 + 1;
    this.darkness = Math.random() * 0.5 + 0.5;
  }

  generateRandomText() {
    let length = this.length;
    return Array.from({ length }, () => {
  const randomCharCode = Math.floor(Math.random() * (126 - 33 + 1)) + 33; 
  return String.fromCharCode(randomCharCode);
}).join('');
  }

  draw() {
    this.setDrawingStyles();
    for (let i = 0; i < this.txt.length; i++) {
      ctx.fillText(this.txt[i], this.x, this.y + i * spacingY);
    }
    this.update();
  }

  setDrawingStyles() {
    ctx.font = `${this.size}em VT323`;
    ctx.shadowBlur = this.size * this.blurFactor;
    ctx.fillStyle = `rgba(0, ${255 * (1 - Math.min(this.y / canvas.height, 1)) * this.darkness}, 0, 1)`;
  }

  update() {
    if (this.y > canvas.height + spacingY * this.length) {
      this.resetPosition();
    }
    this.y += this.speed;
  }

  resetPosition() {
    this.y = -this.size * spacingY - spacingY * this.length;
    this.x = Math.random() * canvas.width;
    this.height = this.newHeight();
    this.speed = Math.random() * 5 + 1;
    this.darkness = Math.random() * 0.5 + 0.5;
  }

  newHeight() {
    return -this.size * spacingY - Math.floor(Math.random() * 30) * spacingY;
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let i = 0; i < cols; i++) {
    txtCols[i].draw();
  }
  setTimeout(() => requestAnimationFrame(draw), delay);
}

function init() {
  createTxtCols();
  requestAnimationFrame(draw);
}

function createTxtCols() {
  for (let i = 0; i < cols; i++) {
    txtCols.push(new Txt());
  }
}

document.addEventListener("DOMContentLoaded", init);