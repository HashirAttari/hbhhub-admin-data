# Popout Text with Background Image Shadow

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/xympyG](https://codepen.io/markmead/pen/xympyG).

Cutting out text from a background and then having it "popout" similar to how text shadow can be used. In fact, this does make use of text shadow!