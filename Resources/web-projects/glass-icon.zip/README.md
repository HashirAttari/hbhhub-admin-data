# Glass Icon

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/MWqOxwe](https://codepen.io/jkantner/pen/MWqOxwe).

A skeuomorphic icon design based on [this Dribbble shot](https://dribbble.com/shots/18146372-Glass-Icon) by Sandor.