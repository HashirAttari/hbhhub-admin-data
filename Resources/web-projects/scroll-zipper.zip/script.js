var lastScrollTop = 0;
window.addEventListener(
  "scroll",
  () => {
    document.body.style.setProperty(
      "--scroll",
      (window.pageYOffset / (document.body.offsetHeight - window.innerHeight)) *
        100
    );
    var pos = window.pageYOffset || document.documentElement.scrollTop;
    if (pos > lastScrollTop)
      document.querySelector(".pull-tab").classList.remove("up");
    else document.querySelector(".pull-tab").classList.add("up");
    lastScrollTop = pos <= 0 ? 0 : pos;
    if (document.body.style.getPropertyValue("--scroll") == 0)
      document.querySelector(".pull-tab").classList.remove("up");
    if (document.body.style.getPropertyValue("--scroll") == 100)
      document.querySelector(".pull-tab").classList.add("up");
  },
  false
);

setTimeout(function () {
  window.scrollTo({
    top: 500,
    behavior: "smooth"
  });
}, 500);