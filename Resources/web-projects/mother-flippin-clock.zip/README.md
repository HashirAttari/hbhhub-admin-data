# Mother Flippin Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/rikschennink/pen/AeWJjr](https://codepen.io/rikschennink/pen/AeWJjr).

A flip clock, you could easily add other animations by adjusting the CSS.

Not supported on browsers that don't support animation of pseudo elements.

Apparently this no longer works on Chrome.