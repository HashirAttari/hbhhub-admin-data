const b = document.body;
const h = document.querySelector("#h");
const unit = 1.7;
const bioshock = document.querySelector("#bioshock");
const img = document.querySelector("#img");
const video = document.querySelector("#video");
const tv = document.querySelector("#screen");

const playFunc = () => {
	b.removeEventListener("pointermove", base);
	bioshock.removeEventListener("click", playFunc);

	img.classList.add("is-element-hidden");
	video.classList.remove("is-element-hidden");
	h.classList.add("is-main-active");

	video.load();
};
const stopFunc = () => {
	b.addEventListener("pointermove", base);
	bioshock.addEventListener("click", playFunc);

	img.classList.remove("is-element-hidden");
	video.classList.add("is-element-hidden");
	h.classList.remove("is-main-active");

	video.pause();
	video.currentTime = 0;
};

const base = (e) => {
	var x = e.pageX / window.innerWidth - 0.5;
	var y = e.pageY / window.innerHeight - 0.5;
	h.style.transform = `
        perspective(${400 * unit}vmin)
        rotateX(${y * 4 + 66}deg)
        rotateZ(${-x * 24 + 35}deg)
        translateZ(${-14 * unit}vmin)
    `;
};

b.addEventListener("pointermove", base);
bioshock.addEventListener("click", playFunc);
tv.addEventListener("click", stopFunc);
video.addEventListener("ended", stopFunc);