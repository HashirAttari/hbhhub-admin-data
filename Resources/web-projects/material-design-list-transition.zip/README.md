# Material Design List Transition

A Pen created on CodePen.io. Original URL: [https://codepen.io/davidkpiano/pen/RwmdVz](https://codepen.io/davidkpiano/pen/RwmdVz).

Inspired by Android L Material Design

Forked from [Will Chowattanakul](http://codepen.io/nroviw/)'s Pen [Material Design List Transition](http://codepen.io/nroviw/pen/kCazJ/).