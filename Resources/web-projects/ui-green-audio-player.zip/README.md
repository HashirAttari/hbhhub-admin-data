# UI: Green Audio Player

A Pen created on CodePen.io. Original URL: [https://codepen.io/emilcarlsson/pen/qpmdXj](https://codepen.io/emilcarlsson/pen/qpmdXj).

An audio player written in javascript by Greg Hovanesyan, free for stealing and modifying