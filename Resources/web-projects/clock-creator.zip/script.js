function Clock() {
var TimeClock = document.getElementById('TimeClock');
var TC =document.getElementById('TimeClock').style;
var today=new Date();    
var day = today.getSeconds();
var mo = today.getMinutes();
var y = today.getHours();          
TimeClock.innerHTML = '<span id="clockTitle">' + document.getElementById('Title').value + '</span><div>' + y + ':' + mo + ':' + day + '</div>'; 

TC.background=document.getElementById('color').value;
TC.width=document.getElementById('Width').value + 'px';
TC.height=document.getElementById('Height').value+ 'px';
TC.fontSize=document.getElementById('FontSize').value+ 'px';
TC.color=document.getElementById('FontColor').value;
TC.borderRadius=document.getElementById('BorderRadius').value + '%';
TC.borderColor=document.getElementById('BorderColor').value;
t = setTimeout(function(){Clock()} ,10);
} 

function Clocky() {
var Script = "<script&gt;function Clock() {var today=new Date();var day = today.getSeconds();var mo = today.getMinutes();var y = today.getHours();document.getElementById('TimeClock').lastChild.innerHTML = '<div>' + y + ':' + mo + ':' + day + '</div>'; t = setTimeout(function(){Clock()} ,10);}</script&gt;"; 
var Code = document.getElementById('FullCode').innerHTML;
Code2 = Code.replace("<span id" ,"<script&gt;Clock()</script&gt;<span id"); 
Code3 = Code2.replace(/&gt;/g ,">"); 
Script2 = Script.replace(/&gt;/g ,">"); 
document.getElementById('code').value = Script2 + Code3;
}

function Select(a){a.select();}