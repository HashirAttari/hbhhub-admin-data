# Dynamic Instagram Username

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/wvXemqx](https://codepen.io/chrisgannon/pen/wvXemqx).

A dynamic animation that displays an Instagram username. 