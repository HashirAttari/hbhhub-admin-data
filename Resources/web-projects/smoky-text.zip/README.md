# Smoky Text

A Pen created on CodePen.io. Original URL: [https://codepen.io/bennettfeely/pen/nZXRyJ](https://codepen.io/bennettfeely/pen/nZXRyJ).

Combining text-shadow and CSS transforms (especially skew) for a smoky (or smokey?) effect.

Webfont Finger Paint (http://www.google.com/fonts/specimen/Finger+Paint)