# 24

A Pen created on CodePen.io. Original URL: [https://codepen.io/PicturElements/pen/JYyjYL](https://codepen.io/PicturElements/pen/JYyjYL).

