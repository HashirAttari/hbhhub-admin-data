# Path 2.0 Flyout Menu using CSS 

A Pen created on CodePen.io. Original URL: [https://codepen.io/sparanoid/pen/nPopbG](https://codepen.io/sparanoid/pen/nPopbG).

Demo: http://sparanoid.com/lab/path-menu/

Dribbble page: http://drbl.in/cwcK