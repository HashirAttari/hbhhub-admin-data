# Valentine's Day Terminal | Pure CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/mikemang/pen/jyJNWZ](https://codepen.io/mikemang/pen/jyJNWZ).

Learn How to Make These Graphics: https://medium.com/coding-artist/a-beginners-guide-to-pure-css-images-ef9a5d069dd2