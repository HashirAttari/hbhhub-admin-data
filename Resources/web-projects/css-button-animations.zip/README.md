# CSS Button Animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/atloomer/pen/JEaRWX](https://codepen.io/atloomer/pen/JEaRWX).

Playing around with some CSS button transitions.  Possible repo for future use.  Learning experience for me dealing with browser compatibility.
