# SVG Morphing Quarters

A Pen created on CodePen.io. Original URL: [https://codepen.io/brenna/pen/KKOYvX](https://codepen.io/brenna/pen/KKOYvX).

I am a fan of SVG. 

[Bees and Bombs](http://beesandbombs.tumblr.com/) makes rad geometric gifs. 

So I recreated [this gif](http://beesandbombs.tumblr.com/post/101579804084/quarters) in SVG.  

The initial SVG code is one quartered circle that morphs into outward facing quarters with SMIL animations. That circle is then cloned, translated and appended in JavaScript, using the 'begin" attribute to offset animation in concentric diamonds.

Thanks to [Dave Whyte (Bees and Bombs)](https://twitter.com/beesandbombs) for the creativity and [Tab Atkins](https://twitter.com/tabatkins) for some grid algorithm help.