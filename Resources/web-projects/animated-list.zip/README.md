# Animated List

A Pen created on CodePen.io. Original URL: [https://codepen.io/code_dependant/pen/RwKpdY](https://codepen.io/code_dependant/pen/RwKpdY).

Experimenting with list interactions using css animations.

Disclaimer: Far from robust or bug free, but does succeed in demonstrating the concept