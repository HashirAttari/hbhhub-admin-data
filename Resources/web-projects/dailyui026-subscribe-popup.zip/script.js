setTimeout(function(){$('.subscribe').css('top','0');$('.subscribe').css('opacity','1')},200)
$('p').click(function(){$('.subscribe').css('top','-550px');$('.subscribe').css('opacity','0')})
$('button').click(function(){$('h1,h2,button,input').css('opacity','0');setTimeout(function(){$('span').css('opacity','1')},2000);})