$(document).ready(function() {
  var output = "",
    operators = [".", "+", "-", "*", "/", "%"];

  function checkInput(input) {
    //console.log(output);
    //console.log(output.slice(-1), output.slice(-2), output.slice(-2, -1));

    for (var i = 0; i < operators.length; i++) {
      if (
        output.slice(-1) === operators[i] &&
        output.slice(-2, -1) === operators[i]
      ) {
        output = output.slice(0, -1);
        setTimeout(function() {
          //console.log(output);
          $("#output").html(output);
        }, 1000);
      } else {
        $("#output").html(output);
      } //ELSE
    } //for
  } //CHECK INPUT FUNCTION

  $(".btn").click(function() {
    //console.log($(this).attr('id'));
    var userInput = $(this).attr("value");
    if ($(this).attr("value") === "AC") {
        output = "";
        $("#output").html(output);
      } else if (output.length >= 9) {
      $("#output").html("<span>Too Many Characters</span>");
      if (userInput === "CE") {
        output = output.slice(0, -1);
        $("#output").html(output);
      }
    } else {
      if ($(this).attr("value") === "AC") {
        output = "";
        $("#output").html(output);
      } else if (userInput === "CE") {
        output = output.slice(0, -1);
        $("#output").html(output);
      } else if (userInput === "=") {
        $("#output").html(eval(output));
        
      } else {
        output += userInput;
        checkInput(userInput);
      } //ELSE
    } //ELSE
  }); // BTN CLICK FUNCTION
}); //DOCUMENT READY