# NEU KEYBOARD 

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/LYVoqyy](https://codepen.io/MananTank/pen/LYVoqyy).

Recreating my 60% keyboard in CSS