# Shadow cast spotlight

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/XWdRwrm](https://codepen.io/agalliat/pen/XWdRwrm).

