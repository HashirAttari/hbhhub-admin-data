# #codevember14 - CHEESE

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/YExpoX](https://codepen.io/run-time/pen/YExpoX).

A simple little one line javascript which can be run in the console to rain pizza on any webpage.  enjoy!