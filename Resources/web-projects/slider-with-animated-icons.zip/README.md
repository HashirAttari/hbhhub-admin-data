# Slider with animated icons

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/VwgQGxz](https://codepen.io/aaroniker/pen/VwgQGxz).

 icons from: iconists.co