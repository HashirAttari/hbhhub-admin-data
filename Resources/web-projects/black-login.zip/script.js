/*

Inspired by Alex Sadeck work: http://dribbble.com/shots/853912-Black-Login-Freebie  

Feel free to fork it and make it better, Need some clean in the Css but for now my eyes are burning :)

---------------------------------------------
Pure CSS GUI icons 
By Nicolas Gallagher
***modified***
Demo for Pure CSS GUI icons (experimental).

Tested in: Firefox 3.5+, Chrome 5, and Opera 10.6.

84 GUI icons created from semantic HTML.


http://nicolasgallagher.com/pure-css-gui-icons/demo/


*/