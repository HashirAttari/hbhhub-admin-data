// -# ==========================================================================
// -# Collection Builder | Version 1.0
// -# Author: Jamie Coulter
// -# ==========================================================================

// =============================================================================
// Init
// =============================================================================

collection_count = 0; // Default collection total item count
search_count = $('.items_box__item').length; // Initial Search results count
addable = 1; // Set item addable

// Debug
debug = 'true'; // Set console logs on/off

// =============================================================================

// =============================================================================
// HTML blocks
// =============================================================================

function update_blocks() {
    // Empty slot Html
    empty_slot_block = '<div class="empty_slot"><div class="empty_slot__image">+</div><div class="empty_slot__title"></div><div class="empty_slot__desc"></div></div></div>'

    // List item Html
    list_item = '<div class="list_box__item"><div class="list_image"><img src="' + clicked_image + '"></div><div class="list_info"><h3>' + clicked_title + '</h3><h4>' + clicked_description + '</h4><div class="caret collection_caret"></div></div><div class="list_options"><div class="clone_icon"><div class="tooltip">Clone item</div><img class="clone" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/copy_icon.png"></div><div class="delete_icon"><div class="tooltip">Remove item</div><img class="delete" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/delete_icon.png"></div></div><div class="long_description">' + clicked_description_long + '</div></div>'

    // List item clone Html
    list_item_cloned = '<div class="list_box__item cloned"><div class="list_image"><img src="' + clicked_image + '"></div><div class="list_info"><h3>' + clicked_title + '</h3><h4>' + clicked_description + '</h4><div class="caret collection_caret"></div></div><div class="list_options"><div class="clone_icon"><div class="tooltip">Clone item</div><img class="clone" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/copy_icon.png"></div><div class="delete_icon"><div class="tooltip">Remove item</div><img class="delete" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/delete_icon.png"></div></div><div class="long_description">' + clicked_description_long + '</div></div>'

    // Html that is appended back to search results
    result_item = '<div class="items_box__item"><div class="item_image"><img src="' + clicked_image + '"></div><div class="item_info"><h3>' + clicked_title + '</h3><h4>' + clicked_description + '</h4><div class="caret"></div><span class="add">Add to list<span class="add_plus">+</span></span><div class="long_description">' + clicked_description_long + '</div></div></div>'

    // Used up all search results message
    used_up_message = "<span class='used_up'><img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/search_icon.png'/><br/><br/>Looks like you've used up all your search results, try searching for something else</span>";
}

// =============================================================================

// =============================================================================
// Search placeholder
// =============================================================================

default_search_string = $('.search_again input').val(); // Set the inital search placeholder value

$('.search_again input').focus(function() { // On input focus
    if ($(this).val() == default_search_string) { // If it's still the original value
        $(this).val('') // Set the value to null
    }
});

$('.search_again input').blur(function() { // On input blur
    if ($(this).val() == '') { // If nothing has been entered
        $(this).val(default_search_string) // Set the value back to the original value
    }
});

// =============================================================================

// =============================================================================
// Update positions
// =============================================================================

function update_positions(el) {

    // Container position
    container_top = $('.container_inner').offset().top; // Get top
    container_left = $('.container_inner').offset().left; // Get left

    // Placeholder position
    placeholder_top = $('.empty_slot__image').offset().top - container_top; // Get distance from top of container to placeholder
    placeholder_left = $('.empty_slot__image').offset().left - container_left; // Get distance from left of container to placeholder

    // Current image position
    curr_top = $(el).find('.item_image').offset().top - container_top; // Get distance from top of container to source image
    curr_left = $(el).find('.item_image').offset().left - container_left; // Get distance from left of container to source image

}

// =============================================================================

// =============================================================================
// Update details
// =============================================================================

function grab_details(prop) {
    clicked_image = $(prop).find('img').attr('src'); // Get the image
    clicked_title = $(prop).find('h3').html(); // Get the title
    clicked_description = $(prop).find('h4').html(); // Get the short description
    clicked_description_long = $(prop).find('.long_description').html(); // Get the long description
}

// =============================================================================

// =============================================================================
// Update collection count
// =============================================================================

function update_collection_count() {
    $('.list_done span').html(collection_count)
}

// =============================================================================

// =============================================================================
// Description drop down
// =============================================================================

$('.caret').each(function() { // Each drop down icon
    $(this).data('opened', '0'); // Set default value
});

function reset_descriptions() {
    $('.caret').each(function() { // Each drop down icon
        $(this).data('opened', '0'); // Set default value
        $(this).css('transform', 'rotate(0deg)'); // Flip the caret
        $(this).next().next().css('height', '0px'); // Reset the height
    });
}

// On click
$(document).on('click', '.caret', function(event) { // On click
    if ($(this).data('opened') == 0) { // If not open
        $(this).data('opened', '1'); // Set data variable
        if (!$(this).hasClass('collection_caret')) {
            console.log('This is in the right column')
            $(this).next().next().css('height', 'auto'); // Set height to auto
        } else {
            console.log('This is in the left column')
            $(this).parent().next().next().css('height', 'auto'); // Set height to auto
        }
        $(this).css('transform', 'rotate(180deg)'); // Flip the caret
    } else { // If open
        $(this).data('opened', '0'); // Set data variable
        if (!$(this).hasClass('collection_caret')) {
            console.log('This is in the right column')
            $(this).next().next().css('height', '0px'); // Reset the height
        } else {
            console.log('This is in the left column')
            $(this).parent().next().next().css('height', '0px'); // Set height to auto
        }
        $(this).css('transform', 'rotate(0deg)'); // Flip the caret
    }
});

// =============================================================================

// =============================================================================
// Add button hover
// =============================================================================

// Hover over button
$(document).on('mouseenter', '.add', function(event) { // On hover
    $('.list_box').stop(true).animate({
        'opacity': '0.65'
    }, 100); // Animate the opacity of the current list - left
    $('.empty_slot').stop(true).animate({
        'opacity': '1'
    }, {
        queue: false,
        duration: 100
    }); // Fade in the empty slot div
    $('.empty_slot__image').stop(true).animate({
        'margin-left': '0px'
    }, {
        queue: false,
        duration: 100
    }); // Move in the empty slot div
});

// Hover off button
$(document).on('mouseleave', '.add', function(event) { // On hover off
    $('.list_box').stop(true).animate({
        'opacity': '1'
    }, 100); // Animate the opacity of the current list back to original
    $('.empty_slot').stop(true).animate({
        'opacity': '0'
    }, {
        queue: false,
        duration: 100
    }); // Fade out the empty slot div
    $('.empty_slot__image').stop(true).animate({
        'margin-left': '-10px'
    }, {
        queue: false,
        duration: 100
    }); // Move out the empty slot div
});

// =============================================================================

// =============================================================================
// Clone
// =============================================================================

$(document).on('click', '.clone', function(event) {

    // Set variables
    clone = $(this).parent().parent().parent(); // Set clone source
    cloned_height = $(clone).outerHeight(); // Get the height of the original source
    grab_details(clone); // Grab details from the clicked element
    collection_count++; // Increase collection count
    update_collection_count(); // Update the create button
    update_blocks(); // Update Html blocks with variables

    // Append clone
    $(list_item_cloned).insertAfter($(clone))

    // Animate in clone
    $('.cloned').animate({
        'height': cloned_height
    }, 300); // Animate the height of the clone to original source
    $('.cloned').animate({
        'padding': '16px 10px 3px 10px'
    }, 300); // Animate the padding of the clone to original source
    $('.cloned').animate({
        'opacity': '1'
    }, 300); // Fade in clone

    setTimeout(function() { // After 100ms
        // Pop up the item details
        $('.list_info h3').animate({
            'top': '0px'
        }, {
            queue: false
        }); // Animate the title up
        $('.list_info h3').animate({
            'opacity': '1'
        }, {
            queue: false
        }); // Fade in the title
    }, 550);

    setTimeout(function() { // After 100ms
        // Pop up the item details
        $('.list_info h4').animate({
            'top': '0px'
        }, {
            queue: false
        }); // Animate the description up
        $('.list_info h4').animate({
            'opacity': '1'
        }, {
            queue: false
        }); // Fade in the description

        // Pop up the icons
        $('.clone').css('transform', 'scale(1.3)'); // Pop up clone icon
        $('.delete').css('transform', 'scale(1.3)'); // Pop up delete icon
    }, 650);

    setTimeout(function() { // After 100ms
        // Pop up the icons
        $('.clone').css('transform', 'scale(1)'); // Pop up clone icon
        $('.delete').css('transform', 'scale(1)'); // Pop up delete icon
    }, 850);

});

// =============================================================================

// =============================================================================
// Delete
// =============================================================================

$(document).on('click', '.delete', function(event) {

    // Set variables
    del = $(this).parent().parent().parent(); // Set deleted element

    if (search_count == 0) { // If was previously empty
        update_blocks(); // Update Html blocks with variables
        $('.list_box').append(empty_slot_block)
    }

    $('.used_up').remove(); // Remove used up message from the DOM

    setTimeout(function() { // After 200ms
        $(del).animate({
            'opacity': '0'
        }, 400); // Fade out the deleted element
        $(del).animate({
            'margin-left': '20px'
        }, {
            queue: false,
            duration: 400
        }); // Move out the deleted element
    }, 200);
    setTimeout(function() { // After 600ms
        $(del).animate({
            'height': '0px'
        }, {
            queue: false
        }, 1000); // Animate the height of the deleted element to 0
        $(del).animate({
            'padding': '0px'
        }, {
            queue: false
        }, 1000); // Animate the padding of the deleted element to 0
        $(del).animate({
            'margin-bottom': '0px'
        }, {
            queue: false
        }, 1000); // Animate the margin of the deleted element to 0

        // Update collection
        collection_count--; // Decrease the collection item count
        update_collection_count(); // Update the create button

        // Grab details
        grab_details(del); // Get the details of the deleted item - as we will append back to the other list

        // If collection is now empty
        if (collection_count == 0) { // If empty
            $('.list_box h5,.list_box h6').show(); // Show the original message
        }


    }, 600);

    // Append the deleted item back to the results
    setTimeout(function() { // After 1000ms
        if (!$(del).hasClass('cloned')) { // Make sure the item being appended isnt a clone, ignore all clones
            // Increase search count
            search_count++; // Add to search count
            update_blocks(); // Update Html blocks with variables
            $('.items_box').append(result_item); // Append
            reset_descriptions(); // Reset description dropdowns
        }
        $(del).remove(); // Remove deleted item from the DOM
    }, 1000);

});

// =============================================================================

// =============================================================================
// Add
// =============================================================================

$(document).on('click', '.add', function(event) {

    if (addable == 1) {

        addable = 0; // Stop double clicking

        // Set variables
        add = $(this).parent().parent(); // Set added item

        $('.list_box h5,.list_box h6').hide(); // Hide the default message

        setTimeout(function() { // After 200ms
            $(add).animate({
                'opacity': '0'
            }, 400); // Fade out the added item
            $(add).animate({
                'margin-left': '20px'
            }, {
                queue: false,
                duration: 400
            }); // Move in the added item
        }, 200);

        setTimeout(function() { // After 600ms
            $(add).delay(600).animate({
                'height': '0px'
            }, {
                queue: false
            }, 1000); // Animate the height of the added item to 0
            $(add).delay(500).animate({
                'padding': '0px'
            }, {
                queue: false
            }, 1000); // Animate the padding of the added item to 0
            $(add).delay(500).animate({
                'margin-bottom': '0px'
            }, {
                queue: false
            }, 1000); // Animate the margin of the added item to 0
        }, 600);

        update_positions(add); // Update positions

        // Get clicked information
        grab_details(add); // Grab details of added item

        // Append a clone
        $(add).append('<img class="cloned_image" src="' + clicked_image + '"/>'); // Append a clone img with the same src

        // Animate to placeholder
        $(add).find('.cloned_image').delay('700').animate({
            opacity: 0
        }); // Fade out item
        $(add).find('.cloned_image').css('position', 'absolute'); // Set image to absolute
        $(add).find('.cloned_image').css('top', curr_top); // Set initial position.top
        $(add).find('.cloned_image').css('left', curr_left); // Set initial position.left
        $(add).find('.cloned_image').animate({
            'top': placeholder_top
        }, {
            queue: false,
            duration: 400
        }); // Animate to placeholder
        $(add).find('.cloned_image').animate({
            'left': placeholder_left
        }, {
            queue: false,
            duration: 460,
            easing: 'easeOutExpo'
        }); // Animate to placeholder

        // Append new placeholder
        setTimeout(function() { // After 400ms
            $('.empty_slot').remove(); // Remove empty slot div

            update_blocks(); // Update Html blocks with variables

            // Add the item to the collection list
            $('.list_box').append(list_item + empty_slot_block);
            reset_descriptions(); // Reset description dropdowns

            // Pop up the item details
            $('.list_info h3').animate({
                'top': '0px'
            }, {
                queue: false
            }); // Animate the title up
            $('.list_info h3').animate({
                'opacity': '1'
            }, {
                queue: false
            }); // Fade in the title

            setTimeout(function() { // After 100ms
                // Pop up the item details
                $('.list_info h4').animate({
                    'top': '0px'
                }, {
                    queue: false
                }); // Animate the description up
                $('.list_info h4').animate({
                    'opacity': '1'
                }, {
                    queue: false
                }); // Fade in the description

                // Pop up the icons
                $('.clone').css('transform', 'scale(1.3)'); // Pop up clone icon
                $('.delete').css('transform', 'scale(1.3)'); // Pop up delete icon

                // Decrease search count
                search_count--; // Subtract from items in search results

                setTimeout(function() { // After 300ms
                    // Scale down icones
                    $('.clone').css('transform', 'scale(1)'); // Pop up clone icon
                    $('.delete').css('transform', 'scale(1)'); // Pop up delete icon

                    // Increase collection count
                    collection_count++; // Increase collection item count
                    update_collection_count(); // Update create button

                    // Check if search results are empty
                    if (search_count == 0) { // If nothing is there
                        $('.empty_slot').remove(); // Remove the empty slot
                        update_blocks(); // Update Html blocks with variables
                        $('.items_box').append(used_up_message); // Append message
                        $('.used_up').fadeIn(200); // Fade message in
                    }

                }, 300);

            }, 100);

            $('.cloned_image').remove(); // Remove cloned image from DOM

            setTimeout(function() { // Allow adding of items again - Stops user clicking mulitple times
                addable = 1; // Make clickable again
            }, 600);

        }, 400);

        if (debug == 'true') {
            console.log(add)
            console.log('----------------------------------------'); // Sep
            console.log('Item ' + clicked_title + ' has been added to the collection'); // Log item name
            console.log('----------------------------------------'); // Sep
            console.log('The short description is ' + clicked_description); // Log item short description
            console.log('----------------------------------------'); // Sep
            console.log('The image url is ' + clicked_image); // Log item image url
            //console.log('----------------------------------------'); // Sep
            //console.log('The long description is ' + clicked_description_long); // Log item long description
        }

    } else {
        if (debug == 'true') {
            console.log('Clicking too fast')
        }
    }
});

// =============================================================================
// Creation steps
// =============================================================================

function begin_creation() {

    // Intro page only
    $('.current_step').fadeIn(); // Fade in the first step

    setTimeout(function() { // After 1200ms
        $('.current_step .begin_button').animate({
            'top': '0px'
        }); // Animate in the button
        $('.current_step .begin_button').animate({
            'opacity': '1'
        }); // Animate in the button
    }, 1200);

}

// Init
begin_creation(); // Start process

$('.current_step .begin_button').click(function() { // When a button is clicked in the step

    $('.welcome_path').attr("class", 'welcome_path-rev'); // Reverse the 1st step animation

    setTimeout(function() { // After 300ms
        $('.container_intro__inner .begin_button').animate({
            'top': '6px',
            'opacity': '0'
        }); // Animate in the button
    }, 300);

    setTimeout(function() { // After 800ms
        $('.current_step').removeClass('current_step').next().addClass('current_step'); // Remove active step and append to the next
    }, 800)

    setTimeout(function() {

        $('.current_step').show().css('opacity', '1');

        setTimeout(function() {
            $('.current_step h2').animate({
                'opacity': '1',
                'left': '0px'
            });
        }, 400);

        setTimeout(function() {
            $('.current_step p').animate({
                'opacity': '1',
                'left': '0px'
            });
        }, 500);

        setTimeout(function() {
            $('.current_step input').animate({
                'opacity': '1',
                'left': '0px'
            });
        }, 700);

        setTimeout(function() {
            $('.current_step label').animate({
                'opacity': '1',
                'left': '0px'
            });
        }, 600);

        setTimeout(function() {
            $('.current_step .next_button').animate({
                'opacity': '1',
                'left': '0px'
            });
        }, 800);

    }, 900)

});

$('.next_button').click(function() { // When a button is clicked in the step

    $('.current_step h2').animate({
        'opacity': '0',
        'left': '-10px'
    });

    setTimeout(function() {
        $('.current_step p').animate({
            'opacity': '0',
            'left': '-10px'
        });
    }, 100);

    setTimeout(function() {
        $('.current_step input').animate({
            'opacity': '0',
            'left': '-10px'
        });
    }, 200);

    setTimeout(function() {
        $('.current_step label').animate({
            'opacity': '0',
            'left': '-10px'
        });
    }, 300);

    setTimeout(function() {
        $('.current_step .next_button').animate({
            'opacity': '0',
            'left': '-10px'
        });
    }, 400);

    setTimeout(function() {
        $('.current_step').hide().removeClass('current_step').next().addClass('current_step'); // Remove
        $('.current_step').show().css('opacity', '1');
    }, 500)

    setTimeout(function() {
        $('.current_step h2').animate({
            'opacity': '1',
            'left': '0px'
        });
    }, 600);

    setTimeout(function() {
        $('.current_step p').animate({
            'opacity': '1',
            'left': '0px'
        });
    }, 700);

    setTimeout(function() {
        $('.current_step input').animate({
            'opacity': '1',
            'left': '0px'
        });
    }, 800);

    setTimeout(function() {
        $('.current_step label').animate({
            'opacity': '1',
            'left': '0px'
        });
    }, 900);

    setTimeout(function() {
        $('.current_step .next_button').animate({
            'opacity': '1',
            'left': '0px'
        });
    }, 1000);

    setTimeout(function() {
        if ($('.current_step').hasClass('end_step')) {
            preloader_timer()
        }
    }, 1100);

});

// Search preloader
function preloader_timer() {
    setTimeout(function() {
        $('.container_inner').show()
        $('.container_intro').animate({
            'top': '-100%'
        })
    }, 2400)
}

// =============================================================================

// =============================================================================
// To do
// =============================================================================

/* 
  Set up descriptions for the left section
  Add in edit icons for everything - edit and save
  Cloning when desc is open causes issues 
  Add custom item
  Responsivity
  Category
  validation
*/

// =============================================================================