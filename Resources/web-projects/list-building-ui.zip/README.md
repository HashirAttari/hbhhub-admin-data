# List Building UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/YXajQg](https://codepen.io/jcoulterdesign/pen/YXajQg).

Im rebuilding the UI of a personal project. Not CB Tested at all yet!