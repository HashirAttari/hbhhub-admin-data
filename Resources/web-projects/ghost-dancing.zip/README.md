# Ghost dancing

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/yRJXBb](https://codepen.io/yuanchuan/pen/yRJXBb).

Ghosts CodePen Challenge