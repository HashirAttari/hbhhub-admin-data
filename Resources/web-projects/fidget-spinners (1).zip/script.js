const returnSpinner = (color, hw = 78) => {
  return `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100' height='${hw}px' width='${hw}px' fill='${color}'%3E%3Cg class='spinner'%3E%3Cpath d='M 36 42 C 40 34 32 28 32 20 A 1 1 0 0 1 68 20 C 68 28 60 34 64 42 C 68.856 49.34 78.053 45.412 84.981 49.412 A 1 1 0 0 1 66.981 80.588 C 60.053 76.588 58.856 66.66 50 66 C 41.144 66.66 39.947 76.588 33.019 80.588 A 1 1 0 0 1 15.019 49.412 C 21.947 45.412 31.144 49.34 36 42 M 78.481 60.67 A 1 1 0 0 0 73.481 69.33 A 1 1 0 0 0 78.481 60.67 M 45 20 A 1 1 0 0 0 55 20 A 1 1 0 0 0 45 20 M 26.519 69.33 A 1 1 0 0 0 21.519 60.67 A 1 1 0 0 0 26.519 69.33' stroke='rgba(0,0,0,0.3)' stroke-width='2' /%3E%3Cg id='bearing'%3E%3Ccircle cx='50' cy='20' r='10' fill='none' stroke='silver' stroke-width='2' /%3E%3Ccircle cx='50' cy='20' r='7' fill='none' stroke='%23111' stroke-width='4' /%3E%3Ccircle cx='50' cy='20' r='5' fill='none' stroke='silver' stroke-width='2' /%3E%3C/g%3E%3Cuse href='%23bearing' transform='rotate(120 50 50)' /%3E%3Cuse href='%23bearing' transform='rotate(240 50 50)' /%3E%3Ccircle cx='50' cy='50' r='12' stroke='rgba(0,0,0,0.3)' stroke-width='1.2' /%3E%3CanimateTransform class='ballAnim' attributeName='transform' attributeType='XML' type='rotate' values='0 50 50; 1800 50 50' dur='4000ms' begin='0s' repeatCount='indefinite' fill='freeze' keyTimes='0;1' keySplines='0.25 0.1 0.25 1' calcMode='spline' /%3E%3C/g%3E%3C/svg%3E`;
};
function percentX(percent) {
	return Math.round((percent / 100) * window.innerWidth);
}
function percentY(percent) {
	return Math.round((percent / 100) * window.innerHeight);
}

// return a random integer between two values, inclusive
function randInt(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

const Engine = Matter.Engine,
	Bodies = Matter.Bodies,
	Body = Matter.Body,
	Svg = Matter.Svg,
	Vertices = Matter.Vertices,
	Constraint = Matter.Constraint,
	Composite = Matter.Composite,
	Mouse = Matter.Mouse,
	MouseConstraint = Matter.MouseConstraint,
	Render = Matter.Render,
	Runner = Matter.Runner;
let spinners = [];
// create an engine
const engine = Engine.create(),
	world = engine.world;

// create a renderer
const render = Render.create({
	element: document.body,
	engine: engine,
	options: {
		wireframes: false,
		showInternalEdges: false,
		width: percentX(100),
		height: percentY(100),
		background: "transparent"
	}
});

let bodies = [],
	bgColor = "#0A0618";

let mul = 1;
function addEvtListener() {
  document.querySelector('canvas').addEventListener("click", function () {
    for (let i = 0; i < spinners.length; ++i) {
      let rr = randInt(1, 2);
      if (rr == 1) {
        mul = -1;
      } else {
        mul = 1;
      }
      //spins between 1 and 4 rotations
      Body.setAngularVelocity(spinners[i], Math.PI / randInt(mul * 1, mul * 4));
      //jumps to random x and y coordinates
      Body.setVelocity(spinners[i], { x: randInt(-10, 10), y: randInt(-10, 10) });
    }
  });
}

// boundaries

let ceiling = Bodies.rectangle(
	percentX(100) / 2,
	percentY(0) - 100,
	percentX(100),
	200,
	{ isStatic: true }
);
let floor = Bodies.rectangle(
	percentX(100) / 2,
	percentY(100) + 100,
	percentX(100),
	200,
	{ isStatic: true }
);
let rightWall = Bodies.rectangle(
	percentX(100) + 100,
	percentY(100) / 2,
	200,
	percentY(100),
	{ isStatic: true }
);
let leftWall = Bodies.rectangle(
	percentX(0) - 100,
	percentY(100) / 2,
	200,
	percentY(100),
	{ isStatic: true }
);
ceiling.render.visible = false;
floor.render.visible = false;
rightWall.render.visible = false;
leftWall.render.visible = false;
bodies.push(ceiling);
bodies.push(floor);
bodies.push(rightWall);
bodies.push(leftWall);

// add walls to world
Composite.add(world, bodies);

// SVGs
let vertexSets = [],
	svgOne,
	svgTwo,
	svgThree,
	svgThreeLegOne,
	svgThreeLegTwo,
	svgThreeCounter,
	svgFour,
	svgFourCounter;

let cX = percentX(20);
let cY = percentY(20);

let iX = percentX(40);
let iY = percentY(30);

let aX = percentX(60);
let aY = percentY(20);

let aXLegOne = aX - 43;
let aYLegOne = aY + 49;

let aXLegTwo = aX + 43;
let aYLegTwo = aY + 49;

let oX = percentX(80);
let oY = percentY(30);
let lX = percentX(90);
let lY = percentY(30);

// let letterSize = (window.innerWidth / 1000);

let letterSizeHorizontal = 0.8,
	letterSizeVertical = 0.8;

// converting an svg path string to an svg path to add to a 
function createSVGPath(pathD) {
	const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
	path.setAttributeNS(null, "d", pathD);
	return path;
}

function go(stringsArr) {
	for (let i=0; i<20; i++) {
		let shapeColor = `rgb(${randInt(0,255)}, ${randInt(0,255)}, ${randInt(0,255)})`;
		spinners[i] = Matter.Bodies.fromVertices(
			randInt(percentX(5),percentX(100)),
			randInt(percentY(5),percentY(100)),
			Matter.Vertices.scale(
				Svg.pathToVertices(createSVGPath(stringsArr[0]), 10),
				1,
				1
			),
			{
				friction: 0.005,
				frictionAir: 0.006,
				restitution: 0.99,
				render: {
					// fillStyle: shapeColor,
					// strokeStyle: shapeColor,
					// lineWidth: 1,
          sprite: {
            texture: returnSpinner(shapeColor),
            xScale: 1.1,
            yScale: 1.1
          }
				}
			},
			true
		);
		vertexSets.push(spinners[i]);
	}
}

	let pathsArr = ['M 36 42 C 40 34 32 28 32 20 A 1 1 0 0 1 68 20 C 68 28 60 34 64 42 C 68.856 49.34 78.053 45.412 84.981 49.412 A 1 1 0 0 1 66.981 80.588 C 60.053 76.588 58.856 66.66 50 66 C 41.144 66.66 39.947 76.588 33.019 80.588 A 1 1 0 0 1 15.019 49.412 C 21.947 45.412 31.144 49.34 36 42'];

	go(pathsArr);

// add all SVGs to the world
Composite.add(world, vertexSets);

// run the renderer
Render.run(render);

// create runner
const runner = Runner.create();

// run the engine
Runner.run(runner, engine);

// hold in place for testing
world.gravity.y = 1;
world.gravity.x = 0;

// mouse control

let mouse = Mouse.create(render.canvas),
	mouseConstraint = MouseConstraint.create(engine, {
		mouse: mouse,
		constraint: {
			stiffness: 0.2,
			render: {
				visible: false
			}
		}
	});

Composite.add(world, mouseConstraint);
addEvtListener();