# Fidget Spinners

A Pen created on CodePen.io. Original URL: [https://codepen.io/leimapapa/pen/oNOrzwM](https://codepen.io/leimapapa/pen/oNOrzwM).

Spin multiple fidget spinners on your phone without the annoying whirring sound!