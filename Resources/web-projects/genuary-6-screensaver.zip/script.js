import { trilerp, converter, formatCss, formatHex, easingSmoothstep } from 'https://cdn.skypack.dev/culori';

const rgb = converter('rgb');

const RYB_CUBE = [
{ mode: 'rgb', r: 248 / 255, g: 237 / 255, b: 220 / 255 }, // white
{
  "mode": "rgb",
  "r": 0.8901960784313725,
  "g": 0.1411764705882353,
  "b": 0.12941176470588237 },
// red
{
  "mode": "rgb",
  "r": 0.9529411764705882,
  "g": 0.9019607843137255,
  "b": 0 },
// yellow
{
  "mode": "rgb",
  "r": 0.9411764705882353,
  "g": 0.5568627450980392,
  "b": 0.10980392156862745 },
// orange
{
  "mode": "rgb",
  "r": 0.08627450980392157,
  "g": 0.6,
  "b": 0.8549019607843137 },
// blue
{
  "mode": "rgb",
  "r": 0.47058823529411764,
  "g": 0.13333333333333333,
  "b": 0.6666666666666666 },
// violet
{
  "mode": "rgb",
  "r": 0,
  "g": 0.5568627450980392,
  "b": 0.3568627450980392 },
// green
{ mode: 'rgb', r: 29 / 255, g: 28 / 255, b: 28 / 255 } // black
];

function ryb2rgb(coords) {
  const r = easingSmoothstep(coords[0]);
  const y = easingSmoothstep(coords[1]);
  const b = easingSmoothstep(coords[2]);
  return {
    mode: 'rgb',
    r: trilerp(...RYB_CUBE.map(it => it.r), r, y, b),
    g: trilerp(...RYB_CUBE.map(it => it.g), r, y, b),
    b: trilerp(...RYB_CUBE.map(it => it.b), r, y, b) };

}

function hsl2farbrad(h, s, l) {
  const rgbColor = rgb({
    mode: 'hsl',
    h: (h + 360) % 360, s, l: 1 - l });

  return ryb2rgb([
  rgbColor.r,
  rgbColor.g,
  rgbColor.b]);

};

const $can = document.querySelector('canvas');
const ctx = $can.getContext('2d');

let t = 0;

const w = window.innerWidth;
const h = window.innerHeight;

$can.width = w;
$can.height = h;

ctx.fillStyle = formatCss(hsl2farbrad(0, 0, 0));
ctx.fillRect(0, 0, w, h);


function doIt() {

  ctx.fillStyle = formatCss(hsl2farbrad(0, 0, 1));
  ctx.fillRect(0, 0, w, h);

  const scale = .8;
  // get current time
  const now = Date.now();
  // get hours, minutes, seconds
  const hours = new Date(now).getHours();
  const minutes = new Date(now).getMinutes();
  const seconds = new Date(now).getSeconds();
  const milliseconds = new Date(now).getMilliseconds();

  const millisecondsNorm = milliseconds / 1000;
  // get seconds norm from milliseconds
  const secondsNorm = seconds / 60 + millisecondsNorm / 60;
  const hoursNorm = hours / 24 * 2 % 1;
  const minutesNorm = minutes / 60;

  // get hours, minutes, seconds and milliseconds as angles
  const hoursAngle = hoursNorm * 360;
  const minutesAngle = minutesNorm * 360;
  const secondsAngle = secondsNorm * 360;
  const millisecondsAngle = millisecondsNorm * 360;

  const hoursAngleRad = hoursAngle * Math.PI / 180;
  const minutesAngleRad = minutesAngle * Math.PI / 180;
  const secondsAngleRad = secondsAngle * Math.PI / 180;
  const millisecondsAngleRad = millisecondsAngle * Math.PI / 180;

  // quarter circle
  const quarterCircleRad = Math.PI / 2;

  let strokeWeight = Math.min(w, h) * .01;
  //strokeWeight = 100;
  ctx.save();

  // rotate canvas from center of the circle
  ctx.translate(w / 2, h / 2);
  ctx.rotate(hoursAngleRad + minutesAngleRad + secondsAngleRad);
  ctx.scale(scale, scale);
  ctx.translate(-w / 2, -h / 2);

  ctx.fillStyle = formatCss(hsl2farbrad(secondsAngle, 0, 0));
  ctx.fillStyle = 'transparent';
  ctx.fillStyle = formatCss(hsl2farbrad((seconds * seconds + minutes) % 360, .4, 0.6));
  ctx.fillStyle = 'transparent';

  ctx.lineCap = 'round';
  ctx.strokeStyle = formatCss(hsl2farbrad(0, 0, 0));
  ctx.strokeStyle = formatCss(hsl2farbrad(secondsAngle, 0, 0));
  ctx.strokeStyle = formatCss(hsl2farbrad((seconds * seconds + minutes) % 360, .4, 0.4));
  ctx.lineWidth = strokeWeight * .95;
  ctx.beginPath();
  ctx.moveTo(w / 2, h / 2);
  const odd = seconds % 2 === 0;
  ctx.arc(w / 2, h / 2, 300, -quarterCircleRad, millisecondsAngleRad - quarterCircleRad, odd);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(w / 2, h / 2);
  ctx.arc(w / 2, h / 2, 300, -quarterCircleRad, millisecondsAngleRad - quarterCircleRad, odd);
  ctx.closePath();
  ctx.fill();


  ctx.restore();

  ctx.save();
  ctx.translate(w / 2, h / 2);
  ctx.rotate(hoursAngleRad + minutesAngleRad);
  ctx.scale(scale, scale);
  ctx.translate(-w / 2, -h / 2);

  ctx.lineCap = 'round';
  ctx.fillStyle = formatCss(hsl2farbrad((secondsAngle + minutesAngle + hoursAngle) % 360, .6, .8));
  ctx.fillStyle = 'transparent';
  ctx.strokeStyle = formatCss(hsl2farbrad(0, 0, 0));
  ctx.strokeStyle = formatCss(hsl2farbrad((secondsAngle + minutesAngle + hoursAngle) % 360, .6, .7));
  ctx.lineWidth = strokeWeight;
  ctx.beginPath();
  ctx.moveTo(w / 2, h / 2);
  ctx.arc(w / 2, h / 2, Math.max(w, h), -quarterCircleRad, secondsAngleRad - quarterCircleRad);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(w / 2, h / 2);
  ctx.arc(w / 2, h / 2, Math.max(w, h), -quarterCircleRad, secondsAngleRad - quarterCircleRad);
  ctx.closePath();
  ctx.fill();

  ctx.restore();

  ctx.save();
  ctx.translate(w / 2, h / 2);
  ctx.rotate(hoursAngleRad);
  ctx.scale(scale, scale);
  ctx.translate(-w / 2, -h / 2);

  ctx.strokeStyle = formatCss(hsl2farbrad(0, 0, 0));
  ctx.lineWidth = strokeWeight;

  ctx.lineCap = 'round';
  ctx.strokeStyle = formatCss(hsl2farbrad((minutesAngle + hoursAngle - 10) % 360, .5, .45));
  ctx.fillStyle = formatCss(hsl2farbrad((minutesAngle + hoursAngle) % 360, .5, .6));

  ctx.fillStyle = 'transparent';
  ctx.beginPath();
  ctx.moveTo(w / 2, h / 2);
  ctx.arc(w / 2, h / 2, 200, -quarterCircleRad, minutesAngleRad - quarterCircleRad);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();


  ctx.beginPath();
  ctx.moveTo(w / 2, h / 2);
  ctx.arc(w / 2, h / 2, 200, -quarterCircleRad, minutesAngleRad - quarterCircleRad);
  ctx.closePath();
  ctx.fill();

  ctx.restore();

  ctx.save();
  ctx.translate(w / 2, h / 2);
  ctx.rotate(0);
  ctx.scale(scale, scale);
  ctx.translate(-w / 2, -h / 2);

  ctx.strokeStyle = formatCss(hsl2farbrad(0, 0, 0));
  ctx.lineWidth = strokeWeight;

  ctx.lineCap = 'round';
  ctx.strokeStyle = formatCss(hsl2farbrad((secondsAngle + minutesAngle + hoursAngle - 10) % 360, .4, 0.4));
  ctx.fillStyle = formatCss(hsl2farbrad((secondsAngle + minutesAngle + hoursAngle) % 360, .4, 0.5));

  ctx.fillStyle = 'transparent';
  ctx.beginPath();
  ctx.moveTo(w / 2, h / 2);
  ctx.arc(w / 2, h / 2, 100, -quarterCircleRad, hoursAngleRad - quarterCircleRad);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(w / 2, h / 2);
  ctx.arc(w / 2, h / 2, 100, -quarterCircleRad, hoursAngleRad - quarterCircleRad);
  ctx.closePath();
  ctx.fill();

  ctx.restore();


  // copy the last frame to the background and scale it a bit up
  //ctx.drawImage($can, 0, 0, w, h);

  requestAnimationFrame(doIt);
}

setInterval(() => {
  ctx.fillStyle = formatCss(hsl2farbrad(0, 0, 0));
  ctx.fillRect(0, 0, w, h);
}, 2000);

requestAnimationFrame(doIt);

doIt();

document.body.addEventListener('click', doIt);