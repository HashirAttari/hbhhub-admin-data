// Copyright 2015 The Chromium Authors – See license below

const animations = {};

animations.CLASSES = {
  RIPPLE: 'ripple',
  RIPPLE_CONTAINER: 'ripple-container',
  RIPPLE_EFFECT_MASK: 'ripple-effect-mask',
  RIPPLE_EFFECT: 'ripple-effect',
};

animations.RIPPLE_DURATION_MS = 800;

animations.RIPPLE_MAX_RADIUS_PX = 300;

const ripple = (event) => {
  const target = event.target;
  const rect = target.getBoundingClientRect();
  const x = Math.round(event.clientX - rect.left);
  const y = Math.round(event.clientY - rect.top);

  // Calculate radius
  const corners = [
    {x: 0, y: 0},
    {x: rect.width, y: 0},
    {x: 0, y: rect.height},
    {x: rect.width, y: rect.height},
  ];
  const distance = (x1, y1, x2, y2) => {
    const xDelta = x1 - x2;
    const yDelta = y1 - y2;
    return Math.sqrt(xDelta * xDelta + yDelta * yDelta);
  };
  const cornerDistances = corners.map(function(corner) {
    return Math.round(distance(x, y, corner.x, corner.y));
  });
  const radius = Math.min(
    animations.RIPPLE_MAX_RADIUS_PX, Math.max.apply(Math, cornerDistances));

  const ripple = document.createElement('div');
  const rippleMask = document.createElement('div');
  const rippleContainer = document.createElement('div');
  ripple.classList.add(animations.CLASSES.RIPPLE_EFFECT);
  rippleMask.classList.add(animations.CLASSES.RIPPLE_EFFECT_MASK);
  rippleContainer.classList.add(animations.CLASSES.RIPPLE_CONTAINER);
  rippleMask.appendChild(ripple);
  rippleContainer.appendChild(rippleMask);
  target.appendChild(rippleContainer);
  // Ripple start location
  ripple.style.marginLeft = x + 'px';
  ripple.style.marginTop = y + 'px';

  rippleMask.style.width = target.offsetWidth + 'px';
  rippleMask.style.height = target.offsetHeight + 'px';
  rippleMask.style.borderRadius =
    window.getComputedStyle(target).borderRadius;

  // Start transition/ripple
  ripple.style.width = radius * 2 + 'px';
  ripple.style.height = radius * 2 + 'px';
  ripple.style.marginLeft = x - radius + 'px';
  ripple.style.marginTop = y - radius + 'px';
  ripple.style.backgroundColor = 'rgba(0, 0, 0, 0)';

  window.setTimeout(function() {
    ripple.remove();
    rippleMask.remove();
    rippleContainer.remove();
  }, animations.RIPPLE_DURATION_MS);
};

document.querySelector('.ripple-button').addEventListener('mousedown', ripple);


// Copyright 2015 The Chromium Authors
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//    * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//    * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//    * Neither the name of Google LLC nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.