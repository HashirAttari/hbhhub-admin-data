# Circle mask cutout

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/ZEmomZw](https://codepen.io/cbolson/pen/ZEmomZw).

