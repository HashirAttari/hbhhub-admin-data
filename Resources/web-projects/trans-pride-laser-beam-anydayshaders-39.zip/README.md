# Trans Pride Laser Beam – #anydayshaders 39

A Pen created on CodePen.io. Original URL: [https://codepen.io/learosema/pen/yLWgwmR](https://codepen.io/learosema/pen/yLWgwmR).

