# Material Select

A Pen created on CodePen.io. Original URL: [https://codepen.io/WinterCore/pen/WZvJdL](https://codepen.io/WinterCore/pen/WZvJdL).

Material select widget made with React.js
includes next/prev  buttons.