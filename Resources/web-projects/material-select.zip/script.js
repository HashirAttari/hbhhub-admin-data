/************************************************/
// CODE NEEDS REWORK ITS UNREADABLE AND SLOW
/************************************************/



const { Component } = React;
const { Motion, spring } = ReactMotion;


class Select extends Component {
  constructor(props) {
    super(props);
    this.state = {
      step: 0,
      isNextDisabled: false,
      isPrevDisabled: false,
      containerWidth: 0,
      itemStyle: {} };

    this.containerWidth = 0;
    this.calculateDim = this._calculateDim.bind(this);
  }

  _calculateDim(w) {
    const containerWidth = this.container.offsetWidth;
    const width = (isNaN(+w) ? this.props.width : w) * containerWidth / 100;
    this.setState({
      containerWidth,
      itemStyle: {
        width: width,
        flex: `1 0 ${width}px` } });


    this.checkButtons(this.state.step);
  }

  componentDidMount() {
    this.calculateDim();
    window.addEventListener("resize", this.calculateDim);
  }
  componentWillUnmount() {
    window.removeEventListener("resize", this.calculateDim);
  }

  componentWillReceiveProps({ items, width }) {
    this.setState({ step: 0 });
    if (width <= 100 && width > 0)
    this.calculateDim(width);
    this.checkButtons(0);
  }

  checkButtons(step) {
    const isNextDisabled = step === this.props.items.length - 1;
    const isPrevDisabled = step === 0;
    this.setState({ isNextDisabled, isPrevDisabled });
  }

  next() {
    if (this.state.isNextDisabled)
    return;
    const step = this.state.step + 1;
    this.checkButtons(step);
    this.setState({ step });
  }

  prev() {
    if (this.state.isPrevDisabled)
    return;
    const step = this.state.step - 1;
    this.checkButtons(step);
    this.setState({ step });
  }

  render() {
    const animationValue = -this.state.step * this.state.itemStyle.width + (this.state.containerWidth / 2 - this.state.itemStyle.width / 2) || 0;
    return /*#__PURE__*/(
      React.createElement("div", { ref: elem => this.container = elem, className: "select" }, /*#__PURE__*/
      React.createElement("div", { onClick: this.prev.bind(this), className: `select-control scroll-left ${this.state.isPrevDisabled ? "disabled" : ""}` }, /*#__PURE__*/
      React.createElement("svg", { viewBox: "0 0 405.457 405.457", width: "16px", height: "16px" }, /*#__PURE__*/
      React.createElement("g", null, /*#__PURE__*/
      React.createElement("path", { d: "M64.147,331.322c0.078,4.985,2.163,9.911,5.688,13.438l55,55c3.599,3.601,8.659,5.697,13.75,5.697   c5.091,0,10.151-2.096,13.75-5.697l183.281-183.282c3.601-3.599,5.697-8.659,5.697-13.75s-2.096-10.151-5.697-13.75L152.335,5.697   C148.736,2.096,143.676,0,138.585,0c-5.091,0-10.151,2.096-13.75,5.697l-55,55c-3.591,3.598-5.681,8.651-5.681,13.734   s2.09,10.136,5.681,13.734l114.562,114.563L69.835,317.291C66.171,320.958,64.07,326.139,64.147,331.322L64.147,331.322z", fill: "#FFFFFF" })))), /*#__PURE__*/



      React.createElement(Motion, { style: { t: spring(animationValue) } },
      ({ t }) => /*#__PURE__*/React.createElement("div", { style: { transform: `translateX(${t}px)` }, className: "select-steps" },

      this.props.items.map(x => /*#__PURE__*/React.createElement("div", { style: this.state.itemStyle }, x)))), /*#__PURE__*/




      React.createElement("div", { onClick: this.next.bind(this), className: `select-control scroll-right ${this.state.isNextDisabled ? "disabled" : ""}` }, /*#__PURE__*/
      React.createElement("svg", { viewBox: "0 0 405.457 405.457", width: "16px", height: "16px" }, /*#__PURE__*/
      React.createElement("g", null, /*#__PURE__*/
      React.createElement("path", { d: "M64.147,331.322c0.078,4.985,2.163,9.911,5.688,13.438l55,55c3.599,3.601,8.659,5.697,13.75,5.697   c5.091,0,10.151-2.096,13.75-5.697l183.281-183.282c3.601-3.599,5.697-8.659,5.697-13.75s-2.096-10.151-5.697-13.75L152.335,5.697   C148.736,2.096,143.676,0,138.585,0c-5.091,0-10.151,2.096-13.75,5.697l-55,55c-3.591,3.598-5.681,8.651-5.681,13.734   s2.09,10.136,5.681,13.734l114.562,114.563L69.835,317.291C66.171,320.958,64.07,326.139,64.147,331.322L64.147,331.322z", fill: "#FFFFFF" }))))));





  }}


class Main extends Component {
  constructor(props) {
    super(props);
    this.state = {
      input: "144p, 240p, 360p, 480p, 720p, 1080p",
      width: 30 };

  }
  change(e) {
    this.setState({
      input: e.target.value });

  }
  widthChange(e) {
    this.setState({
      width: +e.target.value.trim() });

  }
  render() {
    return /*#__PURE__*/(
      React.createElement("div", null, /*#__PURE__*/
      React.createElement("h1", null, "Material Select"), /*#__PURE__*/
      React.createElement(Select, { items: this.state.input.split(",").map(x => x.trim()), width: this.state.width }), /*#__PURE__*/
      React.createElement("div", { className: "props" }, /*#__PURE__*/
      React.createElement("div", { className: "input-group" }, /*#__PURE__*/
      React.createElement("label", null, "Items (a comma separated list)"), /*#__PURE__*/
      React.createElement("input", { type: "text", value: this.state.input, onChange: this.change.bind(this) })), /*#__PURE__*/

      React.createElement("div", { className: "input-group" }, /*#__PURE__*/
      React.createElement("label", null, "Item Width percentage [0-100]"), /*#__PURE__*/
      React.createElement("input", { type: "text", value: this.state.width, onChange: this.widthChange.bind(this) })))));




  }}


ReactDOM.render( /*#__PURE__*/React.createElement(Main, null), document.getElementById("root"));