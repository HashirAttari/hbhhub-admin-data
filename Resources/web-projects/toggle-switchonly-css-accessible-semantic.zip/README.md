# Toggle switch - only CSS, accessible & semantic

A Pen created on CodePen.io. Original URL: [https://codepen.io/sibisundar/pen/eVzXev](https://codepen.io/sibisundar/pen/eVzXev).

Accessible  and semantic toggle switch with only CSS.

Inspired by this cool dribbble shot: https://dribbble.com/shots/4148855-Switcher-XXXIII

Also one for the the DailyUI collection :3 #015