# CSS Rotary Safe Lock

A Pen created on CodePen.io. Original URL: [https://codepen.io/stephensmith100/pen/AXLvrN](https://codepen.io/stephensmith100/pen/AXLvrN).

CSS animated rotary safe lock. Click the dial and the safe will open. Safe number can be changed in the stylesheet. Positioning of dial and code numbers calculated with Sass.