# Pure CSS Block Reveal Effect ✨

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/PrVBpO](https://codepen.io/jh3y/pen/PrVBpO).

Here's a pure CSS Block Reveal effect.

Read the article: [HOW TO: Looping Block Reveal Effect](https://blog.prototypr.io/how-to-looping-block-reveal-effects-fcb9ded9c6f9)

Enjoy! 