const driverNames = [];
var drivers = [];

const driverBaseCost = 10000;
const driverBaseLevelCost = 12300;
const driverPotentialCost = 13000;
const driverStatCost = 1500;
const levelCapCost = 4000;

const driverAgePenaltyThreshold = 28;
const driverAgePenaltyCost = 100;

class Driver {
    constructor() {
        // Set the drivers name
        this.firstName = getRandomUniqueNameArray(driverFirstNames);
        this.lastName =  getRandomUniqueNameArray(driverLastNames);
        this.fullName = `${this.firstName} ${this.lastName}`;
        this.shortName = `${this.firstName.substring(0, 1)}. ${this.lastName}`;

        // Set driver age
        this.age =  randomNumberBetween(17, 40);
        this.hometown = homeTowns[randomNumberBetween(0, homeTowns.length - 1)];
        this.gender = driverGenders[randomNumberBetween(0, driverGenders.length - 1)];

        this.weight = randomNumberBetween(40, 120) + 'Kg'

        this.height = randomNumberBetween(4, 7) + "'" + randomNumberBetween(0, 11);

        // Set driver level and level cap between 1 and 5
        this.ability = randomNumberBetweenDecimal(0.5, 4, 1);
        this.abilityCap =  Math.ceil(this.ability + randomNumberBetweenDecimal(0, 5 - this.ability, 1));
        this.abilityPotential = parseFloat((this.abilityCap - this.ability).toFixed(2));

        // The drivers growth coefficient dictates the amount of experience gained after a race.
        // This growth potential is based on age, level potential, and some random tom foolery.
        // Gain one point for each year under the threshold age

        let driverAgeBonus = driverAgePenaltyThreshold - this.age;

        if(driverAgeBonus < 0) {
            driverAgeBonus = 0;
        }

        this.currentTeam = teams[randomNumberBetween(0, teams.length - 1)];

        this.growthCoefficient = parseFloat(1 + (driverAgeBonus / 10) + (this.abilityPotential / 10) + randomNumberBetweenDecimal(0, 1, 1)).toFixed(2);

        this.stats = {
            handling: randomNumberBetween(1, 20), 
            braking: randomNumberBetween(1, 20), 
            offensive: randomNumberBetween(1, 20),
            defensive: randomNumberBetween(1, 20)
        };

        let statTotal = 0;

        Object.keys(this.stats).forEach(function(a) {
            statTotal = statTotal + this.stats[a];
        }.bind(this))

        this.statTotal = statTotal;
        this.hireCost = Math.ceil(driverBaseCost + (driverBaseLevelCost * this.ability) + (levelCapCost * this.abilityCap) + (this.growthCoefficient * 100) + (this.statTotal * driverStatCost));
        this.costPerRace = Math.ceil((driverBaseCost + (driverBaseLevelCost * this.ability) + (levelCapCost * this.abilityCap) + (this.growthCoefficient * 100) + (this.statTotal * driverStatCost)) / 10) * 2;
        this.hiringCost = 1000;

        drivers.push(this);
    }
}


class Game {
    constructor(driverPoolCount) {
        this.driverPoolCount = driverPoolCount;
    }

    init() {
        // Generate a list of random driver names based on our name arrays
        for(let i = 0; i < this.driverPoolCount; i++) {
            let driver = new Driver();
        }


        for(let i = 0; i < drivers.length - 2; i++) {
            let d = drivers[i];
            $('.d_items').append(`<div class="d_items__item" data-index="${i}">
<div class="hired"><p>Driver hired</p></div>
<div class="gender">
<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/${d.gender.toLowerCase()}icon.png">
</div>
<div class="name">
<p>${d.fullName}</p>
</div>
<div class="hometown">
<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/${d.hometown.toLowerCase().replace(/\s/g, '')}-flag.svg">
<p>${d.hometown}</p>
</div>
<div class="age">
<p>${d.age}</p>
</div>
<div class="ability">
<img class="base" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/racerabilitybase.png">
<img class="outline" style="clip-path: polygon(0 0, ${d.abilityCap * 20}% 0, ${d.abilityCap * 20}% 100%, 0% 100%);" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/racerabilityoutline.png">
<img class="outer" style="clip-path: polygon(0 0, ${d.ability * 20}% 0, ${d.ability * 20}% 100%, 0% 100%);" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/racerabilityouter.png">
<p>${d.ability}</p>
</div>
<div class="team">
<p>${d.currentTeam}</p>
</div>
<div class="cost">
<svg data-name="Layer 1" id="Layer_1" viewBox="0 0 7.31 9.56" xmlns="http://www.w3.org/2000/svg">
<polyline points="0 9.56 2 7.56 2 0 0 0 0 9.56"></polyline>
<polygon points="4.15 3.29 7.31 0 4.48 0 2.67 1.81 2.67 3.29 4.15 3.29"></polygon>
<polygon points="2.67 5.33 3.45 6.11 4.87 4.7 4.15 3.97 2.67 3.97 2.67 5.33"></polygon>
</svg>
<p>${d.hireCost.toLocaleString()}</p>
</div>
<div class="racecost">
<svg data-name="Layer 1" id="Layer_1" viewBox="0 0 7.31 9.56" xmlns="http://www.w3.org/2000/svg">
<polyline points="0 9.56 2 7.56 2 0 0 0 0 9.56"></polyline>
<polygon points="4.15 3.29 7.31 0 4.48 0 2.67 1.81 2.67 3.29 4.15 3.29"></polygon>
<polygon points="2.67 5.33 3.45 6.11 4.87 4.7 4.15 3.97 2.67 3.97 2.67 5.33"></polygon>
</svg>
<p>${d.costPerRace.toLocaleString()}</p>
</div>
<div class="action">
<button data-cost="${d.hireCost}">Hire</button>
</div>
</div>`)
        }

        for(let i = drivers.length - 2; i < drivers.length; i++) {
            let d = drivers[i];
            $('.driver_roster__list').prepend(`<div class="r_item filled" data-index="${i}">
<div class="r_item__name">
<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/profilewasteland${d.gender.toLowerCase()}.png">
<p>${d.shortName}</p>
</div>
<div class="r_item__ability">
<img class="base" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/racerabilitybase.png">
<img class="outline" style="clip-path: polygon(0 0, ${d.abilityCap * 20}% 0, ${d.abilityCap * 20}% 100%, 0% 100%);" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/racerabilityoutline.png">
<img class="outer" style="clip-path: polygon(0 0, ${d.ability * 20}% 0, ${d.ability * 20}% 100%, 0% 100%);" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/racerabilityouter.png">
<p>3.6</p>
</div>
<div class="r_item__actions">
<button>Fire</button>
</div>
</div>`)
        }

        $(".d_items__item").each(function(index) {
            $(this).delay(15 * index).fadeIn(130);
        });
        $(".r_item").each(function(index) {
            $(this).delay(15 * index).fadeIn(130);
        });

    }
}

let kash = 500000;

function countToNumber(num, el) {

}

$('body').on('click', 'button.available', function() {
    let cost = $(this).data('cost');
    kash = kash - cost;


    $(this).parent().parent().find('.hired').addClass('active')

    //$('.head_kash__kash h3').html(kash.toLocaleString());

    animateValue($('.head_kash__kash h3'), kash + cost, kash, 133300);
    $('.head_kash__kash').css('transform', 'scale(1.3)');

    setTimeout(function(){
        $('.head_kash__kash').css('transform', 'scale(1)')
    }, 150);

    let index = $(this).parent().parent().data('index');
    let d = drivers[index];
    console.log(d)
    $('.driver_roster__list').prepend(`<div class="r_item filled" style="display:block;" data-index="${index}">
<div class="r_item__name">
<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/profilewasteland${d.gender.toLowerCase()}.png">
<p>${d.shortName}</p>
</div>
<div class="r_item__ability">
<img class="base" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/racerabilitybase.png">
<img class="outline" style="clip-path: polygon(0 0, ${d.abilityCap * 20}% 0, ${d.abilityCap * 20}% 100%, 0% 100%);" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/racerabilityoutline.png">
<img class="outer" style="clip-path: polygon(0 0, ${d.ability * 20}% 0, ${d.ability * 20}% 100%, 0% 100%);" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/racerabilityouter.png">
<p>3.6</p>
</div>
<div class="r_item__actions">
<button>Fire</button>
</div>
</div>`)

})

function animateValue(id, start, end, duration) {

    var range = end - start;
    var current = start;
    var increment = end > start? 1000 : -1000;
    var stepTime = Math.abs(Math.floor(duration / range));
    var obj = id;
    var timer = setInterval(function() {
        current += increment;
        $('.head_kash__kash h3').html(current.toLocaleString());

        if (current < end) {
            clearInterval(timer);
        }
    }, stepTime);
}

//

$('.head_kash__kash h3').html(kash.toLocaleString());

setInterval(function() {

    $('.action button').each(function() {
        if(kash > $(this).data('cost')) {
            $(this).addClass('available');
        } else {
            $(this).removeClass('available');
        }
    })
}, 10)

const game = new Game(40);
game.init();

$('body').on('mouseenter', '.d_items__item, .r_item.filled', function() {
    let currentDriver = $(this).data('index');


    $('.driver_info__name p').html(drivers[currentDriver].shortName)
    $('.driver_info .age span').html(drivers[currentDriver].age);
    $('.driver_info .weight span').html(drivers[currentDriver].weight);
    $('.driver_info .height span').html(drivers[currentDriver].height);
    $('.driver_info__flag img').attr('src', `https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/${drivers[currentDriver].hometown.toLowerCase().replace(/\s/g, '')}-flag.svg`);

    $('.driver_info .handling span').html(drivers[currentDriver].stats.handling); 
    $('.driver_info .braking span').html(drivers[currentDriver].stats.braking);
    $('.driver_info .offensive span').html(drivers[currentDriver].stats.offensive);
    $('.driver_info .defensive span').html(drivers[currentDriver].stats.defensive);

    $('.driver_info__image img').attr('src', `https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/profilewasteland${drivers[currentDriver].gender.toLowerCase()}.png`);

    $('.braking, .handling, .offensive, .defensive').each(function() {
        let bar = $(this).find('span');
        let value = bar.html();
        bar.removeClass('active');

        setTimeout(function() {
            bar.addClass('active');
        },10)


        if(value < 5) {
            bar.css('background', '#701e1a');
            bar.css('border-bottom', '2px solid #ff190e');
        }

        if(value > 5 && value < 10 ) {
            bar.css('background', '#69401e');
            bar.css('border-bottom', '2px solid #ff7a0e');
        }

        if(value > 10 && value < 15 ) {
            bar.css('background', 'rgb(140, 129, 56)');
            bar.css('border-bottom', '2px solid rgb(255, 209, 0)');
        }

        if(value > 15 ) {
            bar.css('background', '#525e23');
            bar.css('border-bottom', '2px solid #bef627');
        }
    })

})

// Returns a random value from any array and removes it completely so it cannot be used again
function getRandomUniqueNameArray(array) {
    let randomNumber = randomNumberBetween(0, array.length - 1);
    let value = array[randomNumber];
    array.splice(randomNumber, 1);
    return value;
}

function randomNumberBetween(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

function randomNumberBetweenDecimal(min, max, decimalPlaces) {  
    var rand = Math.random() < 0.5 ? ((1-Math.random()) * (max-min) + min) : (Math.random() * (max-min) + min);
    var power = Math.pow(10, decimalPlaces);
    return Math.floor(rand*power) / power;
}

audioArray = [
    {
        'name'      : 'beepOne',
        'source'    : 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/buttonHoverScary.wav',
        'stackSize' : 20
    },
    {
        'name'      : 'beepTwo',
        'source'    : 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/counter-03-by_YIO.wav',
        'stackSize' : 20
    },
    {
        'name'      : 'hire',
        'source'    : 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/export_ofoct.com.mp3',
        'stackSize' : 4
    },
    {
        'name'      : 'bg',
        'source'    : 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/The+Plague+Doctor+%28online-audio-converter.com%29.mp3'
    }
    
   
]

audioController = new AudioController(audioArray);

$('body').on('mouseenter', '.d_items__item, .r_item.filled', function() {
    audioController.play('beepOne');
})

$('body').on('mouseenter', '.select, .filters_item, .d_head__item, .head_nextrace, .head_weather', function() {
    audioController.play('beepTwo');
})

$('body').on('click', 'button.available', function() {
    audioController.play('hire');
}) 

audioController.play('bg');

'use strict';

///console.clear();

class Grain {
    constructor (el) {
        /**
     * Options
     * Increase the pattern size if visible pattern
     */
        this.patternSize = 1332;
        this.patternScaleX = 231;
        this.patternScaleY = 231;
        this.patternRefreshInterval = 3; // 8
        this.patternAlpha = 8; // int between 0 and 255,

        /**
     * Create canvas
     */
        this.canvas = el;
        this.ctx = this.canvas.getContext('2d');
        this.ctx.scale(this.patternScaleX, this.patternScaleY);

        /**
     * Create a canvas that will be used to generate grain and used as a
     * pattern on the main canvas.
     */
        this.patternCanvas = document.createElement('canvas');
        this.patternCanvas.width = this.patternSize;
        this.patternCanvas.height = this.patternSize;
        this.patternCtx = this.patternCanvas.getContext('2d');
        this.patternData = this.patternCtx.createImageData(this.patternSize, this.patternSize);
        this.patternPixelDataLength = this.patternSize * this.patternSize * 4; // rgba = 4

        /**
     * Prebind prototype function, so later its easier to user
     */
        this.resize = this.resize.bind(this);
        this.loop = this.loop.bind(this);

        this.frame = 0;

        window.addEventListener('resize', this.resize);
        this.resize();

        window.requestAnimationFrame(this.loop);
    }

    resize () {
        this.canvas.width = window.innerWidth * devicePixelRatio;
        this.canvas.height = window.innerHeight * devicePixelRatio;
    }

    update () {
        const {patternPixelDataLength, patternData, patternAlpha, patternCtx} = this;

        // put a random shade of gray into every pixel of the pattern
        for (let i = 0; i < patternPixelDataLength; i += 4) {
            // const value = (Math.random() * 255) | 0;
            const value = Math.random() * 255;

            patternData.data[i] = value;
            patternData.data[i + 1] = value;
            patternData.data[i + 2] = value;
            patternData.data[i + 3] = patternAlpha;
        }

        patternCtx.putImageData(patternData, 0, 0);
    }

    draw () {
        const {ctx, patternCanvas, canvas, viewHeight} = this;
        const {width, height} = canvas;

        // clear canvas
        ctx.clearRect(0, 0, width, height);

        // fill the canvas using the pattern
        ctx.fillStyle = ctx.createPattern(patternCanvas, 'repeat');
        ctx.fillRect(0, 0, width, height);
    }

    loop () {
        // only update grain every n frames
        const shouldDraw = ++this.frame % this.patternRefreshInterval === 0;
        if (shouldDraw) {
            this.update();
            this.draw();
        }

        window.requestAnimationFrame(this.loop);
    }
}


/**
 * Initiate Grain
 */
const el = document.querySelector('.grain');
const grain = new Grain(el);