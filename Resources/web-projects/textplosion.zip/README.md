# TextPlosion

A Pen created on CodePen.

Original URL: [https://codepen.io/sakri/pen/AmYjGz](https://codepen.io/sakri/pen/AmYjGz).

The script renders a text onto a canvas, then shrinks it and loops through the pixels of the shrunken version, storing colored pixels as "particle locations".  The particles then shoot out and are rendered as text characters. In "Full Page" you can enter your own text and see it explode :)