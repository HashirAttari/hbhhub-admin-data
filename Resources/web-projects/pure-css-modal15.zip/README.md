# Pure CSS Modal - #15

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/BajVZre](https://codepen.io/ig_design/pen/BajVZre).

