function f(a) {
  if (a.value != '') {
    document.getElementById('to-do').innerHTML += '<p><input type="checkbox" data-name="' + a.value + '"><button class="fa fa-trash"></button></p>';
    a.value = " ";
  }
}

$("iframe[name='CodePen']").each(function() {
    this.sandbox += ' allow-modals';
});

for (var i = 0; i < 5; i++) {
  document.getElementsByTagName('p')[i].innerHTML += "<button class='fa fa-trash' onclick='del(this)'></button>";
}

function del(a) {
 a.parentNode.parentNode.removeChild(a.parentNode)
}