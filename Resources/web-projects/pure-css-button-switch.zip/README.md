# Pure CSS button switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/KittyGiraudel/pen/AzYrPb](https://codepen.io/KittyGiraudel/pen/AzYrPb).

Inspired by Diego Monzon's work on Dribbble : http://dribbble.com/shots/388701-Blue-Ice-User-Interface.<br>
What do you think, does it look good ? Are there some disturbing shadows ? 