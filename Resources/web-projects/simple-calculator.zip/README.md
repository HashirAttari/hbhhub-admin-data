# Simple calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/johnnycopes/pen/EPwKwo](https://codepen.io/johnnycopes/pen/EPwKwo).

