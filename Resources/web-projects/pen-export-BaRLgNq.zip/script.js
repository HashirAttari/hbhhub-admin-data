import * as React from "https://cdn.skypack.dev/react@17.0.2";
import * as ReactDOM from "https://cdn.skypack.dev/react-dom@17.0.2";
import { v4 as uuidv4 } from "https://jspm.dev/uuid";
import {
useState,
useEffect,
createContext,
useContext } from
"https://cdn.skypack.dev/react@17.0.2";
// ================
// ================
const initialTasks = [
{
  id: 0,
  title: "todo",
  tasks: [
  {
    id: uuidv4(),
    name: "Learn about a distributed version control system such as Git",
    timestamp: new Date().toDateString() }] },



{
  id: 1,
  title: "doing",
  tasks: [
  {
    id: uuidv4(),
    name: "Take a class at your local community center that interests you",
    timestamp: new Date().toDateString() }] },



{
  id: 2,
  title: "done",
  tasks: [
  {
    id: uuidv4(),
    name: "Fix something that's broken in your house",
    timestamp: new Date().toDateString() }] }];




// ================
// ================
const TaskContext = createContext();

const TaskProvider = ({ children }) => {
  const tasks = localStorage.getItem("tasks") ?
  JSON.parse(localStorage.getItem("tasks")) :
  initialTasks;

  const [lane, setLanes] = useState(tasks);

  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(lane));
  }, [lane]);

  return /*#__PURE__*/(
    React.createElement(TaskContext.Provider, { value: { lane, setLanes } },
    children));


};
// ================
// ================
const LaneSection = () => {
  const { lane } = useContext(TaskContext);

  return /*#__PURE__*/(
    React.createElement(React.Fragment, null,
    lane.map((t) => /*#__PURE__*/
    React.createElement("div", { key: t.id }, /*#__PURE__*/
    React.createElement(FormComponent, { id: t.id }), /*#__PURE__*/
    React.createElement("article", { className: "lane" }, /*#__PURE__*/
    React.createElement("div", { className: "lane__info" }, /*#__PURE__*/
    React.createElement("h2", { className: "lane__title" }, t.title), /*#__PURE__*/
    React.createElement("span", { className: "lane__number" }, "(", t.tasks.length, ")")), /*#__PURE__*/

    React.createElement("div", { className: "lane__tasks" }, /*#__PURE__*/
    React.createElement(TaksComponent, {
      task: t.tasks,
      type: t.id,
      title: t.title })))))));







};
// -------------
const FormComponent = ({ id }) => {
  const { lane, setLanes } = useContext(TaskContext);
  const [name, setName] = useState("");

  const createTask = e => {
    e.preventDefault();
    let currentID = parseInt(e.target.id);

    if (name.trim().length > 0) {
      setLanes(
      lane.map(t => {
        if (t.id === currentID)
        return {
          ...t,
          tasks: [
          { id: uuidv4(), name: name, timestamp: new Date().toDateString() },
          ...t.tasks] };


        return t;
      }));

      setName("");
    }
  };

  return /*#__PURE__*/(
    React.createElement("form", { className: "form" }, /*#__PURE__*/
    React.createElement("input", {
      className: "form__input",
      type: "text",
      name: "task",
      placeholder: "Add a new task",
      autoComplete: "off",
      value: name,
      onChange: e => setName(e.target.value) }), /*#__PURE__*/

    React.createElement("button", { className: "form__submit", type: "submit", id: id, onClick: createTask }, "Add task")));




};
// -------------
const TaksComponent = ({ task, type, title }) => {
  const { lane, setLanes } = useContext(TaskContext);

  const changeTask = (e, op) => {
    let currentLane = parseInt(e.target.id);
    let currentID = e.currentTarget.value;
    let currentTask = lane.
    find(t => t.id === currentLane).
    tasks.find(t => t.id === currentID);
    let otherTask = lane.
    find(t => t.id === currentLane).
    tasks.filter(t => t.id !== currentID);

    console.log(currentID);

    setLanes(
    lane.map(t => {
      if (t.id === currentLane) return { ...t, tasks: otherTask };else
      if (t.id === eval(`${currentLane}${op}1`))
      return { ...t, tasks: [currentTask, ...t.tasks] };
      return t;
    }));

  };

  const deleteTask = e => {
    let currentLane = parseInt(e.target.id);
    let currentID = e.currentTarget.value;
    let otherTask = lane.
    find(t => t.id === currentLane).
    tasks.filter(t => t.id !== currentID);

    setLanes(
    lane.map(t => {
      if (t.id === currentLane) return { ...t, tasks: otherTask };
      return t;
    }));

  };

  return /*#__PURE__*/(
    React.createElement(React.Fragment, null,
    task.length === 0 ? /*#__PURE__*/
    React.createElement("p", { className: "task__empty" }, "Nothing to see here...") :

    task.map((t) => /*#__PURE__*/
    React.createElement("article", { className: `task task--${title}`, key: t.id }, /*#__PURE__*/
    React.createElement("p", { className: "task__name" }, t.name), /*#__PURE__*/
    React.createElement("div", { className: "task__info" }, /*#__PURE__*/
    React.createElement("span", { className: "task__timestamp" }, t.timestamp), /*#__PURE__*/
    React.createElement("div", { className: "task__buttons" },
    type > 0 && /*#__PURE__*/
    React.createElement("button", {
      className: "task__button",
      type: "button",
      title: "Previous Stage",
      bvalue: t.id,
      id: type,
      onClick: e => changeTask(e, "-") }, "\uD83E\uDC10"),




    type < 2 && /*#__PURE__*/
    React.createElement("button", {
      className: "task__button",
      type: "button",
      title: "Next Stage",
      value: t.id,
      id: type,
      onClick: e => changeTask(e, "+") }, "\uD83E\uDC12"), /*#__PURE__*/




    React.createElement("button", {
      className: "task__button",
      type: "button",
      title: "Delete Task",
      value: t.id,
      id: type,
      onClick: deleteTask }, "\xD7")))))));










};

// -------------
const KanbanPage = () => {
  return /*#__PURE__*/(
    React.createElement(TaskProvider, null, /*#__PURE__*/
    React.createElement("div", { className: "kanban" }, /*#__PURE__*/
    React.createElement("header", { className: "header" }, /*#__PURE__*/
    React.createElement("h1", { className: "header__title" }, "Testing")), /*#__PURE__*/

    React.createElement("main", { className: "main" }, /*#__PURE__*/
    React.createElement(LaneSection, null)))));




};
// ================
// ================
ReactDOM.render( /*#__PURE__*/React.createElement(KanbanPage, null), document.getElementById("root"));