const divs = document.querySelectorAll("div");
const colors = [
  "#CC0000",
  "#D11A1A",
  "#D63333",
  "#DB4D4D",
  "#E06666",
  "#E68080",
  "#EB9999",
  "#F0B3B3",
  "#F5CCCC",
  "#FAE6E6",

  "#FC835D",
  "#FC8F6D",
  "#FD9C7D",
  "#FDA88E",
  "#FDB59E",
  "#FEC1AE",
  "#FECDBE",
  "#FEDACE",
  "#FEE6DF",
  "#FFF3EF",

  "#FFDC1F",
  "#FFE035",
  "#FFE34C",
  "#FFE762",
  "#FFEA79",
  "#FFEE8F",
  "#FFF1A5",
  "#FFF5BC",
  "#FFF8D2",
  "#FFFCE9",

  "#68C74F",
  "#77CD61",
  "#86D272",
  "#95D884",
  "#A4DD95",
  "#B4E3A7",
  "#C3E9B9",
  "#D2EECA",
  "#E1F4DC",
  "#F0F9ED",

  "#16B0DD",
  "#2DB8E0",
  "#45C0E4",
  "#5CC8E7",
  "#73D0EB",
  "#8BD8EE",
  "#A2DFF1",
  "#B9E7F5",
  "#D0EFF8",
  "#E8F7FC",

  "#3760DD",
  "#4B70E0",
  "#5F80E4",
  "#7390E7",
  "#87A0EB",
  "#9BB0EE",
  "#AFBFF1",
  "#C3CFF5",
  "#D7DFF8",
  "#EBEFFC",

  "#983CDD",
  "#A250E0",
  "#AD63E4",
  "#B777E7",
  "#C18AEB",
  "#CC9EEE",
  "#D6B1F1",
  "#E0C5F5",
  "#EAD8F8",
  "#F5ECFC",

  "#DD58AE",
  "#E069B6",
  "#E479BE",
  "#E78AC6",
  "#EB9BCE",
  "#EEACD7",
  "#F1BCDF",
  "#F5CDE7",
  "#F8DEEF",
  "#FCEEF7",

  "#FFA1BD",
  "#FFAAC4",
  "#FFB4CA",
  "#FFBDD1",
  "#FFC7D7",
  "#FFD0DE",
  "#FFD9E5",
  "#FFE3EB",
  "#FFECF2",
  "#FFF6F8",

  "#666666",
  "#757575",
  "#858585",
  "#949494",
  "#A3A3A3",
  "#B3B3B3",
  "#C2C2C2",
  "#DADADA",
  "#EAEAEA",
  "#F0F0F0"
];
let n = 0;
function flip(d) {
  d.style.backgroundColor = colors[n];
  if (d.classList.contains("flip")) {
    d.classList.remove("flip");
  } else {
    d.classList.add("flip");
  }
}
for (let i = 0; i < divs.length; i++) {
  divs[i].addEventListener("mouseover", (e) => {
    flip(e.target);
  });
}
setInterval(() => {
  flip(divs[n]);
  n += 1;
  if (n >= colors.length) {
    n = 0;
  }
}, 300);