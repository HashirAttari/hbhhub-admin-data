$(".slider-big").slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  fade: true,
  asNavFor: ".slider-thumbs",
  draggable: true,
  speed: 1800,
  infinite: true,
  dots: false,
  arrows: false,
  cssEase: "cubic-bezier(0.7, 0, 0.3, 1)",
  touchThreshold: 100
});
$(".slider-thumbs").slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  asNavFor: ".slider-big",
  dots: false,
  speed: 1800,
  centerMode: true,
  vertical: true,
  arrows: false,
  focusOnSelect: true
});