console.clear();

/*
const colors = {
  blue: '#00fff1',
  red: '#ff2211',
  black: '#010101',
  yellow: '#f4f142',
  darkGrey: '#212121',
  lime: '#42ff3f',
  silver: 'silver',
  gold: 'gold',
  glass: 'rgba(0,0,0,1)'
};

/// npm dependency palettes.js
const palettes = {
  brand: {
    logo: 'blue',
    main: 'black',
    hightlight: 'lime'
  },
  typography: {
    default: 'brand--main', //optional default color
    heading: 'brand--logo', //links to palettes.brand
    title: 'brand--main',
    subtitle: 'darkGrey',
  },
  irregularity : {
    error: 'red',
    warning: 'yellow',
    notification: 'brand--hightlight'
  },
  interaction: {
    default: 'brand--hightlight',
    link: 'brand--logo',
    button: 'brand--hightlight'
  },
  layout: {
    lines: 'brand--main'
  },
  products: {
    silver: 'silver',
    gold: 'gold',
    platinum: 'glass'
  }
};
*/

/*
{
  "colors": {
    "zueriblau": "rgb(0, 60, 180)",
    "himmelblau": "rgb(0, 140, 210)",
    "himmelblau-hell": "rgb(130, 190, 245)",
    "nachtblau": "rgb(0, 0, 120)",
    "nachtblau-hell": "rgb(100, 135, 190)",
    "nachtblau-90": "rgba(0, 0, 120, 0.9)",
    "seeblau": "rgb(0, 190, 200)",
    "seeblau-hell": "rgb(130, 225, 225)",
    "weiss": "rgb(255, 255, 255)",
    "weiss-30": "rgba(255, 255, 255, .3)",
    "grau-dunkel": "rgb(168, 168, 168)",
    "grau": "rgb(200, 200, 200)",
    "grau-hell": "rgb(235, 235, 235)",
    "gruen": "rgb(40, 205, 120)",
    "gruen-hell": "rgb(155, 220, 140)",
    "korall": "rgb(245, 95, 105)",
    "korall-hell": "rgb(255, 155, 155)",
    "orange": "rgb(255, 152, 0)",
    "limmatblau": "rgb(0, 108, 255)",
    "sihlblau": "rgb(218, 232, 255)",
    "sihlblau-hell": "rgb(229, 238, 254)",
    "sihlblau-leicht": "rgb(239, 245, 255)",
    "transparent": "rgba(255, 255, 255, 0)",
    "deprecated": "rgb(255, 0, 255)"
  },
  "palettes": {
    "brand": {
      "default": "zueriblau",
      "shade": "nachtblau",
      "highlight": "seeblau",
      "contrast": "weiss"
    },
    "text": {
      "default": "brand--default",
      "title": "brand--default",
      "inverted": "brand--contrast",
      "disabled": "shade--medium",
      "highlight": "seeblau",
      "muted": "sihlblau",
      "error": "korall"
    },
    "interaction": {
      "default": "brand--default",
      "on-default": "text--inverted",
      "hover": "limmatblau",
      "on-hover": "text--inverted",
      "active": "limmatblau",
      "on-active": "text--inverted",
      "discreet": "sihlblau-leicht",
      "focus": "interaction--default",
      "disabled": "grau-hell",
      "on-disabled": "shade--dark",
      "disabled-text": "shade--dark",
      "error": "korall"
    },
    "interaction-inverted": {
      "default": "brand--contrast",
      "on-default": "brand--default",
      "hover": "seeblau-hell",
      "on-hover": "brand--default",
      "active": "seeblau-hell",
      "on-active": "brand--default",
      "focus": "seeblau-hell",
      "disabled": "weiss-30",
      "on-disabled": "weiss-30",
      "disabled-text": "weiss-30",
      "error": "korall"
    },
    "input": {
      "default": "sihlblau-leicht",
      "placeholder": "text--default"
    },
    "shade": {
      "light": "grau-hell",
      "medium": "grau-mittel",
      "dark": "grau-dunkel"
    },
    "notification": {
      "error": "korall",
      "warning": "orange",
      "success": "gruen",
      "neutral": "himmelblau-hell",
      "info": "himmelblau",
      "positive": "notification--success",
      "negative": "notification--error"
    },
    "pikto": {
      "decoration": "brand--highlight",
      "decoration-inverted": "seeblau-hell"
    },
    "layout": {
      "background": "brand--contrast",
      "line": "brand--default",
      "navigation": "brand--default",
      "shadow": "shade--dark",
      "border": "sihlblau",
      "header": "brand--contrast",
      "header-inverted": "brand--shade",
      "modal-backdrop": "nachtblau-90",
      "progress": "interaction--active",
      "shell-header": "context--normal",
      "shell-sidebar": "context--strong"
    },
    "dataviz": {
      "neutral": "himmelblau-hell",
      "neutral-min": "nachtblau",
      "neutral-max": "nachtblau-hell",
      "positive-min": "gruen",
      "positive-max": "gruen-hell",
      "negative": "korall-hell"
    },
    "context": {
      "normal": "brand--contrast",
      "weak": "sihlblau-leicht",
      "strong": "brand--shade",
      "strong-alt": "brand--default",
      "none": "transparent"
    },
    "debug": {
      "default": "deprecated"
    }
  }
}
*/

const colors = {
  "zueriblau": "rgb(0, 60, 180)",
  "himmelblau": "rgb(0, 140, 210)",
  "himmelblau-hell": "rgb(130, 190, 245)",
  "nachtblau": "rgb(0, 0, 120)",
  "nachtblau-hell": "rgb(100, 135, 190)",
  "nachtblau-90": "rgba(0, 0, 120, 0.9)",
  "seeblau": "rgb(0, 190, 200)",
  "seeblau-hell": "rgb(130, 225, 225)",
  "weiss": "rgb(255, 255, 255)",
  "weiss-30": "rgba(255, 255, 255, .3)",
  "grau-dunkel": "rgb(168, 168, 168)",
  "grau": "rgb(200, 200, 200)",
  "grau-hell": "rgb(235, 235, 235)",
  "gruen": "rgb(40, 205, 120)",
  "gruen-hell": "rgb(155, 220, 140)",
  "korall": "rgb(245, 95, 105)",
  "korall-hell": "rgb(255, 155, 155)",
  "orange": "rgb(255, 152, 0)",
  "limmatblau": "rgb(0, 108, 255)",
  "sihlblau": "rgb(218, 232, 255)",
  "sihlblau-hell": "rgb(229, 238, 254)",
  "sihlblau-leicht": "rgb(239, 245, 255)",
  "transparent": "rgba(255, 255, 255, 0)",
  "deprecated": "rgb(255, 0, 255)" };


let palettes = {
  "brand": {
    "default": "zueriblau",
    "shade": "nachtblau",
    "highlight": "seeblau",
    "contrast": "weiss" },

  "text": {
    "default": "brand--default",
    "title": "brand--default",
    "inverted": "brand--contrast",
    "disabled": "shade--medium",
    "highlight": "seeblau",
    "muted": "sihlblau",
    "error": "korall" },

  "interaction": {
    "default": "brand--default",
    "on-default": "text--inverted",
    "hover": "limmatblau",
    "on-hover": "text--inverted",
    "active": "limmatblau",
    "on-active": "text--inverted",
    "discreet": "sihlblau-leicht",
    "focus": "interaction--default",
    "disabled": "grau-hell",
    "on-disabled": "shade--dark",
    "disabled-text": "shade--dark",
    "error": "korall" },

  "interaction-inverted": {
    "default": "brand--contrast",
    "on-default": "brand--default",
    "hover": "seeblau-hell",
    "on-hover": "brand--default",
    "active": "seeblau-hell",
    "on-active": "brand--default",
    "focus": "seeblau-hell",
    "disabled": "weiss-30",
    "on-disabled": "weiss-30",
    "disabled-text": "weiss-30",
    "error": "korall" },

  "input": {
    "default": "sihlblau-leicht",
    "placeholder": "text--default" },

  "shade": {
    "light": "grau-hell",
    "medium": "grau-mittel",
    "dark": "grau-dunkel" },

  "notification": {
    "error": "korall",
    "warning": "orange",
    "success": "gruen",
    "neutral": "himmelblau-hell",
    "info": "himmelblau",
    "positive": "notification--success",
    "negative": "notification--error" },

  "pikto": {
    "decoration": "brand--highlight",
    "decoration-inverted": "seeblau-hell" },

  "layout": {
    "background": "brand--contrast",
    "line": "brand--default",
    "navigation": "brand--default",
    "shadow": "shade--dark",
    "border": "sihlblau",
    "header": "brand--contrast",
    "header-inverted": "brand--shade",
    "modal-backdrop": "nachtblau-90",
    "progress": "interaction--active",
    "shell-header": "context--normal",
    "shell-sidebar": "context--strong" },

  "dataviz": {
    "neutral": "himmelblau-hell",
    "neutral-min": "nachtblau",
    "neutral-max": "nachtblau-hell",
    "positive-min": "gruen",
    "positive-max": "gruen-hell",
    "negative": "korall-hell" },

  "context": {
    "normal": "brand--contrast",
    "weak": "sihlblau-leicht",
    "strong": "brand--shade",
    "strong-alt": "brand--default",
    "none": "transparent" }
  /*
  "debug": {
  "default": "deprecated"
  }*/ };

/**
palettes =     {
  "brand": {
      "default": "zueriblau",
      "shade": "nachtblau",
      "highlight": "seeblau",
      "contrast": "weiss"
    },
    "text": {
      "default": "brand--default",
      "title": "brand--default",
      "inverted": "brand--contrast",
      "disabled": "shade--dark",
      "highlight": "seeblau",
      "muted": "nachtblau-hell",
      "error": "korall"
    },
    "interaction": {
      "default": "brand--default",
      "on-default": "text--inverted",
      "hover": "limmatblau",
      "on-hover": "text--inverted",
      "active": "limmatblau",
      "on-active": "text--inverted",
      "focus": "interaction--default",
      "discreet": "sihlblau-leicht",
      "on-discreet": "brand--default",
      "disabled": "grau-leicht",
      "on-disabled": "grau",
      "disabled-text": "interaction--on-disabled",
      "error": "korall"
    },
    "interaction-inverted": {
      "default": "brand--contrast",
      "on-default": "brand--default",
      "hover": "seeblau-hell",
      "on-hover": "brand--default",
      "active": "seeblau-hell",
      "on-active": "brand--default",
      "focus": "seeblau-hell",
      "disabled": "weiss-30",
      "on-disabled": "weiss-30",
      "disabled-text": "weiss-30",
      "error": "korall"
    },
    "input": {
      "default": "sihlblau-leicht",
      "placeholder": "text--default"
    },
    "shade": {
      "light": "grau-leicht",
      "medium": "grau-hell",
      "dark": "grau"
    },
    "notification": {
      "error": "korall",
      "warning": "orange",
      "success": "gruen",
      "neutral": "himmelblau-hell",
      "info": "himmelblau",
      "positive": "notification--success",
      "negative": "notification--error"
    },
    "pikto": {
      "decoration": "brand--highlight",
      "decoration-inverted": "seeblau-hell"
    },
    "layout": {
      "background": "brand--contrast",
      "line": "brand--default",
      "border": "sihlblau",
      "navigation": "brand--default",
      "header": "context--normal",
      "header-inverted": "context--strong",
      "footer": "context--normal",
      "modal-backdrop": "nachtblau-90",
      "progress": "interaction--active",
      "page-sidenav": "context--normal",
      "page-sidenav-inverted": "context--strong"
    },
    "dataviz": {
      "neutral": "himmelblau-hell",
      "neutral-min": "nachtblau",
      "neutral-max": "nachtblau-hell",
      "positive-min": "gruen",
      "positive-max": "gruen-hell",
      "negative": "korall-hell"
    },
    "context": {
      "normal": "brand--contrast",
      "weak": "sihlblau-leicht",
      "strong": "brand--shade",
      "strong-alt": "brand--default",
      "none": "transparent"
    },
    "debug": {
      "default": "deprecated"
    }
  }
/**
**/

class Paletter {
  // palettename--name
  /**
   * Creates an instance of Paletter.
   * @param {Object} paletteObj colors palettes
   * @param {Object} colors Raw color values {name: value}
   * @param {Object} [options={}] Default options
   */
  constructor(paletteObj, colors, options = {}) {
    this.defaults = {
      separator: '--',
      modifier: '',
      defaultColorKey: 'default' };

    this.options = Object.assign({}, this.defaults, options);
    this.colors = Object.assign({}, colors);
    this.palette = Object.assign({}, paletteObj);
    this._validateColors();
  }

  /**
   * makes sure a a color is valid by creating a chroma instance of that color
   * @static
   * @param {string|number} value color value as rgb, hex, hsl... string
   * @return {Boolean}
   */
  static isValidColor(value) {
    return chroma.valid(value);
  }

  /**
   * Makes sure all colors passed to the Palette are valid
   */
  _validateColors() {
    const invalidColors = Object.entries(this.colors).filter((entry) =>
    !Paletter.isValidColor(entry[1]));


    if (invalidColors.length) {
      console.log('following colors are invalid:', invalidColors);
    }
  }

  /**
   * returns a string containg the palette plus color within it
   * @param {String} palette palette name
   * @param {String} key color key within palette
   * @return {String}
   */
  _getPaletteKey(palette, key) {
    return `${palette}${this.options.separator}${key}`;
  }

  /**
   * remaps all the color names to the actual color value
   * @param {Object} palettes You palette object
   * @return {Object} parsed palette with color values instead of links
   */
  _parsePalette(palettes) {
    const parsedPalette = {};
    for (let palette in palettes) {
      parsedPalette[palette] = {};
      for (let key in palettes[palette]) {
        parsedPalette[palette][key] =
        this.getColor(this._getPaletteKey(palette, key)).value;
      }
    }
    return parsedPalette;
  }

  /**
   * @return {Object} palette parsed by _parsePalette
   */
  getParsed() {
    return this._parsePalette(this.palette);
  }

  /**
   * parses key passed to the getColor method
   * @param {String} paletteKey
   * @return {Object} containing a property with the palette palette and
   *                  color key
   */
  _parseKey(paletteKey) {
    const parts = paletteKey.split(this.options.separator);
    return {
      palette: parts[0],
      color: parts[0].length > 1 && parts[1] ?
      parts[1] : this.options.defaultColorKey };

  }

  /**
   * Gets color value string and return if its a link to an other palette value
   * @param {String} value
   * @return {Boolean}
   */
  _isPaletteLink(value) {
    return value.indexOf(this.options.separator) !== -1;
  }

  /**
   * returns a color value from this.palette
   * and checks if the palette and color exists
   *
   * @param {String} palette name of the palette (property name of this.palette)
   * @param {String} key name of the color within a palette
   *                     (property name of this.palette[paletteKey])
   * @return {String} color value
   */
  _getKeyReference(palette, key) {
    let paletteRef;

    if (this.palette.hasOwnProperty(palette)) {
      paletteRef = this.palette[palette];
    } else {
      throw new Error(`no palette called "${palette}"`);
    }

    if (paletteRef.hasOwnProperty(key)) {
      return paletteRef[key];
    } else {
      throw new Error(`no color called "${key}" in "${palette}"`);
    }
  }

  /**
   * @param {String} paletteKey typically contains a palette--key string
   * @param {Array} [callStack=[]] Stores all previous calls to make sure we
   *                               don't infinite loop
   * @return {Object} val: color string stored in color object, name: name in
   *                  color palette
   */
  getColor(paletteKey, callStack = []) {
    if (callStack.indexOf(paletteKey) > -1) {
      throw new Error('you have infinite recursion in your palette');
    }

    const parsedKey = this._parseKey(paletteKey);
    const colorKey = this._getKeyReference(parsedKey.palette, parsedKey.color);

    if (this._isPaletteLink(colorKey)) {
      return this.getColor(colorKey, callStack.concat([paletteKey]));
    } else {
      return {
        value: this.colors[colorKey],
        name: colorKey };

    }
  }

  /**
   * Returns all connections of between palettes
   * @return {Array} List of all connections
   */
  getConnections() {
    const connections = [];
    for (const paletteKey in this.palette) {
      const palette = this.palette[paletteKey];
      for (const colorName in palette) {
        const colorValue = palette[colorName];
        if (this._isPaletteLink(colorValue)) {
          const parsedTargetKey = this._parseKey(colorValue);
          connections.push({
            from: {
              key: this._getPaletteKey(paletteKey, colorName),
              ref: this._parseKey(colorValue) },

            to: {
              key: colorValue,
              ref: this._getKeyReference(
              parsedTargetKey.palette,
              parsedTargetKey.color) } });



        }
      }
    }
    return connections;
  }}


/// Demo
const palette = new Paletter(palettes, colors);

//console.log( 'palette', palette.getParsed() );
//console.log( 'connections', palette.getConnections() );

const parsedPalette = palette.getParsed();
const paletteConnections = palette.getConnections();

let palettesArr = Object.keys(parsedPalette);

palettesArr = palettesArr.map(paletteKey => {
  return {
    name: paletteKey,
    colors: parsedPalette[paletteKey],
    connectionsTo: paletteConnections.filter((c) =>
    c.from.key.split('--')[0] === paletteKey) };


}).sort((p1, p2) => p2.connectionsTo.length - p1.connectionsTo.length);

//probably need some kind of topsoort here
//console.log(palettesArr);

const $app = document.querySelector('#app');

function createNode(palette, nodePosition) {
  const $div = document.createElement('div');
  $div.classList.add('node');

  const pal = Object.keys(palette.colors).map(key => {
    return {
      name: key,
      value: palette.colors[key] };

  });

  //console.log('ct', palette.name, palette.connectionsTo);

  $div.innerHTML = `
    <h2>${palette.name}</h2>
    <ol>
      ${pal.reduce((rem, p, i) => {
    const localConnections = palette.connectionsTo.filter(c => c.from.key === `${palette.name}--${p.name}`);

    return `${rem}
          <li style="--color: ${p.value}">
            <span 
              id="${palette.name}--${p.name}"
              data-color="${p.value}"
              data-n="${i}"
              data-totalnodes="${pal.length}"
              data-parentposx="${nodePosition[0]}"
              data-parentposy="${nodePosition[1]}"
              data-connectionpoint="true"
              ${localConnections.length ?
    `data-connections="${
    localConnections.reduce((rem, d) => `${rem ? ',' : ''}${d.to.key}`, '')
    }"` : ''
    }
            ></span>
            <strong>${p.name}</strong>
          </li>`;}, '')}
    </ol>
  `;

  return $div;
}


function toRadians(angle) {
  return angle * (Math.PI / 180);
}

let partRadAngle = toRadians(360 / palettesArr.length);

palettesArr.forEach((pal, i) => {
  let pos = [0, 0];

  pos = [
  .5 + Math.sin(i * partRadAngle) * .35,
  .5 - Math.cos(i * partRadAngle) * .35];


  const $node = createNode(pal, pos);

  $node.style.setProperty('--x', pos[0]);
  $node.style.setProperty('--y', pos[1]);

  if (pos[0] < .5) {
    $node.classList.add('left');
  } else {
    $node.classList.add('right');
  }

  $app.appendChild($node);
});

let appBox = $app.getBoundingClientRect();

let connectionNodes = Array.from(document.querySelectorAll('[data-connections]'));

const $svg = document.querySelector('svg');

connectionNodes.forEach(($cn, i) => {
  const $target = document.querySelector('#' + $cn.dataset.connections);
  const rect = $cn.getBoundingClientRect();
  const targetRect = $target.getBoundingClientRect();
  const parentPosX = parseFloat($cn.dataset.parentposx);
  const targetParentPosX = parseFloat($target.dataset.parentposx);
  const n = parseFloat($target.dataset.n);
  const totalnodes = parseFloat($target.dataset.totalnodes);


  const top = (rect.top + rect.height * .5 - appBox.top) / appBox.height;
  const left = (rect.left + rect.width * .5 - appBox.left) / appBox.width;

  const targetTop = (targetRect.top + targetRect.height * .5 - appBox.top) / appBox.height;
  const targetLeft = (targetRect.left + targetRect.width * .5 - appBox.left) / appBox.width;

  const goToLeft = parentPosX < .5;
  const targetHoGoLeft = targetParentPosX < .5;
  const yDiff = Math.abs(left - targetLeft);
  //Math.pow(10,(i/connectionNodes.length))
  const amp = 20 + (1 - n / totalnodes) * 30 + yDiff * 200;


  const newpath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  newpath.setAttributeNS(null, 'd', `M ${left * 1000} ${top * 1000} C ${left * 1000 + (goToLeft ? amp : -amp)} ${top * 1000}, ${targetLeft * 1000 + (targetHoGoLeft ? amp : -amp)} ${targetTop * 1000}, ${targetLeft * 1000} ${targetTop * 1000}`);

  newpath.setAttributeNS(null, 'stroke', $cn.dataset.color);

  const point = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
  point.setAttributeNS(null, 'cx', `${targetLeft * 1000}`);
  point.setAttributeNS(null, 'cy', `${targetTop * 1000}`);
  point.setAttributeNS(null, 'r', `${6}`);

  point.setAttributeNS(null, 'stroke', $cn.dataset.color);
  newpath.dataset.to = $cn.dataset.connections;
  newpath.dataset.from = $cn.id;

  $svg.appendChild(newpath);
  $svg.appendChild(point);
});

document.querySelector('#app').addEventListener('mouseenter', e => {
  if (e.target.dataset.connectionpoint) {
    let paths = Array.from(document.querySelectorAll(`[data-to=${e.target.id}], [data-from=${e.target.id}]`));
    paths.forEach($p => $p.classList.add('highlight'));
  }
}, { capture: true });

document.querySelector('#app').addEventListener('mouseleave', e => {
  if (e.target.dataset.connectionpoint) {
    console.log(e.target.id);
    let paths = Array.from(document.querySelectorAll(`[data-to=${e.target.id}], [data-from=${e.target.id}]`));
    paths.forEach($p => $p.classList.remove('highlight'));
  }
}, { capture: true });