# Candy Heart

A Pen created on CodePen.

Original URL: [https://codepen.io/kathykato/pen/WMEJMg](https://codepen.io/kathykato/pen/WMEJMg).

Happy Valentine's Day!  Here's a candy heart made with CSS (SCSS) and animated using GreenSock (GSAP)!