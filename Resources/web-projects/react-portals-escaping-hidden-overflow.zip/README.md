# React Portals: Escaping Hidden Overflow

A Pen created on CodePen.io. Original URL: [https://codepen.io/jscottsmith/pen/xYaawK](https://codepen.io/jscottsmith/pen/xYaawK).

Artboard that lets you create shapes within a window.

More info here =>[blog post](https://codepen.io/jscottsmith/post/react-16-s-stellar-new-portal-api).