function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}function _defineProperty(obj, key, value) {if (key in obj) {Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true });} else {obj[key] = value;}return obj;} /**
 * -------------------------------------------------------
 * Context Menu
 * -------------------------------------------------------
 */

const ContextMenu = ({
  addShape,
  closeMenu,
  portalEl,
  menuX,
  menuY,
  artX,
  artY }) =>
{
  const menu = /*#__PURE__*/
  React.createElement("nav", {
    className: "context-menu",
    style: {
      top: menuY,
      left: menuX } }, /*#__PURE__*/


  React.createElement("ul", null, /*#__PURE__*/
  React.createElement("li", {
    className: "menu-item",
    onClick: event => {
      addShape({ x: artX, y: artY, type: 'square' });
      closeMenu();
    } }, "Add Shape: Square"), /*#__PURE__*/



  React.createElement("li", {
    className: "menu-item",
    onClick: event => {
      addShape({ x: artX, y: artY, type: 'circle' });
      closeMenu();
    } }, "Add Shape: Circle"), /*#__PURE__*/



  React.createElement("li", {
    className: "menu-item",
    onClick: event => {
      addShape({ x: artX, y: artY, type: 'diamond' });
      closeMenu();
    } }, "Add Shape: Diamond"), /*#__PURE__*/






  React.createElement("hr", null), /*#__PURE__*/
  React.createElement("li", null, "Fake Menu Item: Foo"), /*#__PURE__*/
  React.createElement("li", null, "Fake Menu Item: Bar"), /*#__PURE__*/
  React.createElement("hr", null), /*#__PURE__*/
  React.createElement("li", null, "Fake Menu Item: Bat"), /*#__PURE__*/
  React.createElement("li", null, "Fake Menu Item: Bin"), /*#__PURE__*/
  React.createElement("li", null, "Fake Menu Item: Foe"), /*#__PURE__*/
  React.createElement("hr", null), /*#__PURE__*/
  React.createElement("li", null, "Fake Menu Item: Fat"), /*#__PURE__*/
  React.createElement("li", null, "Fake Menu Item: Bot")));




  // if the portal el is available render into it.
  // This is just for demo purposes to toggle between states.

  return portalEl ? ReactDOM.createPortal(menu, portalEl) : menu;
};


/**
 * -------------------------------------------------------
 * Window
 * -------------------------------------------------------
 */

const Window = ({ children, title }) => /*#__PURE__*/
React.createElement("section", { className: "window" }, /*#__PURE__*/
React.createElement("header", null, /*#__PURE__*/
React.createElement("h2", null, title), /*#__PURE__*/
React.createElement("div", { className: "controls" }, /*#__PURE__*/
React.createElement("span", { className: "red" }), /*#__PURE__*/
React.createElement("span", { className: "yellow" }), /*#__PURE__*/
React.createElement("span", { className: "green" }))),


children);



/**
 * -------------------------------------------------------
 * Shape
 * -------------------------------------------------------
 */

class Shape extends React.Component {
  render() {
    const { x, y, type } = this.props;
    return /*#__PURE__*/React.createElement("div", { className: `shape ${type}`, style: { top: y, left: x } });
  }}


/**
 * -------------------------------------------------------
 * Artboard
 * -------------------------------------------------------
 */

function randomIntBetween(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

class Artboard extends React.Component {
  constructor() {
    super();_defineProperty(this, "state",



    {
      portalActive: false,
      menuOpen: false,
      menuX: 0,
      menuY: 0,
      shapes: this.generateRandomArt() });_defineProperty(this, "handleClick",
















    event => {
      const { clientX: x, clientY: y } = event;
      const { top, left } = this.artboard.getBoundingClientRect();
      const artX = x - left;
      const artY = y - top;

      this.setState(({ menuOpen }) => ({
        menuOpen: !menuOpen,
        menuX: x,
        menuY: y,
        artX,
        artY }));

    });_defineProperty(this, "handleCloseMenu",

    () => {
      this.setState(() => ({
        menuOpen: false }));

    });_defineProperty(this, "handleTogglePortal",

    () => {
      this.setState(({ portalActive }) => ({
        portalActive: !portalActive }));

    });_defineProperty(this, "handleAddObject",

    newShape => {
      const shapes = [...this.state.shapes, newShape];
      this.setState(() => ({ shapes }));
    });this.portalEl = document.getElementById('context-menu');}generateRandomArt() {const mw = 5000;const mh = 5000;const types = ['circle', 'square', 'diamond'];const shapes = new Array(randomIntBetween(80, 150)).fill({}).map(shape => ({ x: randomIntBetween(0, mw), y: randomIntBetween(0, mh), type: types[randomIntBetween(0, types.length)] }));return shapes;}

  render() {
    const { children } = this.props;
    const {
      portalActive,
      menuOpen,
      menuX,
      menuY,
      artX,
      artY,
      shapes,
      event } =
    this.state;

    return /*#__PURE__*/(
      React.createElement(React.Fragment, null, /*#__PURE__*/
      React.createElement("div", { className: "scroll", onClick: this.handleClick }, /*#__PURE__*/
      React.createElement("div", {
        className: "artboard",
        ref: ref => this.artboard = ref },

      shapes.map((config, i) => /*#__PURE__*/
      React.createElement(Shape, _extends({ key: i }, config))))),









      menuOpen && /*#__PURE__*/
      React.createElement(ContextMenu, {
        menuX: menuX,
        menuY: menuY,
        artX: artX,
        artY: artY,
        portalEl: portalActive ? this.portalEl : null,
        addShape: this.handleAddObject,
        closeMenu: this.handleCloseMenu }), /*#__PURE__*/







      React.createElement("button", {
        className: "portal-toggle",
        onClick: this.handleTogglePortal },

      portalActive ? 'Disable Portal' : 'Activate Portal')));



  }}


const App = () => /*#__PURE__*/
React.createElement("main", null, /*#__PURE__*/
React.createElement(Window, { title: "Artboard Window" }, /*#__PURE__*/
React.createElement(Artboard, null)));




const run = () => {
  const root = document.getElementById("root");

  ReactDOM.render( /*#__PURE__*/React.createElement(App, null), root);
};

run();