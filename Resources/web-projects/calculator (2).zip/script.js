const state = {
  previewQuantity: '',
  previewHistory: '',
  newOperation: true
};
const previewer = document.querySelector('.resultPreview .result');
const history = document.querySelector('.resultPreview .history');
const execResult = document.querySelector('.button[data-type="exec"]');

window.addEventListener('load', () => {
  // render();

  //Numbers
  document.querySelectorAll('.button[data-type="number"]').forEach(button => {
    button.addEventListener('click', event => {
      if (!state.unlockedButtons) updateState({ ...state, unlockedButtons: true });
      const value = event.currentTarget.dataset.value;
      let previewQuantity;
      switch (value) {
        case '.':
          previewQuantity = state.execResult ? value : previewer.innerText.includes('.') ? previewer.innerText : previewer.innerText + value;
          break;
        case '-':
          previewQuantity = state.execResult ? value : previewer.innerText.includes('-') ? previewer.innerText.slice(1) : value + previewer.innerText;
          break;
        default:
          previewQuantity = state.execResult ? value : previewer.innerText + value;
          break;
      }
      execResult.classList.remove('disabled');
      document.querySelectorAll('.button[data-type="cleaner"]').forEach(b => b.classList.remove('disabled'));
      document.querySelectorAll('.button[data-type="memory"]').forEach(b => b.classList.remove('disabled'));
      updateState({ ...state,
                   previewQuantity,
                   execResult: false
                  });
    })
  })
  //Operators
  document.querySelectorAll('.button[data-type="operator"]').forEach(button => {
    button.addEventListener('click', event => {
      if (state.unlockedButtons) updateState({ ...state, unlockedButtons: false });
      const value = event.currentTarget.dataset.value;
      previewer.dataset.pq = state.previewQuantity;
      switch (value) {
        case '1/':
          updateState({ ...state,
                       previewHistory: value + state.previewQuantity,
                       previewQuantity: '',
                       newOperation: false
                      });
          execResult.click();
          break;
        case '²√':
          let result = Math.sqrt(state.previewQuantity);
          updateState({
            ...state,
            previewHistory: result ? value + state.previewQuantity : '',
            previewQuantity: result || '-Error',
            unlockedButtons: result ? true : false,
            newOperation: true,
            execResult: true
          });
          execResult.classList.add('disabled');
          break;
        default:
          let newHistory = state.previewHistory + state.previewQuantity + value;
          updateState({ ...state,
                       previewHistory: (state.previewHistory.length && !state.newOperation) ? newHistory : state.previewQuantity + value,
                       previewQuantity: '',
                       newOperation: false
                      });
          break;
      }
    })
  })
  //Clean buttons
  document.querySelectorAll('.button[data-type="cleaner"]').forEach(button => {
    button.addEventListener('click', event => {
      switch (event.currentTarget.dataset.cleaner) {
        case 'current':
          previewer.dataset.pq = 0;
          execResult.classList.add('disabled');
          event.currentTarget.classList.add('disabled');
          document.querySelector('.button[data-cleaner="char"]').classList.add('disabled');
          if (!state.previewHistory.length) document.querySelector('.button[data-cleaner="full"]').classList.add('disabled');
          updateState({ ...state, previewQuantity: '', unlockedButtons: false });
          break;
        case 'full':
          previewer.dataset.pq = 0;
          execResult.classList.add('disabled');
          document.querySelectorAll('.button[data-type="cleaner"]').forEach(b => b.classList.add('disabled'));
          updateState({ ...state, previewHistory: '', previewQuantity: '', unlockedButtons: false });
          break;
        case 'char':
          updateState({ ...state, previewQuantity: state.previewQuantity.toString().slice(0, -1) });
          if (!state.previewQuantity.length) {
            previewer.dataset.pq = 0;
            execResult.classList.add('disabled');
            event.currentTarget.classList.add('disabled');
            document.querySelector('.button[data-cleaner="current"]').classList.add('disabled');
            updateState({ ...state, unlockedButtons: false });
            if (!state.previewHistory.length) document.querySelector('.button[data-cleaner="full"]').classList.add('disabled');
          }
          break;
        default:
          break;
      }
    })
  })
  //Memory buttons
  document.querySelectorAll('.button[data-type="memory"]').forEach(button => {
    button.addEventListener('click', event => {
      switch (event.currentTarget.dataset.opc) {
        case 'add':
          updateState({ ...state, memory: state.previewQuantity.toString(), previewQuantity: '' });
          previewer.dataset.pq = 0;
          break;
        case 'clear':
          updateState({ ...state, memory: '' });
          break;
        case 'read':
          if (state.memory.length) {
            updateState({ ...state, previewQuantity: state.memory, unlockedButtons: true });
            document.querySelectorAll('.button[data-type="cleaner"]').forEach(b => b.classList.remove('disabled'));
          }
          break;
        default:
          break;
      }
    })
  })
  //Exec result
  execResult.addEventListener('click', _ => {
    execResult.classList.add('disabled');
    let previewHistory, previewQuantity, unlockedButtons;
    try {
      previewHistory = state.previewHistory + state.previewQuantity;
      previewQuantity = eval(state.previewHistory + state.previewQuantity);
      unlockedButtons = true;
    } catch (error) {
      previewHistory = '';
      previewQuantity = '-Error';
      unlockedButtons = false;
    }
    updateState({ ...state, previewHistory, previewQuantity, unlockedButtons, newOperation: true, execResult: true });
  })
})

const updateState = (newState) => {
  Object.assign(state, newState);
  render();
}
const render = () => {
  previewer.innerText = state.previewQuantity;
  history.innerText = state.previewHistory;
  document.querySelectorAll('.button[data-type="operator"]').forEach(b => {
    state.unlockedButtons ? b.classList.remove('disabled') : b.classList.add('disabled');
  });
  history.dataset.memory = state.memory?.length ? `In memory: ${state.memory}` : '';
}