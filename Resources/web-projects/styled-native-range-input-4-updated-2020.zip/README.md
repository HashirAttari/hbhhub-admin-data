# Styled native range input #4 (updated 2020)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/Bymjmm](https://codepen.io/thebabydino/pen/Bymjmm).

**January 2020 update**

Demo now uses CSS variables and conic gradients. JS not needed for Firefox & Edge.

---

**Initial description**

Goal: create a nicely styled crossbrowser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling the slider track. Fallback for no JS: simply display the same shade of grey for the entire track, both before and after the thumb. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found.

Original design: [Led Slider](https://designshack.net/design/led-slider/) ([via](https://i.imgur.com/0W03qXZ.jpg))