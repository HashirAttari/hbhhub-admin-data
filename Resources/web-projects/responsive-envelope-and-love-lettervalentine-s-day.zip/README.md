# Responsive Envelope and Love Letter - Valentine's Day

A Pen created on CodePen.

Original URL: [https://codepen.io/ibbuilds/pen/MWbbVBW](https://codepen.io/ibbuilds/pen/MWbbVBW).

for u.. ♥
---------------------------------------------------------------------------------------------
Envelop and love letter made it by me.
HTML, CSS, JS, GSAP.
2021.