var joystick = nipplejs.create({
    zone: document.body,
    mode: 'static',
    position: {
      left: '70px',
      bottom: '70px'
    },
    color: 'white'
});

joystick.on('dir plain end', function(evt, data) {
  if (evt.type != 'end') {
    document.querySelector('.keymap').innerHTML = data.direction.x+' '+data.direction.y+'<br>';
    document.querySelector('.keymap').innerHTML += Math.round(data.angle.degree);
    if (data.angle.degree < -90 && data.angle.degree > -140) {
      document.querySelector('.keymap').innerHTML += ' downright';
    }
    else if (data.angle.degree > -45 && data.angle.degree < -25) {
      document.querySelector('.keymap').innerHTML += ' downleft';
    }
    else if (data.angle.degree > 120 && data.angle.degree < 140) {
      document.querySelector('.keymap').innerHTML += ' upright';
    }
    else if (data.angle.degree > 0 && data.angle.degree < 90) {
      document.querySelector('.keymap').innerHTML += ' upleft';
    }
  }
  else {
    document.querySelector('.keymap').innerHTML = '';
  }
})