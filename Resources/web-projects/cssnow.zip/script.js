//just to add spans so HTML windows doesnt look ugly :P
for(let i=0;i<9;i++){
  document.querySelector('.cssnow').innerHTML += '<span>';}