# iPhone X

A Pen created on CodePen.io. Original URL: [https://codepen.io/ryanzola/pen/wqOJdm](https://codepen.io/ryanzola/pen/wqOJdm).

Pure CSS iPhone X