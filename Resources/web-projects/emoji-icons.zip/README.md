# Emoji Icons

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/RwGyJNZ](https://codepen.io/markmead/pen/RwGyJNZ).

