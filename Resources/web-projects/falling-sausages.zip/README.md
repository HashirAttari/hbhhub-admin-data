# Falling Sausages

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/yLOOPqJ](https://codepen.io/chrisgannon/pen/yLOOPqJ).

Messing around with Illustrator's Puppet Warp tool combined with Greensock's MorphSVGPlugin. Ace combo!