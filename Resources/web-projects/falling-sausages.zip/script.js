let select = s => document.querySelector(s),
  selectAll = s =>  document.querySelectorAll(s),
		mainSVG = select('#mainSVG')

function blendEases(startEase, endEase, blender) {
    var s = gsap.parseEase(startEase),
        e = gsap.parseEase(endEase),
        blender = gsap.parseEase(blender || "power3.inOut");
    return function(v) {
      var b = blender(v);
      return s(v) * (1 - b) + e(v) * b;
    };
}

gsap.set('svg', {
	visibility: 'visible'
})
let rollEase = blendEases('expo.in', 'sine')
let sausage1Tl = gsap.timeline({repeat: -1, repeatDelay: 1.5});
sausage1Tl
	.from('#sausageGroup', {
	y: -1500,
	ease: 'power1.in'
})
	.add('bend')
	.to('#sausage', {
	morphSVG: {
		shape: '#sausageEnd'
	},
	duration: 0.5,
	ease: 'elastic(2, 0.6)'
}, 'bend')
.to('#sausageShine', {
	morphSVG: {
		shape: '#sausageShineEnd'
	},
	duration: 0.5,
	ease: 'elastic(2, 0.6)'
}, 'bend')
.to('#sausageGroup', {
	rotation: 90,
	duration: 1.5,
	ease: rollEase,
	svgOrigin: '403 322'
})

	.add('straight', '-=1')
	.to('#sausage', {
	morphSVG: {
		shape: "M563.58,312.78c-104.32.38-220.84.4-325.16,0C202.73,312.63,174,292.36,174,262s28.75-50.64,64.42-50.78c104.3-.4,220.87-.38,325.15,0C599.24,211.35,627,231.65,627,262S599.27,312.65,563.58,312.78Z"
	},
	duration: 1,
	ease: rollEase
}, 'straight')
.to('#sausageShine', {
	morphSVG: {
		shape: "M567,230H243a4,4,0,0,1-4-4h0a4,4,0,0,1,4-4H567a4,4,0,0,1,4,4h0A4,4,0,0,1,567,230Z"
	},
	duration: 1,
	ease: rollEase
}, 'straight')
.to('#sausageGroup', {
	x: 0,
	duration: 0.2,
	ease: 'linear'
	
}, 'straight+=0.3')
.to('#sausageGroup', {
	y: 600,
	x: 120,
	duration: 0.3,
	ease: 'power1.in'
	
}, 'straight+=0.5')

let sausage2Tl = gsap.timeline({repeat: -1, repeatDelay: 1.5});
sausage2Tl
	.from('#sausageGroup2', {
	y: -1500,
	ease: 'power1.in'
})
	.add('bend')
	.to('#sausage2', {
	morphSVG: {
		shape: '#sausageEnd'
	},
	duration: 0.5,
	ease: 'elastic(2, 0.6)'
}, 'bend')
.to('#sausageShine2', {
	morphSVG: {
		shape: '#sausageShineEnd'
	},
	duration: 0.5,
	ease: 'elastic(2, 0.6)'
}, 'bend')
.to('#sausageGroup2', {
	rotation: -90,
	duration: 1.5,
	ease: rollEase,
	svgOrigin: '403 322'
})

	.add('straight', '-=1')
	.to('#sausage2', {
	morphSVG: {
		shape: "M563.58,312.78c-104.32.38-220.84.4-325.16,0C202.73,312.63,174,292.36,174,262s28.75-50.64,64.42-50.78c104.3-.4,220.87-.38,325.15,0C599.24,211.35,627,231.65,627,262S599.27,312.65,563.58,312.78Z"
	},
	duration: 1,
	ease: rollEase
}, 'straight')
.to('#sausageShine2', {
	morphSVG: {
		shape: "M567,230H243a4,4,0,0,1-4-4h0a4,4,0,0,1,4-4H567a4,4,0,0,1,4,4h0A4,4,0,0,1,567,230Z"
	},
	duration: 1,
	ease: rollEase
}, 'straight')
.to('#sausageGroup2', {
	x: 0,
	duration: 0.2,
	ease: 'linear'
	
}, 'straight+=0.3')
.to('#sausageGroup2', {
	y: 600,
	x: -120,
	duration: 0.3,
	ease: 'power1.in'
	
}, 'straight+=0.5')

console.log(sausage2Tl.totalDuration())
console.log(sausage2Tl.duration())

let mainTl = gsap.timeline({repeat:0});
mainTl.add(sausage1Tl)
.add(sausage2Tl, 2)
//ScrubGSAPTimeline(mainTl)