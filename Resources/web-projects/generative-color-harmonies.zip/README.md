# Generative color harmonies

A Pen created on CodePen.io. Original URL: [https://codepen.io/meodai/pen/RerqjG](https://codepen.io/meodai/pen/RerqjG).

- color names: https://github.com/meodai/color-names

- reload icon by Ravindra Kalkani from the Noun Project: https://thenounproject.com/search/?q=reload&i=1973430

- inspired by: http://www.husl-colors.org/syntax/