# CSS Wiggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/DGgedP](https://codepen.io/hakimel/pen/DGgedP).

CSS animation and blur filter experiment. WebKit only for the blur.