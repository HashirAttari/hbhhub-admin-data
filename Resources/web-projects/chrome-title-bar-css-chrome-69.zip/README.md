# Chrome Title Bar CSS (Chrome 69)

A Pen created on CodePen.io. Original URL: [https://codepen.io/z-/pen/mGGPXj](https://codepen.io/z-/pen/mGGPXj).

![](https://i.imgur.com/O5Jjoql.gif)
I really like the new design and to study it I remade it.