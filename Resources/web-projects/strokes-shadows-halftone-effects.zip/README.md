# Strokes, Shadows + Halftone Effects

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/YjQKeZ](https://codepen.io/markmead/pen/YjQKeZ).

