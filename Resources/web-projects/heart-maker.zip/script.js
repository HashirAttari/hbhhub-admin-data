"use strict";
// setup document styles
typestyle.cssRule('body', {
    fontSize: '13pt',
    margin: 0
});
typestyle.cssRule('body, button', {
    fontFamily: 'Caveat Brush, cursive'
});
const pulseAnimation = typestyle.keyframes({
    from: {
        transform: 'none'
    },
    '22%': {
        transform: csx.scale(1.05)
    },
    '50%': {
        transform: csx.scale(.95)
    },
    '79%': {
        transform: csx.scale(1.1)
    },
    to: {
        transform: 'none'
    }
});
// define app component styles
const appStyles = typestyle.style({
    height: '100vh',
    overflow: 'hidden',
    textAlign: 'center',
    transition: 'background-color 800ms ease-in-out',
    width: '100vw',
    $nest: {
        '.color-label': {
            textTransform: 'capitalize',
            cursor: 'pointer'
        },
        '.color-selector': {
            padding: '.6rem',
            display: 'inline-block'
        },
        '.create': {
            border: 'solid thin black',
            borderRadius: '10px',
            color: 'white',
            cursor: 'pointer',
            display: 'inline-block',
            //fontSize: '2vmin',
            outline: 'none',
            padding: '1vmin 3vmin',
            textDecoration: 'none'
        },
        '.heart': {
            marginLeft: 'auto',
            marginRight: 'auto',
            marginTop: '2vmin',
            marginBottom: '2vmin',
            position: 'relative',
            width: '45vmin'
        },
        '.heart-container': {
            animation: pulseAnimation + ' 4.5s ease-in-out infinite'
        },
        '.heart-shape': {
            transition: 'fill 800ms ease-in-out, stroke 800ms ease-in-out',
            strokeWidth: '.5vmin'
        },
        '.hidden': {
            visibility: 'hidden'
        },
        '.message': {
            display: 'flex',
            fontSize: '8vmin',
            height: '22vmin',
            justifyContent: 'center',
            left: '10vmin',
            position: 'absolute',
            top: '8vmin',
            width: '30vmin'
        },
        '.message > div': {
            alignSelf: 'center',
            width: '100%',
            minHeight: '10vmin'
        }
    }
});
const params = new URLSearchParams(window.location.search);
const color = params.get('color') || 'red';
const message = params.get('message') || 'Roses are #ff0000';
const readonly = params.get('readonly') || false;
new Vue({
    el: '#app',
    data: {
        colors: ['red', 'pink', 'orange', 'green', 'teal', 'blue', 'purple', 'black'],
        selectedColor: color,
        message: message,
        readonly: readonly,
        styles: appStyles,
        returnUrl: location.pathname
    },
    computed: {
        dynamicStyles() {
            const namedColor = this.$data.selectedColor;
            const selectedColor = csx.color(namedColor);
            const fillColor = selectedColor.toHexString();
            const heartStroke = selectedColor.darken(.1, true).toHexString();
            const bgColor = selectedColor.lighten(.9, true).toHexString();
            const btnBgColor = selectedColor.lighten(.3, true).toHexString();
            return typestyle.style({
                backgroundColor: bgColor,
                $nest: {
                    '.create': {
                        borderColor: heartStroke,
                        backgroundColor: btnBgColor
                    },
                    '.heart-shape': {
                        fill: namedColor,
                        stroke: heartStroke
                    },
                    [`.color-label[color="${namedColor}"]`]: {
                        textDecoration: 'underline',
                    },
                    '.message': {
                        color: bgColor
                    }
                }
            });
        },
        url() {
            const selectedColor = this.$data.selectedColor;
            const message = this.$data.message;
            return '/notoriousb1t/full/WRLRdQ/' + `?color=${selectedColor}&message=${encodeURIComponent(message)}&readonly=true`;
        }
    },
    methods: {
        updateMessage(evt) {
            this.$data.message = event.target.textContent.trim();
        }
    }
});