# Flame - only CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pedro-Ondiviela/pen/xxMdWBJ](https://codepen.io/Pedro-Ondiviela/pen/xxMdWBJ).

