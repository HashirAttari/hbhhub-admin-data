# Draggable Metro App Showcase

A Pen created on CodePen.io. Original URL: [https://codepen.io/SaraSoueidan/pen/DRxWdG](https://codepen.io/SaraSoueidan/pen/DRxWdG).

Demo for blog post: http://sarasoueidan.com/blog/draggable-metro-app-showcase -- 
use all 5 buttons to interact with the demo.

* Left arrow: slide screen inside frame completely
* Windows button: slide screen out to its initial position
* magnifier: toggle "focus" mode
* left and right navigation arrows: move the screen left and right respectively
* drag or swipe app screen with your mouse or finger
