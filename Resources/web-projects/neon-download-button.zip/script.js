const el = document.querySelector(".down")
let state = "normal"

// if the pen is in thumbnail view, scale it up, center it in the image and start the animation

if (location.pathname.match(/fullcpgrid/i) ? true : false) {
  document.documentElement.style.fontSize = "48px"
  el.style.transform = "translateX(-4rem)"
  
  setTimeout(function() {
    el.classList.add("inprogress")
    state = "inprogress"
  }, 250);
}

// when clicking the upload button
function downstart() {
  if (state == "finished") {
    // go back if the upload finished
    state = "normal"
    el.classList.remove("finished")
  } else if (state == "normal") {
    // open the menu if its in the normal state
    state = "inprogress"
    el.classList.add("inprogress")
  }
}


function downend() {
  if (state == "inprogress") {
    state = "finished"
    el.classList.remove("inprogress")
    el.classList.add("finished")
  }
}
document.querySelector(".downprogress > div").addEventListener("transitionend", downend);