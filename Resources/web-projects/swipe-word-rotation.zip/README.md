# Swipe Word Rotation

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/XWMpWYG](https://codepen.io/benhatsor/pen/XWMpWYG).

