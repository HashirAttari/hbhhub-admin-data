# Trad'Mania simple logo loading animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/AlaricBaraou/pen/PKMaYz](https://codepen.io/AlaricBaraou/pen/PKMaYz).

Animating all path stroke's at once in a circle to display the logo then slide it away to reveal the website. 