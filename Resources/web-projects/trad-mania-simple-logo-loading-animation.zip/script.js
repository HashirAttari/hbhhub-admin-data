$(document).ready(function(){
	var tl2 = new TimelineMax({repeat:-1,repeatDelay:5});
        tl2.fromTo($('#tradmaniasvg #backgroundcircle'), 1, {transformOrigin:"50% 50%",opacity:1,scale:0.1},{scale:1})
        .set($('#tradmaniasvg path.cls-2'),{opacity:1})
        .fromTo($('#tradmaniasvg path.cls-2'), 2,{drawSVG:"0%"},{drawSVG:"100%"})
        .to($('#tradmaniasvg path.cls-2'), 1,{fill:"#fff"})
        .to($('#tradmaniasvg path'), 1,{opacity:1},"-=1")
	.to($('#loader'),1,{opacity:1,y:"100%"})
	.set($('#loader'),{display:"none"});
  });