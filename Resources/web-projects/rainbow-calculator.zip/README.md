# Rainbow Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/imtoobose/pen/yJOZEB](https://codepen.io/imtoobose/pen/yJOZEB).

Calculator with a neat color trick used in Ruandre Janse Van Rensburg's pen (linked in html comments), that I tried to emulate. Made for free code camp. Keyboard instructions: Use number keys, space for execution, and delete to backspace.
