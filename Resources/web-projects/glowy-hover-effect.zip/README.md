# glowy hover effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/wtaype/pen/qBLrdVE](https://codepen.io/wtaype/pen/qBLrdVE).

Inspired by the hover effects in Linear's features page