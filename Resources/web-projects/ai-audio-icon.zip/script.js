"use strict";
class App {
    constructor() {
        this.select = e => document.querySelector(e);
        this.selectAll = e => document.querySelectorAll(e);
        this.mainTl = new TimelineMax();
        const seg = this.select('.seg');
        const bar = this.select('.bar');
        const container = this.select('.container');
        const barContainer = this.select('.barContainer');
        const segArray = [];
        const barArray = [];
        const tl = new TimelineMax();
        this.mainTl.add(tl);
        const numSegs = 140;
        const centerX = 400;
        const centerY = 300;
        const segHeight = Number(seg.getAttribute('height'));
        const mainCircleRadius = 180;
        const step = 360 / numSegs;
        const myEase = new CustomEase("wavey", "M0,0 C0.072,0.22 0.06,0.364 0.108,0.368 0.143,0.37 0.233,0.237 0.3,0.3 0.379,0.374 0.316,0.969 0.48,1 0.62,1.026 0.583,0.295 0.636,0.176 0.714,-0.002 0.708,0.207 0.782,0.304 0.822,0.357 0.795,0.154 0.842,0.066 0.877,-0.001 0.993,0.055 1,0");
        for (var i = 0; i < numSegs; i++) {
            let clone = seg.cloneNode(true);
            container.appendChild(clone);
            let angle = (step * i);
            var point = {
                x: (Math.cos(angle * Math.PI / 180) * mainCircleRadius) + centerX,
                y: (Math.sin(angle * Math.PI / 180) * mainCircleRadius) + centerY - segHeight
            };
            TweenMax.set(clone, {
                x: point.x,
                y: point.y,
                rotation: (angle) + 90,
                transformOrigin: '50% 100%'
            });
            segArray.push(clone);
        }
        const barTl = new TimelineMax();
        for (var i = 0; i < numSegs; i++) {
            let clone = bar.cloneNode(true);
            barContainer.appendChild(clone);
            let angle = (step * i);
            var point = {
                x: (Math.cos(angle * Math.PI / 180) * mainCircleRadius) + centerX,
                y: (Math.sin(angle * Math.PI / 180) * mainCircleRadius) + centerY - segHeight
            };
            TweenMax.set(clone, {
                x: point.x,
                y: point.y,
                rotation: (angle) + 90,
                transformOrigin: '50% 100%'
            });
            barArray.push(clone);
            let xx = TweenMax.to({}, 1.3, {
                repeat: -1,
                delay: 3.77 * i,
                ease: Power1.easeOut,
                yoyo: true,
                onUpdate: () => {
                    TweenMax.to(clone, 1, {
                        scaleY: myEase.getRatio(xx.progress()),
                        repeat: -1,
                        yoyo: true
                    });
                }
            });
            barTl.add(xx, i / 20);
        }
        ;
        barTl.seek(1000);
    }
    onUpdate() {
        console.log(this);
    }
    get timeline() {
        return this.mainTl;
    }
}
TweenMax.set('svg', {
    visibility: 'visible'
});
new App();
//TweenMax.globalTimeScale(0.3333)