# AI Audio Icon

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/mGemwG](https://codepen.io/chrisgannon/pen/mGemwG).

