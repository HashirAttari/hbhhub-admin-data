/* =========================================
   PulseBridge Callback Studio - JS
========================================= */

(function () {
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  const STORAGE = {
    theme: "pb:theme:v1",
    accent: "pb:accent:v1",
    draft: "pb:draft:v1",
    lastRef: "pb:lastRef:v1"
  };

  const header = $("#siteHeader");
  const navToggle = $("#navToggle");
  const navPanel = $("#navPanel");
  const themeToggle = $("#themeToggle");
  const themeIcon = $("#themeIcon");
  const accentSelect = $("#accentSelect");
  const goTop = $("#goTop");

  const form = $("#callbackForm");
  const formMsg = $("#formMsg");
  const progressBar = $("#progressBar");
  const progressText = $("#progressText");
  const clearDraftBtn = $("#clearDraft");

  const modal = $("#successModal");
  const refIdEl = $("#refId");
  const copySummaryBtn = $("#copySummary");

  const tzLabel = $("#tzLabel");
  const clockLine = $("#clockLine");
  const year = $("#year");
  const buildStamp = $("#buildStamp");

  const fullName = $("#fullName");
  const company = $("#company");
  const phone = $("#phone");
  const phoneHint = $("#phoneHint");
  const email = $("#email");
  const topic = $("#topic");
  const urgency = $("#urgency");
  const date = $("#date");
  const slot = $("#slot");
  const slotHint = $("#slotHint");
  const slaHint = $("#slaHint");
  const notes = $("#notes");
  const charCount = $("#charCount");
  const consent = $("#consent");

  const sumName = $("#sumName");
  const sumPhone = $("#sumPhone");
  const sumTopic = $("#sumTopic");
  const sumSlot = $("#sumSlot");
  const sumSla = $("#sumSla");

  const copyRefLast = $("#copyRefLast");
  const toggleDesk = $("#toggleDesk");
  const statusChip = $("#statusChip");

  // ---------- Helpers ----------
  function pad2(n) {
    return String(n).padStart(2, "0");
  }

  function formatBuildStamp(d) {
    // Format: "Sep 20, 2025 HH:MM:SS hrs"
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    return `${months[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()} ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())} hrs`;
  }

  function setHeaderHeightVar() {
    const h = header.getBoundingClientRect().height;
    document.documentElement.style.setProperty("--headerH", `${Math.round(h)}px`);
  }

  function smoothScrollTo(targetEl) {
    const headerH = header.getBoundingClientRect().height;
    const y = window.scrollY + targetEl.getBoundingClientRect().top - (headerH + 10);
    window.scrollTo({ top: y, behavior: "smooth" });
  }

  function openMsg(kind, text) {
    formMsg.className = `formMsg isOpen ${kind || ""}`.trim();
    formMsg.textContent = text;
  }

  function closeMsg() {
    formMsg.className = "formMsg";
    formMsg.textContent = "";
  }

  function clampText(s, max) {
    if (!s) return "";
    const t = String(s).trim();
    return t.length > max ? t.slice(0, max) : t;
  }

  function setFieldState(fieldWrap, state) {
    fieldWrap.classList.remove("isValid", "isInvalid");
    if (state === "valid") fieldWrap.classList.add("isValid");
    if (state === "invalid") fieldWrap.classList.add("isInvalid");
  }

  function shake(el) {
    el.classList.remove("shake");
    // force reflow
    void el.offsetWidth;
    el.classList.add("shake");
  }

  function safeLocalStorageGet(key) {
    try { return localStorage.getItem(key); } catch { return null; }
  }
  function safeLocalStorageSet(key, val) {
    try { localStorage.setItem(key, val); } catch {}
  }
  function safeLocalStorageRemove(key) {
    try { localStorage.removeItem(key); } catch {}
  }

  function generateRefId() {
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    const chunk = (len) => Array.from({ length: len }, () => alphabet[Math.floor(Math.random() * alphabet.length)]).join("");
    return `PB-${chunk(4)}-${chunk(4)}`;
  }

  function copyToClipboard(text) {
    return navigator.clipboard.writeText(text);
  }

  // ---------- Theme ----------
  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    themeToggle.setAttribute("aria-pressed", theme === "dark" ? "true" : "false");
    themeIcon.className = theme === "dark" ? "fa-solid fa-moon" : "fa-solid fa-sun";
    safeLocalStorageSet(STORAGE.theme, theme);
  }

  function applyAccent(accent) {
    document.documentElement.setAttribute("data-accent", accent);
    safeLocalStorageSet(STORAGE.accent, accent);
  }

  // ---------- Nav ----------
  function closeNav() {
    navPanel.classList.remove("open");
    navToggle.setAttribute("aria-expanded", "false");
  }

  function toggleNav() {
    const isOpen = navPanel.classList.toggle("open");
    navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
  }

  // Close on outside click
  document.addEventListener("click", (e) => {
    const isSmall = window.matchMedia("(max-width: 820px)").matches;
    if (!isSmall) return;
    if (navPanel.contains(e.target) || navToggle.contains(e.target)) return;
    closeNav();
  });

  navToggle.addEventListener("click", toggleNav);

  // Header-aware smooth scroll
  document.addEventListener("click", (e) => {
    const a = e.target.closest("a[data-scroll]");
    if (!a) return;

    const href = a.getAttribute("href") || "";
    if (!href.startsWith("#")) return;

    const target = $(href);
    if (!target) return;

    e.preventDefault();
    closeNav();
    smoothScrollTo(target);
  });

  // ---------- Image fallback handling ----------
  // Keep frame size stable via aspect-ratio; show fallback overlay if image fails.
  $$("[data-img] img").forEach((img) => {
    img.addEventListener("error", () => {
      const frame = img.closest("[data-img]");
      if (!frame) return;
      const fallback = frame.querySelector(".imgFallback");
      if (fallback) fallback.style.opacity = "1";
      img.style.opacity = "0";
    }, { once: true });
  });

  // ---------- Reveal on scroll ----------
  const revealEls = $$(".reveal");
  const io = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (en.isIntersecting) {
        en.target.classList.add("in");
        io.unobserve(en.target);
      }
    });
  }, { threshold: 0.12 });

  revealEls.forEach((el) => io.observe(el));

  // ---------- Stats counter ----------
  function animateCount(el, to) {
    const start = 0;
    const dur = 900 + Math.random() * 700;
    const t0 = performance.now();

    function step(now) {
      const p = Math.min(1, (now - t0) / dur);
      const val = Math.round(start + (to - start) * (1 - Math.pow(1 - p, 3)));
      el.textContent = String(val);
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  // Trigger counts when visible
  const statNums = $$("[data-count]");
  const ioCount = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (!en.isIntersecting) return;
      const el = en.target;
      const to = Number(el.getAttribute("data-count") || "0");
      animateCount(el, to);
      ioCount.unobserve(el);
    });
  }, { threshold: 0.35 });

  statNums.forEach((el) => ioCount.observe(el));

  // ---------- FAQ accordion ----------
  const acc = $("#faqAccordion");
  if (acc) {
    const items = $$(".accItem", acc);
    items.forEach((btn) => {
      btn.addEventListener("click", () => {
        const panel = btn.nextElementSibling;
        const isOpen = btn.getAttribute("aria-expanded") === "true";

        // close others
        items.forEach((b) => {
          b.setAttribute("aria-expanded", "false");
          const p = b.nextElementSibling;
          if (p) p.style.maxHeight = "0px";
          const icon = b.querySelector("i");
          if (icon) icon.style.transform = "rotate(0deg)";
        });

        if (!panel) return;

        if (!isOpen) {
          btn.setAttribute("aria-expanded", "true");
          panel.style.maxHeight = panel.scrollHeight + "px";
          const icon = btn.querySelector("i");
          if (icon) icon.style.transform = "rotate(180deg)";
        }
      });
    });
  }

  // ---------- Quote rotator ----------
  const quoteEl = $("#rotatingQuote");
  const quoteBy = $("#quoteBy");
  const quotes = [
    { q: "“Fast callbacks turned our ‘maybe later’ leads into real conversations.”", by: "— Ops Lead, Midtown Retail" },
    { q: "“The slot + topic combo made our first calls shorter and more effective.”", by: "— Sales Director, B2B SaaS" },
    { q: "“Off-hours expectations reduced complaints. Small detail, big impact.”", by: "— Support Manager, Hospitality" },
    { q: "“Draft saving helps mobile users. It quietly improved completions.”", by: "— Growth, Local Services" }
  ];
  let quoteIdx = 0;

  function rotateQuote() {
    if (!quoteEl || !quoteBy) return;
    quoteIdx = (quoteIdx + 1) % quotes.length;
    quoteEl.style.opacity = "0";
    quoteEl.style.transform = "translateY(4px)";
    quoteBy.style.opacity = "0";
    setTimeout(() => {
      quoteEl.textContent = quotes[quoteIdx].q;
      quoteBy.textContent = quotes[quoteIdx].by;
      quoteEl.style.opacity = "1";
      quoteEl.style.transform = "translateY(0px)";
      quoteBy.style.opacity = "1";
    }, 220);
  }
  if (quoteEl) setInterval(rotateQuote, 5200);

  // ---------- Go top button ----------
  function updateGoTop() {
    if (window.scrollY > 100) goTop.classList.add("show");
    else goTop.classList.remove("show");
  }
  window.addEventListener("scroll", updateGoTop, { passive: true });
  goTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

  // ---------- Chips to auto-fill topic ----------
  $$(".chip").forEach((btn) => {
    btn.addEventListener("click", () => {
      const t = btn.getAttribute("data-topic") || "";
      topic.value = t;
      topic.dispatchEvent(new Event("input", { bubbles: true }));
      smoothScrollTo($("#request"));
    });
  });

  // ---------- Date + slot generation ----------
  function isWeekend(d) {
    const day = d.getDay();
    return day === 0 || day === 6;
  }

  function buildSlotsForDate(dateStr) {
    const chosen = new Date(dateStr + "T00:00:00");
    if (Number.isNaN(chosen.getTime())) return [];

    // Base schedule rules
    const weekend = isWeekend(chosen);

    // Weekdays: 09:30 - 18:30 (every 30 min)
    // Weekends: 11:00 - 16:00 (every 30 min)
    const start = weekend ? { h: 11, m: 0 } : { h: 9, m: 30 };
    const end = weekend ? { h: 16, m: 0 } : { h: 18, m: 30 };

    const slots = [];
    for (let h = start.h; h <= end.h; h++) {
      for (let m = 0; m < 60; m += 30) {
        // Skip minutes before start minute in start hour
        if (h === start.h && m < start.m) continue;
        // Stop beyond end minute in end hour
        if (h === end.h && m > end.m) continue;

        slots.push({ h, m });
      }
    }
    return slots;
  }

  function formatSlotLabel(h, m) {
    const ampm = h >= 12 ? "PM" : "AM";
    const hh = h % 12 || 12;
    return `${hh}:${pad2(m)} ${ampm}`;
  }

  function setSlotOptions(dateStr) {
    const slotsList = buildSlotsForDate(dateStr);

    // If today, block past times
    const now = new Date();
    const chosenDate = new Date(dateStr + "T00:00:00");
    const isToday =
      chosenDate.getFullYear() === now.getFullYear() &&
      chosenDate.getMonth() === now.getMonth() &&
      chosenDate.getDate() === now.getDate();

    const filtered = slotsList.filter(({ h, m }) => {
      if (!isToday) return true;
      const slotTime = new Date();
      slotTime.setHours(h, m, 0, 0);
      return slotTime.getTime() > now.getTime() + 10 * 60 * 1000; // at least 10 min from now
    });

    slot.innerHTML = "";
    if (filtered.length === 0) {
      slot.disabled = true;
      slot.innerHTML = `<option value="">No slots left today — choose another date</option>`;
      return;
    }

    slot.disabled = false;
    slot.innerHTML = `<option value="">Select a slot…</option>`;
    filtered.forEach(({ h, m }) => {
      const label = formatSlotLabel(h, m);
      const value = `${pad2(h)}:${pad2(m)}`;
      const opt = document.createElement("option");
      opt.value = value;
      opt.textContent = label;
      slot.appendChild(opt);
    });
  }

  function getSlaText() {
    const dateVal = date.value;
    const slotVal = slot.value;
    const urg = urgency.value;

    if (!dateVal || !slotVal) return "—";

    const chosen = new Date(`${dateVal}T${slotVal}:00`);
    const weekend = isWeekend(chosen);

    // Default: within 2–5 minutes (demo)
    // Weekends/off-hours: within 30–90 minutes (demo)
    // High urgency tries to keep it short unless off-hours
    const hour = chosen.getHours();
    const offHours = weekend || hour < 9 || hour >= 18;

    if (offHours) {
      if (urg === "high") return "30–60 minutes (off-hours)";
      return "45–90 minutes (off-hours)";
    }

    if (urg === "high") return "2–4 minutes";
    if (urg === "med") return "3–7 minutes";
    return "5–12 minutes";
  }

  function updateSlaHint() {
    const sla = getSlaText();
    slaHint.textContent = `SLA: ${sla}`;
  }

  // Date constraints: today to +30 days
  function setDateBounds() {
    const now = new Date();
    const min = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const max = new Date(min);
    max.setDate(max.getDate() + 30);

    const toISO = (d) => `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`;
    date.min = toISO(min);
    date.max = toISO(max);
  }

  date.addEventListener("change", () => {
    if (date.value) {
      setSlotOptions(date.value);
      slotHint.textContent = "Slots are in your local time.";
      closeMsg();
    } else {
      slot.disabled = true;
      slot.innerHTML = `<option value="">Pick a date first…</option>`;
    }
    updateSlaHint();
    validateAll(false);
    saveDraft();
  });

  slot.addEventListener("change", () => {
    updateSlaHint();
    validateAll(false);
    saveDraft();
  });

  urgency.addEventListener("change", () => {
    updateSlaHint();
    validateAll(false);
    saveDraft();
  });

  // ---------- Phone formatting + validation ----------
  function normalizePhone(raw) {
    // Keep + and digits
    let v = String(raw || "").trim();
    v = v.replace(/[^\d+]/g, "");

    // Only one leading +
    if (v.includes("+")) {
      v = "+" + v.replace(/\+/g, "");
    }

    // Basic grouping for readability (not country-specific)
    // +91 98765 43210 or 98765 43210
    const isPlus = v.startsWith("+");
    const digits = isPlus ? v.slice(1) : v;

    const groups = [];
    if (isPlus) {
      // country code 1-3 digits
      groups.push(digits.slice(0, 3).replace(/^0+/, "") || digits.slice(0, 1));
      const rest = digits.slice(groups[0].length);
      if (rest.length) {
        groups.push(rest.slice(0, 5));
        if (rest.length > 5) groups.push(rest.slice(5, 10));
        if (rest.length > 10) groups.push(rest.slice(10, 14));
      }
      return "+" + groups.filter(Boolean).join(" ");
    }

    // no plus: split 5-5-4
    groups.push(digits.slice(0, 5));
    if (digits.length > 5) groups.push(digits.slice(5, 10));
    if (digits.length > 10) groups.push(digits.slice(10, 14));
    return groups.filter(Boolean).join(" ");
  }

  function isPhoneValid(v) {
    const raw = String(v || "").replace(/[^\d]/g, "");
    // Accept 10-14 digits (covers many cases for demo)
    return raw.length >= 10 && raw.length <= 14;
  }

  phone.addEventListener("input", () => {
    const caret = phone.selectionStart || 0;
    const before = phone.value;
    phone.value = normalizePhone(phone.value);

    // keep caret reasonably stable
    const diff = phone.value.length - before.length;
    phone.setSelectionRange(Math.max(0, caret + diff), Math.max(0, caret + diff));

    validateAll(false);
    saveDraft();
  });

  // ---------- Email validation ----------
  function isEmailValid(v) {
    if (!v) return true; // optional
    const s = String(v).trim();
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s);
  }

  // ---------- Notes character counter ----------
  const NOTE_MAX = 320;
  notes.addEventListener("input", () => {
    notes.value = clampText(notes.value, NOTE_MAX);
    charCount.textContent = `${notes.value.length} / ${NOTE_MAX}`;
    validateAll(false);
    saveDraft();
  });

  // ---------- Progress tracking ----------
  function computeProgress() {
    const checks = [
      fullName.value.trim().length >= 2,
      isPhoneValid(phone.value),
      topic.value.trim().length >= 5,
      urgency.value !== "",
      date.value !== "",
      slot.value !== "",
      consent.checked === true
    ];
    const done = checks.filter(Boolean).length;
    const pct = Math.round((done / checks.length) * 100);
    return { done, total: checks.length, pct };
  }

  function renderProgress() {
    const { pct } = computeProgress();
    progressBar.style.setProperty("--w", pct + "%");
    // use ::after width by writing it via style rule on element
    progressBar.style.setProperty("width", "100%");
    progressBar.style.position = "relative";
    progressBar.style.overflow = "hidden";
    progressBar.style.borderRadius = "999px";
    progressBar.style.background = "rgba(255,255,255,0.12)";
    progressBar.style.height = "8px";
    progressBar.style.setProperty("--pct", pct);

    progressBar.style.setProperty("transform", "translateZ(0)");
    progressBar.style.setProperty("willChange", "contents");

    // set width via CSS variable by injecting to ::after is not direct,
    // so we update a data attr and use inline style on a child-less bar using background-size trick:
    progressBar.style.backgroundImage = `linear-gradient(90deg, var(--accent), var(--accent2))`;
    progressBar.style.backgroundRepeat = "no-repeat";
    progressBar.style.backgroundSize = `${pct}% 100%`;

    progressText.textContent = `${pct}% complete`;
  }

  // ---------- Validation ----------
  function validateAll(showMessages) {
    let ok = true;
    closeMsg();

    // wrappers: field element is parent .field
    const nameField = fullName.closest(".field");
    const phoneField = phone.closest(".field");
    const emailField = email.closest(".field");
    const topicField = topic.closest(".field");
    const urgField = urgency.closest(".field");
    const dateField = date.closest(".field");
    const slotField = slot.closest(".field");
    const consentField = consent.closest(".consent");

    // Full name
    if (fullName.value.trim().length < 2) {
      setFieldState(nameField, showMessages ? "invalid" : null);
      ok = false;
    } else setFieldState(nameField, "valid");

    // Phone
    if (!isPhoneValid(phone.value)) {
      setFieldState(phoneField, showMessages ? "invalid" : null);
      if (showMessages) phoneHint.textContent = "Add a valid phone number (10–14 digits).";
      ok = false;
    } else {
      setFieldState(phoneField, "valid");
      phoneHint.textContent = "Include country code if possible.";
    }

    // Email optional
    if (!isEmailValid(email.value)) {
      setFieldState(emailField, showMessages ? "invalid" : null);
      ok = false;
    } else if (email.value.trim()) {
      setFieldState(emailField, "valid");
    } else {
      setFieldState(emailField, null);
    }

    // Topic
    if (topic.value.trim().length < 5) {
      setFieldState(topicField, showMessages ? "invalid" : null);
      ok = false;
    } else setFieldState(topicField, "valid");

    // urgency
    if (!urgency.value) {
      setFieldState(urgField, showMessages ? "invalid" : null);
      ok = false;
    } else setFieldState(urgField, "valid");

    // date
    if (!date.value) {
      setFieldState(dateField, showMessages ? "invalid" : null);
      ok = false;
    } else setFieldState(dateField, "valid");

    // slot
    if (!slot.value) {
      setFieldState(slotField, showMessages ? "invalid" : null);
      ok = false;
    } else setFieldState(slotField, "valid");

    // consent
    if (!consent.checked) {
      if (showMessages) {
        consentField.classList.add("shake");
        setTimeout(() => consentField.classList.remove("shake"), 350);
      }
      ok = false;
    }

    renderProgress();

    if (!ok && showMessages) {
      openMsg("bad", "Please fix the highlighted fields to submit your callback request.");
    } else if (ok && showMessages) {
      openMsg("good", "Looks good. Submitting your request…");
    }

    return ok;
  }

  // Validate on input changes
  [fullName, company, email, topic, urgency, date, slot].forEach((el) => {
    el.addEventListener("input", () => {
      validateAll(false);
      saveDraft();
    });
  });
  consent.addEventListener("change", () => {
    validateAll(false);
    saveDraft();
  });

  // ---------- Draft autosave ----------
  function getDraft() {
    const raw = safeLocalStorageGet(STORAGE.draft);
    if (!raw) return null;
    try { return JSON.parse(raw); } catch { return null; }
  }

  function saveDraft() {
    const draft = {
      fullName: fullName.value,
      company: company.value,
      phone: phone.value,
      email: email.value,
      topic: topic.value,
      urgency: urgency.value,
      date: date.value,
      slot: slot.value,
      notes: notes.value,
      consent: !!consent.checked,
      utm: readUtm(),
      savedAt: Date.now()
    };
    safeLocalStorageSet(STORAGE.draft, JSON.stringify(draft));
  }

  function loadDraft() {
    const d = getDraft();
    if (!d) return;

    fullName.value = d.fullName || "";
    company.value = d.company || "";
    phone.value = d.phone || "";
    email.value = d.email || "";
    topic.value = d.topic || "";
    urgency.value = d.urgency || "";
    notes.value = d.notes || "";
    consent.checked = !!d.consent;

    charCount.textContent = `${notes.value.length} / ${NOTE_MAX}`;

    if (d.date) {
      date.value = d.date;
      setSlotOptions(d.date);
      if (d.slot) slot.value = d.slot;
    }

    updateSlaHint();
    validateAll(false);

    const ageMin = Math.round((Date.now() - (d.savedAt || Date.now())) / 60000);
    openMsg("warn", `Draft restored (saved ${ageMin} min ago).`);
    setTimeout(() => closeMsg(), 2400);
  }

  clearDraftBtn.addEventListener("click", () => {
    safeLocalStorageRemove(STORAGE.draft);
    form.reset();
    slot.disabled = true;
    slot.innerHTML = `<option value="">Pick a date first…</option>`;
    charCount.textContent = `0 / ${NOTE_MAX}`;
    updateSlaHint();
    validateAll(false);
    openMsg("warn", "Draft cleared on this device.");
    setTimeout(closeMsg, 1600);
  });

  // ---------- UTM capture ----------
  function readUtm() {
    const params = new URLSearchParams(window.location.search);
    const keys = ["utm_source","utm_medium","utm_campaign","utm_term","utm_content"];
    const utm = {};
    keys.forEach((k) => {
      const v = params.get(k);
      if (v) utm[k] = v;
    });
    return utm;
  }

  // ---------- Modal ----------
  function openModal() {
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }

  function closeModal() {
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }

  modal.addEventListener("click", (e) => {
    const closeEl = e.target.closest("[data-close]");
    if (closeEl) closeModal();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modal.classList.contains("open")) closeModal();
  });

  // ---------- Submission (demo, but functional) ----------
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const ok = validateAll(true);
    if (!ok) {
      // shake the first invalid field
      const firstInvalid = $(".isInvalid", form);
      if (firstInvalid) shake(firstInvalid);
      return;
    }

    // Simulated request latency
    $("#submitBtn").disabled = true;

    const ref = generateRefId();
    const sla = getSlaText();

    const dateStr = date.value;
    const slotStr = slot.value;
    const slotLabel = (() => {
      if (!dateStr || !slotStr) return "—";
      const [hh, mm] = slotStr.split(":").map(Number);
      return `${dateStr} • ${formatSlotLabel(hh, mm)} (${Intl.DateTimeFormat().resolvedOptions().timeZone})`;
    })();

    // Prepare summary
    const summaryText =
      `Callback Request\n` +
      `Reference: ${ref}\n` +
      `Name: ${fullName.value.trim()}\n` +
      `Company: ${company.value.trim() || "—"}\n` +
      `Phone: ${phone.value.trim()}\n` +
      `Email: ${email.value.trim() || "—"}\n` +
      `Topic: ${topic.value.trim()}\n` +
      `Urgency: ${urgency.value}\n` +
      `Slot: ${slotLabel}\n` +
      `SLA: ${sla}\n` +
      `Notes: ${notes.value.trim() || "—"}\n`;

    // Save last ref
    safeLocalStorageSet(STORAGE.lastRef, JSON.stringify({ ref, summaryText, at: Date.now() }));

    // Update modal UI
    refIdEl.textContent = ref;
    sumName.textContent = fullName.value.trim();
    sumPhone.textContent = phone.value.trim();
    sumTopic.textContent = topic.value.trim();
    sumSlot.textContent = slotLabel;
    sumSla.textContent = sla;

    // Simulate “send”
    await new Promise((r) => setTimeout(r, 700 + Math.random() * 600));

    // Clear draft after successful submit
    safeLocalStorageRemove(STORAGE.draft);

    // Reset UI (keep user at same place; modal shows summary)
    form.reset();
    slot.disabled = true;
    slot.innerHTML = `<option value="">Pick a date first…</option>`;
    charCount.textContent = `0 / ${NOTE_MAX}`;
    updateSlaHint();
    validateAll(false);

    $("#submitBtn").disabled = false;

    openMsg("good", "Request submitted. Opening confirmation…");
    setTimeout(() => {
      closeMsg();
      openModal();
    }, 500);

    // Copy summary button behavior
    copySummaryBtn.onclick = async () => {
      try {
        await copyToClipboard(summaryText);
        copySummaryBtn.innerHTML = `<i class="fa-solid fa-check"></i> Copied`;
        setTimeout(() => {
          copySummaryBtn.innerHTML = `<i class="fa-solid fa-copy"></i> Copy summary`;
        }, 1400);
      } catch {
        openMsg("bad", "Copy failed. Your browser may block clipboard access.");
      }
    };
  });

  copyRefLast.addEventListener("click", async () => {
    const raw = safeLocalStorageGet(STORAGE.lastRef);
    if (!raw) {
      openMsg("warn", "No reference saved yet. Submit a request to generate one.");
      setTimeout(closeMsg, 1700);
      return;
    }
    try {
      const data = JSON.parse(raw);
      await copyToClipboard(data.ref);
      openMsg("good", `Copied: ${data.ref}`);
      setTimeout(closeMsg, 1200);
    } catch {
      openMsg("bad", "Could not read saved reference.");
    }
  });

  // Toggle desk status chip
  let deskOnline = true;
  toggleDesk.addEventListener("click", () => {
    deskOnline = !deskOnline;
    const dot = statusChip.querySelector(".pulse");
    const text = statusChip.querySelector("span:last-child");
    if (!dot || !text) return;

    if (deskOnline) {
      dot.style.background = "var(--good)";
      dot.style.boxShadow = "0 0 0 6px rgba(83,243,166,0.12)";
      text.textContent = "Callback desk: Online";
    } else {
      dot.style.background = "var(--warn)";
      dot.style.boxShadow = "0 0 0 6px rgba(255,206,99,0.12)";
      text.textContent = "Callback desk: Busy";
    }
  });

  // ---------- Header clock ----------
  function renderClock() {
    const now = new Date();
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const t = `${pad2(now.getHours())}:${pad2(now.getMinutes())}:${pad2(now.getSeconds())}`;
    clockLine.textContent = `Local time: ${t} • ${tz}`;
  }

  // ---------- Init ----------
  function init() {
    // Date bounds
    setDateBounds();

    // Header height variable for scroll offset + mobile menu placement
    setHeaderHeightVar();
    window.addEventListener("resize", () => {
      setHeaderHeightVar();
    });

    // Year + build stamp
    year.textContent = String(new Date().getFullYear());
    buildStamp.textContent = formatBuildStamp(new Date());

    // Timezone label
    tzLabel.textContent = Intl.DateTimeFormat().resolvedOptions().timeZone;

    // Theme from storage
    const savedTheme = safeLocalStorageGet(STORAGE.theme) || "dark";
    applyTheme(savedTheme === "light" ? "light" : "dark");

    const savedAccent = safeLocalStorageGet(STORAGE.accent) || "aurora";
    accentSelect.value = savedAccent;
    applyAccent(savedAccent);

    themeToggle.addEventListener("click", () => {
      const current = document.documentElement.getAttribute("data-theme") || "dark";
      applyTheme(current === "dark" ? "light" : "dark");
    });

    accentSelect.addEventListener("change", () => {
      applyAccent(accentSelect.value);
    });

    // Slot hint
    updateSlaHint();

    // Restore draft if present
    loadDraft();

    // Clock tick
    renderClock();
    setInterval(renderClock, 1000);

    // GoTop initial check
    updateGoTop();
  }

  init();
})();