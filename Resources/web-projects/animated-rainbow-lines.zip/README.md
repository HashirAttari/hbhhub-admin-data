# Animated rainbow lines

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/xwMRox](https://codepen.io/giana/pen/xwMRox).

Another pen inspired by Eva Ferreira's SassConf workshop on animation and loops.