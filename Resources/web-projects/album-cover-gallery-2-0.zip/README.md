# Album Cover Gallery 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/hluebbering/pen/RwdQbPW](https://codepen.io/hluebbering/pen/RwdQbPW).

