# Choose

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/rNeYMbZ](https://codepen.io/ricardoolivaalonso/pen/rNeYMbZ).

