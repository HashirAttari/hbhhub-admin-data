# Telephone

A Pen created on CodePen.io. Original URL: [https://codepen.io/bleepbloop/pen/WNeaxr](https://codepen.io/bleepbloop/pen/WNeaxr).

Just goofing around with Sass.