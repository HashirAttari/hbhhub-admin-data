# Image Transition by Szenia Zadvornykh

A Pen created on CodePen.io. Original URL: [https://codepen.io/erujs/pen/QNoWmO](https://codepen.io/erujs/pen/QNoWmO).

Pen by Szenia Zadvornykh


Copied for reference only~