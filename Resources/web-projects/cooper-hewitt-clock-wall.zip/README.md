# Cooper Hewitt Clock Wall

A Pen created on CodePen.io. Original URL: [https://codepen.io/aurer/pen/XEVNOV](https://codepen.io/aurer/pen/XEVNOV).

A CSS clock loosely based on [this installation](https://www.youtube.com/watch?v=46hZw_waTPU) in the Cooper Hewitt Design Museum NYC.
I wrote a brief explanation of how it works - https://codepen.io/aurer/post/the-making-of-cooper-hewitt-clock-wall