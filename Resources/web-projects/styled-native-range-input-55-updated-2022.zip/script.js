/* external resources *only* for displaying the info boxes */

/* this below is all the JS needed for the demo itself to work */
document.documentElement.classList.add('js');

addEventListener('input', e => {
	let _t = e.target, j = +_t.id.split('-')[1];
	
	_t.parentNode.style.setProperty(`--v${j}`, +_t.value)
})