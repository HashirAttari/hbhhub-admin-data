/*
Documentation: https://fonts.google.com/icons

To include in your page, add the link: 

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

Then copy the html code for the icon you wish to use.

Google often adds new icons to this font.  If the icon you want is not listed here, you can: a) download the woff2 font via Dev Tools, b) convert it to OTF or TTF using an online font converter, and c) open it in FontForge to find the code.

*/