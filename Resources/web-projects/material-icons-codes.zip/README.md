# Material Icons codes

A Pen created on CodePen.io. Original URL: [https://codepen.io/btn-ninja/pen/YrXmax](https://codepen.io/btn-ninja/pen/YrXmax).

The codes for Material icons (instead of ligatures), for IE9 and some other reasons.  Includes a few of the newest, which might be missing from codepoints.