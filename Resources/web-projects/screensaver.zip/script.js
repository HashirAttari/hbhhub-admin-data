if (document.documentElement.requestFullscreen) {
  document.querySelector('css-doodle').addEventListener('click', e => {
    document.documentElement.requestFullscreen();
  })  
 }