# Emojis as mask images

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/vYNQVvj](https://codepen.io/yuanchuan/pen/vYNQVvj).

