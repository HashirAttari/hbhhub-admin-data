/*

I have written a tutorial about this clock, explaining all elements:

http://dreamdealer.nl/tutorials/behind_the_scenes_css_only_clock.html

*/