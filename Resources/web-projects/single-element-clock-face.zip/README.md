# Single Element Clock Face

A Pen created on CodePen.io. Original URL: [https://codepen.io/Dreamdealer/pen/AVaMWR](https://codepen.io/Dreamdealer/pen/AVaMWR).

Now using Denisx's PHP file for setting time and animation.