# Custom animated hamburger menus

A Pen created on CodePen.io. Original URL: [https://codepen.io/waldo/pen/JbezRG](https://codepen.io/waldo/pen/JbezRG).

