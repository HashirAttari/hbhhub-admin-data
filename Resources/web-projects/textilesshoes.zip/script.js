const sole = document.querySelector(".sole");
const base = document.querySelector(".base");
const patt = document.querySelectorAll(".pattern");
var root = document.documentElement;
var color = "hsl(" + Math.random() * 360 + "deg,50%,50%)";
root.style.setProperty("--color-accent", color);
document.querySelector(".pattern.argyle").style.backgroundColor = color;

patt.forEach(function (elm) {
	elm.addEventListener("click", function () {
		var p = elm.classList[1];
		sole.className = "sole " + p;
		base.className = "base " + p;

		var elm_s = window.getComputedStyle(elm);
		var clr = elm_s.getPropertyValue("background-color");
		root.style.setProperty("--color-accent", clr);
	});
});