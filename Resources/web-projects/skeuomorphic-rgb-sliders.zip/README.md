# Skeuomorphic RGB sliders

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/VwqzBqj](https://codepen.io/nicolasjesenberger/pen/VwqzBqj).

