const sliders = document.querySelectorAll('.slider');

sliders.forEach(slider => {
  const sliderInput = slider.querySelector('.slider-input');
  
  const minValue = +sliderInput.min || 0;
  const maxValue = +sliderInput.max || 100;

  const updateSlider = () => {
    slider.style.setProperty('--slider-value', 100 * +sliderInput.value / (maxValue - minValue));
  }

  sliderInput.addEventListener('input', () => {
    updateSlider();
  });

  updateSlider();
});