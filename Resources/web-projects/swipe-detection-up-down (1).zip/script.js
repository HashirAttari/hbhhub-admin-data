let CSSanim = {
  
  parse: (text) => {

    function rulesForCSSText(text) {

      const doc = document.implementation.createHTMLDocument(''),
            styleElement = document.createElement('style');

      styleElement.textContent = text;

      // the style will only be parsed once it is added to a document
      doc.body.appendChild(styleElement);

      return styleElement.sheet.cssRules;

    }

    
    // get rules for CSS text
    const cssRules = rulesForCSSText(text);
    
    let cssObj = {};

    // parse rules to object
    Array.from(cssRules).forEach(selector => {
      
      const selName = selector.selectorText,
            styleMap = selector.styleMap;
      
      // push properties to selector
      cssObj[selName] = Array.from(styleMap);

    });
    
    return cssObj;

  },
  
  getAnimValueForOffset: (currOffset, maxOffset, maxAnimValue) => {    
    
    // returns percentage
    function percentOfValueFromTotalValue(value, totalValue) {
       return (100 * value) / totalValue;
    }

    // returns number
    function percentOfNum(percent, num) {
      return (percent / 100) * num;
    }
    
    
    const percentage = percentOfValueFromTotalValue(currOffset, maxOffset);
    
    const animValue = percentOfNum(percentage, maxAnimValue);
        
    return animValue;
    
  },
  
  getHTMLAttr: (attr, el) => {
    return el.getAttribute(attr);
  },
  
  animate: {}
  
};



/*
 * Touch animation
 * CSSanim module
 *
 * invoke via the  'animate' property in HTML
 * and by calling CSSanim.animations.touchAnim
 *
 */

CSSanim.animate.touchAnim = (el, maxY = 30, maxBoundaryCallback, minBoundaryCallback, clickCallback, swipeCallback, releaseCallback) => {
  
  const styleText = CSSanim.getHTMLAttr('animate', el);

  let propsToAnimate = CSSanim.parse(styleText).to;
  
  
  var currentAnimPos;
  
  var currentY;
  var initialY;
  var yOffset = 0;
  var yBoundary = maxY;

  var active = false;
  var click = false;
  var swiped = false;

  var direction = 0;

  document.addEventListener("touchstart", dragStart, false);
  document.addEventListener("touchend", dragEnd, false);
  document.addEventListener("touchmove", drag, false);

  document.addEventListener("mousedown", dragStart, false);
  document.addEventListener("mouseup", dragEnd, false);
  document.addEventListener("mousemove", drag, false);

  function dragStart(e) {
    
    if (e.type === "touchstart") {
      initialY = e.touches[0].clientY - yOffset;
    } else {
      initialY = e.clientY - yOffset;
    }

    active = true;
    click = true;
    swiped = false;
    
  }

  function dragEnd(e) {
    
    if (click && clickCallback) {
      clickCallback(e);
    }
    
    
    // animate to closest state
    if (!click && !swiped) {
      
      if (releaseCallback) releaseCallback(e);
      
      
      let currOffset = currentAnimPos,
          maxOffset = yBoundary;
      
      // divide max offset into two halves
      // if current offset is in top half
      if (currOffset >= (maxOffset / 2)) {
        
        // animate element to end state
        currOffset = maxOffset;
        
      } else {

        // animate element to initial state
        currOffset = 0;
        
      }
      
      // update animation position
      currentAnimPos = currOffset;
      
      
      el.style.transition = '.2s ease';
      
      
      // animate all props
      propsToAnimate.forEach(prop => {

        const [name, [CSSValue]] = prop;

        const animValue = CSSanim.getAnimValueForOffset(currOffset, maxOffset, CSSValue.value);

        // create new value with anim value and CSS units
        const CSSanimValue = CSS[CSSValue.unit](animValue);

        el.style[name] = CSSanimValue;

      });
      
      
      window.setTimeout(() => {
        
        el.style.transition = '';
        
      }, 200);
      
    }
    
    yOffset = 0;
    
    active = false;
    swiped = false;
    
  }

  function drag(e) {
    
    if (active) {
      
      e.preventDefault();

      if (e.type === "touchmove") {
        currentY = e.touches[0].clientY - initialY;
      } else {
        currentY = e.clientY - initialY;
      }

      yOffset = currentY;

      if (yOffset < 0) {
        direction = -1;
      }
      else {
        direction = 1;
      }

      if (Math.abs(yOffset) < yBoundary) {
        direction = 0;
      }

      if (direction == 1 && swiped == false
          && Math.abs(yOffset) >= yBoundary) {
        if (minBoundaryCallback) minBoundaryCallback(e);
        swiped = true;
      } else if (direction == -1 && swiped == false
                 && Math.abs(yOffset) >= yBoundary) {
        if (maxBoundaryCallback) maxBoundaryCallback(e);
        swiped = true;
      }

      if (swiped == false) {
        
        currentAnimPos = currentAnimPos + 1;
        
        
        if (swipeCallback) swipeCallback(e);
        

        let currOffset = currentAnimPos,
            maxOffset = yBoundary;

        // animate all props
        propsToAnimate.forEach(prop => {

          const [name, [CSSValue]] = prop;

          const animValue = CSSanim.getAnimValueForOffset(currOffset, maxOffset, CSSValue.value);

          // create new value with anim value and CSS units
          const CSSanimValue = CSS[CSSValue.unit](animValue);

          el.style[name] = CSSanimValue;

        });

      } else {
        
        yOffset = 0;
        
      }
      
      
      click = false;
      
    }
    
  }
  
}


var message = document.querySelector('.message');
var fillEl = document.querySelector('.fill');

CSSanim.animate.touchAnim(fillEl, 30, () => { message.textContent = 'Up' }, () => { message.textContent = 'Down' }, () => { message.textContent = 'Clicked' }, () => { message.textContent = 'Swiping' }, () => { message.textContent = 'Release' });