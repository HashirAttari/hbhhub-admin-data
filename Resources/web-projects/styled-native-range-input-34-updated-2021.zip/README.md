# Styled native range input #34 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/pvaaWq](https://codepen.io/thebabydino/pen/pvaaWq).

**May 2021 update**

This didn't really look broken, but there were a number of things that were problematic in the code by today's standards, so... major changes:

* got rid of testing for SMIL support to specifically target IE

* got rid of Modernizr and Compass dependencies, the latter of which was never even used at all

* simplified the JS ***a lot*** - it was a huge mess that was creating a style element and injecting styles targeting the slider pseudos into it; not wit just updates a custom property

* would have loved to make it CSS only in Firefox, but `::-moz-range-progress` produces problematic results at both ends of the range... so I opted for using the same method that needs that tiny bit of JS mentioned above for updating the slider progress/ fill

* used CSS variables to give each slider its own custom look

* switched from absolute positioning to a CSS `grid` layout to avoid things breaking on certain viewports

* simplified the track `background` - previously, it was using the [Carbon pattern](https://projects.verou.me/css3patterns/#carbon) from Lea Verou's gallery; while it was incredible to be able to achieve such a result at the time, I couldn't help but think CSS got better in the meanwhile and we could now both reduce the amount of code by a lot and make the result more robust, so after a bit of toying with an idea, I [got somewhere with it](https://twitter.com/anatudor/status/1396540014675337218)

* simplified the thumb `background` to use a single `conic-gradient()` instead of many linear ones to get the metallic shine look

* not providing free IE/ pre-Chromium Edge support anymore

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling the range track.  Fallback for no JS: simply display the same background for the entire track, both before and after the thumb.

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/p1SK3G6.png) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/).