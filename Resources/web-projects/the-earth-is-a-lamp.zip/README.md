# The earth... is a lamp!

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pedro-Ondiviela/pen/XWGVQyY](https://codepen.io/Pedro-Ondiviela/pen/XWGVQyY).

You can see the earth floating in the space.... but wait... It's a lamp! You can set it on and off by clicking.

A simple THREE.js animation, for my first time with this library.