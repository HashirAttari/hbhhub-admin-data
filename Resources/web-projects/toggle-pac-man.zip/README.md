# Toggle Pac-Man

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/OJGzBqe](https://codepen.io/alvaromontoro/pen/OJGzBqe).

