# Toggle Switch: Light/Dark

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/dyrzpJX](https://codepen.io/alvaromontoro/pen/dyrzpJX).

