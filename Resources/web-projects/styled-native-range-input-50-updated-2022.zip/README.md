# Styled native range input #50 (updated 2022)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/qEYZOv](https://codepen.io/thebabydino/pen/qEYZOv).

**February 2022 update**

Major changes:

* got rid of Compass and Modernizr dependencies, neither of which was needed anyway

* ditched the 1 element restriction

* now using `output` elements for the sliders that have tooltips instead of the very hacky method of putting the value in the `content` of a pseudo on the thumb (only ever worked in Chrome and has been broken there too since 2015 anyway)

* since I now know how to code a multi thumb slider (see my [article](https://css-tricks.com/multi-thumb-sliders-particular-two-thumb-case/) on CSS-Tricks for details), I added that feature to match the design too (the original 2015 version only had a single handle for all sliders, even though the original design showed two handles for the second one)

* now using a `datalist` for the ruler with values instead of the very hacky method of adding the number values with spaces between them in the `content` of a pseudo on the track (a trick that only ever worked in Chrome and has been broken there too since 2015 anyway)

* got rid of the convoluted JS that was adding the fill/ progress/ range highlight for the WebKit browsers and Firefox and switched to a simpler method based on CSS variables (thus reduced the JS by about 25% of what it was before, in spite of also spicing things up with some extra functionality)

* made it degrade gracefully in the no JS case (the wrapper's `::after` pseudo that's used to create the range highlights and the tooltips get `display: none` in the no JS case since the values they depend on don't get updated anyway)

* ditched `absolute` positioning in favour of using a `grid` layout now

* used smarter gradient techniques for the slider thumbs to better reproduce the design

* cleaned up the CSS and made it more maintainable by using CSS variables and the DRY switching technique, explained in this two part article I wrote for CSS-Tricks: [part one](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) and [part two](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/); not totally happy with this as there are different sliders with different designs and I got super meh about it midway...

* added `:focus-within`/ `:hover` styles

* ensured it now behaves consistently in both WebKit browsers and Firefox

* not providing free IE/ pre-Chromium support anymore

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE or Firefox don't need any JS, while  Chrome/ Opera have a bit of an extra, the tooltip above the thumb of the third slider in the first section. This tooltip is updated using JS. The tooltip is created using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). IE also has a tooltip, but that only shows the value rounded to the nearest integer and I cannot style it. Fallback for no JS: just don't display a tooltip for Chrome/ Opera. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/s9cGBcS.png) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 