/* external resources *only* for displaying the info boxes */

/* this below is all the JS needed for the demo itself to work */
/* only needed for fill in WebKit browsers */
document.documentElement.classList.add('js');

addEventListener('input', e => {
  let _t = e.target;
  
  _t.parentNode.style.setProperty('--val', +_t.value)
});