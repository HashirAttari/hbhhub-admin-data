# Styled native range input #1 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/JoOomG](https://codepen.io/thebabydino/pen/JoOomG).

**May 2021 update**

Cleaned up the code a bit more and made it behave consistently cross-browser.

See my other styled sliders in [this collection](https://codepen.io/collection/DgYaMj?sort_by=id).

---

**September 2017 update**

[Watch me update this in ~15 minutes](https://www.youtube.com/watch?v=XJ-IT5Wj8MY) (you can speed it up if you feel I'm typing/ speaking too slow).  Tested and looks exactly as desired in Firefox, though the solution for the `-moz-range-progress` pseudo-element is kind of hacky and could break in the future. Chrome doesn't allow the `thumb` to slide past the horizontal ends of the `track`'s `content-box`, while Firefox and Edge limit it to the `padding-box` (which makes more sense IMO). Sadly, I can't think of a bulletproof way to solve this problem in the case of this design. Also, the Chrome fake progress is hacky and could break in the future. The Edge solution doesn't require any unreliable hacks and it looks almost perfect save for the `thumb` shadows being cut off laterally beyond the horizontal limits of the input's `content-box`.

Major changes:

* eliminated the 1 element constraint and now used a range `input` tied to an `output` displaying its current value, both of them in a `form` which stores the current value of the range input in a custom property - this greatly simplifies the JavaScript for updating the fake progress in WebKit browsers

* eliminated hacks like using the `-ms-` class for specifically targeting IE (doesn't work in Edge, which gets the `-webkit-` class instead... yes, it's a crazy world we live in) or the `track`'s `::after` pseudo-element for the progress text label (that's now done cleanly and in a cross-browser manner with the `output` element)

----

**19-Dec-2015 update description**

Done using only one range input element. See more such sliders in [this collection](http://codepen.io/collection/DgYaMj/).

Changes:

* simpler thumb background using a `conic-gradient` with the [polyfill](http://leaverou.github.io/conic-gradient/) Lea Verou created - conic gradients are not yet supported by any browser, but **you can change that**, see: [Edge](https://wpdev.uservoice.com/forums/257854-microsoft-edge-developer/suggestions/8471413-implement-conic-gradients-from-css-image-values-le), [Gecko](https://bugzilla.mozilla.org/show_bug.cgi?id=1175958), [Chromium](https://code.google.com/p/chromium/issues/detail?id=502970), [WebKit](https://bugs.webkit.org/show_bug.cgi?id=146113)

* progress is CSS-only for Firefox as well (using `::-moz-range-progress`)

* completely removed the `/deep/` version used for styling the text in Blink as it's no longer working since February

* a single demo background for both browsers that support `background-blend-mode` and those that don't (you can [vote for Edge support](https://wpdev.uservoice.com/forums/257854-microsoft-edge-developer/suggestions/9434463-background-blend-mode))

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling. There's a bit of an extra in Chrome/ Opera with a nicely styled "label" (not a separate element, a pseudo on the thumb) on the right displaying progress. This is done using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). Fallback for no JS: simply display the same shade of grey for the entire track, both before and after the thumb and no "label". 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found.

[Image that inspired this demo](http://i.imgur.com/FzLXYfp.jpg). 