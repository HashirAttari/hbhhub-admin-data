$(document).ready(function() {
   $(".block").click(function() {
      var newElement=$(this).eq(0).clone(true).appendTo(".blocks");
      newElement.toggleClass("embiggen");
      newElement.click(function() {
         $(this).animate({
            top: '-200vh'
         },200);
         setTimeout(function() {
           $('.block:last-of-type').remove();
         }, 0);
      });
      $("#output").toggleClass("embiggen");
      var elem = this;
      function getTheStyle() {
         var theCSSprop = window
            .getComputedStyle(elem, null)
            .getPropertyValue("background-image");
         document.getElementById("output").innerHTML =
            "YOUR BROWSER RENDERED THIS: " + theCSSprop + ";";
      }
      getTheStyle();
   });
});