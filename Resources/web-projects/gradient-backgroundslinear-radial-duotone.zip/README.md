# Gradient Backgrounds - linear, radial, duotone

A Pen created on CodePen.io. Original URL: [https://codepen.io/EricPorter/pen/yXKGoX](https://codepen.io/EricPorter/pen/yXKGoX).

I use these and will keep adding to them. Thought I'd share.