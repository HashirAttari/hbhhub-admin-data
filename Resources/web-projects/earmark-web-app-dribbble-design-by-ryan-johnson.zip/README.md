# Earmark web app | Dribbble design by Ryan Johnson

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/WNxOQQM](https://codepen.io/havardob/pen/WNxOQQM).

A recreation of Ryan Johnson's beautiful Dribbble-design: https://dribbble.com/shots/14302892-Web-App-Overview 

It's also a real app coming soon, so credit to Earmark as well: https://www.earmark.co/

Icons from Phosphor: https://phosphoricons.com/

Illustration from Pablo Stanley at: https://www.opendoodles.com/