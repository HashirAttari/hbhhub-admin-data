# Toggle on/off

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/wvOBroa](https://codepen.io/alvaromontoro/pen/wvOBroa).

