/*
Inspired by
https://codepen.io/simeydotme/pen/Gzfuh

Don't hover dot you fool !

*/