# 'Making pancake' loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/pawelqcm/pen/ObwyNe](https://codepen.io/pawelqcm/pen/ObwyNe).

Yet another silly loader ;)