function hex (c) {
  var s = "0123456789abcdef";
  var i = parseInt (c);
  if (i == 0 || isNaN (c))
    return "00";
  i = Math.round (Math.min (Math.max (0, i), 255));
  return s.charAt ((i - i % 16) / 16) + s.charAt (i % 16);
}

/* Convert an RGB triplet to a hex string */
function convertToHex (rgb) {
  return hex(rgb[0]) + hex(rgb[1]) + hex(rgb[2]);
}

/* Remove '#' in color hex string */
function trim (s) { return (s.charAt(0) == '#') ? s.substring(1, 7) : s }

/* Convert a hex string to an RGB triplet */
function convertToRGB (hex) {
  var color = [];
  color[0] = parseInt ((trim(hex)).substring (0, 2), 16);
  color[1] = parseInt ((trim(hex)).substring (2, 4), 16);
  color[2] = parseInt ((trim(hex)).substring (4, 6), 16);
  return color;
}

function generateColor(colorStart,colorEnd,colorCount){

	// The beginning of your gradient
	var start = convertToRGB (colorStart);    

	// The end of your gradient
	var end   = convertToRGB (colorEnd);    

	// The number of colors to compute
	var len = colorCount;

	//Alpha blending amount
	var alpha = 0.0;

	var saida = [];
	
	for (i = 0; i < len; i++) {
		var c = [];
		alpha += (1.0/len);
		
		c[0] = start[0] * alpha + (1 - alpha) * end[0];
		c[1] = start[1] * alpha + (1 - alpha) * end[1];
		c[2] = start[2] * alpha + (1 - alpha) * end[2];

		saida.push(convertToHex (c));
		
	}
	
	return saida;
	
}

function updatePalette() {
  let e = document.querySelector('#selectColor');
  let p = e.options[e.selectedIndex].value;
  let c = themes[p];
  
  let h = '';
  for (let i=0; i<c.length; i++) {
    let col = c[i];
    h += `<div class="color" style="background-color:${col}"></div>`;
  }
  
  document.querySelector("#outPalette").innerHTML = h;
}

function randColor() {
  return '#'+Math.floor(Math.random()*16777215).toString(16);
}

function randPal() {
  let e = document.querySelector('#selectColor');
  let pal = e.options[e.selectedIndex].value;
  let colors = themes[pal];
  
  return colors[Math.floor(Math.random()*colors.length)];
}


const themes = {
  "fruitloops": ["#82A3DB","#94CA6B","#DCD280","#F1A75C","#B68570","#E36E90","#B087C7"],
  "ocean": ["#f1f1f1","#c6e3e1","#8cb9ba","#54a4a5","#068592","#005365"],
  "chocolatemilk": ["#B28F76","#C29F87","#D2AF98","#E3BEA9","#F5CEBA"],
  "hottamales": ["#FF4C4F","#EE3336","#CF0206","#BC0304"]
};

function updateText() {
  let txt = document.querySelector('#inText').value;
  let e = document.querySelector('#selectColor');
  let pal = e.options[e.selectedIndex].value;
  let m = document.querySelector('#selectMode');
  let mode = m.options[m.selectedIndex].value;
  let cList = themes[pal];
  let c = "#ffffff";
  let lastC = "";
  let h = '';
  let ot = '';
  
  let asciiArtList = [];
  
  let listNums = ('|'+txt).split('|');
  if (listNums.length > 2) {
    // 2, 4, 6, 8 ...
    for (let i=2; i<listNums.length; i+=2) {
      asciiArtList.push(listNums[i]);
    }
  }
  
  txt = listNums[1];
  
  if (mode === "random") {
    for (let i=0; i < txt.length; i++) {
      c = randPal();
      h += `<span style="color:${c}">${txt[i]}</span>`;
      if (c === lastC) {
        ot += txt[i];
      } else {
        ot += (txt[i]===" ") ? txt[i] : `[${c}]${txt[i]}`;
      }
      lastC = c;
    }
  }
  else if (mode === "order") {
    for (let i=0; i < txt.length; i++) {
      c = cList[i % cList.length];
      h += `<span style="color:${c}">${txt[i]}</span>`;
      if (c === lastC) {
        ot += txt[i];
      } else {
        ot += (txt[i]===" ") ? txt[i] : `[${c}]${txt[i]}`;
      }
      lastC = c;
    }
  }
  else if (mode === "stretch") {
    let chunkLen = Math.round(txt.length / cList.length);
    
    let cPart = 0;
    
    for (let i=0; i < txt.length; i++) {
      if ( (i > (chunkLen-1)) && (i % chunkLen === 0) ) {
        cPart++;
      }
      c = cList[cPart] || cList[cList.length-1];
      h += `<span style="color:${c}">${txt[i]}</span>`;
      if (c === lastC) {
        ot += txt[i];
      } else {
        ot += (txt[i]===" ") ? txt[i] : `[${c}]${txt[i]}`;
      }
      lastC = c;
    }
  }
  else {
    console.error('ERROR: unknown mode');
  }
  
  for (let i=0; i < asciiArtList.length; i++) {
    ot += document.querySelector('#ascii_' + asciiArtList[i]).innerText;
  }
  
  /*
  if (txt && txt.length > 0) {
    var h = '';
    var ot = '';
    let cF = "#ffffff";
    let cM = "#ffffff";
    let cL = "#ffffff";
    let tLen = Math.floor(txt.length * 0.5) + 1;
    
    if (pal && themes[pal]) {
      cF = themes[pal][0] || "#ffffff";
      cM = themes[pal][1] || themes[pal][0] || "#ffffff";
      cL = themes[pal][2] || themes[pal][1] || themes[pal][0] || "#ffffff";
    } else {
      console.error(`ERROR: unknown theme [${pal}]`);
    }
    
    let c1 = generateColor(cM,cF,tLen);
    let c2 = generateColor(cL,cM,tLen);
    let colorList = c1.concat(c2);
    
    
  } else {
    console.error(`ERROR: text message too short [${txt}]`);
    return;
  }
  */
  
  document.querySelector('#charLength').innerText = (ot.length);
  
  document.querySelector('#results').innerHTML = h;
  document.querySelector('#outText').value = ot;
  document.querySelector('#display').innerText = ot;
  
}

document.querySelector('#btnChar').addEventListener("click", addChar);
document.querySelector('#btnAscii').addEventListener("click", addAscii);

document.querySelector('#copyButton').addEventListener("click", copyText);
document.querySelector('#inText').addEventListener("change", update);
document.querySelector('#inText').addEventListener("keyup", update);

document.querySelector('#selectColor').addEventListener("change", handleChange);
document.querySelector('#selectMode').addEventListener("change", handleChange);

function handleChange() {
  updatePalette();
  update();
}

function update() {
  let iTxt = document.querySelector('#inText').value;
  updateText(iTxt, "randLight");
}

function addChar() {
  let e = document.querySelector('#specialChar');
  let ch = e.options[e.selectedIndex].value;
  let iTxt = document.querySelector('#inText');
  iTxt.value = ch + iTxt.value;
  update();
}

function addAscii() {
  let e = document.querySelector('#asciiArt');
  let ascii = e.options[e.selectedIndex].value;
  let iTxt = document.querySelector('#inText');
  iTxt.value = iTxt.value + ascii;
  update();
}

function copyText() {
  let el = document.getElementById("outText");
  el.select();
  if (el.setSelectionRange) {
    var oldContentEditable = el.contentEditable,
    oldReadOnly = el.readOnly,
    range = document.createRange();

    el.contentEditable = true;
    el.readOnly = false;
    range.selectNodeContents(el);

    var s = window.getSelection();
    s.removeAllRanges();
    s.addRange(range);

    el.setSelectionRange(0, 999999);

    el.contentEditable = oldContentEditable;
    el.readOnly = oldReadOnly;
  }

    document.execCommand('copy');
}


function init() {
  updatePalette();
  update();
  openTab(null, 'Color');
}

init();

/*
dark
#396AB1
#3E9651
#948B3D
#DA7C30
#922428
#CC2529
#6B4C9A
#535154

light
#82A3DB
#94CA6B
#DCD280
#F1A75C
#B68570
#E36E90
#B087C7
#909595
*/


/*
bright colors

#F012BE
#B10DC9

#0074D9
#39CCCC

#3D9970
#2ECC40

#FFDC00
#FF851B

#FF4136
#85144b








[#ff6666]@[#66ff88]-}-,-‘-,—


[#ccffcc]¯\_(ツ)_/¯

[#ff8888] [#ffcc88] [#ffff88] [#88ff88] [#8888ff] [#ff88ff]

[#ff8888] ♡ [#ffcc88] ♡ [#ffff88] ♡ [#88ff88] ♡ [#8888ff] ♡ [#ff88ff] ♡

[#ff8888] ⚀ [#ffcc88] ⚁ [#ffff88] ⚂ [#88ff88] ⚃ [#88ccff] ⚄ [#ff88ff] ⚅ [#ffffff] — Yahtzee!



[#ff8888] ⚀ [#ffcc88] ⚁ [#ffff88] ⚂ [#88ff88] ⚃ [#88ccff] ⚄ [#ff88ff] ⚅ [#ffffff] — roll the dice and join my alliance!



[#ff6666]★[#ffcc88]★[#ffff88]★[#88ff88]★[#88ccff]★[#ff88ff]★




*/



function openTab(evt, tabName) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  if (evt) {
    evt.currentTarget.className += " active";
    document.getElementById(tabName).style.display = "block";
  } else {
    document.getElementById('Color').style.display = "block";
  }
}