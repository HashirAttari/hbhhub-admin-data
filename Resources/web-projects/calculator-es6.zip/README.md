# Calculator ES6

A Pen created on CodePen.io. Original URL: [https://codepen.io/richardhuf/pen/KWoKJy](https://codepen.io/richardhuf/pen/KWoKJy).

Javascript calculator, that uses some ES6 features. 