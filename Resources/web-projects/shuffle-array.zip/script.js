const shuffle = (array) => {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

var arr = new Array(10).fill().map((x, i) => i);
console.log(arr);
shuffle(arr);
console.log(arr);