# shuffle array

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/qBLLJdN](https://codepen.io/run-time/pen/qBLLJdN).

