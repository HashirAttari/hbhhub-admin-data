# 3D Player/Recorder - Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/PoRvRmM](https://codepen.io/ricardoolivaalonso/pen/PoRvRmM).

