# Background Pattern

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/LYPJPGE](https://codepen.io/ricardoolivaalonso/pen/LYPJPGE).

