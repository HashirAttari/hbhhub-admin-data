# Dynamic periodic table

A Pen created on CodePen.io. Original URL: [https://codepen.io/fbuireu/pen/EegBON](https://codepen.io/fbuireu/pen/EegBON).

## Dynamic Periodic Table

I brought this CodePen to life five years ago, blending my love for geology with coding finesse. The initial spark was to craft an interactive periodic table with an educational twist, injecting dynamism and engagement, especially in primary school classrooms. Although the project hit pause for a while, I recently dusted it off and gave it the finishing touches it deserved.

The CSS and JS tech have evolved leaps and bounds since its inception, offering ample opportunities for upgrades. However, I opted to preserve some original design aspects as a tribute to the journey and enthusiasm that birthed the project. It's a nostalgic nod to appreciate progress and honor the project's origins.

The table boasts interactive and didactic features, offering a plethora of micro-interactions. Dive into the dynamic realm of elements – hope you enjoy exploring it as much as I enjoyed creating it!

For the HTML, I kept it straightforward. Each element is an `<li>` wrapped in a `<ul>`, both for groups and periods.

Modals use the native `<dialog>` element. Custom data-attributes hold the key to information that would otherwise require an API request.

The SCSS isn't too mysterious either: both the table and modals are static grids. Some elements, like the "Key" in the legend, use pseudo-selectors like `:after` and `:before`.

The previously mentioned data-attributes allow me to target each element and place it in its grid position. The atom animation floats freely while the rest of the content forms a grid starting a few rows below to make space for the atom animation.

The JavaScript, aside from a hefty 4k-line JSON with element info, essentially listens for hover events on each hoverable element (groups, periods, elements, etc.) to determine what type of info is being sought. It traverses all DOM elements in order, applying the corresponding animation with its delay, hence the potential delay depending on element order.

Actinoids and lanthanoids, being the quirky ones, behave differently, acting like a sort of "many elements in one" – as my lab chemistry professor used to say.

For the draggable range slider, it modifies the data-attribute of each element, changing its state based on temperature conditions for transitions to gas or solid.

For the modal animation, it calculates the clicked element's position and scales it to the center of the screen:

```js
  scale = modalProperties.width / 100;
  translateX = Math.round(
    positionX - selfProperties.left - selfProperties.width / 2
  );
  translateY = Math.round(
    positionY - selfProperties.top - selfProperties.height / 2
  );
  self.style.transform = `translate(${translateX}px, ${translateY}px) scale(${scale})`;
```

Behind the `<dialog>`, the same element in large size ensures synchronized animations and transitions for the desired effect.

- - -

Disclaimer:  for the best experience, it's recommended to view this pen on a wide screen (up to 1300px) to ensure optimal performance

- - -

**Acknowledgements:**

- [IUPAC](https://iupac.org) (International Union of Pure and Applied Chemistry)

- [RasMol](http://rasmol.org) and [Michael Dayah](https://www.dayah.com/) for providing valuable information. Special thanks to Michael Dayah for the continuously updated content on [Ptable](https://www.ptable.com/?lang=en).

- Loïc Monard ([@LoicMonard](https://codepen.io/LoicMonard)) for the inspiring color palette used in their [periodic table project](https://codepen.io/LoicMonard/pen/BPVbEa).
