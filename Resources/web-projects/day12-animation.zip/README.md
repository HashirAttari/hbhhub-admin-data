# day12: animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/kenjiSpecial/pen/WNpvoN](https://codepen.io/kenjiSpecial/pen/WNpvoN).

100day coding boot camp
1 canvas 1day work.