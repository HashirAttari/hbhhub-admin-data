# Styled native range input #46 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/KwoXaR](https://codepen.io/thebabydino/pen/KwoXaR).

**June 2021 update**

Major changes:

* got rid of Compass and Modernizr dependencies, neither of which was needed anyway anymore

* ditched the 1 element restriction to make it functional again (the hacky `/deep/` technique from early 2015 had stopped working within the same year, so I've now eliminated all that completely useless code) and accessible - the ruler marks are now `option` elements within a `datalist` tied to the corresponding range input

* still hacky (using `datalist` pseudos to emulate thumb with arrow in JS case; in the no JS case, since the ruler fill cannot be updated, it's just not displayed and the arrow is unnecessary since there's nothing to point to anymore), but not as bad as before

* generated the HTML in a logical manner with Pug that also helps me pass some custom properties to the CSS

* got rid of the convoluted JS that was adding the fill/ progress highlight on the ruler and switched to a simpler method based on CSS variables (this reduced the JS to about a quarter of what it was before!!!)

* made it degrade gracefully in the no JS case (there's just no ruler fill or thumb arrow pointing to it)

* ditched `absolute` positioning in favour of using a `grid` layout now

* cleaned up the CSS and made it more maintainable by using CSS variables and the DRY switching technique, explained in this two part article I wrote for CSS-Tricks: [part one](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) and [part two](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/)

* ensured it now behaves consistently in both WebKit browsers and Firefox

* corrected thumb motion behaviour using the [track wrapper](https://codepen.io/thebabydino/pen/NWpNGpo) in Chrome (the way it [behaves in Firefox](https://css-tricks.com/sliding-nightmare-understanding-range-input/#the-range-thumb-component), within the `content-box` of the `actual input`, causes no problems)

* would have loved to make it all CSS-only in Firefox, but the way `::-moz-range-progress` behaves [is just not practical](https://css-tricks.com/sliding-nightmare-understanding-range-input/#the-range-progress-fill-component) 😭

* not providing free IE/ pre-Chromium support anymore

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE has a problem with thumb being cut off once it reaches the ends. Chrome/ Opera have a bit of an extra, the progress ruler and the arrow on the thumb. This is done using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). No JS is needed unless I have to update the progress ruler, so the demo is CSS-only in Firefox and IE. Fallback for no JS: simply display the plain ruler, without lighting it up as the slider moves towards 100%.

---

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/9AAqCvj.jpg) 

---

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 