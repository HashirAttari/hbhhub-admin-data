// 2013 by Kaushalya Mandaliya SHtyle
// https://seebeetee.com / @kmandalwala
// Inspired by http://drbl.in/iLzs