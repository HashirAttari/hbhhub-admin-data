# dot slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/d4rek/pen/dMMKjo](https://codepen.io/d4rek/pen/dMMKjo).

Navigation bar. See more at https://dribbble.com/shots/2581199-Dot-navigation