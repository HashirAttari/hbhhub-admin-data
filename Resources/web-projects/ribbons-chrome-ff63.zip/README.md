# Ribbons (Chrome/FF63+)

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/oaBYKe](https://codepen.io/yuanchuan/pen/oaBYKe).

