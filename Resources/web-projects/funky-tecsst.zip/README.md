# funky teCSSt

A Pen created on CodePen.io. Original URL: [https://codepen.io/jbasoo/pen/AbVwWN](https://codepen.io/jbasoo/pen/AbVwWN).

Re-inspired by http://darcyclarke.me/dev/hawtcss/#landing-slide