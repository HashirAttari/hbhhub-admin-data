let p = document.documentElement,
		z = 5500,
		yt = "https://www.youtube.com/embed/YsxBCb03JCo?si=jL5-yxMQnL7tSw10&controls=0&start=0&autoplay=1"

function playTheThing(){
	function runAnimation() {
		if(z == 1000) {
			clearInterval(running)
			document.querySelector('iframe').src = yt
		}
		if(z > 1000) {
			z--
		}

		p.style.setProperty("--depth", z+"px")

		if(!document.querySelector('.move_bg')){
			document.querySelector('.building').classList.add('move_bg')
		}
	}	
	
	startBtn.remove()
	let running = setInterval(runAnimation)
	
}