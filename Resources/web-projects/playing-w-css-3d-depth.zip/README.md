# Playing w/ CSS 3D Depth

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/MWLwVmj](https://codepen.io/kitjenson/pen/MWLwVmj).

Trying out a little idea...???