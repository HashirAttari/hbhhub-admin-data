# Circulating balls follow straight lines (No Safari)

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/YzzYdJm](https://codepen.io/yuanchuan/pen/YzzYdJm).

