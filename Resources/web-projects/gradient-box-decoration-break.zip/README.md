# gradient + box-decoration-break

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/BawBBGO](https://codepen.io/t_afif/pen/BawBBGO).

https://css-tip.com/multi-line-text-decoration/