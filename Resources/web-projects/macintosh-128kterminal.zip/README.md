# Macintosh 128k - Terminal

A Pen created on CodePen.io. Original URL: [https://codepen.io/tryggvigy/pen/gwmyYJ](https://codepen.io/tryggvigy/pen/gwmyYJ).

Inspired by a dribbble that I can't find any more.