const gridSize = 5;
const $grid = document.querySelector('[data-grid]');

const fanBlades = (amountOfBlades = 10) => {
  const $d = document.createElement('div');
  $d.classList.add('blades');
  $d.style.setProperty('--fr', 1 / amountOfBlades);
  Array.from(
  new Array(amountOfBlades),
  (_, i) => {
    const $blade = document.createElement('i');
    $blade.classList.add('blade');
    $blade.style.setProperty('--bladeI', i / (amountOfBlades - 1));
    $d.appendChild($blade);
  });

  return $d;
};

$grid.style.setProperty('--gridSize', gridSize);
const grid = Array.from(
new Array(gridSize),
(_, y) =>
Array.from(
new Array(gridSize),
(_, x) => {
  const $d = document.createElement('div');
  const i = y * gridSize + x;
  $d.style.setProperty('--x', x);
  $d.style.setProperty('--y', y);

  $d.style.setProperty('--i', i);
  $d.classList.add('grid__item');
  //$d.innerText = `[x ${x}] [y ${y}] [i ${i}]`
  const $blades = fanBlades(12);

  $d.appendChild($blades);
  $grid.appendChild($d);

  return $d;
}));