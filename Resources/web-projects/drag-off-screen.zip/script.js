function makeDraggable(dragItem) {
  var active = false;
  var click = false;
  var currentX;
  var initialX;
  var xOffset = 0;
  var direction;

  dragItem.addEventListener("touchstart", dragStart, false);
  dragItem.addEventListener("touchend", dragEnd, false);
  dragItem.addEventListener("touchmove", drag, false);

  dragItem.addEventListener("mousedown", dragStart, false);
  dragItem.addEventListener("mouseup", dragEnd, false);
  dragItem.addEventListener("mousemove", drag, false);

  function dragStart(e) {
    if (e.type === "touchstart") {
      initialX = e.touches[0].clientX - xOffset;
    } else {
      initialX = e.clientX - xOffset;
    }

    active = true;
    click = true;
  }

  function dragEnd(e) {
    initialX = currentX;

    dragItem.style.transition = '.2s ease';
    if (isInViewport(dragItem)) {
      xOffset = 0;
      dragItem.style.left = 0;
      window.setTimeout(function() {
        dragItem.style.transition = '';
      }, 200);
    }
    else {
      dragItem.style.left = 100 * direction + '%';
      window.setTimeout(function() {
        dragItem.style.marginTop = '-81px';
      }, 200);
      window.setTimeout(function() {
        dragItem.remove();
      }, 400);
    }

    active = false;
    
    if (click == true) {
      console.log('staticClick');
    }
  }

  function drag(e) {
    if (active) {
      e.preventDefault();

      if (e.type === "touchmove") {
        currentX = e.touches[0].clientX - initialX;
      } else {
        currentX = e.clientX - initialX;
      }

      xOffset = currentX;

      if (xOffset < 0) {
        direction = -1;
      }
      else {
        direction = 1;
      }

      dragItem.style.left = currentX + 'px';
      
      click = false;
    }
  }
}

var isInViewport = function (elem) {
    var bounding = elem.getBoundingClientRect();
    return (
        bounding.left >= 0 &&
        bounding.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
};

document.querySelectorAll('.draggable').forEach(el => {
  makeDraggable(el);
})