# Drag off screen

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/KKzgXXQ](https://codepen.io/benhatsor/pen/KKzgXXQ).

