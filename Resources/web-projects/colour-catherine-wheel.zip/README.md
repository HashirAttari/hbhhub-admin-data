# Colour Catherine Wheel

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/abWZPGx](https://codepen.io/chrisgannon/pen/abWZPGx).

