# Dusty Particle Sphere

A Pen created on CodePen.io. Original URL: [https://codepen.io/sparanoid/pen/KRJeam](https://codepen.io/sparanoid/pen/KRJeam).

Modified my Particle Heart (http://codepen.io/Zaku/pen/IkcqC) from Valentine's Day inspired by http://rectangleworld.com/blog/archives/298.