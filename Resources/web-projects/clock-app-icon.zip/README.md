# Clock App Icon

A Pen created on CodePen.io. Original URL: [https://codepen.io/marcobiedermann/pen/DoWGLg](https://codepen.io/marcobiedermann/pen/DoWGLg).

View it at <a href="http://drbl.in/hZed">dribbble</a> or <a href="http://bit.ly/14386be">Behanced</a>