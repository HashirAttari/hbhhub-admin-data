console.clear();

/**
Darth Eyeball

URL:
https://farbvelo.elastiq.ch/?s=eyJzIjoiM2FhNTFlMWZjOTNlYiIsImEiOjEwLCJjZyI6NSwiaGciOmZhbHNlLCJoYiI6dHJ1ZSwiaG8iOmZhbHNlLCJoYyI6ZmFsc2UsImh0Ijp0cnVlLCJiIjp0cnVlLCJwIjowLCJtZCI6NjAsImNtIjoibGFiIiwiZiI6Ikh1ZSBCaW5nbyIsImMiOiJoc2x1diIsInNjIjpmYWxzZSwiYnciOmZhbHNlLCJhaCI6dHJ1ZSwiaXUiOiJodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTYzMzU4NTMwOTYwNS05ODIwNWNkYTkxZTQ/Y3JvcD1lbnRyb3B5JmNzPXRpbnlzcmdiJmZpdD1jcm9wJmZtPWpwZyZoPTMwMCZpeGlkPU1ud3hmREI4TVh4eVlXNWtiMjE4TUh4OGZIeDhmSHg4TVRZek5EZzBNell4TVEmaXhsaWI9cmItMS4yLjEmcT04MCZ3PTIwMCIsImxtIjp0cnVlfQ==

**/
const colors = [
['#c3c7c9', '#dda2bc', '#ef78b0', '#ce6184', '#97564a', '#634423', '#392a1b', '#101111'], ['#444048', '#6d6d8b', '#989ed4', '#c4bae6', '#e3bcb0', '#f8be78', '#eca058', '#c86850', '#a32945'],
['#221a22', '#63456c', '#ae74bf', '#de92d8', '#e09aa0', '#dca266', '#d8ac5f', '#d7b685', '#d2c1aa'],
['#2d4c45', '#37544f', '#75555a', '#ab4e65', '#c75b6c', '#c87e6d', '#c79f6d', '#c5b183', '#c3c0a0'],
['#000000', '#233950', '#3771a5', '#7071b9', '#9c57b6', '#b85fa5', '#c58d86', '#d1b77b', '#eadabc', '#ffffff'],
[`#0c120d`, `#162726`, `#1a3e3f`, `#66544e`, `#ba6559`, `#d77757`, `#bd8c46`, `#a99e46`, `#aeb87d`, `#acd3b4`]];




const random = (min, max) => {
  if (Array.isArray(min)) {
    return min[random(0, min.length - 1)];
  }
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

const gradientStops = (nbr, colors, start = 1, stop = 1000) => {
  const values = new Array(nbr).fill('').map(i => random(start, stop));
  const total = values.reduce((r, c) => r + c, 0);
  let lastTotal = 0;

  return values.map((v, i) => {
    const totalTilHere = values.slice(0, i).reduce((r, c) => {
      return r + c / total;
    }, 0);
    const c = random(colors);
    let str = `${c} ${lastTotal * 100}% , ${c} ${totalTilHere * 100}%`;
    str = `${c} ${totalTilHere * 100}%`;
    lastTotal = totalTilHere;
    return str;
  }).join(',');
};

const newDiv = ($parent, nbr = 40, start = 1, stop = 1000, c = colors[0], smin = 20, smax = 95) => {
  const $d = document.createElement('div');
  $d.style.background = `conic-gradient(${gradientStops(nbr, c)})`;
  $d.style.setProperty('--r', Math.random());
  $d.style.setProperty('--s', random(smin, smax));
  $d.style.setProperty('--d', random([-1, 1]));

  $parent.appendChild($d);
  return $d;
};

const build = $el => {
  $el.innerHTML = '';
  const c = random(colors);

  for (var i = 0; i < 10; i++) {
    const $n = newDiv($el, 40, 1, 1000, c, 20, 95);
    $n.style.setProperty('--i', i / 10);
  }
};

const buildMin = $el => {
  $el.innerHTML = '';
  const c = random(colors);
  for (var i = 0; i < 4; i++) {
    const $n = newDiv($el, 4, 1, 1000, c, 20, 95);
    $n.style.setProperty('--i', i / 10);
  }
};

const ok = () => {
  const cs = Array.from(document.querySelectorAll('.c'));

  cs.forEach($c => {
    const rnd = random([build, buildMin]);
    buildMin($c);
  });

};

ok();
//setInterval(doit, 500);
document.documentElement.addEventListener('click', () => {
  ok();
});