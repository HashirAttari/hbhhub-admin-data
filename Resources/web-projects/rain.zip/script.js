var body = document.body;
var lightning = document.querySelector(".lightning");
var ground = document.querySelector(".ground");

function light() {
 body.classList.toggle("light");     lightning.classList.toggle("light");
 ground.classList.toggle("light");
};

function dark() {
 body.classList.toggle("light");     lightning.classList.toggle("light");
 ground.classList.toggle("light");
};

setInterval(light, 3000);
setInterval(dark, 3010);

setInterval(light, 3500);
setInterval(dark, 3510);