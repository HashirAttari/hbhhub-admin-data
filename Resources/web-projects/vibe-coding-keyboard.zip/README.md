# Vibe coding keyboard

A Pen created on CodePen.

Original URL: [https://codepen.io/alvaromontoro/pen/qEBQWEm](https://codepen.io/alvaromontoro/pen/qEBQWEm).

