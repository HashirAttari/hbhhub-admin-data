# Animated Retrowave 👾  (CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/konstantindenerz/pen/WNgEqbG](https://codepen.io/konstantindenerz/pen/WNgEqbG).

I had created this retro wave scene with different CSS techniques (@property, filter, mask, gradient, mix-blend-mode, clip-path). Chromium-based browsers provide the best viewing results. The goal wasn't to get the best performance, more to have fun.

Music: https://assets.codepen.io/907471/synthesizer-synthwave-80s-110045-license.txt 