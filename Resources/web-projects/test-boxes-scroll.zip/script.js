var tl, tlscroll;

tl = new TimelineMax ();


tl.set('.box', {autoAlpha: 0.1})
.set('#box1', {x:-150, y:-100})
.set('#box2', {x:-200, y:-200})
.set('#box3', {x:280, y:-200})
.set('#box4', {x:420, y:-100})
.set('#box5', {x:-320, y:-100})
.set('#box6', {x:-150, y:-200})
.set('#box7', {x:50, y:-250})
.set('#box8', {x:250, y:-200})
.set('#box9', {x:-330, y:-100})
.set('#box10', {x:-310, y:-200})
.set('#box11', {x:240, y:-250})
.set('#box12', {x:310, y:-200})
.set('#box13', {x:-270, y:-100})
.set('#box14', {x:-190, y:-200})
.set('#box15', {x:320, y:-200})
.set('#box16', {x:320, y:-100})
.set('#box17', {x:-270, y:-100})
.set('#box18', {x:-190, y:-200})
.set('#box19', {x:320, y:-200})
.set('#box20', {x:320, y:-100});



var controller = new ScrollMagic.Controller();

var tween = TweenMax.staggerTo(".box", 3, {x: 0, y:0, autoAlpha:1}, 0.35)


	// build scene
	var scene = new ScrollMagic.Scene({triggerElement: "#board", duration: 500, offset:50})
					.setTween(tween)
					.addIndicators({name: "staggering"}) // add indicators (requires plugin)
					.addTo(controller);


var scene = new ScrollMagic.Scene({triggerElement: "#board", duration: 500, offset:200, })
						.setPin("#board")
						.addIndicators({name: "1 (duration: 300)"}) // add indicators (requires plugin)
						.addTo(controller);