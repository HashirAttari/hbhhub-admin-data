# Test boxes scroll

A Pen created on CodePen.io. Original URL: [https://codepen.io/MatteoDevBN1/pen/NRgaza](https://codepen.io/MatteoDevBN1/pen/NRgaza).

GSAP + Scrollmagic