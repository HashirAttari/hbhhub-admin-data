gsap.config({trialWarn: false});
let select = s => document.querySelector(s),
  selectAll = s =>  document.querySelectorAll(s),
		toArray = s => gsap.utils.toArray(s),
		mainSVG = select('#mainSVG'),
		allLines = toArray('#container rect'),
		spinDuration = 5,
		colorArray = ["#ff595e","#ffca3a","#8ac926","#1982c4","#6a4c93"]

gsap.set(allLines, {
	rotation: (c, t) => (360/allLines.length) * c,
	svgOrigin: '400 300'
})
gsap.set('svg', {
	visibility: 'visible'
})
let rippleTl = gsap.timeline();
rippleTl.to(allLines, {
	duration: 1,
	opacity: 0.2,
	stagger: {
		amount: 1,
		repeat: -1
	},
	ease: 'sine'
}).seek(100)

let spinTl = gsap.timeline({paused: true});
spinTl
.to('#container', {
	duration: 3,
	rotation: 360,
	transformOrigin: '50% 50%',
	repeat: -1,
	ease: 'none'
}, 0).seek(0)

const spinLoader = (pos) => {
	//console.log(pos);
	rippleTl.reversed( !rippleTl.reversed() ); 
	spinTl.tweenTo(pos, {duration: spinDuration, ease:  'back(0.4)'});
	gsap.to(allLines, {
		fill: gsap.utils.wrap(colorArray),
		stagger: {
			amount: 0.5,
			repeat: 7,
		},
		ease: 'slow(0.3, 0.8 , true)'
	})
	
}

let mainTl = gsap.timeline({repeat: -1});
mainTl.set('#cursor', {
	x: 430,
	y: 360
})
.add('ready1')
.to('#cursor', {
	y: 280,
	ease: 'power4.inOut'
}, 'ready1+=1')
.add('spin1')

.to('#cursor', {
	duration: 0.2,
	x: 430,
	y: 360,
	ease: 'power3'
}, 'spin1')
.call( spinLoader,  [16], 'spin1+=0.05')
.to('#cursor', {
	x: '-=60',
	y: '+=30',
	delay: 2.3,
	duration: 3,
	ease: 'power4.inOut'
})
.add('ready2')
.to('#cursor', {
	x: 360,
	y: 280,
	ease: 'power3.inOut'
}, 'ready2')
.add('spin2')

.to('#cursor', {
	duration: 0.2,
	x: 390,
	y: 380,
	ease: 'power3'
}, 'spin2')
.call( spinLoader, [1], 'spin2+=0.05')
.to('#cursor', {
	x: 430,
	y: 360,
	delay: 4,
	duration: 2,
	ease: 'power2.inOut'
})