# Toggles | cpcj23w1

A Pen created on CodePen.io. Original URL: [https://codepen.io/mugosagi/pen/bGQNorN](https://codepen.io/mugosagi/pen/bGQNorN).

