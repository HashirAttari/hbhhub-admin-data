# Simple calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/i1yas/pen/xOyWbP](https://codepen.io/i1yas/pen/xOyWbP).

