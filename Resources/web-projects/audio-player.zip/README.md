# Audio Player

A Pen created on CodePen.io. Original URL: [https://codepen.io/internette/pen/zqoLpe](https://codepen.io/internette/pen/zqoLpe).

Inspired by the following dribbble: https://dribbble.com/shots/799178-Knob

This piece was extremely fun. I got to look at Winamp skins for inspiration for the playlist section. I also learned a lot more about the audio HTML tag and all of the native JS related to it. It's super cool. The only dependency is the SoundCloud SDK.

I went with Soundcloud because:
1. Spotify requires access tokens, either requiring the user to log in or have some server side script ran. I didn't want either of those approaches.
2. Spotify's API doesn't have full versions of songs to stream.