# Loader CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/vYBQqGK](https://codepen.io/ricardoolivaalonso/pen/vYBQqGK).

