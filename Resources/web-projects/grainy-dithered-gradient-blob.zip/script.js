/* absolutely no JS 🙃 */
/* my 1st attempt at this https://codepen.io/thebabydino/pen/wvJbpMd */