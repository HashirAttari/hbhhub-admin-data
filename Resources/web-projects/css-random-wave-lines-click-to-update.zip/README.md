# CSS random wave lines  (click to update)

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/mZNyYB](https://codepen.io/yuanchuan/pen/mZNyYB).

This demo only runs in Chrome.  

(Firefox doesn't support web components yet. And Safari has an issue to do animations on pseudo-elements inside Shadow DOM.)

You can edit the variables to get some variations like this pen:
https://codepen.io/yuanchuan/pen/YaoXXX
 


----
