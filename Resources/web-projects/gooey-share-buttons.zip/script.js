$('.goob').click(function() {
  document.getElementsByClassName('scale')[0].classList.remove('scaled');
  setTimeout(function() {
    document.getElementsByClassName('scale')[0].classList.add('scaled');
  }, 100);
  document.getElementsByClassName('scale')[0].style.background = $(this).css('background');
  var b = $(this).css('background');
  setTimeout(function() {
    document.body.style.background = b;
  }, 1000);
})