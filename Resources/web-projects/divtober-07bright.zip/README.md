# #divtober 07 - Bright

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/KKMwgMz](https://codepen.io/ricardoolivaalonso/pen/KKMwgMz).

