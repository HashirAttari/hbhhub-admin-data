/*
		Designed by: Saeed Tavoosi
		Original image: https://dribbble.com/shots/5888593-Damavand
*/