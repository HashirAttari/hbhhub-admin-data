document.querySelectorAll('.button').forEach(button => {
  button.onclick = () => {
    button.classList.toggle('active');
  }
})