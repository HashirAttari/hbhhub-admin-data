setInterval(function () {
  document.body.style.backgroundColor = getRandColor();
}, 3000);

function getRandColor() {
  let colorList = ['#396AB1','#3E9651','#DCD280','#DA7C30','#CC2529','#E36E90','#6B4C9A'];
  let r = Math.floor(Math.random()*colorList.length);
  return colorList[r];
}