# Ushanka bear, Valentine's day, Hugs, SVG ANIMATION, Heart | CodePen Challenge

A Pen created on CodePen.

Original URL: [https://codepen.io/zack_frost/pen/ZmONzy](https://codepen.io/zack_frost/pen/ZmONzy).

