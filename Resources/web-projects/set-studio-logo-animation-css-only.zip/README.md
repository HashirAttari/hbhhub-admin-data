# Set.Studio logo animation (CSS only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/gOjzgBL](https://codepen.io/amit_sheen/pen/gOjzgBL).

