# Drag / swipe to unlock

A Pen created on CodePen.io. Original URL: [https://codepen.io/pimskie/pen/xxZPbd](https://codepen.io/pimskie/pen/xxZPbd).

Based on the pen of Justin Blaisdell: http://codepen.io/jsblaisdell/pen/AoxeL

Only this one is without jQuery(UI) and is much more crappy (not tested)