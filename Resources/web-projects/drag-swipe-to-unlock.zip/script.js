var outer = document.getElementById('outer'),
    outerRect = outer.getBoundingClientRect(),
    lock = document.getElementById('lock'),
    message = document.getElementById('message'),
    isTouch = 'ontouchstart' in document.documentElement,
    lockRect = null,
    dragProps = null;

function dragStart (e) {
  lockRect = lock.getBoundingClientRect();
  var x = getX(e);
  dragProps = {
    start: lockRect.left - outerRect.left,
    mouseStart: x,
    newX: 0
  }
  lock.classList.add('dragging');
  document.addEventListener('mousemove', dragLock, false);
  document.addEventListener('touchmove', dragLock, false);
  document.addEventListener('mouseup', dragStop);
  document.addEventListener('touchend', dragStop);
}

function dragStop (reset) {  
  lock.classList.remove('dragging');
  if (reset !== false) {
    lock.style.left = '0px';
  } 
  document.removeEventListener('mousemove', dragLock, false);
  document.removeEventListener('touchmove', dragLock, false);
  document.removeEventListener('mouseup', dragStop);
  document.removeEventListener('touchend', dragStop);
}

function unlock () {
  outer.classList.add('unlocked');
  
  dragStop(false);
  lock.removeEventListener('mousedown', dragStart);
  lock.removeEventListener('touchstart', dragStart);
  message.innerHTML = 'Unlockioni';
}

function dragLock (e) {
 e.preventDefault();
  var posX = getX(e);
  
  var mouseDiff = posX - dragProps.mouseStart,
      maxX = outerRect.width - lockRect.width,
      newX = dragProps.start + mouseDiff,
      newX = clamp(newX, 0, maxX);
  
  lock.style.left = newX + 'px';
  if (newX >= maxX) {
    unlock();
  }
}


// king: http://codingmath.com/posts/mini4.html
function clamp (value, min, max) {
  return Math.min(Math.max(value, min), max);
}


function getX(event) {
  if (isTouch === true) {
    return event.touches[0].pageX;
  } else {
    return event.clientX;
  }
}

lock.addEventListener('mousedown', dragStart);
lock.addEventListener('touchstart', dragStart);