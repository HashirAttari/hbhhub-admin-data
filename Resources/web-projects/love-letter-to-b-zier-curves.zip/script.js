var black = '#34495e';
var white = '#fff';
var blue = '#3498db';
var red = '#e74c3c';
var silver = '#bdc3c7';

var svg = d3.select('svg')
  .attr('width', 500)
  .attr('height', 500)
;

function addHandle(x, y, update) {
  var handle = svg.append('circle')
    .attr('fill', black)
    .attr('stroke', white)
    .attr('stroke-width', 1)
    .attr('r', 5)
    .attr('cx', x)
    .attr('cy', y)
  ;
  var drag = d3.behavior.drag()
    .on('drag', function() {
      handle
        .attr('cx', d3.event.x)
        .attr('cy', d3.event.y)
      ;
      update();
    })
  ;
  handle.call(drag);
  return handle;
}

function addGuide() {
  return svg.append('path')
    .attr('fill', 'none')
    .attr('stroke', silver)
    .attr('stroke-width', 1)
  ;
}

function addBezierPath(x1, y1, x2, y2, x3, y3, x4, y4) {
  var g1 = addGuide(); 
  var g2 = addGuide(); 

  var path = svg.append('path')
    .attr('fill', 'none')
    .attr('stroke', red)
    .attr('stroke-width', 6)
  ;

  var h1 = addHandle(x1, y1, updatePath);
  var h2 = addHandle(x2, y2, updatePath);
  var h3 = addHandle(x3, y3, updatePath);
  var h4 = addHandle(x4, y4, updatePath);
  
  function updatePath() {
    path
      .attr('d',
         'M ' + h1.attr('cx') + ',' + h1.attr('cy') + ' ' +
         'C' + h2.attr('cx') + ',' + h2.attr('cy') + ' ' +
         h3.attr('cx') + ',' + h3.attr('cy') + ' ' +
         h4.attr('cx') + ',' + h4.attr('cy')
      )
    ;
    g1 
      .attr('d',
         'M ' + h1.attr('cx') + ',' + h1.attr('cy') + ' ' +
         'L' + h2.attr('cx') + ',' + h2.attr('cy')
      )
    ;
    g2 
      .attr('d',
         'M ' + h3.attr('cx') + ',' + h3.attr('cy') + ' ' +
         'L' + h4.attr('cx') + ',' + h4.attr('cy')
      )
    ;
  }

  updatePath();
}

addBezierPath(100,200, 100,100, 250,100, 250,200);
addBezierPath(100,200, 100,300, 250,300, 250,400);

addBezierPath(250,200, 250,100, 400,100, 400,200);
addBezierPath(400,200, 400,300, 250,300, 250,400);