//Change the value of the following variables to customize.
var rows = 15, //Amount of rows
    columns = 18, //Amount of columns
    topperc = 50, // Percentage the top of a block is of the total height of a block.
    selector = "div", //jQuery selector for the element the background must be applied to.
    startcolor = "#b41820", //Hex value of the color of the blocks on the top row.
    endcolor = "#e0ad66"; //Hex value of the color the blocks will change to row by row.

function colorLuminance(hex, lum) {

	hex = String(hex).replace(/[^0-9a-f]/gi, '');
	if (hex.length < 6) {
		hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
	}
	lum = lum || 0;

	var rgb = "#", c, i;
	for (i = 0; i < 3; i++) {
		c = parseInt(hex.substr(i*2,2), 16);
		c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
		rgb += ("00"+c).substr(c.length);
	}

	return rgb;
}    

function isOdd(num) { return num % 2;}

function utf8_to_b64( str ) {
    return window.btoa(unescape(encodeURIComponent( str )));
}

function makeGradientColor(color1, color2, percent) {
    var newColor = {};

    function makeChannel(a, b) {
        return(a + Math.round((b-a)*(percent/100)));
    }

    function makeColorPiece(num) {
        num = Math.min(num, 255);
        num = Math.max(num, 0);
        var str = num.toString(16);
        if (str.length < 2) {
            str = "0" + str;
        }
        return(str);
    }

    newColor.r = makeChannel(color1.r, color2.r);
    newColor.g = makeChannel(color1.g, color2.g);
    newColor.b = makeChannel(color1.b, color2.b);
    newColor.cssColor = "#" + 
                        makeColorPiece(newColor.r) + 
                        makeColorPiece(newColor.g) + 
                        makeColorPiece(newColor.b);
    return(newColor);
}

function hexToRgb(hex) {
    var shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    hex = hex.replace(shorthandRegex, function(m, r, g, b) {
        return r + r + g + g + b + b;
    });

    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

var c, a;

function setColor( r, s ){
    c = makeGradientColor( hexToRgb(startcolor), hexToRgb(endcolor), (r/rows)*100 ).cssColor;
    if(isOdd(r)){
        a = s.substring(s.lastIndexOf("row-"+r)+1,s.lastIndexOf("</g>"));
    }
    else {
        a = s.substring(s.lastIndexOf("row-"+r)+1,s.lastIndexOf("</g></g>"));
    }
    b = a.replace(/left'/g,"left' style='fill: "+c+"'").replace(/top'/g,"top' style='fill: "+colorLuminance(c,0.2)+"'").replace(/right'/g,"right' style='fill: "+colorLuminance(c,0.1)+"'");
    s = s.replace(a, b);
    return s;
}

var height = (1 + topperc / 100 ) * ( $(selector).height() / rows ),
    width = $(selector).width()/columns,
    topheight = ( height / 100 ) * topperc,
    
    svg = "<svg height='"+$(selector).height()+"' width='"+width+"' version='1.1' xmlns='http://www.w3.org/2000/svg' style='overflow: hidden;'>";

for( var i=0; i <= rows; i++ ) {
    if(i===0){
        svg += "<g class='row-"+i+"' transform='matrix(1,0,0,1,0,"+(-height+(topheight/2))+")'><g transform='matrix(1,0,0,1,"+(-width/2)+",0)'><path class='top'  d='M0,"+topheight/2+"L"+width/2+",0L"+width+","+topheight/2+"L"+width/2+","+topheight+"Z'></path><path class='left' d='M0,"+topheight/2+"L"+width/2+","+topheight+"L"+width/2+","+height+"L0,"+(height-topheight/2)+"Z'></path><path class='right' d='M"+width+","+topheight/2+"L"+width+","+(height-topheight/2)+"L"+width/2+","+height+"L"+width/2+","+topheight+"Z'></path></g><g transform='matrix(1,0,0,1,"+width/2+",0)'><path class='top'  d='M0,"+topheight/2+"L"+width/2+",0L"+width+","+topheight/2+"L"+width/2+","+topheight+"Z'></path><path class='left' d='M0,"+topheight/2+"L"+width/2+","+topheight+"L"+width/2+","+height+"L0,"+(height-topheight/2)+"Z'></path><path class='right' d='M"+width+","+topheight/2+"L"+width+","+(height-topheight/2)+"L"+width/2+","+height+"L"+width/2+","+topheight+"Z'></path></g></g>";
    }
    else if(isOdd(i)){
        svg += "<g class='row-"+i+"' transform='matrix(1,0,0,1,0,"+((i-1)*(height-topheight/2))+")'><path class='top'  d='M0,"+topheight/2+"L"+width/2+",0L"+width+","+topheight/2+"L"+width/2+","+topheight+"Z'></path><path class='left' d='M0,"+topheight/2+"L"+width/2+","+topheight+"L"+width/2+","+height+"L0,"+(height-topheight/2)+"Z'></path><path class='right' d='M"+width+","+topheight/2+"L"+width+","+(height-topheight/2)+"L"+width/2+","+height+"L"+width/2+","+topheight+"Z'></path></g>";
    }
    else{
        svg += "<g class='row-"+i+"' transform='matrix(1,0,0,1,0,"+((i-1)*(height-topheight/2))+")'><g transform='matrix(1,0,0,1,"+(-width/2)+",0)'><path class='top'  d='M0,"+topheight/2+"L"+width/2+",0L"+width+","+topheight/2+"L"+width/2+","+topheight+"Z'></path><path class='left' d='M0,"+topheight/2+"L"+width/2+","+topheight+"L"+width/2+","+height+"L0,"+(height-topheight/2)+"Z'></path><path class='right' d='M"+width+","+topheight/2+"L"+width+","+(height-topheight/2)+"L"+width/2+","+height+"L"+width/2+","+topheight+"Z'></path></g><g transform='matrix(1,0,0,1,"+width/2+",0)'><path class='top'  d='M0,"+topheight/2+"L"+width/2+",0L"+width+","+topheight/2+"L"+width/2+","+topheight+"Z'></path><path class='left' d='M0,"+topheight/2+"L"+width/2+","+topheight+"L"+width/2+","+height+"L0,"+(height-topheight/2)+"Z'></path><path class='right' d='M"+width+","+topheight/2+"L"+width+","+(height-topheight/2)+"L"+width/2+","+height+"L"+width/2+","+topheight+"Z'></path></g></g>";
    }
    svg = setColor( i, svg );
}
svg += "</svg>";

var b64 = utf8_to_b64(svg);
$(selector).attr("style","background: url(data:image/svg+xml;base64,"+b64+");");