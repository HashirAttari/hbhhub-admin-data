# Gradient cube background generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/bleepbloop/pen/nLwKXb](https://codepen.io/bleepbloop/pen/nLwKXb).

Generates svg of column of cubes. Colorizes those cubes based on side (top, left, right) and row. Converts that svg to a base64 string. Uses that string as a background.
Starting color, ending color, amount of rows, amount of columns and element can be customized. 