class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      display: '0' };

    this.changeValue = this.changeValue.bind(this);
    this.equalEval = this.equalEval.bind(this);
  }

  changeValue(event) {
    if (event.target.value === 'CE') {
      this.setState({ display: '0' });
    } else {
      this.setState({
        display: this.state.display === "0" ? event.target.value : this.state.display + event.target.value });

    }

  }

  equalEval() {
    this.setState({
      display: eval(this.state.display) });

  }

  render() {
    return /*#__PURE__*/(
      React.createElement("div", { className: "App" }, /*#__PURE__*/

      React.createElement("div", { className: "calculator" }, /*#__PURE__*/
      React.createElement("div", { className: "numinput" }, this.state.display), /*#__PURE__*/
      React.createElement("div", { className: "buttongrid" }, /*#__PURE__*/

      React.createElement("button", { value: "(", id: "leftBrackets", onClick: this.changeValue }, "("), /*#__PURE__*/
      React.createElement("button", { value: ")", id: "rightBrackets", onClick: this.changeValue }, ")"), /*#__PURE__*/
      React.createElement("button", { value: " % ", id: "percentage", onClick: this.changeValue }, "%"), /*#__PURE__*/
      React.createElement("button", { value: "CE", id: "divide", className: "commands", onClick: this.changeValue }, "CE"), /*#__PURE__*/

      React.createElement("button", { value: "7", id: "number7", onClick: this.changeValue }, "7"), /*#__PURE__*/
      React.createElement("button", { value: "8", id: "number8", onClick: this.changeValue }, "8"), /*#__PURE__*/
      React.createElement("button", { value: "9", id: "number9", onClick: this.changeValue }, "9"), /*#__PURE__*/
      React.createElement("button", { value: " / ", id: "divide", className: "operations", onClick: this.changeValue }, "\xF7"), /*#__PURE__*/

      React.createElement("button", { value: "4", id: "number4", onClick: this.changeValue }, "4"), /*#__PURE__*/
      React.createElement("button", { value: "5", id: "number5", onClick: this.changeValue }, "5"), /*#__PURE__*/
      React.createElement("button", { value: "6", id: "number6", onClick: this.changeValue }, "6"), /*#__PURE__*/
      React.createElement("button", { value: " * ", id: "mult", className: "operations", onClick: this.changeValue }, "x"), /*#__PURE__*/

      React.createElement("button", { value: "1", id: "number1", onClick: this.changeValue }, "1"), /*#__PURE__*/
      React.createElement("button", { value: "2", id: "number2", onClick: this.changeValue }, "2"), /*#__PURE__*/
      React.createElement("button", { value: "3", id: "number3", onClick: this.changeValue }, "3"), /*#__PURE__*/
      React.createElement("button", { value: " - ", id: "sub", className: "operations", onClick: this.changeValue }, "-"), /*#__PURE__*/

      React.createElement("button", { value: ".", id: "dot", onClick: this.changeValue }, "."), /*#__PURE__*/
      React.createElement("button", { value: "0", id: "number0", onClick: this.changeValue }, "0"), /*#__PURE__*/
      React.createElement("button", { value: " = ", id: "result", onClick: this.equalEval }, "="), /*#__PURE__*/
      React.createElement("button", { value: " + ", id: "sum", className: "operations", onClick: this.changeValue }, "+")))));








  }}


ReactDOM.render( /*#__PURE__*/
React.createElement(App, null),
document.getElementById('root'));