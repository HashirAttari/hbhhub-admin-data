# Naruto Shippuden - Konan

A Pen created on CodePen.io. Original URL: [https://codepen.io/tdullah/pen/xPGgad](https://codepen.io/tdullah/pen/xPGgad).

Konan (小南, Konan) was a kunoichi from Amegakure and a founding member of the original Akatsuki. After Yahiko's death, she was partnered with Nagato, who had since taken control of Akatsuki, and was the only member to call him by his name. After Nagato's death, Konan defected from the Akatsuki and became the de facto village head of Amegakure. 