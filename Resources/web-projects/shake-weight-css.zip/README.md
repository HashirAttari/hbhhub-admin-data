# Shake Weight CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/MWQeKXN](https://codepen.io/kitjenson/pen/MWQeKXN).

