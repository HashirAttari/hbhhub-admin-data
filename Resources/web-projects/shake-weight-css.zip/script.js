const sw = document.querySelector('#shake_weight')
const el = document.querySelector('.left')
const er = document.querySelector('.right')
const spl = document.querySelector('.spring_width_left')
const spr = document.querySelector('.spring_width_right')

window.addEventListener('mousemove', function(e){  
  var x = e.clientX,
      halfW = window.innerWidth*.5,
      rx = x < halfW ? -(1-(x/halfW)) : (1-(halfW/x))*2,
      spring_width_left = 1,
      spring_width_right = 1;

  sw.style.transform = 'translateX('+rx*100+'px)'
  el.style.transform = 'translateX('+rx*50+'px)'
  er.style.transform = 'translateX('+rx*50+'px) scaleX(-1)'
  
  if(x > halfW) {
    spring_width_left = 1 - rx
    spring_width_right = 1 + Math.abs(rx)
    if(spring_width_left < .5) {
      spring_width_left = .5      
    }
    if(spring_width_right > 1.25) {
      spring_width_right = 1.25
    }
  } else {
    spring_width_left = 1 + Math.abs(rx)
    spring_width_right = 1 + rx
    if(spring_width_left > 1.25) {
      spring_width_left = 1.25
    }
    if(spring_width_right < .5) {
      spring_width_right = .5
    }
  }
  
  spl.style.transform = 'scaleX('+spring_width_left+')'
  spr.style.transform = 'scaleX('+spring_width_right+')'
})