# CSS Flag

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/JjEQywZ](https://codepen.io/amit_sheen/pen/JjEQywZ).

