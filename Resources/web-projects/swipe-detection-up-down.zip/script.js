var currentY;
var initialY;
var yOffset = 0;
var yBoundary = 30;

var active = false;
var click = false;
var swiped = false;

var direction = 0;
var message = document.querySelector('.message');

document.addEventListener("touchstart", dragStart, false);
document.addEventListener("touchend", dragEnd, false);
document.addEventListener("touchmove", drag, false);

document.addEventListener("mousedown", dragStart, false);
document.addEventListener("mouseup", dragEnd, false);
document.addEventListener("mousemove", drag, false);

function dragStart(e) {
  if (e.type === "touchstart") {
    initialY = e.touches[0].clientY - yOffset;
  } else {
    initialY = e.clientY - yOffset;
  }

  active = true;
  click = true;
  swiped = false;
}

function dragEnd() {
  initialY = currentY;

  if (click == true) {
    message.innerHTML = 'Clicked';
  } else {
    message.innerHTML = 'Idle';
  }
  
  yOffset = 0;
  active = false;
}

function drag(e) {
  if (active) {
    e.preventDefault();

    if (e.type === "touchmove") {
      currentY = e.touches[0].clientY - initialY;
    } else {
      currentY = e.clientY - initialY;
    }

    yOffset = currentY;

    if (yOffset < 0) {
      direction = -1;
    }
    else {
      direction = 1;
    }
    
    if (Math.abs(yOffset) < yBoundary) {
      direction = 0;
    }
    
    if (direction == 1 && swiped == false) {
      message.innerHTML = 'Swiped down';
      swiped = true;
    } else if (direction == -1 && swiped == false) {
      message.innerHTML = 'Swiped up';
      swiped = true;
    }
    
    if (swiped == false) {
      message.innerHTML = Math.round(Math.abs((yOffset / yBoundary)) * 100) + '%';
    }
    
    click = false;
  }
}