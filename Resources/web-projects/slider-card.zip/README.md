# Slider Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/batuhanbas/pen/LYGZQeg](https://codepen.io/batuhanbas/pen/LYGZQeg).

