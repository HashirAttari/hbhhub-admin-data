# Daily UI #03 | On/Off switch | CSS only

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/eZrZvJ](https://codepen.io/havardob/pen/eZrZvJ).

Checkbox disguised as a power on/off switch. Uses the :checked psuedo class 