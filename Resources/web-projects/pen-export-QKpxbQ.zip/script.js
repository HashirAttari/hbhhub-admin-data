var clicked=false;

backdrop.add("circles","#full");
backdrop.add("fireworks",".testParent",[0,2]);
backdrop.add("fireworks",".testParent2","test1",[0,1]);
backdrop.add("fireworks",".testParent2","test2",[2,3]);
backdrop.start(20);
backdrop.canvasData("t:circles")[0].color="rgba(255,255,255,0.1)";
/*backdrop.canvasData("t:boxes")[0].minOpacity=0.1;
backdrop.canvasData("t:boxes")[0].maxOpacity=0.2;*/
backdrop.addSpecificCSS("%test1","opacity:0.7; transform:rotate(15deg)");
backdrop.addSpecificCSS("%test2","box-sizing:border-box; border:5px solid red; transform:rotate(-15deg)");
backdrop.add("fireworks",".testParent3","testing");
backdrop.canvasData("%testing")[1].colors=["#f00","#fff","#00f"];
//backdrop.remove("t:boxes",0);

function scroll(inID){
  var scTo=document.body.scrollTop+document.getElementById(inID).getBoundingClientRect().top;
  window.scrollTo(0,scTo+10);
}

window.onscroll=function(){
  scrollAction();
}

function scrollAction(){
  var scrollers=["intro","basic","advanced","objects","credits","end"];
  var index=0;
  for (var i=0;i<scrollers.length;i++){
    if (i<scrollers.length-1){document.getElementsByClassName("footerbutton")[i].style="";}
    if (document.getElementById(scrollers[i]).getBoundingClientRect().top>0){
      index=i-1;
      break;
    }
  }
  if (index>=0){
    if (index>=4){index=4;}
    document.getElementsByClassName("footerbutton")[index].style="background-color:#85a; color:#305";
  }
}

function test(){
  clicked=!clicked;
  if (clicked){
    backdrop.multiData("circles",{ 
      color: "rgba(0,0,255,0.1)", 
      circleNo: 200 
    });
    document.getElementById("testBtn").innerHTML="TEST! (white,100)";
  }else{
    backdrop.multiData("circles",{ 
      color: "rgba(255,255,255,0.1)", 
      circleNo: 100 
    });
    document.getElementById("testBtn").innerHTML="TEST! (blue,200)";
  }
}

window.onresize=function(){
  backdrop.resize();
}