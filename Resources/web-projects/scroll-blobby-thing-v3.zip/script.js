const cursor = document.querySelector(".cursor");

document.addEventListener("mousemove", (e) => {
  let x = e.offsetX;
  let y = e.offsetY - window.scrollY;

  cursor.style.setProperty("--x", x + "px");
  cursor.style.setProperty("--y", y + "px");
});
// let x = 500;
// let y = 500;

//   cursor.style.setProperty("--x", x + "px");
//   cursor.style.setProperty("--y", y + "px");