# SCROLL blobby thing v3

A Pen created on CodePen.io. Original URL: [https://codepen.io/badly_written_stylesheet/pen/wvOPeGZ](https://codepen.io/badly_written_stylesheet/pen/wvOPeGZ).

