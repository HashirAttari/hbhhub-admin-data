# Neon Bubbles in CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/ZOYzLa](https://codepen.io/giana/pen/ZOYzLa).

No click events, just the initial animation.

Buggy and might require a few refreshes.