# Interactive keyboard animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/stivaliserna/pen/ZEbKrEe](https://codepen.io/stivaliserna/pen/ZEbKrEe).

