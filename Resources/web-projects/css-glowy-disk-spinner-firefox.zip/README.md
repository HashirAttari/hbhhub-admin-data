# CSS glowy disk spinner (Firefox)

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/JYgXLJ](https://codepen.io/giana/pen/JYgXLJ).

Edit: <a href="http://codepen.io/giana/details/NGQjMV/">Chrome compatible version</a> (not exact).  

Broken in Chrome. Animating the transform property screws up blend mode. Enabling slimming paint and slimming paint phase 2 in flags fixes it.

Displays correctly in Firefox and Safari. Correct rendering:  
<img src="http://i.imgur.com/EkxekzV.gif">