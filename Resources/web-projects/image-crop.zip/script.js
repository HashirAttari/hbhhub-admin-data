function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);} // This is a basic example of an image cropping tool. 
// Click on the little circles or the box borders to 
// resize the cropping tool. 
// 
// This pen was developed with Webrix.js - A set of powerful 
// building blocks for React-based applications. For more 
// information, visit https://webrix.amdocs.com/

import React, { useCallback, useState, useEffect, useRef, useMemo } from 'https://cdn.skypack.dev/react@17.0.2';
import ReactDOM from 'https://cdn.skypack.dev/react-dom@17.0.2';
import PropTypes from 'https://cdn.skypack.dev/prop-types@15.7.2';
import { Resizable, Movable } from 'https://cdn.skypack.dev/webrix@1.4.0/components';

const mo = Movable.Operations;
const ro = Resizable.Operations;

const Grid = () => /*#__PURE__*/
React.createElement("div", { className: "grid" },
[...new Array(4)].map((_, i) => /*#__PURE__*/
React.createElement("div", { key: i, className: "grid-line" })));




const Circles = () => /*#__PURE__*/
React.createElement("div", { className: "circles" },
[...new Array(8)].map((_, i) => /*#__PURE__*/
React.createElement("div", { key: i, className: "circle" })));




const Crop = ({ image }) => {
  const [position, setPosition] = useState({});
  const crop = useRef();
  const movable = useRef();
  const mProps = Movable.useMove(useMemo(() => [
  mo.move(movable),
  mo.contain(movable, image),
  mo.update(({ top, left }) => setPosition(p => ({ ...p, top, left })))],
  [setPosition, image]));
  const rProps = Resizable.useResize(useMemo(() => [
  ro.resize(crop),
  ro.contain(image),
  ro.min(50, 50),
  ro.lock(),
  ro.update(setPosition)],
  [image]));
  useEffect(() => {
    // Set the crop to the image size initially
    const { width, height, top, left } = image.current.getBoundingClientRect();
    setPosition({ width, height, top, left });
  }, [image]);

  return /*#__PURE__*/(
    React.createElement("div", { className: "crop", style: position, ref: crop }, /*#__PURE__*/
    React.createElement(Movable, _extends({}, mProps, { className: "handler", ref: movable })), /*#__PURE__*/
    React.createElement(Resizable, rProps, /*#__PURE__*/
    React.createElement(Resizable.Resizer.All, null)), /*#__PURE__*/

    React.createElement(Circles, null), /*#__PURE__*/
    React.createElement(Grid, null)));


};

const App = () => {
  const ref = useRef();
  return /*#__PURE__*/(
    React.createElement("div", { className: "image-crop", ref: ref }, /*#__PURE__*/
    React.createElement(Crop, { image: ref }), /*#__PURE__*/
    React.createElement("div", { className: "image" }), /*#__PURE__*/
    React.createElement("div", { className: "attribution" }, "Image courtesy of ", /*#__PURE__*/
    React.createElement("a", { target: "_blank", rel: "noreferrer", href: "https://pixabay.com/users/pexels-2286921/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1850116" }, "Pexels"), " from ", /*#__PURE__*/React.createElement("a", { target: "_blank", rel: "noreferrer", href: "https://pixabay.com/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1850116" }, "Pixabay"))));



};

ReactDOM.render( /*#__PURE__*/
React.createElement(App, null),
document.body);