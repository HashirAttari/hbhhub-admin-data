var snowmax = 25;
var snowcolor = ["rgb(220,220,220)", "rgb(210,210,250)"];
var snowletter = ["."];
var sinkspeed = 2.5;
var snowmaxsize = 40;
var snowminsize = 30;
var snow = [];
var marginbottom = window.innerHeight;
var marginright = window.innerWidth;
var x_mv = [];
var crds = [];
var lftrght = [];

document.body.onresize = function() {
	marginbottom = window.innerHeight;
	marginright = window.innerWidth;
}

function randommaker(range) {
	rand = Math.floor(range * Math.random());
	return rand;
}
window.onload = function() {
	var snowsizerange = snowmaxsize - snowminsize;
	for (var i = 0; i <= snowmax; i++) {
		crds[i] = 0;
		lftrght[i] = Math.random() * 15;
		x_mv[i] = 0.03 + Math.random() / 10;
		var flake = document.createElement('span');
		flake.size = randommaker(snowsizerange) + snowminsize;
		flake.sink = sinkspeed;
		flake.style.position = 'fixed';
		flake.style.fontSize = flake.size + 'px';
		flake.style.color = snowcolor[randommaker(snowcolor.length)];
		flake.innerHTML = snowletter[randommaker(snowletter.length)];
		flake.posx = randommaker(marginright - flake.size);
		flake.posy = randommaker(marginbottom - 2 * flake.size);
		flake.style.left = flake.posx + 'px';
		flake.style.top = flake.posy + 'px';
		flake.id = 's' + i;
		flake.className = 'flake';
		snow[i] = flake;
		document.body.appendChild(flake);
	}
	movesnow();
};

function movesnow() {
	for (var i = 0; i <= snowmax; i++) {
		crds[i] += x_mv[i];
		snow[i].posy += snow[i].sink;
		var posx = snow[i].posx + lftrght[i] * Math.sin(crds[i]);
		var posy = snow[i].posy;
		snow[i].style.left = posx + 'px';
		snow[i].style.top = posy + 'px';
		if (snow[i].posy >= marginbottom - 2 * snow[i].size || parseInt(snow[i].style.left) > (marginright - 3 * lftrght[i])) {
			snow[i].posx = randommaker(marginright - snow[i].size);
			snow[i].posy = 0;
		}
	}
	setTimeout(movesnow, 50);
}