# Toggle Toothed (I)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/bGJeGGw](https://codepen.io/alvaromontoro/pen/bGJeGGw).

inspired by Josetxu's https://codepen.io/josetxu/pen/NWEPmGz