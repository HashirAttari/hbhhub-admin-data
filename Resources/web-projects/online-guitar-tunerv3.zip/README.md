# Online Guitar Tuner - v3 

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/jOQegyB](https://codepen.io/josetxu/pen/jOQegyB).

A new guitar tuner with a couple of new features and a new CSS-only design. Javascript is also used, though only to play the sounds and add or remove classes to different elements when a guitar string or some other button is pressed.

The first new feature is being able to choose between two types of guitar (electric or classical) with their different sounds for the strings. The second new feature is a volume control to separate between the audio from the guitar tuner and the general audio from your device.

I've also made some improvements to the Javascript code, although not as many as I would have liked, maybe in the next version. But I'm very happy with how the CSS design has turned out and I don't rule out making some changes that keep occurring to me.

I hope it will be of help to you!


<hr>


Un nuevo afinador de guitarra con un par de características nuevas y un nuevo diseño creado solo con CSS. También se usa Javascript, aunque solo para reproducir los sonidos y añadir o quitar clases a diferentes elementos cuando se pulsa una cuerda de la guitarra o algún otro botón.

La primera característica nueva es poder elegir entre dos tipos de guitarra (eléctrica o clásica) con sus diferentes sonidos para las cuerdas. La segunda característica nueva es un control de volumen para separar entre el audio del afinador de guitarra y el audio general de tu dispositivo.

También he hecho algunas mejoras al código Javascript, aunque no tantas como me hubiera gustado, quizá en la próxima versión. Pero estoy muy contento de como ha quedado el diseño en CSS y no descarto hacer algunos cambios que se me siguen ocurriendo.

Espero que te sea de ayuda!


Ver artículo en el <a href="https://josetxu.com/afinador-de-guitarra-online-guitar-tuner-v3/">Blog</a>. 