/* external resources *only* for displaying the info boxes */

/* this below is all the JS needed for the demo itself to work */
document.documentElement.classList.add('js');

addEventListener('input', e => {
	const _t = e.target;
	
	_t.parentNode.style.setProperty('--val', +_t.value)
})