# Styled  native range input #44 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/vERyRy](https://codepen.io/thebabydino/pen/vERyRy).

**June 2021 update**

Major changes:

* got rid of Compass and Modernizr dependencies, neither of which was needed anyway anymore

* got rid of the convoluted JS that was updating the tooltip

* ditched the 1 element restriction to make it functional again (the hacky `/deep/` technique from early 2015 had stopped working within the same year, so I've now eliminated all that completely useless code) and accessible - the slider value tooltip is now an `output` element tied to the range input

* made it degrade gracefully in the no JS case (there's just no  tooltip)

* ditched `absolute` positioning in favour of using a `grid` layout now

* made it responsive in a simple manner

* cleaned up, compacted the CSS and made it more maintainable by using CSS variables and the DRY switching technique, explained in this two part article I wrote for CSS-Tricks: [part one](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) and [part two](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/)

* made the whole thing greyscaled if not hovered and no focus on the slider

* ensured it now behaves consistently in both WebKit browsers and Firefox

* not providing IE/ pre-Chromium support anymore

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. CSS-only for Firefox and IE. Chrome/ Opera have a bit of an extra, the tooltip above the thumb which is updated using JS. The tooltip is created using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). IE also has a tooltip, but that only shows the value rounded to the nearest integer and I cannot style it. Fallback for no JS: don't display a tooltip for Chrome/ Opera. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/7lVlUxz.jpg) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 