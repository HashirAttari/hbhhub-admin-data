# Chat Bar Interaction

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/xBPYPo](https://codepen.io/aaroniker/pen/xBPYPo).

From https://dribbble.com/shots/6155986-Chat-Bar-Interaction