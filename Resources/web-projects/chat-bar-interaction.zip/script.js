$('.chatbar .control > a').on('click touch', function(e) {

    e.preventDefault();

    let parent = $(this).parent().parent();

    if(parent.hasClass('active')) {
        parent.addClass('default');
        setTimeout(() => {
            parent.removeClass('active default');
        }, 1000);
    } else {
        parent.addClass('active');
    }

});