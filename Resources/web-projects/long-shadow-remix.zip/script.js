var depth = document.getElementById('Depth')
var spread = document.getElementById('Spread')
var opacity = document.getElementById('Opacity')
var inputs = document.querySelectorAll('input')

function createShadow() {
  let text = document.querySelector('p');
  let shadow = '';
  let shadow_depth = depth.value 
  let layer_spread = spread.value 
  let layer_opacity = opacity.value 
  let x = Math.random() < .5 ? -1 : 1;
  let y = Math.random() < .5 ? -1 : 1;  
  let color = 'hsla('+Math.random()*360+'deg,75%,50%,'+layer_opacity+')'

  for(let i = 0; i < shadow_depth; i++) {
    shadow += (shadow ? ',' : '') + (i*x*layer_spread) + 'px ' + (i*y*layer_spread) + 'px 0 '+color+'';
  }
  text.style.textShadow = shadow;
}
createShadow()
setInterval(createShadow, 500)

inputs.forEach(function(elm){
  elm.addEventListener('input', function(){
    elm.nextElementSibling.innerHTML = elm.id + ' ('+elm.value+')'
  })
})