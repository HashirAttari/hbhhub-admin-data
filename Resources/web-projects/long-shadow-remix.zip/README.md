# Long Shadow Remix

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/OJRvKGv](https://codepen.io/kitjenson/pen/OJRvKGv).

Special thanks to
Long Shadow Text by Batuhan Baş
https://codepen.io/batuhanbas/pen/dypdxvp