# Inclusive toggles using <button> and the aria-checked attribute

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/WNwGmNJ](https://codepen.io/havardob/pen/WNwGmNJ).

Toggles that are inclusive and accessible using the aria-checked attribute.