# Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/WwNJbM](https://codepen.io/giana/pen/WwNJbM).

This takes forever to render - a 360 loop in both Jade and Sass.