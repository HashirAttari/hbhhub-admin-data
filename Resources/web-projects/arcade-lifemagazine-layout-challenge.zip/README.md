# Arcade Life - Magazine Layout Challenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/KKmPvBq](https://codepen.io/havardob/pen/KKmPvBq).

My contribution to this weeks CodePen challenge, inspired by the Vaporwave trend and old OS UI. 