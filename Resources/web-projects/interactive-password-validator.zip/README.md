# Interactive Password Validator

A Pen created on CodePen.io. Original URL: [https://codepen.io/erenesto/pen/YzyYgvJ](https://codepen.io/erenesto/pen/YzyYgvJ).

