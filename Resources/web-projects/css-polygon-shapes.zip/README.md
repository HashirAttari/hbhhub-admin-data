# CSS Polygon Shapes

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/QWGWXPz](https://codepen.io/yuanchuan/pen/QWGWXPz).

