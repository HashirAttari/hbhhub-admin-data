var bd = document.body;
var suns = document.getElementById("suns")
var mountain = document.getElementById("mountain")

function getSuns(event) {
    var w = window.innerWidth / 2;
    var x = event.clientX;
    if (x > w + 100) {
        suns.style.transform = "translateX(4px)";
        mountain.style.transform = "rotateZ(45deg) translateX(-5px) translateY(5px)";
    }
    if (x > w - 100 && x < w + 100) {
        suns.style.transform = "translateX(0px)";
        mountain.style.transform = "rotateZ(45deg) translateX(0px) translateY(0px)";
    }
    if (x < w - 100) {
        suns.style.transform = "translateX(-4px)";
        mountain.style.transform = "rotateZ(45deg) translateX(5px) translateY(-5px)";
    }
}
bd.addEventListener("mousemove", getSuns);