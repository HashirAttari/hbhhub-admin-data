/*
Designed by: Gigantic
Link: https://dribbble.com/shots/7049062-Monkeys-Illustration-Flat-Design-Animals
*/