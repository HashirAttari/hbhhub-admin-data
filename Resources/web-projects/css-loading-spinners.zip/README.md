# CSS Loading Spinners

A Pen created on CodePen.io. Original URL: [https://codepen.io/r34h87fh/pen/JjQbjK](https://codepen.io/r34h87fh/pen/JjQbjK).

A collection of spinners using CSS, keyframes and basic animation. No JS.