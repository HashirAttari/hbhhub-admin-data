const closeBtn = document.querySelector("#btn-close");
const wrapperEl = document.querySelector("#wrapper");
const titleEl = document.querySelector("#title");
const subtitleEl = document.querySelector("#subtitle");
const button1El = document.querySelector("#button-1");
const button2El = document.querySelector("#button-2");
const button3El = document.querySelector("#button-3");
const themeToggleEl = document.querySelector("#theme-toggle");
const maskPositionBt = document.querySelector("#btn-mask");

// close the box with some transitions
closeBtn.addEventListener("click", () => {

    button1El.classList.add("-translate-x-96");
    button2El.classList.add("translate-y-[600px]");
    button3El.classList.add("translate-x-96");
    setTimeout(() =>{
        titleEl.classList.add("scale-0");
        subtitleEl.classList.add("scale-0");
    }, 500);
    setTimeout(() => {
        themeToggleEl.classList.add("-translate-x-56");
        closeBtn.classList.add("translate-x-56");
        maskPositionBt.classList.add("-translate-y-56");
    }, 1000);

    setTimeout(() => {
        wrapperEl.classList.add("scale-0")
    }, 1500);

    setTimeout(() => {
        wrapperEl.classList.remove("scale-0")
        setTimeout(() => {
            themeToggleEl.classList.remove("-translate-x-56");
            closeBtn.classList.remove("translate-x-56");
            maskPositionBt.classList.remove("-translate-y-56");
        }, 500);

        setTimeout(() => {
            titleEl.classList.remove("scale-0");
            subtitleEl.classList.remove("scale-0");
        }, 1000);
        
        setTimeout(() => {
            button1El.classList.remove("-translate-x-96");
            button2El.classList.remove("translate-y-[600px]");
            button3El.classList.remove("translate-x-96");
        }, 1500);
    }, 3500);
})


// just for fun I wanted the theme mask element to have a random position, however I didn't want it to be completly behind the main contents - I enlisted the help of ChatGPT to work this out for me.
function randomPositionMask(){
    const bgMask = document.querySelector("#bg-mask");

    const wrapperRect = wrapperEl.getBoundingClientRect();
    const minX = wrapperRect.left + 100;
    const maxX = wrapperRect.right - 100;
    const minY = wrapperRect.top + 100;
    const maxY = wrapperRect.bottom - 100;

    // Set a random position within the viewport, avoiding the wrapperEl boundaries
    do {
        bgMask.style.left = Math.floor(Math.random() * window.innerWidth) + "px";
        bgMask.style.top = Math.floor(Math.random() * window.innerHeight) + "px";
    } while (
        parseInt(bgMask.style.left) > minX &&
        parseInt(bgMask.style.left) < maxX &&
        parseInt(bgMask.style.top) > minY &&
        parseInt(bgMask.style.top) < maxY
    );
}
// use timeout to ensure that the main container has finished resizing with the intro animations
//setTimeout(() => randomPositionMask(), 1000)

maskPositionBt.addEventListener("click", () => randomPositionMask())

randomPositionMask()