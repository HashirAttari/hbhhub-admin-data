# Tailwind - Theme Toggle - random starting point

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/xxeWRrV](https://codepen.io/cbolson/pen/xxeWRrV).

This is forked from my iCodeThis submission here:
https://icodethis.com/modes/design-to-code/161/submissions/286377