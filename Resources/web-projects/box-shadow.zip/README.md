# Box-shadow

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/oQyXRq](https://codepen.io/yuanchuan/pen/oQyXRq).

CSS Challenge: https://twitter.com/yuanchuan23/status/1066555792122241024