# <sup> & <sub>: Math Sums & Products

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/qYvRKO](https://codepen.io/leenalavanya/pen/qYvRKO).

I cannot believe this was a first-year 4-mark-worth degree question.