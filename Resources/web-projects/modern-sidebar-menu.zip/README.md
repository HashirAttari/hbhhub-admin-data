# Modern Sidebar Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/FlorinCornea/pen/YzGeprR](https://codepen.io/FlorinCornea/pen/YzGeprR).

