# Custom Cursor Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/yZjXaY](https://codepen.io/markmead/pen/yZjXaY).

