# Brick Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/qBoKKxr](https://codepen.io/benhatsor/pen/qBoKKxr).

