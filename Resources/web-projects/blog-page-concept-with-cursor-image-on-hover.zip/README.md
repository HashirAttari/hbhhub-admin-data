# Blog page concept with cursor image on hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/OrLBqO](https://codepen.io/ig_design/pen/OrLBqO).

