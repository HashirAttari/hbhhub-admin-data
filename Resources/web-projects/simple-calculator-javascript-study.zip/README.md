# 🐲 Simple Calculator | JavaScript Study

A Pen created on CodePen.io. Original URL: [https://codepen.io/artcoholic/pen/mxXJdx](https://codepen.io/artcoholic/pen/mxXJdx).

Functional javascript calculator based on the MacOS calculator.