const phoneOptions = document.querySelector(".phone-options");
const barIcon = document.querySelector(".bar-icon");
const closeIcon = document.querySelector(".close-icon");

const toggleOptions = () => {
  closeIcon.classList.toggle("show-close-icon");
  closeIcon.classList.toggle("hide-close-icon");
  barIcon.classList.toggle("show-bar-icon");
  barIcon.classList.toggle("hide-bar-icon");
  phoneOptions.classList.toggle("show-options");
  phoneOptions.classList.toggle("hide-options");
};