# Pure CSS Text animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/kh-mamun/pen/NdwZdW](https://codepen.io/kh-mamun/pen/NdwZdW).

Text animation with pure css using @keyframes rules