# Three Dots - CSS loading animations made with single element

A Pen created on CodePen.io. Original URL: [https://codepen.io/nzbin/pen/GGrXbp](https://codepen.io/nzbin/pen/GGrXbp).

A set of CSS loading animations created with three dots which made by just single element.
https://github.com/nzbin/three-dots