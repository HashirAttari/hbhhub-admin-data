# TypeWave 

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/xxRrKOL](https://codepen.io/chrisgannon/pen/xxRrKOL).

A looping animated typographic SVG pattern.