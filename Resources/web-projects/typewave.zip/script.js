gsap.set('#radialDotPattern path', {
	transformOrigin: '50% 50%'
})

gsap.to('#radialDotPattern path', {
	scale: 0.3,
	y: -5,
	ease: 'sine.in',
	duration: 0.73,
	stagger: {
		each: 0.34,
		grid: 'auto',
		from: 'end',
		repeat: -1,
		yoyoEase: 'sine'
	}
}).seek(1000)