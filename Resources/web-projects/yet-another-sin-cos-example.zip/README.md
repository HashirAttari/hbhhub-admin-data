# Yet another sin / cos example

A Pen created on CodePen.io. Original URL: [https://codepen.io/sfi0zy/pen/qBGrZxx](https://codepen.io/sfi0zy/pen/qBGrZxx).

https://qna.habr.com/q/1354638