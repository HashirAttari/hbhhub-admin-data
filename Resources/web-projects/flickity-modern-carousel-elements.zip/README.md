# Flickity Modern Carousel [ELEMENTS]

A Pen created on CodePen.io. Original URL: [https://codepen.io/RaduBratan/pen/GRoryXm](https://codepen.io/RaduBratan/pen/GRoryXm).

