# Toggle Colorful

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/VwRJXBY](https://codepen.io/alvaromontoro/pen/VwRJXBY).

Toggle switch inspired by Nick Buturishvili's Switch on Dribbble: https://dribbble.com/shots/2272690-Switch