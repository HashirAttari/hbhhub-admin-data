# Analog Clock with html, css & js

A Pen created on CodePen.io. Original URL: [https://codepen.io/ky0suke/pen/MyNXWX](https://codepen.io/ky0suke/pen/MyNXWX).

A pretty clock made with html, css and some javascript to get the time and update the clock.

Inspired by Zhu Sheng's work on dribble, check his work :
https://dribbble.com/shots/2720228-Clock-App