# Pendulum Animation (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/kh-mamun/pen/PWgzJe](https://codepen.io/kh-mamun/pen/PWgzJe).

This is a fancy stuff that may not be used in real life website. It's just I got an idea if a pendulum animation can be created with pure CSS. Hence I ended up with this snippet.