/*
Here's another Multiple pendulum wave animation

https://codepen.io/kh-mamun/pen/xWmrJN
*/