# A re-creation of @CodeMeNatalie's work with css-doodle.

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/LYEYjLo](https://codepen.io/yuanchuan/pen/LYEYjLo).

