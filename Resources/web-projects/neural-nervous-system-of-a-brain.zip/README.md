# Neural nervous system of a brain

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/vYGXJxQ](https://codepen.io/agalliat/pen/vYGXJxQ).

