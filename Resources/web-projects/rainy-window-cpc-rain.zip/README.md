# Rainy window (CPC Rain)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/xxzoVaK](https://codepen.io/amit_sheen/pen/xxzoVaK).

