// minimuim color distance allowed
var allowedDiff = 0;

// returns true if two hex colors are similar
const isSimilar = (c1, c2) => {
  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result
      ? {
          r: parseInt(result[1], 16),
          g: parseInt(result[2], 16),
          b: parseInt(result[3], 16)
        }
      : null;
  };

  const color1 = hexToRgb(c1);
  const color2 = hexToRgb(c2);

  const distR = Math.abs(color1.r - color2.r);
  const distG = Math.abs(color1.g - color2.g);
  const distB = Math.abs(color1.b - color2.b);

  const totalDiff = distR + distG + distB;

  //if (totalDiff === 0) {
  // exactly the same is not similar
  //return false;
  //} else {
  return totalDiff < allowedDiff;
  //}
};

// 256 terminal colors from 0 - 255
const orderedTerminalColors = [
  "#000000",
  "#800000",
  "#008000",
  "#808000",
  "#000080",
  "#800080",
  "#008080",
  "#c0c0c0",
  "#808080",
  "#ff0000",
  "#00ff00",
  "#ffff00",
  "#0000ff",
  "#ff00ff",
  "#00ffff",
  "#ffffff",
  "#000000",
  "#00005f",
  "#000087",
  "#0000af",
  "#0000d7",
  "#0000ff",
  "#005f00",
  "#005f5f",
  "#005f87",
  "#005faf",
  "#005fd7",
  "#005fff",
  "#008700",
  "#00875f",
  "#008787",
  "#0087af",
  "#0087d7",
  "#0087ff",
  "#00af00",
  "#00af5f",
  "#00af87",
  "#00afaf",
  "#00afd7",
  "#00afff",
  "#00d700",
  "#00d75f",
  "#00d787",
  "#00d7af",
  "#00d7d7",
  "#00d7ff",
  "#00ff00",
  "#00ff5f",
  "#00ff87",
  "#00ffaf",
  "#00ffd7",
  "#00ffff",
  "#5f0000",
  "#5f005f",
  "#5f0087",
  "#5f00af",
  "#5f00d7",
  "#5f00ff",
  "#5f5f00",
  "#5f5f5f",
  "#5f5f87",
  "#5f5faf",
  "#5f5fd7",
  "#5f5fff",
  "#5f8700",
  "#5f875f",
  "#5f8787",
  "#5f87af",
  "#5f87d7",
  "#5f87ff",
  "#5faf00",
  "#5faf5f",
  "#5faf87",
  "#5fafaf",
  "#5fafd7",
  "#5fafff",
  "#5fd700",
  "#5fd75f",
  "#5fd787",
  "#5fd7af",
  "#5fd7d7",
  "#5fd7ff",
  "#5fff00",
  "#5fff5f",
  "#5fff87",
  "#5fffaf",
  "#5fffd7",
  "#5fffff",
  "#870000",
  "#87005f",
  "#870087",
  "#8700af",
  "#8700d7",
  "#8700ff",
  "#875f00",
  "#875f5f",
  "#875f87",
  "#875faf",
  "#875fd7",
  "#875fff",
  "#878700",
  "#87875f",
  "#878787",
  "#8787af",
  "#8787d7",
  "#8787ff",
  "#87af00",
  "#87af5f",
  "#87af87",
  "#87afaf",
  "#87afd7",
  "#87afff",
  "#87d700",
  "#87d75f",
  "#87d787",
  "#87d7af",
  "#87d7d7",
  "#87d7ff",
  "#87ff00",
  "#87ff5f",
  "#87ff87",
  "#87ffaf",
  "#87ffd7",
  "#87ffff",
  "#af0000",
  "#af005f",
  "#af0087",
  "#af00af",
  "#af00d7",
  "#af00ff",
  "#af5f00",
  "#af5f5f",
  "#af5f87",
  "#af5faf",
  "#af5fd7",
  "#af5fff",
  "#af8700",
  "#af875f",
  "#af8787",
  "#af87af",
  "#af87d7",
  "#af87ff",
  "#afaf00",
  "#afaf5f",
  "#afaf87",
  "#afafaf",
  "#afafd7",
  "#afafff",
  "#afd700",
  "#afd75f",
  "#afd787",
  "#afd7af",
  "#afd7d7",
  "#afd7ff",
  "#afff00",
  "#afff5f",
  "#afff87",
  "#afffaf",
  "#afffd7",
  "#afffff",
  "#d70000",
  "#d7005f",
  "#d70087",
  "#d700af",
  "#d700d7",
  "#d700ff",
  "#d75f00",
  "#d75f5f",
  "#d75f87",
  "#d75faf",
  "#d75fd7",
  "#d75fff",
  "#d78700",
  "#d7875f",
  "#d78787",
  "#d787af",
  "#d787d7",
  "#d787ff",
  "#d7af00",
  "#d7af5f",
  "#d7af87",
  "#d7afaf",
  "#d7afd7",
  "#d7afff",
  "#d7d700",
  "#d7d75f",
  "#d7d787",
  "#d7d7af",
  "#d7d7d7",
  "#d7d7ff",
  "#d7ff00",
  "#d7ff5f",
  "#d7ff87",
  "#d7ffaf",
  "#d7ffd7",
  "#d7ffff",
  "#ff0000",
  "#ff005f",
  "#ff0087",
  "#ff00af",
  "#ff00d7",
  "#ff00ff",
  "#ff5f00",
  "#ff5f5f",
  "#ff5f87",
  "#ff5faf",
  "#ff5fd7",
  "#ff5fff",
  "#ff8700",
  "#ff875f",
  "#ff8787",
  "#ff87af",
  "#ff87d7",
  "#ff87ff",
  "#ffaf00",
  "#ffaf5f",
  "#ffaf87",
  "#ffafaf",
  "#ffafd7",
  "#ffafff",
  "#ffd700",
  "#ffd75f",
  "#ffd787",
  "#ffd7af",
  "#ffd7d7",
  "#ffd7ff",
  "#ffff00",
  "#ffff5f",
  "#ffff87",
  "#ffffaf",
  "#ffffd7",
  "#ffffff",
  "#080808",
  "#121212",
  "#1c1c1c",
  "#262626",
  "#303030",
  "#3a3a3a",
  "#444444",
  "#4e4e4e",
  "#585858",
  "#626262",
  "#6c6c6c",
  "#767676",
  "#808080",
  "#8a8a8a",
  "#949494",
  "#9e9e9e",
  "#a8a8a8",
  "#b2b2b2",
  "#bcbcbc",
  "#c6c6c6",
  "#d0d0d0",
  "#dadada",
  "#e4e4e4",
  "#eeeeee"
];

// terminal colors sorted in rainbow order
const sortedTerminalColors = [
  "#5f0000",
  "#800000",
  "#870000",
  "#af0000",
  "#d70000",
  "#ff0000",
  "#ff0000",
  "#d75f5f",
  "#d75f87",
  "#d7875f",
  "#ff5f5f",
  "#ff5f87",
  "#ff875f",
  "#d78787",
  "#d787af",
  "#d7af87",
  "#ff8787",
  "#ff87af",
  "#ffaf87",
  "#ffafaf",
  "#ffd7d7",
  "#875f00",
  "#af5f00",
  "#d75f00",
  "#d78700",
  "#ff5f00",
  "#ff8700",
  "#ffaf00",
  "#d7af5f",
  "#d7d75f",
  "#ffaf5f",
  "#ffd75f",
  "#d7d787",
  "#ffd787",
  "#ffd7af",
  "#5f5f00",
  "#808000",
  "#878700",
  "#87af00",
  "#af8700",
  "#afaf00",
  "#afd700",
  "#d7af00",
  "#d7d700",
  "#ffff00",
  "#d7ff00",
  "#ffd700",
  "#ffff00",
  "#ffff5f",
  "#ffff87",
  "#ffffaf",
  "#ffffd7",
  "#5f8700",
  "#5faf00",
  "#5fd700",
  "#87d700",
  "#5fff00",
  "#87ff00",
  "#afff00",
  "#afd75f",
  "#afff5f",
  "#d7ff5f",
  "#d7ff87",
  "#d7ffaf",
  "#005f00",
  "#008000",
  "#008700",
  "#00af00",
  "#00d700",
  "#00ff00",
  "#00ff00",
  "#5fd75f",
  "#5fd787",
  "#87d75f",
  "#5fff5f",
  "#5fff87",
  "#87ff5f",
  "#87d787",
  "#87d7af",
  "#afd787",
  "#87ff87",
  "#87ffaf",
  "#afff87",
  "#afffaf",
  "#d7ffd7",
  "#00875f",
  "#00af5f",
  "#00d75f",
  "#00d787",
  "#00ff5f",
  "#00ff87",
  "#00ffaf",
  "#5fd7af",
  "#5fd7d7",
  "#5fffaf",
  "#5fffd7",
  "#87d7d7",
  "#87ffd7",
  "#afffd7",
  "#005f5f",
  "#008080",
  "#008787",
  "#0087af",
  "#00af87",
  "#00afaf",
  "#00afd7",
  "#00d7af",
  "#00d7d7",
  "#00ffff",
  "#00d7ff",
  "#00ffd7",
  "#00ffff",
  "#5fffff",
  "#87ffff",
  "#afffff",
  "#d7ffff",
  "#005f87",
  "#005faf",
  "#005fd7",
  "#0087d7",
  "#005fff",
  "#0087ff",
  "#00afff",
  "#5fafd7",
  "#5fafff",
  "#5fd7ff",
  "#87d7ff",
  "#afd7ff",
  "#00005f",
  "#000080",
  "#000087",
  "#0000af",
  "#0000d7",
  "#0000ff",
  "#0000ff",
  "#5f5fd7",
  "#5f87d7",
  "#875fd7",
  "#5f5fff",
  "#5f87ff",
  "#875fff",
  "#8787d7",
  "#87afd7",
  "#af87d7",
  "#8787ff",
  "#87afff",
  "#af87ff",
  "#afafff",
  "#d7d7ff",
  "#5f0087",
  "#5f00af",
  "#5f00d7",
  "#8700d7",
  "#5f00ff",
  "#8700ff",
  "#af00ff",
  "#af5fd7",
  "#d75fd7",
  "#af5fff",
  "#d75fff",
  "#d787d7",
  "#d787ff",
  "#d7afff",
  "#5f005f",
  "#800080",
  "#870087",
  "#8700af",
  "#af0087",
  "#af00af",
  "#af00d7",
  "#d700af",
  "#d700d7",
  "#ff00ff",
  "#d700ff",
  "#ff00d7",
  "#ff00ff",
  "#ff5fff",
  "#ff87ff",
  "#ffafff",
  "#ffd7ff",
  "#87005f",
  "#af005f",
  "#d7005f",
  "#d70087",
  "#ff005f",
  "#ff0087",
  "#ff00af",
  "#d75faf",
  "#ff5faf",
  "#ff5fd7",
  "#ff87d7",
  "#ffafd7",
  "#000000",
  "#000000",
  "#080808",
  "#121212",
  "#1c1c1c",
  "#262626",
  "#303030",
  "#3a3a3a",
  "#444444",
  "#4e4e4e",
  "#5f5f5f",
  "#585858",
  "#626262",
  "#6c6c6c",
  "#5f5f87",
  "#5f875f",
  "#875f5f",
  "#808080",
  "#878787",
  "#767676",
  "#808080",
  "#8a8a8a",
  "#5f8787",
  "#875f87",
  "#87875f",
  "#5f5faf",
  "#5f87af",
  "#5faf5f",
  "#5faf87",
  "#875faf",
  "#87af5f",
  "#af5f5f",
  "#af5f87",
  "#af875f",
  "#afafaf",
  "#949494",
  "#9e9e9e",
  "#a8a8a8",
  "#8787af",
  "#87af87",
  "#87afaf",
  "#af8787",
  "#af87af",
  "#afaf87",
  "#5fafaf",
  "#af5faf",
  "#afaf5f",
  "#c0c0c0",
  "#b2b2b2",
  "#bcbcbc",
  "#c6c6c6",
  "#d0d0d0",
  "#afafd7",
  "#afd7af",
  "#afd7d7",
  "#d7afaf",
  "#d7afd7",
  "#d7d7af",
  "#d7d7d7",
  "#dadada",
  "#e4e4e4",
  "#eeeeee",
  "#ffffff",
  "#ffffff"
];

const terminalColors = [...orderedTerminalColors];

function hideTwinsOf(arr, idx) {
  const base = arr[idx];
  const ret = [];

  arr.forEach((c, i) => {
    if (i === idx) {
      // dont remove self
      ret.push(c);
    } else {
      let isTwin = isSimilar(base, c);
      if (isTwin) {
        console.log(`${base} ~= ${c}`);
        ret.push("");
      } else {
        ret.push(c);
      }
    }
  });

  return ret;
}

function hideSimilar() {
  let filteredColors = [...terminalColors];
  let finalColors = [...terminalColors];

  for (let i = 0; i < 16; i++) {
    let temp = hideTwinsOf([...filteredColors], i);
    for (let j = 0; j < temp.length; j++) {
      if (temp[j] == "") {
        finalColors[j] = "";
      }
    }
  }

  return [...finalColors];
}

function update() {
  allowedDiff = parseInt(document.querySelector("#colorDistance").value, 10);

  const viewDiv = document.querySelector("#view");
  viewDiv.innerHTML = "";

  let swatchList = "";
  terminalColors.map((c, index) => {
    swatchList += `<div title="${index}" class="color-swatch" style="background:${c};"></div>`;
  });
  viewDiv.innerHTML = swatchList;

  const filtDiv = document.querySelector("#filt");
  const filtCols = hideSimilar();

  filtDiv.innerHTML = "";

  let filtList = "";
  let cbClass = document.querySelector("#hideCb").checked;
  filtCols.map((c, index) => {
    if (c !== "") {
      filtList += `<div title="${index}" class="color-swatch" style="background:${c};"></div>`;
    } else {
      filtList += `<div title="${index}" class="color-swatch hide-${cbClass}" style="background:transparent;"></div>`;
    }
  });

  filtDiv.innerHTML = filtList;

  function handleClick(e) {
    let n = e.target.getAttribute("title");
    if (e.target.classList.contains("hide-false")) {
      // no-op
    } else {
      document.querySelector(
        "#cmd"
      ).value = `printf "\\n\\e[0;38;5;${n}mTHIS IS TEXT COLOR 38;5;${n}\\e[0m\\n\\n"`;
    }
  }

  document.querySelectorAll(".color-swatch").forEach((el) => {
    el.addEventListener("click", handleClick);
  });
}

const slider = document.querySelector("#colorDistance");
slider.addEventListener("change", (el) => {
  update();
});

const cb = document.querySelector("#hideCb");
cb.addEventListener("change", (el) => {
  update();
});

update();