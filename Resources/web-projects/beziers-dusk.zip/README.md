# Beziers @ Dusk

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/vEKqrM](https://codepen.io/yuanchuan/pen/vEKqrM).

A recreation of http://thedotisblack.tumblr.com/post/105081869561/grid09-2014-2014-9-6-13-30-46-frame-0002-made

I highly recommend http://thedotisblack.tumblr.com/, fwiw.

Forked from [satchmorun](http://codepen.io/satchmorun/)'s Pen [Beziers @ Dusk](http://codepen.io/satchmorun/pen/GgqzgM/).