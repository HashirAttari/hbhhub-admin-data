var canvas = document.getElementById('canvas');
var ctx = canvas.getContext('2d');

'floor|random|round|abs|sqrt|PI|atan2|sin|cos|pow|max|min'
  .split('|')
  .forEach(function(p) { window[p] = Math[p]; });

var TAU = PI*2;

function r(n) { return random()*n; }
function rint(lo, hi) {
  return lo + floor(r(hi - lo + 1))
}
function choose() {
  return arguments[rint(0, arguments.length-1)];
}

/*---------------------------------------------------------------------------*/

var W, H;

function resize() {
  var w = innerWidth;
  var h = innerHeight;
  var dpr = devicePixelRatio;
  
  canvas.style.width = w+'px';
  canvas.style.height = h+'px';
  
  W = canvas.width = w * dpr;
  H = canvas.height = h * dpr;
}

/*---------------------------------------------------------------------------*/

var N = 7;

function draw() {
  var grad = ctx.createRadialGradient(W/3, H/3, 0, W/3, H/3, max(W, H));
  grad.addColorStop(0, 'rgb(248, 148, 6)');
  grad.addColorStop(1, 'rgb(192, 57, 43)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = 'rgb(150, 40, 27)';
  
  var len = floor(min(W, H) / (N + 2));
  var offsetX = (W - len*N) / 2;
  var offsetY = (H - len*N) / 2;
  
  for (var y = 0; y < N; y++)
    for (var x = 0; x < N; x++)
      path(offsetX + x*len, offsetY + y*len, len);
}

function path(x, y, size) {
  function nx() { return rint(x, x+size-1); }
  function ny() { return rint(y, y+size-1); }
  
  var ox = nx();
  var oy = ny();
  
  ctx.beginPath();
  ctx.moveTo(ox, oy);
  ctx.bezierCurveTo(nx(), ny(), nx(), ny(), nx(), ny());
  ctx.bezierCurveTo(nx(), ny(), nx(), ny(), nx(), ny());
  ctx.bezierCurveTo(nx(), ny(), nx(), ny(), ox, oy);
  ctx.fill();
}

function paint() {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  resize();
  ctx.clearRect(0, 0, W, H);
  draw();
}

paint();

window.onresize = paint;
document.onclick = paint;