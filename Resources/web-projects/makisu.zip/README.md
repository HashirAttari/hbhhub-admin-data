# Makisu

A Pen created on CodePen.io. Original URL: [https://codepen.io/soulwire/pen/AmywKv](https://codepen.io/soulwire/pen/AmywKv).

CSS 3D Dropdown Concept