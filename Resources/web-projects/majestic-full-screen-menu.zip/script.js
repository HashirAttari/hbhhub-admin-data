document.getElementsByClassName('majestic-menu_x')[0].onclick = function() {
	majestic_menu('close', this.parentNode)
}

function majestic_menu(a, m) {
	if (a == 'fade') {
		m.style = "display:block;-webkit-transform: rotateX(0deg)";
		setTimeout(function() {
			m.style = "display:block;transition: all 0.5s; opacity:1;-webkit-transform: rotateX(0deg)"
		}, 1)
	} else if (a == 'flip_top') {
		m.style = "display:block;-webkit-transform-origin:50% 0%;-webkit-transform: rotateX(-90deg)";
		setTimeout(function() {
			m.style = "display:block;transition:all 0.5s;opacity:1;-webkit-transform: rotateX(0deg)"
		}, 1)
	} else if (a == 'flip_bottom') {
		m.style = "display:block;-webkit-transform-origin:50% 100%;-webkit-transform: rotateX(90deg)";
		setTimeout(function() {
			m.style = "display:block;transition: all 0.5s; opacity:1;-webkit-transform: rotateX(0deg)"
		}, 1)
	} else if (a == 'flip_left') {
		m.style = "display:block;-webkit-transform-origin:0% 50%;-webkit-transform: rotateX(0deg) rotateY(90deg)";
		setTimeout(function() {
			m.style = "display:block;transition: all 0.5s; opacity:1;-webkit-transform: rotateY(0deg)"
		}, 1)
	} else if (a == 'flip_right') {
		m.style = "display:block;-webkit-transform-origin:100% 50%;-webkit-transform: rotateX(0deg) rotateY(-90deg)";
		setTimeout(function() {
			m.style = "display:block;transition: all 0.5s; opacity:1;-webkit-transform: rotateY(0deg)"
		}, 1)
	} else if (a == 'slide_top') {
		m.style = "display:block;-webkit-transform: rotateX(0deg);top:-100vh";
		setTimeout(function() {
			m.style = "display:block;transition:all 0.5s;opacity:1;-webkit-transform: rotateX(0deg);top:0"
		}, 1)
	} else if (a == 'slide_bottom') {
		m.style = "display:block;-webkit-transform: rotateX(0deg);top:200vh;"
		setTimeout(function() {
			m.style = "display:block;transition:all 0.5s;opacity:1;-webkit-transform: rotateX(0deg);top:0vh"
		}, 1)
	} else if (a == 'slide_left') {
		m.style = "display:block;-webkit-transform: rotateX(0deg);left:-100vh";
		setTimeout(function() {
			m.style = "display:block;transition:all 0.5s;opacity:1;-webkit-transform: rotateX(0deg);left:0"
		}, 1)
	} else if (a == 'slide_right') {
		m.style = "display:block;-webkit-transform: rotateX(0deg);left:100vh";
		setTimeout(function() {
			m.style = "display:block;transition:all 0.5s;opacity:1;-webkit-transform: rotateX(0deg);left:0"
		}, 1)
	} else if (a == 'close') {
		m.style = "transition: all 0.5s;display:block";
		setTimeout(function() {
			m.style = ''
		}, 500)
	}
}