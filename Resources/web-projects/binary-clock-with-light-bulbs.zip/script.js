const hoursLightBulbElems = document.querySelectorAll('#hours .lights .lamp .lamp-bottom');
const minutesLightBulbElems = document.querySelectorAll('#minutes .lights .lamp .lamp-bottom');
const secondsLightBulbElems = document.querySelectorAll('#seconds .lights .lamp .lamp-bottom');

function updateTime() {
    const currTime = new Date();
    
    const hours = currTime.getHours();
    const minutes = currTime.getMinutes();
    const seconds = currTime.getSeconds();

    hoursLightBulbElems.forEach((lamp, index) => {
        const bulb = lamp.querySelector('.bulb');
        const bit = hours & (2 ** (hoursLightBulbElems.length - index - 1));
        bit ? lamp.classList.add('lamp-on') : lamp.classList.remove('lamp-on');
        bit ? bulb.classList.add('bulb-on') : bulb.classList.remove('bulb-on');
    });
    
    minutesLightBulbElems.forEach((lamp, index) => {
        const bulb = lamp.querySelector('.bulb');
        const bit = minutes & (2 ** (minutesLightBulbElems.length - index - 1));
        bit ? lamp.classList.add('lamp-on') : lamp.classList.remove('lamp-on');
        bit ? bulb.classList.add('bulb-on') : bulb.classList.remove('bulb-on');
    });
    
    secondsLightBulbElems.forEach((lamp, index) => {
        const bulb = lamp.querySelector('.bulb');
        const bit = seconds & (2 ** (secondsLightBulbElems.length - index - 1));
        bit ? lamp.classList.add('lamp-on') : lamp.classList.remove('lamp-on');
        bit ? bulb.classList.add('bulb-on') : bulb.classList.remove('bulb-on');
    });
    
    setTimeout(updateTime, 1000);
}
updateTime();