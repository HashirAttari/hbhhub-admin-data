# Binary clock with light bulbs

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/QWNLaoy](https://codepen.io/agalliat/pen/QWNLaoy).

