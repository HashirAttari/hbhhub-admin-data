# Lazy loading with inline SVG

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/aLKxjm](https://codepen.io/ainalem/pen/aLKxjm).

Lazy loading with inline SVGs. Using inline SVGs to create lightweight thumbnails that creates a better before experience compared to blurred rendered thumbnails.

Credit for images
John Cobb - Mountains
Joey Pilgrim - Deer
Nathan McBride - Desert
Jakub Dziubak - Cup