# [Fork Demo]  - Card with dotted pattern background

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/xxNRJzx](https://codepen.io/cbolson/pen/xxNRJzx).

