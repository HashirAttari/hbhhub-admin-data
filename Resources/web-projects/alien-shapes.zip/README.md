# Alien shapes

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/XVNmRG](https://codepen.io/yuanchuan/pen/XVNmRG).

css-doodle DEMO http://yuanchuan.name/css-doodle