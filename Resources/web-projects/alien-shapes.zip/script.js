document.body.addEventListener('click', update);

function update(e) {
  if (e.target.update) {
    e.target.update();
  }
}