# CSS Dotted Number 

A Pen created on CodePen.io. Original URL: [https://codepen.io/hilotacker/pen/vGqYVP](https://codepen.io/hilotacker/pen/vGqYVP).

This is a typography challenge with CSS and without any font. 