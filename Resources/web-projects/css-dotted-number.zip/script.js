$(function(){
  
  //init
  var i=0;
  var wW = $(window).width();
  var wH = $(window).height();
 
  //Box
  var dotNum = 5 * 7;
  for(var t=0; t<dotNum; t++){
    duplicateDot(t);
  }
  $('#original').remove();
  function duplicateDot(num){
    var dId = 'd'+num;
    $('#original').
      clone().
      removeAttr('id').
      //html(num).
      addClass(dId).
      appendTo('.container');
  }
  
  //Boxs
   $('#c0').hide();
  for(var n = 0; n<9; n++){
    var cId = 'c'+ (n+1);
    $('#c0').
      clone().
      //attr('id',cId).
      appendTo('.wrapper').hide();
  }
  //BG
  var bgW= (wW-30);
  var bgH = Math.floor((wH-60)/15)*15;
  $('.bg').height(bgH);
  var bgDotNum= Math.floor(bgW/15) *Math.floor(bgH/15); //3000;
  var delay = 1200;
  for(var i=0; i<bgDotNum; i++){
    $('#bg-dot-original').
      clone().
      removeAttr('id').
      appendTo('.bg');
  }
  
  
  //font start
  function startTimer(timerNum){
    var myTimer;
    var cNum;
    myTimer=setInterval(function(){
      cNum = Math.floor( Math.random()*10 );
      $('.container:eq('+timerNum+')').show().
        attr('id','c'+cNum);
    } , 20);
    setTimeout(function(){
      clearInterval(myTimer);
      $('.container:eq('+timerNum+')').attr('id','c'+timerNum);
    },1000);
  }
  setTimeout(function(){startTimer(0)},delay);
  setTimeout(function(){startTimer(1)},delay+200);
  setTimeout(function(){startTimer(2)},delay+400);
  setTimeout(function(){startTimer(3)},delay+600);
  setTimeout(function(){startTimer(4)},delay+800);
  setTimeout(function(){startTimer(5)},delay+1000);
  setTimeout(function(){startTimer(6)},delay+1200);
  setTimeout(function(){startTimer(7)},delay+1400);
  setTimeout(function(){startTimer(8)},delay+1600);
  setTimeout(function(){startTimer(9)},delay+1800);
  
  function changeNumber(){
    var myTimer;
    var cNum;
    myTimer=setInterval(function(){
      for(var i=0;i<10;i++){
      cNum = Math.floor( Math.random()*10 );
      $('.container:eq('+i+')').show().
        attr('id','c'+cNum);
      }
    } , 1000);
  }
  setTimeout(function(){changeNumber()},delay+2600);
  
  
  
});