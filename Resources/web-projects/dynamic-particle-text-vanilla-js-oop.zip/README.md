# Dynamic particle text Vanilla JS OOP

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/rNpRNvN](https://codepen.io/franksLaboratory/pen/rNpRNvN).

