# CSS arrow buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/VLRmgG](https://codepen.io/giana/pen/VLRmgG).

Sass mixin for creating arrow buttons. Uses transform: skew on pseudo-elements.

Check out <a href="https://codepen.io/collection/AObpre/">my button collection</a> for more.