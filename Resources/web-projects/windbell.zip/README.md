# Windbell

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/VEKVZB](https://codepen.io/yuanchuan/pen/VEKVZB).

Safari has a bug with pseudo elements animation inside Shadow DOM, so it works only in Chrome and FF 63+