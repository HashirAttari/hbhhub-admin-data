# CSS random wave lines #2  (click to update)

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/YaoXXX](https://codepen.io/yuanchuan/pen/YaoXXX).

<del>This demo only runs in Chrome.</del>

(<del>Firefox doesn't support web components yet. </del> And Safari has an issue to do animations on pseudo-elements inside Shadow DOM.)

See also: https://codepen.io/yuanchuan/pen/KoLovK