# Particle System

A Pen created on CodePen.io. Original URL: [https://codepen.io/waddington/pen/rNKjwd](https://codepen.io/waddington/pen/rNKjwd).

first time using canvas, following this tutorial (http://cssdeck.com/labs/html5-canvas-particles-web-matrix/0) so credit goes to them; may change some things.

I dont copy & paste, i rewrite it out, so i follow it, and when i get to something i dont know, i look it up.

they now repel instead of attract