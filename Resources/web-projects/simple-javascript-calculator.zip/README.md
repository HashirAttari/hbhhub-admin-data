# Simple Javascript Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/deityhub/pen/zdbMXy](https://codepen.io/deityhub/pen/zdbMXy).

This is the replica of our everyday calculate, that can do basic logic. 