# Gates

A Pen created on CodePen.io. Original URL: [https://codepen.io/PicturElements/pen/VmZPwY](https://codepen.io/PicturElements/pen/VmZPwY).

