# Solid Gauge

A Pen created on CodePen.io. Original URL: [https://codepen.io/hluebbering/pen/KKqbWZE](https://codepen.io/hluebbering/pen/KKqbWZE).

