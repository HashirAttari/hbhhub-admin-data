# JS Calculator - Zipline

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nyxx/pen/vLXddR](https://codepen.io/Nyxx/pen/vLXddR).

My implementation of a calculator in Javascript, built for FreeCodeCamp.