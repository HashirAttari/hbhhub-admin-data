# lapisCordis | a greco-roman mythological card game

A Pen created on CodePen.io. Original URL: [https://codepen.io/delvignefred/pen/abMmXwg](https://codepen.io/delvignefred/pen/abMmXwg).

**Selected for the  CodePenChallenge CSS Stunts WEEK3 of January 2024**
<br>
⇨ https://codepen.io/challenges/2024/january
<br>
<br>
**Made with**
<br>
 DALL·E 3, Photoshop, After Effects, Illustrator, Aseprite