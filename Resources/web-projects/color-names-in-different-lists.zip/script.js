console.clear();

function hyphensToCamelCase(str) {
  return str.replace(/-([a-zA-Z])/g, g => g[1].toUpperCase());
}

new Vue({
  el: '#app',
  data: function () {
    return {
      currentColor: '#ff0000',
      currentFetches: [],
      bestMatches: {},
      count: 0,
      meta: {} };

  },
  computed: {
    currentHex: function () {
      return this.currentColor.substring(1);
    },
    lists: function () {
      if (Object.keys(this.meta).length) {
        return Object.keys(this.meta).map(key => hyphensToCamelCase(key));
      } else {
        return [];
      }
    } },

  methods: {
    listTitle: function (key) {
      return Object.values(this.meta).find(v => hyphensToCamelCase(v.key) === key).title;
    },
    lumToColor: function (lum) {
      return parseFloat(lum) < 80 ? '#fff' : '#202124';
    },
    fetchColors: function () {
      this.lists.forEach(listTitle => {
        this.currentFetches[listTitle] = fetch(`https://api.color.pizza/v1/?values=${this.currentHex}&list=${listTitle}`).
        then(data => data.json()).then(d => {
          this.$forceUpdate();
          this.bestMatches[listTitle] = d.colors[0];
        });
      });
    } },

  mounted() {
    fetch('https://cdn.skypack.dev/color-name-lists@3.10.0/lib/descriptions.json').then(d => d.json()).then(d => {

      this.meta = d;
      this.meta['default'] = {
        "title": "Handpicked Color Names",
        "description": "A handpicked list of 29777 unique color names from various sources and thousands of curated user submissions.",
        "source": "https://github.com/meodai/color-names",
        "key": "default" };

      this.meta['bestOf'] = {
        "title": "Best Of Handpicked Color Names",
        "description": "Best of subset of handpicked list of 29777 unique color names from various sources and thousands of curated user submissions.",
        "source": "https://github.com/meodai/color-names",
        "key": "bestOf" };

      this.fetchColors();
    });
  } });