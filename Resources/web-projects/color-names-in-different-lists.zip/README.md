# Color Names in Different Lists

A Pen created on CodePen.io. Original URL: [https://codepen.io/meodai/pen/vYddvLB](https://codepen.io/meodai/pen/vYddvLB).

