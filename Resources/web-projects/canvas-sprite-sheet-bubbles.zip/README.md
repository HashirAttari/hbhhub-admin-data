# Canvas sprite-sheet bubbles

A Pen created on CodePen.io. Original URL: [https://codepen.io/creativeocean/pen/NWmemaY](https://codepen.io/creativeocean/pen/NWmemaY).

Sprite art found via google image search. Then Photoshop to isolate each frame and create transparency.  I used this handy tool to create the final sprite-sheets (there are two in the JS): https://draeton.github.io/stitches/ And finally I used this terrific compression tool to make tiny WEBPs: https://squoosh.app/ ...Hope those are both useful links for others, I use them often!