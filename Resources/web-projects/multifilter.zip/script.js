const sportBrands = ["2XU","361 Degrees","A.F.C.A","Adidas","Admiral","Air Jordan","Airness","Alanic","AND1","ANTA","Ashworth","ASICS","Athleta","Athletic DNA","Atletica","Audimas","BIKE Athletic Company","BLK","BRG","Brine","British Cricket Balls","British Knights","Brooks","Bukta","Burley-Sekem","Callaway","Canterbury","Carbrini","CCM","Champion","Champs","Classic","Columbia","Concave","Converse","De Marchi","Deuter Sport","Diadora","Donnay","Dryworld","Duarig","Dunlop","Dynamic","Ellesse","ERKE","Erima","Erreà","Everlast","Fabletics","Fairtex Gym","FBT","Fila","Finta","Forward","FSS","Galvin Green","The Game","Geox","Gilbert","Givova","Gola","Grand","Gul","Gunn & Moore","Head","Hi-Tec","Hummel","Hunkemöller HKMX","ISC","Ivivva athletica","Jako","Joma","K-Swiss","K2 Sports","Kappa","Karhu","Kelme","Kempa","Keuka","Kickers","Kukri","Le Coq Sportif","Le Tigre","Let's Bands","League","Legea","Lescon","Li-Ning","Lonsdale","Looptworks","Lorna Jane","Lotto","Loudmouth Golf","Luanvi","Lululemon Athletica","LUTA","Macron","Majestic Athletic","Marathon","Maverik Lacrosse","Merooj","Meyba","Mikasa","Mitchell & Ness","Mitre","Mizuno","Molten","Moncler","Mondetta","Munich","Musto","Nanque","New Balance","New Era","Nike","No Fear","Nomis","Olympikus","Onda","One Way","O'Neill","O'Neills","Patrick","Peak","Pearl Izumi","Penalty","Ping","Pirma","Pony","Prince","Prospecs","Puma","Quechua","Quick","Rapha","Raymond","Reebok","Reusch","Riddell","Russell Athletic","Rykä","Saeta","Salomon","Samurai","Santini SMS","Sarson","Select","Sergio Tacchini","Sherrin","Shimano","Signia","Skins","Skis Rossignol","Slazenger","Soffe","Sondico","Spalding","SPECS","Speedo","Sportika","Starbury","Starter","Steeden","Sting","Sugino","Superga","Swix","TaylorMade-Adidas","TH3","Titleist","Tokaido","Topper","Tyr","Uhlsport","Umbro","Under Armour","Walon Sport","Warrior","Warriors","Webb Ellis","Wilson","XBlades","Xero Shoes","Xtep","Yonex","Zoke"];

//const data = Array.from({ length: 5 }, (v, k) => k);

function randomInt(min, max) {
  let rand = min - 0.5 + Math.random() * (max - min + 1)
  rand = Math.round(rand);
  return rand;
}
const data = sportBrands.map((brand,idx) => ({
  id: idx+1,
  brand: brand,
  qty: randomInt(2,500)
}))



const vm = new Vue({
  el: "#app",
  data() {
    return {
      Data: data,
      keyword:'',
      selected: []
    }
  },
  computed: {
    filteredData() {
      return this.Data.filter((item) => {
        return item.brand.toLowerCase().includes(this.keyword.toLowerCase())   
      })
    }, 
  },
  methods: {
    mark(word) {
      const regex = new RegExp("(" + this.keyword + ")", "gi");
      return this.keyword ? word.replace(regex, '<mark>$1</mark>') : word;
    },
  },
});