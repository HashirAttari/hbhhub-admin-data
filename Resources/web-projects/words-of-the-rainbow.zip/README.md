# Words of the Rainbow

A Pen created on CodePen.

Original URL: [https://codepen.io/tmrDevelops/pen/MwBrzQ](https://codepen.io/tmrDevelops/pen/MwBrzQ).

`#rainbowTextWeekend`  | A few of the symbolic meanings of the rainbow expressed in particle words.  Mousemove / TouchSwipe over text. <br><a href = 'http://codepen.io/tmrDevelops/blog/rainbows-in-a-world-of-clouds'>The Blog Post</a>