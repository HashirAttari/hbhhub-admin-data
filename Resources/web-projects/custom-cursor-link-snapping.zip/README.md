# Custom Cursor + Link Snapping

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/aXjerK](https://codepen.io/markmead/pen/aXjerK).

Inspired by WesBos #JavaScript30 - https://javascript30.com/