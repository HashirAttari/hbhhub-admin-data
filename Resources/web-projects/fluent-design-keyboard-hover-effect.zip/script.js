var relX,relY;
$(".keyboard").mousemove(function(event) {
    var offset = $(this).offset();
    relX = event.pageX- offset.left;
    relY = event.pageY- offset.top;
    $('.hover_mouse').css('-webkit-mask-image', 'radial-gradient(ellipse 176px 176px at ' + relX + 'px ' + relY + 'px, black 30%, transparent 50%)' );
  
});

$(".keyboard ul li").click(function(event) {
    event.preventDefault();
});