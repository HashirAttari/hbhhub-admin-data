# Spectrograph

A Pen created on CodePen.io. Original URL: [https://codepen.io/munkholm/pen/mdbOpBp](https://codepen.io/munkholm/pen/mdbOpBp).

