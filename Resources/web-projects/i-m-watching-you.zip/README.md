# I'm Watching You ! 👀

A Pen created on CodePen.io. Original URL: [https://codepen.io/visnuravichandran/pen/poyaPZa](https://codepen.io/visnuravichandran/pen/poyaPZa).

Created this LOOK up eye using GSAP !

Inspired from https://dribbble.com/shots/2249960-Feast-your-peepers