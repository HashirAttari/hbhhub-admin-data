const animateEye = gsap.timeline({ delay: 1, repeat: -1, repeatDelay: 1 });

animateEye
  .to(".eye", 0.1, {
    webkitClipPath: "circle(0% at 50% 50%)"
  })
  .to(".eye", 0.1, {
    webkitClipPath: "none"
  })
  .to(".eye-ball", 0.1, {
    left: "25px"
  }, 1)
  .to(".eye", 0.1, {
    webkitClipPath: "circle(0% at 50% 50%)"
  }, 2)
  .to(".eye", 0.1, {
    webkitClipPath: "none"
  })
  .to(".eye-ball", 0.1, {
    left: "10px",
    top: "25px"
  }, 3)
 .to(".eye", 0.1, {
    webkitClipPath: "circle(0% at 50% 50%)"
  }, 4)
  .to(".eye", 0.1, {
    webkitClipPath: "none"
  })
  .to(".eye-ball", 0.1, {
    left: "9px",
    top: "9px"
  }, 5)
  .to(".eye", 0.1, {
    webkitClipPath: "circle(0% at 50% 50%)"
  }, 6)
  .to(".eye", 0.1, {
    webkitClipPath: "none"
  })
  .to(".eye-ball", 0.1, {
    left: "-5px",
    top: "10px"
  }, 7)
  .to(".eye", 0.1, {
    webkitClipPath: "circle(0% at 50% 50%)"
  }, 8)
  .to(".eye", 0.1, {
    webkitClipPath: "none"
  });