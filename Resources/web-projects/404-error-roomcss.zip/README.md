# 404 Error Room - CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/NWmjaja](https://codepen.io/josetxu/pen/NWmjaja).

Inspired by this image from Pinterest:  

- https://www.pinterest.es/pin/619526492470038067/