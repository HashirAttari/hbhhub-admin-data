# Realistic Red Switch (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/ExNOmZx](https://codepen.io/ykadosh/pen/ExNOmZx).

This is my attempt at making a realistic switch using CSS only. I'm using multiple CSS techniques here, including gradients, 3D transformations, animations and transitions.

Check out my tutorial on how I made this: https://dev.to/ykadosh/how-i-made-this-realistic-red-switch-pure-css-49g2

This pen is based on this beautiful Dribbble shot by Voicu Apostol https://dribbble.com/shots/14172039-3D-Red-Switch