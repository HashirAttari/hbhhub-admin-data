# toggle switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/vYxyGwY](https://codepen.io/run-time/pen/vYxyGwY).

