Splitting();

console.log([...'👨‍👩‍👦'])
console.log([...'👩‍🦰'])