# Splitting Complex Emoji

A Pen created on CodePen.io. Original URL: [https://codepen.io/ste-vg/pen/QWRpGxj](https://codepen.io/ste-vg/pen/QWRpGxj).

_Built with [Splitting](https://splitting.js.org)_