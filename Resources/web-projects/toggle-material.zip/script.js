var toggleWrapper = document.querySelector('.toggle-wrapper');

document.querySelector('.toggle_handler').addEventListener('click', () => {
  toggleWrapper.classList.toggle('pushed');
});