const el = document.querySelector(".upload")
let state = "normal"

// if the pen is in thumbnail view, scale it up to look better and show it as open in the center of the image
if (location.pathname.match(/fullcpgrid/i) ? true : false) {
  document.documentElement.style.fontSize = "32px"
  document.querySelector(".note").style.display = "none"
  el.style.transform = "translate(-1rem, 1rem)"
  
  setTimeout(function() {
    el.classList.add("open")
    state = "open"
  }, 500);
}

// when clicking the upload button
function uploadopen() {
  if (state == "finished") {
    // go back if the upload finished
    state = "normal"
    el.classList.remove("finished")
  } else if (state == "open") {
    // close the menu if its open
    state = "normal"
    el.classList.remove("open")
  } else if (state == "normal") {
    // open the menu if its in the normal state
    state = "open"
    el.classList.add("open")
  }
}

// when dragging on the upload button (different, because the onclick above will also trigger right after)
function uploadtouch() {
  if (state == "normal") {
    state = "open"
    el.classList.add("open")
  }
}

// when dragging ends
function uploaddrag(event) {
  // check to make sure its on a file type
    element = document.elementFromPoint(event.pageX, event.pageY)
  console.log("before", element.nodeName)
  if (element.nodeName == "ION-ICON") {element = element.parentNode}
  console.log("after", element.nodeName)
  if (!element.classList.contains("uploadoption")) {return}
  
  // start the upload animation
  console.log("drag")
  if (state != "open") {return}
  state = "uploading"
  el.classList.remove("open")
  el.classList.add("uploading")
}

// when clicking on a file type, start the upload animation
function uploadstart() {
  if (state != "open") {return}
  state = "uploading"
  el.classList.remove("open")
  el.classList.add("uploading")
}

document.querySelector(".uploadprogress").addEventListener("animationend", () => uploadend());

// when the upload animation ends, set the state so the checkmark appears
function uploadend() {
  if (state != "uploading") {return}
  state = "finished"
  el.classList.remove("uploading")
  el.classList.add("finished")
}