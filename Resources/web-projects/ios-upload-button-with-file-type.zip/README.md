# iOS Upload Button with file type

A Pen created on CodePen.io. Original URL: [https://codepen.io/cleveryeti/pen/YzdNaPr](https://codepen.io/cleveryeti/pen/YzdNaPr).

Upload button with file location options like on iOS