# Swipeable Cards nightly

A Pen created on CodePen.io. Original URL: [https://codepen.io/ionic/pen/nQRBVW](https://codepen.io/ionic/pen/nQRBVW).

A card stack UI with swipeable cards.