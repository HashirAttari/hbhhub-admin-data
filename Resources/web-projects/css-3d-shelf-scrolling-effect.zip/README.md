# CSS 3D shelf scrolling effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/zYovPey](https://codepen.io/benhatsor/pen/zYovPey).

Translated a sketch i made some years back (see: http://goo.gl/vCdfRF) with help of tridiv.com