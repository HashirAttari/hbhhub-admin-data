/*
		Designed by: Guillaume Kurkdjian
		Original image: https://www.behance.net/gallery/29135019/Simple-day
*/