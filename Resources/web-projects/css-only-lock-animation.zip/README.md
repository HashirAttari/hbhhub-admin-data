# CSS Only Lock Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/matthewjmoran/pen/dXdYbN](https://codepen.io/matthewjmoran/pen/dXdYbN).

