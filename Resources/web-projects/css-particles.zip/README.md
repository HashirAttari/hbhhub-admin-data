# CSS Particles

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/ZGZeWR](https://codepen.io/giana/pen/ZGZeWR).

Inspired by [Bits](http://codepen.io/hellomatt/pen/pJYxyX). Be warned: terrible performance.

Click and hold for even worse performance.