# The Unstoppable Valentine Proposal 💘

A Pen created on CodePen.

Original URL: [https://codepen.io/Haleema-Sadia/pen/NPromZL](https://codepen.io/Haleema-Sadia/pen/NPromZL).

"Experience a digital journey of love! 🌹 This project is a multi-slide interactive story that takes you through the beautiful milestones of a relationship—from the first 'Hi' to the '3 AM conversations.'

Key Features:
✨ Romantic Glassmorphism UI: A luxury red and gold aesthetic.
📊 Progress Tracker: A top bar that fills up as you move through our story.
🎨 Canvas Heart Particles: Beautiful red particles floating in the background.
📱 Fully Responsive: Optimized for both mobile and desktop lovers.