# Slide to unlock

A Pen created on CodePen.io. Original URL: [https://codepen.io/waylaid/pen/DozKzj](https://codepen.io/waylaid/pen/DozKzj).

Have adapted Mr Coyier's slide to unlock script (http://css-tricks.com/examples/SlideToUnlock/) so that the slider springs back to open if not closed fully. I couldnt find a way to do this with just the jQuery UI script so I've used a duplicate of the slider-circle to add the 'opened' part and disable / enable the draggable class as necessary.

This doesn't work with touch with defeats the object of this kind of UI but I haven't been able to get the touch script by Evan Black (http://www.evanblack.com/blog/touch-slide-to-unlock/) that Chris used on CSS Tricks working.