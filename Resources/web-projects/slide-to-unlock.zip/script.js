$(function() {
  
  $('.opened').hide();
  
  $('.closed').draggable({
		  axis: 'x',
		  containment: 'parent',
		  drag: function(event, ui) {
		    if (ui.position.left > 230) {
	     }
		  },
    stop: function(event, ui) {
   			if (ui.position.left < 230) {
				    $(this).animate({
					     left: 17
				    })
			   }
      if (ui.position.left < 15) {
				    $(this).animate({
					     left: 17
			     })
      }   
      if (ui.position.left > 230) {
				    $(this).animate({
					     left: 230
        }, function() {
          $(this).hide().animate({left: 17});
          $('.opened').show();
          $('.padlock-loop').addClass('padlock-open');
        });
      }
    }
  });
  
  $('.opened').draggable({
		  axis: 'x',
		  containment: 'parent',
		  drag: function(event, ui) {
			   if (ui.position.left < 5) {
			   }
		  },
    stop: function(event, ui) {
   			if (ui.position.left > 15) {
				    $(this).animate({
					     left: 230
				    })
			   }
      if (ui.position.left > 230) {
				    $(this).animate({
					     left: 230
				    })
      }
      if (ui.position.left < 15) {
				    $(this).animate({
					     left: 17
				    }, function() {
          $(this).hide().animate({left: 230});
          $('.closed').show();
          $('.padlock-loop').removeClass('padlock-open');
        });
      }
		  }
  });

});