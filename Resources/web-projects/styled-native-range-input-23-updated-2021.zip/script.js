// nope, no JS this time :) 
/* external resources *only* for displaying the info box */