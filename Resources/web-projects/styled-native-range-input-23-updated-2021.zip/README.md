# Styled native range input #23 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/VYyYzL](https://codepen.io/thebabydino/pen/VYyYzL).

**May 2021 description**

Major changes:

* cleaned up an compacted the CSS

* eliminated hacks like testing for SMIL support specifically targeting IE... no shit, what was I thinking? ಠ_ಠ 

* got rid of `absolute` positioning in favour of a CSS `grid` layout

The external resources are only there to add the warning, which was sadly very necessary given a lot of people shared these saying that I designed them... which is not true.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. Pure CSS. 

---

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/LKLQJ1A.jpg) 