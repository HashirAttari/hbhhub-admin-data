# Apple Keyboard in HTML/CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/carlcalderon/pen/nOybKz](https://codepen.io/carlcalderon/pen/nOybKz).

