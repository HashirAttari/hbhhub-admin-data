# Yin Yang (CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/YzrKrrN](https://codepen.io/amit_sheen/pen/YzrKrrN).

