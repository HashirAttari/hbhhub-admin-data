# Toggle Day/Night BW

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/JjVOevq](https://codepen.io/alvaromontoro/pen/JjVOevq).

