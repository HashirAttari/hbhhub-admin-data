# Divtober 2021 #01: Fan

A Pen created on CodePen.io. Original URL: [https://codepen.io/cobra_winfrey/pen/LYLvLbQ](https://codepen.io/cobra_winfrey/pen/LYLvLbQ).

