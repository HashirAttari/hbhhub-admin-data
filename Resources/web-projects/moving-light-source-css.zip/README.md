# Moving light source (CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/dyWPdvL](https://codepen.io/amit_sheen/pen/dyWPdvL).

