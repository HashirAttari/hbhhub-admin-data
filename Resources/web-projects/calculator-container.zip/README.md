# Calculator Container

A Pen created on CodePen.io. Original URL: [https://codepen.io/maxakohler/pen/nMwMzK](https://codepen.io/maxakohler/pen/nMwMzK).

Aww I felt like coding a calculator thingy.
This pen holds all the different css variations that I made over time.

1. [Design Inspiration](http://dribbble.com/shots/875591-Calculator)

2. Awesome calculator icon:   <a href="http://thenounproject.com/noun/calculator/#icon-No804" target="_blank">Calculator</a> designed by <a href="http://thenounproject.com/iconify" target="_blank">Scott Lewis</a> from The Noun Project