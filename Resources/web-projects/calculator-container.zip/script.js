var eq = '';
	var s = 0;
	var mode = '';

var reset = function(){
	s = 0;
	eq = '';
	mode = '';
}

$('document').ready(function(){
  //$(select).change(function(){
  //  body.toggleClass('hello-world');
  //})
	$('.button').click(function(){
	  $('body').toggleClass('active');
	})

	$('ul li:not(.meta)').click(function(){
	  var number = $(this).text();
	  eq += number;
	  if (mode === ''){
		s += number;
	  }
	  s *= 1;
	  if (mode === 'add'){
		  number *= 1;
		  s += number;
	  }
	  if (mode === 'substract'){
		  number *= 1;
		  s -= number;
	  }
	  if (mode === 'multiply'){
		  number *= 1;
		  s *= number;
	  }  
	  if (mode === 'divide'){
		  number *= 1;
		  s /= number;
	  }    	  
	$('.equation').text(eq);
	    
	})

	$('.meta').click(function(){
	  var operation = $(this).text();
	  eq += ' ' + operation + ' ';
	  $('.equation').text(eq);
	  if (operation === '+'){
		mode = 'add';
	  }
	  if (operation === '-'){
		mode = 'substract';
	  }
	  if (operation === '*'){
		mode = 'multiply';
	  }
	  if (operation === '/'){
		mode = 'divide';
	  }
	})

	$('.equals').click(function(){
	   $('.result').text(s);
	   reset();
	})  
});