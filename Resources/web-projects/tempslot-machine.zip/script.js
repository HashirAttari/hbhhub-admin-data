let button = document.querySelector("button"),
    bars = document.querySelectorAll(".bar")

button.onclick = event => {
  bars.forEach(bar => {
    let container = bar.querySelector(".container");
    let randomOffset = getRandomOffset();
    console.log(randomOffset);
    container.style.setProperty('--translate-offset', randomOffset);
    container.classList.add("animation");
    container.addEventListener("animationend", () => {
      container.classList.remove("animation");
    }, { once: true });
  });
};

function getRandomOffset() {
  return `${getRandomNumber(10, 90)}%`;
}

function getRandomNumber(min, max) {
  let number = Math.floor(Math.random() * (max - min + 1) + min );
  return Math.round(number / 10) * 10 +.75
}