/* external resources *only* for displaying the info boxes */

/* this below is all the JS needed for the demo itself to work */
document.documentElement.classList.add('js');

addEventListener('input', e => {
	let _t = e.target;
	
	_t.parentNode.style.setProperty(`--${_t.dataset.c}`, +_t.value)
}, false);

addEventListener('click', e => {
	let _t = e.target;
	
	if(_t.tagName.toLowerCase() === 'button') {
		let _p = _t.parentNode, 
				_r = _p.querySelector('[type=range]'), 
				dir = 1*_t.style.getPropertyValue('--dir');
		
		_p.style.setProperty('--c', _r.value = +_r.value + dir*10)
	}
})