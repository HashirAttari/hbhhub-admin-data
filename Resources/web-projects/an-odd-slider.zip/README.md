# An odd slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/cleveryeti/pen/LYQoWBX](https://codepen.io/cleveryeti/pen/LYQoWBX).

