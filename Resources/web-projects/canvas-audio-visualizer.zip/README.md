# Canvas Audio Visualizer

A Pen created on CodePen.io. Original URL: [https://codepen.io/ClementRoche/pen/dgwavz](https://codepen.io/ClementRoche/pen/dgwavz).

Here is an audio visualizer of "N'to - Alter Ego" made with canvas.
I've made in the context of "Creative coding" course in Gobelins, Paris.