//Best css only masonry example.
//original link:
//http://jsfiddle.net/gabrieleromanato/tQANc/