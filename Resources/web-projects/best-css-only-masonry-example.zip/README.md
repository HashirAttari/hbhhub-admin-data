# Best css only masonry example

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/YyooqB](https://codepen.io/mselmany/pen/YyooqB).



Forked from [Rio](http://codepen.io/riogrande/)'s Pen [Best css only masonry example](http://codepen.io/riogrande/pen/jbYPJQ/).