let code = document.body.innerHTML;
code = code.replace(/(\r\n|\n|\r)/gm, "");
//code = code.replace(/\s/g, "");

let animEl = document.querySelector(".codegraphictext");

animEl.innerText = code + "\n" + code + "\n" + code;
//animEl.innerText = "" + [Array(100).fill(1), Array(100).fill(2), Array(100).fill(3), Array(100).fill(4), Array(100).fill(5), Array(100).fill(6), Array(100).fill(7)] + [Array(100).fill(1), Array(100).fill(2), Array(100).fill(3), Array(100).fill(4), Array(100).fill(5), Array(100).fill(6), Array(100).fill(7)]