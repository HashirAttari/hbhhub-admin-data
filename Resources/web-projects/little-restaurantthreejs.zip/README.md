# Little Restaurant - ThreeJS

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/JjxMXEB](https://codepen.io/ricardoolivaalonso/pen/JjxMXEB).

