# Live Chat 2.0 [Built with Google Forms/Spreadsheet]

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/JZEGXZ](https://codepen.io/leenalavanya/pen/JZEGXZ).

You could also call it:
How To Build A Live Chat Widget Using Only A Free Google Account and Limited Knowledge of Front-end.