function chat_send() {
    document.getElementsByClassName("chat_s")[0].innerHTML +=
        '<div class="chat chat_me">' +
        document.getElementById("entry_1650216873").value +
        "</div>";
    chat_tobottom();
    document.getElementById("entry_1650216873").value = "";
}

function chat_tobottom() {
    document.getElementsByClassName(
        "chat_s"
    )[0].scrollTop = document.getElementsByClassName("chat_s")[0].scrollHeight;
}

function chat_load() {
    document.getElementsByClassName("chat_s")[0].innerHTML =
        "<p style='margin:20px'>Loading...</p>";
    $.getJSON(
        "https://spreadsheets.google.com/feeds/list/17GkffJw4P6sABGH7trefxFax22G4pL8ZZL5oMSJsXoU/od6/public/values?alt=json",
        function(data) {
            document.getElementsByClassName("chat_s")[0].innerHTML = "";
            for (var i = 0; i < data.feed.entry.length; i++) {
                var entry = data.feed.entry[i];
                var a;
                if (entry.gsx$name.$t == "Ariana") {
                    a = "chat_ar";
                } else {
                    a = "chat_me";
                }
                document.getElementsByClassName("chat_s")[0].innerHTML +=
                    '<div class="chat ' +
                    a +
                    '">' +
                    entry.gsx$message.$t +
                    "</div>";
            }
        }
    );
}

chat_load();