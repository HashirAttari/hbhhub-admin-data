# Happy Halloween - Parallax Effect & Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/ecemgo/pen/ZEwYqMQ](https://codepen.io/ecemgo/pen/ZEwYqMQ).

Happy Halloween!

In this pen, a parallax effect is provided by using GreenSock. It also contains a slider by Swiper and on the slider, the glitch effect is used on titles and images. Images on the slider were created by AI.

Note: Please, do not use it in profit-making platforms and projects without permission.