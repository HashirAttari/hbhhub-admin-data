# partner / client carousel

A Pen created on CodePen.io. Original URL: [https://codepen.io/GrandvincentMarion/pen/BzNdLV](https://codepen.io/GrandvincentMarion/pen/BzNdLV).

partner / client carousel