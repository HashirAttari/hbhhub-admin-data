# Gif animation + CSS animation + Blend modes

A Pen created on CodePen.io. Original URL: [https://codepen.io/yoksel/pen/jORoQq](https://codepen.io/yoksel/pen/jORoQq).

