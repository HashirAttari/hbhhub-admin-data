/*

Inspired by this twit:

https://twitter.com/paul_irish/status/523339110027505664

*/