function pixelLazyLoad(selector) {
  const lazyImages = [...document.querySelectorAll(".lazy")];

  for (let lazyImage of lazyImages) {
    if (lazyImage.getBoundingClientRect().top <= 100) {
      lazyImage.src = lazyImage.dataset.src;
      lazyImage.classList.add("loaded");
    }
  }
}

pixelLazyLoad();

window.addEventListener("scroll", pixelLazyLoad);