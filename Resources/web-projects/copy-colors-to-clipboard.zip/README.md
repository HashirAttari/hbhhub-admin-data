# Copy colors to clipboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/myacode/pen/oNgKJad](https://codepen.io/myacode/pen/oNgKJad).

