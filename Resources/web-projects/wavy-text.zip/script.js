var str = document.querySelector('.wavy').innerHTML;

if (Math.abs(str.length % 2) == 1) {str += " "}

var out = '';
for (let i = 0; i < str.length/2; i++) {
  out += '<span style="animation-delay:'+i*0.04+'s">'+str[i]+'</span>';
}
let n = str.length/2;
for (let i = str.length/2; i < str.length; i++) {
  out += '<span style="animation-delay:'+n*0.04+'s">'+str[i]+'</span>';
  n--;
}

document.querySelector('.wavy').innerHTML = out;