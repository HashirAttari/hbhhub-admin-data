# My CSS Console

A Pen created on CodePen.io. Original URL: [https://codepen.io/joseluisq/pen/dyXpVw](https://codepen.io/joseluisq/pen/dyXpVw).

Simple css console