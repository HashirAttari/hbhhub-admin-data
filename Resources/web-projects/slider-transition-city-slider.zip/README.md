# Slider Transition (City Slider)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Manoylov/pen/YeWYPm](https://codepen.io/Manoylov/pen/YeWYPm).

