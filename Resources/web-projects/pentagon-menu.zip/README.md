# Pentagon menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/KKZYqMo](https://codepen.io/kitjenson/pen/KKZYqMo).

Easily adjusted pentagon shape menu. 