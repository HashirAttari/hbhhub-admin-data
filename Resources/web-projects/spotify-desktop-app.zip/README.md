# Spotify Desktop App

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/PrBEqW](https://codepen.io/ricardoolivaalonso/pen/PrBEqW).

