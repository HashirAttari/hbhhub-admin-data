#  CSS3 Button Hover Effects with FontAwesome

A Pen created on CodePen.io. Original URL: [https://codepen.io/foxeisen/pen/bqZxLa](https://codepen.io/foxeisen/pen/bqZxLa).

Pure  CSS3 Button Hover Effects