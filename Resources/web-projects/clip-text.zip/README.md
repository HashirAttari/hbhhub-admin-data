# Clip text

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/yLQzrQK](https://codepen.io/cbolson/pen/yLQzrQK).

