# Sine clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/sschepis/pen/abrmQEz](https://codepen.io/sschepis/pen/abrmQEz).

