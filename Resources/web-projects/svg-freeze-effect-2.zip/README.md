# SVG Freeze Effect 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/vainsan/pen/QWRLdLq](https://codepen.io/vainsan/pen/QWRLdLq).

