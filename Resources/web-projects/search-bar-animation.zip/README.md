# Search Bar Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/VGrVmy](https://codepen.io/leenalavanya/pen/VGrVmy).

Based on the Dribble shot: https://dribbble.com/shots/5094907-Search-Field-Animation-Demo.