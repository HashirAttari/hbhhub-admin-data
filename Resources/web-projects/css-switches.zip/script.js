// @AbubakerSaeed96 (twitter)
// abubakersaeed.netlify.com
// =========================

// 1&2 Simple
// 3&4 Outline/Border
// 5 Material Design-like
// 6 I've seen it on sites but I don't know what people call that design/effect (maybe liquid/or-like?)
// 7 Material Design-like (Half thumb out)

/*
  #keyboard-users: It's not an outline but more of a custom outline using box-shadow. All the effects that mouse users can see you'll get the same except for the sixth switch.
*/

/* Things to keep in mind.
=========================
  Colors:

    1. Outline Color (...that you'll see when you focus the switch) should be brighter than the background color of the switch. So that #keyboard-users can see/know which switch/item they are currently on. It can be same as thumb background color (as I used in my blue theme).

    2. Choose colors wisely. And don't just pick any color. I've tried purple (and even though I like purple...) it doesn't look good on switches.

==========================
These are for my component not saying you should not try/use in yours...
*/

// Thank You for viewing.
// ========================================

// Theming Stuff
const $ = e => document.querySelectorAll(e);

const _switches = $(".switches")[0];
const _colors = $("input[name='color']");

for (let i = 0; i < _colors.length; i++) {

  _colors[i].addEventListener("change", e => {
    if (e.target.checked) _switches.setAttribute('data-theme', e.target.value);
  })

}