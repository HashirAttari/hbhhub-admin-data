# CSS Switches

A Pen created on CodePen.io. Original URL: [https://codepen.io/AbubakerSaeed/pen/ExYyRQd](https://codepen.io/AbubakerSaeed/pen/ExYyRQd).

