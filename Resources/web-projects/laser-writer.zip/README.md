# Laser Writer

A Pen created on CodePen.

Original URL: [https://codepen.io/DonKarlssonSan/pen/VazvQx](https://codepen.io/DonKarlssonSan/pen/VazvQx).

I've seen several text effect animations lately that inspired me to try it myself.

 * [THREE Text Animation #2](http://codepen.io/zadvorsky/pen/xVrMMO) by Szenia Zadvornykh
 * [Shattering Text Animation](http://codepen.io/Zagora/pen/KdezPK) by Zagora
 * [Peace Springs](http://codepen.io/tmrDevelops/pen/MyoMew) by Tiffany Rayside
 * [Text particle](http://codepen.io/Gthibaud/pen/pyeNKj) by Gthibaud