# Fancy Image Splitting (SplittingJS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/mGyqjW](https://codepen.io/markmead/pen/mGyqjW).

SplittingJS: https://splitting.js.org/