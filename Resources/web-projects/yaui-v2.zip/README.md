# YAUI v2

A Pen created on CodePen.io. Original URL: [https://codepen.io/hugo/pen/kQdYee](https://codepen.io/hugo/pen/kQdYee).

Version 2 of Yet Another UI kit, Hope you like it :)