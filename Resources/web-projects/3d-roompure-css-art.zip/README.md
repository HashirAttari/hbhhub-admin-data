# 3D Room - Pure CSS Art

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/mdPzrpe](https://codepen.io/ricardoolivaalonso/pen/mdPzrpe).

