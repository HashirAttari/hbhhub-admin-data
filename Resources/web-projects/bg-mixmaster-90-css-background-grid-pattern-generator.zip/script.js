Vue.component('modal', {
  template: `
    <transition name="modal">
      <div class="modal flip-container" :class="{'flip-me': flipMe}">
        <div class="modal__mask" v-if="showMask"></div>
        <div class="modal__wrapper flipper">
          <div class="modal__container front">
            <div class="modal__header">
              <slot name="front-header"></slot>
              <div class="modal__x" v-if="showX" @click="$emit('toggle')">&times;</div>
            </div>
            <div class="modal__body">
              <slot name="front-body"></slot>
            </div>
            <div class="modal__footer">
              <slot name="front-footer"></slot>
            </div>
          </div>
          <div class="modal__container back">
            <div class="modal__header">
              <slot name="back-header"></slot>
              <div class="modal__x" v-if="showX" @click="$emit('toggle')">&times;</div>
            </div>
            <div class="modal__body">
              <slot name="back-body"></slot>
            </div>
            <div class="modal__footer">
              <slot name="back-footer"></slot>
            </div>
          </div>
        </div>
      </div>
    </transition>
  `,
  props: [
    'showX',
    'showMask',
    'flipMe'
  ]
})

Vue.component('rad-slider', {
  template: `
    <div 
        class="rad-slider"
        :name="name"
        :class="{moving: moving, dirty: dirty}" 
        @mousedown.self="start" 
        @mousemove="move" 
        @mouseup="stop"
        @touchstart.self="start" 
        @touchmove="move" 
        @touchend="stop"
        >
      <slot></slot>
      <div class="label">{{degree}}&deg;</div>
    </div>
  `,
  props: {
    name: {
      type: String,
      required: true
    },
    degree: {
      type: Number,
      default: 0
    },
    lockWith: {
      type: String
    },
    eventName: {
      type: String,
      required: true
    }
  },
  data: function(){
    return {
      moving: false,
      dirty: false,
      delta: 0,
      buddy: null,
      previousDegree: this.degree
    }
  },
  mounted: function(){
    this.processDegree(this.degree, this.degree)
    if(this.lockWith){
      this.buddy = document.querySelector('.rad-slider[name="'+this.lockWith+'"]')
    }
  },
  updated: function(){
    this.processDegree(this.degree, this.degree)
  },
  methods: {
    getPointerDeg: function(e){
      let x = e.touches && e.touches.length ? e.touches[0].clientX : e.clientX
      let y = e.touches && e.touches.length ? e.touches[0].clientY : e.clientY
      return Math.floor(Math.atan2(x - (this.metrics.left + this.metrics.width/2), y - (this.metrics.top + this.metrics.height/2))*(-180/Math.PI)) + 180
    },
    processDegree: function(value, previousValue){
      this.degree = (value >= 360 ? value - 360 : (value < 0 ? value + 360 : value))
      this.$el.style.setProperty('--degree', this.degree + 'deg')
      this.delta = this.degree - previousValue
      this.$emit(this.eventName, this.name, this.degree, this.delta, this.lockWith, this.buddy)
    },
    start: function(e){
      this.moving = true
      this.dirty = true
      this.metrics = e.target.getBoundingClientRect()
      this.pointer = this.getPointerDeg(e) - this.degree
      this.previousDegree = this.degree
    },
    move: function(e){
      if(this.moving){
        let step = 1
        let input = this.getPointerDeg(e)
        if(e.shiftKey && e.metaKey){
          step = 45
        } else if(e.shiftKey){
          step = 15
        } else if(e.metaKey){
          step = 30
        }
        this.degree = Math.ceil((this.getPointerDeg(e) - this.pointer) / step) * step
        if(this.previousDegree !== this.degree){
          this.processDegree(this.degree, this.previousDegree)
        }
        this.previousDegree = this.degree
      }
    },
    stop: function(e){
      this.moving = false
    }
  }
})

let _units = [
  'vmax',
  'vmin',
  'vw',
  'vh',
  '%',
  'em',
  'px'
]

let _translator = {
  c1: 'color B',
  c2: 'color A',
  bg: 'background'
}

let _tracks = [
  {
    name: 'Basket Case',
    a: 305,
    b: 220,
    x: 75,
    y: 75,
    l: 5,
    lockstep: false,
    lineY: false,
    lineX: false,
    isolate: false,
    c1: '#9959cf',
    c2: '#40ccde',
    bg: '#e783b1',
    size: '100% 100%',
    line_y: 'var(--c2) var(--y)',
    line_x: 'var(--c1) var(--x)',
    unit_x: 'vmax',
    unit_y: 'vmax',
    unit_l: 'px'
  },
  {
    name: 'Because I Said So',
    a: 0,
    b: 90,
    x: 2,
    y: 2,
    l: 2,
    lockstep: true,
    lineY: true,
    lineX: true,
    isolate: true,
    c1: '#dbf7ff',
    c2: '#dbf7ff',
    bg: '#ffffff',
    size: 'var(--x) var(--y)',
    line_y: 'var(--c2) var(--y)',
    line_x: 'var(--c1) var(--x)',
    unit_x: 'em',
    unit_y: 'em',
    unit_l: 'px'
  },
  {
    name: 'College Rules',
    a: 0,
    b: 270,
    x: 85,
    y: 2,
    l: 3,
    lockstep: true,
    lineY: true,
    lineX: true,
    isolate: false,
    c1: '#ffebf3',
    c2: '#dbf7ff',
    bg: '#ffffff',
    size: '100% 100%',
    line_y: 'rgba(0,0,0, 0) calc(var(--y) - var(--l))',
    line_x: 'rgba(0,0,0, 0) calc(var(--x) - var(--l))',
    unit_x: 'vw',
    unit_y: 'em',
    unit_l: 'px'
  }
]

let vm = new Vue({
  el: 'main',
  data: {
    showModal: true,
    showMask: false,
    showX: true,
    flipMe: false,
    isPaletteOpen: false,
    currentKey: null,
    currentColor: '',
    color: {
      h: 0,
      s: 0,
      l: 0
    },
    tracks: _tracks,
    units: _units,
    translator:_translator,
    track: {},
    params: {}
  },
  mounted: function(){
    this.playTrack(this.tracks[0].name)
  },
  methods: {
    setSize: function(track){
      track.size = (track.isolate ? `${track.x}${track.unit_x} ${track.y}${track.unit_y}`:'100% 100%')
      this.foo('size', track.size, '')
    },
    setLineY: function(track){
      let bg = this.hex2rgb(track.bg)
      if(track.lineY) {
        track.line_y = `rgba(${bg.r},${bg.g},${bg.b}, 0) calc(${track.y}${track.unit_y} - ${track.l}${track.unit_l})` //, rgba(${bg.r},${bg.g},${bg.b}, 0) ${track.y}${track.unit_y}`
      } else {
        track.line_y = `${track.c2} ${track.y}${track.unit_y}`
      }
      this.foo('line-y', track.line_y, '')
    },
    setLineX: function(track){
      let bg = this.hex2rgb(track.bg)
      if(track.lineX) {
        track.line_x = `rgba(${bg.r},${bg.g},${bg.b}, 0) calc(${track.x}${track.unit_x} - ${track.l}${track.unit_l})` //, rgba(${bg.r},${bg.g},${bg.b}, 0) ${track.x}${track.unit_x}`
      } else {
        track.line_x = `${track.c1} ${track.x}${track.unit_x}`
      }
      this.foo('line-x', track.line_x, '')
    },
    setY: function(track){
      this.foo('y', track.y, track.unit_y)
      this.setSize(track)
      this.setLineY(track)
    },
    setX: function(track){
      this.foo('x', track.x, track.unit_x)
      this.setSize(track)
      this.setLineX(track)
    },
    setLine: function(track){
      this.foo('l', track.l, track.unit_l)
      this.setLineY(track)
      this.setLineX(track)
    },
    setXYUnit: function(track, key){
      this.foo('unit-'+key, track.unit+"_"+key, '')
      this.setX(track)
      this.setY(track)
    },
    setLUnit: function(track, key){
      this.foo('unit-'+key, track.unit+"_"+key, '')
      this.setLine(track)
    },
    setParams: function(track){
      let bg = this.hex2rgb(track.bg)
      return {
        title: '',
        editors: '010',
        css: `body {
  min-height: 100vh;
  background-image: 
    repeating-linear-gradient(${track.a}deg, 
      rgba(${bg.r},${bg.g},${bg.b}, 0) 0,
      ${track.line_y},
      ${track.c2} calc(${track.y}${track.unit_y} - ${track.l}${track.unit_l}),
      ${track.c2} ${track.y}${track.unit_y}
    ),
    repeating-linear-gradient(${track.b}deg, 
      rgba(${bg.r},${bg.g},${bg.b}, 0) 0,
      ${track.line_x},
      ${track.c1} calc(${track.x}${track.unit_x} - ${track.l}${track.unit_l}),
      ${track.c1} ${track.x}${track.unit_x}
    );

  background-color: ${track.bg};
  background-size: ${track.size};
}`
      }
    },
    togglePlaylist: function(event){
      event.target.classList.toggle('open')
    },
    playTrack: function(name){
      this.hidePalette()
      let track = this.tracks.find(function(item){
        return item.name === name
      })
      this.track = JSON.parse(JSON.stringify(track)) // cheap clone
      this.foo('a', this.track.a, 'deg')
      this.foo('b', this.track.b, 'deg')
      this.foo('c1', this.track.c1, '')
      this.foo('c2', this.track.c2, '')
      this.foo('bg', this.track.bg, '')
      this.foo('x', this.track.x, this.track.unit_x)
      this.foo('y', this.track.y, this.track.unit_y)
      this.foo('l', this.track.l, this.track.unit_l)
      this.setSize(this.track)
      this.setLineY(this.track)
      this.setLineX(this.track)
    },
    foo: function(key, value, unit){
      this.track[key] = value
      document.documentElement.style.setProperty('--' + key, value + unit)
      if(key === 'bg') {
        let rgbObject = this.hex2rgb(value)
        let rgb = `${rgbObject.r}, ${rgbObject.g}, ${rgbObject.b}`
        document.documentElement.style.setProperty('--' + key + '-rgb', rgb)
      }
      if(key == 'c1' || key === 'c2' || key === 'bg') {
        let contrast = this.brightness(value) < 165 ? '#fff' : '#212126';
        document.documentElement.style.setProperty('--contrast', contrast)
        document.documentElement.style.setProperty('--' + key + '-contrast', contrast)
      }
    },
    toggleModal: function(){
      this.hidePalette()
      this.showModal = !this.showModal
      if(!this.showModal && this.flipMe){
        this.flipModal()
      }
    },
    flipModal: function(){
      this.flipMe = !this.flipMe
      if(this.flipMe) {
        this.params = this.setParams(this.track)
      }
    },
    rotate: function(name, degree, delta, lockWith, buddy){
      this.foo(name, degree, 'deg')
      if(this.track.lockstep && buddy) {
        this.track[lockWith] += delta
        this.track[lockWith] = (this.track[lockWith] >= 360 ? this.track[lockWith] - 360 : (this.track[lockWith] < 0 ? this.track[lockWith] + 360 : this.track[lockWith]))
        buddy.style.setProperty('--degree', this.track[lockWith] + 'deg')
        this.foo(lockWith, this.track[lockWith], 'deg')
      }
    },
    showPalette: function(key){
      this.isPaletteOpen = true
      this.currentKey = key
      let hex = this.track[this.currentKey]
      this.color = this.hex2hsl(hex)
      this.updateColor(this.color)
    },
    hidePalette: function(){
      this.isPaletteOpen = false
      this.currentKey = null
    },
    togglePalette: function(key){
      if(key !== this.currentKey || !this.isPaletteOpen) {
        this.showPalette(key)
      } else {
        this.hidePalette()
      }
    },
    updateColor: function(hsl){
      this.currentColor = this.hsl2hex(parseInt(hsl.h), parseInt(hsl.s), parseInt(hsl.l))
      this.foo(this.currentKey, this.currentColor, '')
      this.setLineY(this.track)
      this.setLineX(this.track)
    },
    updateHue: function(name, degree){
      this.color.h = degree
      this.updateColor(this.color)
    },
    hex2rgb: function(hex){
      if(hex) {
        hex = hex.replace('#', '')
        var r = (parseInt(hex.substring(0, 2), 16)|0)
        var g = (parseInt(hex.substring(2, 4), 16)|0)
        var b = (parseInt(hex.substring(4, 6), 16)|0)
        return {r:r, g:g, b:b}
      }
    },
    rgb2hsl: function(r, g, b) {
      r /= 255, g /= 255, b /= 255
      let max = Math.max(r, g, b),
          min = Math.min(r, g, b)
      let h, 
          s, 
          l = (max + min) / 2

      if(max == min) {
          h = s = 0; // achromatic
      } else {
          let d = max - min
          s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
          switch(max) {
              case r: h = (g - b) / d + (g < b ? 6 : 0); break;
              case g: h = (b - r) / d + 2; break;
              case b: h = (r - g) / d + 4; break;
          }
      }
      h = Math.floor(h*60+0.5)|0
      s = Math.floor(s*100+0.5)|0
      l = Math.floor(l*100+0.5)|0
      return {h:h, s:s, l:l};
    },
    hex2hsl: function(hex) {
      let rgb = this.hex2rgb(hex)
      let hsl = this.rgb2hsl(rgb.r, rgb.g, rgb.b)
      return hsl
    },
    hue2rgb: function(p, q, t){
      if(t < 0) t += 1
      if(t > 1) t -= 1
      if(t < 1/6) return p + (q - p) * 6 * t
      if(t < 1/2) return q
      if(t < 2/3) return p + (q - p) * (2/3 - t) * 6
      return p
    },    
    hsl2rgb: function(h, s, l){
      let r, g, b, q, p
      h /= 360
      s /= 100
      l /= 100
      if(s === 0) {
          r = g = b = l // achromatic
      } else {
        q = l < 0.5 ? l * (1 + s) : l + s - l * s
        p = 2 * l - q
        r = this.hue2rgb(p, q, h + 1/3)
        g = this.hue2rgb(p, q, h)
        b = this.hue2rgb(p, q, h - 1/3)
      }
      r = Math.min(Math.floor(r*256), 255)
      g = Math.min(Math.floor(g*256), 255)
      b = Math.min(Math.floor(b*256), 255)

      return {r:r, g:g, b:b}
    },
    rgb2hex: function(r, g, b){
      r = ('0' + parseInt(r).toString(16)).substr(-2)
      g = ('0' + parseInt(g).toString(16)).substr(-2)
      b = ('0' + parseInt(b).toString(16)).substr(-2)
      return '#'+r+''+g+''+b
    },
    hsl2hex: function(h, s, l){
     let rgb = this.hsl2rgb(h, s, l)
     return this.rgb2hex(rgb.r, rgb.g, rgb.b)
    },
    brightness: function(hex) {
      let r = parseInt(hex.slice(1, 3), 16)
      let g = parseInt(hex.slice(3, 5), 16)
      let b = parseInt(hex.slice(5, 7), 16)
      return (r * 299 + g * 587 + b * 114) / 1000
    }
  }
})