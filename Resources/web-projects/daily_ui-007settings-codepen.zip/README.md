# Daily_UI #007 - Settings CodePen

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/NNNyQM](https://codepen.io/mselmany/pen/NNNyQM).



Forked from [Pavel Laptev](http://codepen.io/PavelLaptev/)'s Pen [Daily_UI #007 - Settings CodePen](http://codepen.io/PavelLaptev/pen/xVwvYQ/).