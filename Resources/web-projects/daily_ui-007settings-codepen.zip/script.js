$( ".select_item" ).click(function() {
	$( ".options" ).slideToggle('fast');
	$( ".arrow" ).toggleClass('arrow_rotate');
});

$( ".option" ).click(function() {
	$('.select_item p').text($(this).data('val'));
	$('.option').removeClass('select_option');
	$(this).addClass('select_option');
	$( ".options" ).slideToggle('fast');
});

$( ".form_head" ).click(function() {
	$(this).parent().find( ".switch_pick" ).toggleClass('switch_pick_active');
	$(this).parent().find( ".switch_line" ).toggleClass('switch_line_active');
	$(this).parent().find(".form_textarea").slideToggle(100);
});


$( ".help" ).click(function() {
	$( this ).toggleClass( "help_active", 'fast');
	tooltip();
});


function tooltip() {
	if ($( ".help" ).hasClass('help_active')){
		$('.select, .form_toggle').hover(function(){
		        // Hover over code
		        var title = $(this).attr('alt-title');
		        $(this).data('tipText', title).removeAttr('alt-title');
		        $('<p class="tooltip"></p>')
		        .text(title)
		        .appendTo('body')
		        .fadeIn('fast');
		}, function() {
		        // Hover out code
		        $(this).attr('alt-title', $(this).data('tipText'));
		        $('.tooltip').remove();
		}).mousemove(function(e) {
		        var mousex = e.pageX + 20; //Get X coordinates
		        var mousey = e.pageY + 10; //Get Y coordinates
		        $('.tooltip')
		        .css({ top: mousey, left: mousex })
		});
	} else {
		$('.select, .form_toggle').hover(function() {
		        // Hover out code
		        $(this).attr('alt-title', $(this).data('tipText'));
		        $('.tooltip').remove();
		});
	}
}