# OS X-Style Context Menu in CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/sstephenson/pen/kawawV](https://codepen.io/sstephenson/pen/kawawV).

HTML 5 &lt;menu&gt; element styled to look like a native OS X menu. View this pen in Chrome or Safari on a Mac. (Firefox supports the HTML 5 contextmenu attribute, so right-clicking on the purple square shows the items in a native menu.)