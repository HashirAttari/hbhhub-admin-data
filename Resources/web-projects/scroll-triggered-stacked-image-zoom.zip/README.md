# Scroll‑Triggered Stacked Image Zoom

A Pen created on CodePen.

Original URL: [https://codepen.io/ol-ivier/pen/ogLZpYV](https://codepen.io/ol-ivier/pen/ogLZpYV).

A visual experiment where scrolling vertically triggers a smooth zoom‑out transition between stacked full‑screen images. Each image scales down as the next one emerges, creating a continuous flow. Built with vanilla JavaScript and enhanced with Lenis for smooth scrolling. The captions fade in only when an image is fully active.