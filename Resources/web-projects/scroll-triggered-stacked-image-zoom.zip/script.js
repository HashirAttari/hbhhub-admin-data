document.addEventListener("DOMContentLoaded", () => {
    const images = [...document.querySelectorAll(".image")];
    const total = images.length;
    const section = document.querySelector(".agrandissement");
    let viewport = window.innerHeight;
    const clamp = (v, min = 0, max = 1) => Math.min(max, Math.max(min, v));

    function updateSectionHeight() {
        viewport = window.innerHeight;
        const scrollLength = viewport * total;
        section.style.height = scrollLength + "px"
    }

    function initImages() {
        images.forEach((img, i) => {
            img.style.zIndex = total - i;
            img.style.height = "";
            img.style.opacity = "";
            img.classList.remove("active")
        });
        images[0].classList.add("active")
    }

    function update() {
        const scrollY = window.scrollY;
        let globalProgress = scrollY / viewport;
        globalProgress = clamp(globalProgress, 0, total - 1);
        images.forEach((image, index) => {
            const localProgress = clamp(globalProgress - index);
            const height = (1 - localProgress) * 100;
            image.style.height = height + "%";
            if (height > 95) {
                image.style.opacity = "1";
                image.classList.add("active")
            } else if (height > 1) {
                image.style.opacity = "1";
                image.classList.remove("active")
            } else {
                image.style.opacity = "0";
                image.classList.remove("active")
            }
        })
    }
    initImages();
    updateSectionHeight();
    update();
    let resizeTimeout;
    window.addEventListener("resize", () => {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(() => {
            updateSectionHeight();
            initImages();
            update()
        }, 100)
    });
    window.addEventListener("scroll", update);
    const lenis = new Lenis({
        duration: 3,
        easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        smoothWheel: !0
    });

    function raf(time) {
        lenis.raf(time);
        requestAnimationFrame(raf)
    }
    requestAnimationFrame(raf)
})