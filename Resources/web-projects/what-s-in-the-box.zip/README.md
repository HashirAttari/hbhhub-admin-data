# What's in the box!?

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/pMxJyy](https://codepen.io/kitjenson/pen/pMxJyy).

Try you hand, and luck, at opening the chest. 

