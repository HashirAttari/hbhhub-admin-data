var c = document.getElementById('chest')
var i = document.getElementById('item')
var t = document.getElementById('top')
var b = document.getElementById('bottom')
var g = document.getElementById('type')
var inv = document.getElementById('inventory')

i.addEventListener('click', function(e){
  e = this
  e.classList.remove('yea')
    if(inv.querySelectorAll('div').length < 5) {
      var cln = e.cloneNode()
      inv.appendChild(cln)  
    } else {    
      inv.firstChild.remove(inv.firstChild)
      var cln = e.cloneNode()
      inv.appendChild(cln) 
    }
  
  t.className = ""
  i.className = ""
  g.innerHTML = ""
  b.style.pointerEvents = ""
})


gems = ["ruby","emerald","sapphire","diamond","amethyst","aquamarine","amber","onyx","garnet","rainbow"]

function magic() {
  var gem = Math.floor(Math.random()*gems.length)
  i.classList.add(gems[gem])
  
  setTimeout(function(){
  g.innerHTML = gems[gem]  
  },4000)  
  
  // var num = Math.random()*window.innerWidth
  // t.style.left = num+"px"
  // t.style.top = "-40vh"
  t.classList.add('open') 
  i.classList.add('yea')
  b.style.pointerEvents = "none"
}

t.addEventListener('click', magic)
b.addEventListener('click', magic)