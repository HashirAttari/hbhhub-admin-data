# Kickass Web Elements #2 Pure CSS Form

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/yNpEpg](https://codepen.io/jcoulterdesign/pen/yNpEpg).

Part #2 of the Kickass Web Elements Series.