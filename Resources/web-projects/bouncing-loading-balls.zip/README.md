# bouncing loading balls

A Pen created on CodePen.io. Original URL: [https://codepen.io/nzbin/pen/BvQjGz](https://codepen.io/nzbin/pen/BvQjGz).

bouncing loading balls made entirely with HTML and CSS(LESS)