/*
Another kind 
https://codepen.io/Raphael/pen/opvkH

*/
$('.Cube').each(function(i){
	var self = $(this),
		delta = self.position().top+self.position().left;

	self.css({
		'animation':'panel 10s '+(delta/2)+'ms cubic-bezier(0.680, -0.550, 0.265, 1.550) infinite forwards'
	});

	self.children('.cube-face').css({
		'background':'rgba(40,180,210,'+(10*(delta/20000))+')'
	})
});