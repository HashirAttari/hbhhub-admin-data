# 3D cube & easing

A Pen created on CodePen.io. Original URL: [https://codepen.io/Raphael/pen/eYeLBv](https://codepen.io/Raphael/pen/eYeLBv).

30min challenge, fell free to improve