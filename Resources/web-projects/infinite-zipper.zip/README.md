# Infinite Zipper

A Pen created on CodePen.io. Original URL: [https://codepen.io/jbanegas/pen/WPjJmj](https://codepen.io/jbanegas/pen/WPjJmj).

Infinite zipper using scrollmagic and GSAP