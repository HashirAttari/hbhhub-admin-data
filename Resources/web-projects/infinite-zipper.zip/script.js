const controller = new ScrollMagic.Controller();
const halfWindowHeight = $(window).height() / 2;
const zipperList = $("#zipper li");

function zipperAnimation(i, e) {
  const zipper = new TimelineMax();
  let xVal;

  i % 2 != 0 ? xVal = 75 : xVal = -75;

  zipper.add(
  TweenMax.to(e, 3, {
    xPercent: xVal,
    ease: Linear.noEase }));



  new ScrollMagic.Scene({
    triggerElement: e,
    triggerHook: .6,
    duration: halfWindowHeight }).

  setTween(zipper).
  addTo(controller);
}

zipperList.each(zipperAnimation);

zipHooks = {
  triggerElement: ".last-zip",
  triggerHook: "onEnter" };


var scene = new ScrollMagic.Scene(zipHooks).
addTo(controller).
on('enter', function () {addBoxes(50);});

function addBoxes(amount) {
  $('.zip').removeClass('new');
  $(".last-zip").removeClass('last-zip');

  for (let i = 1; i <= amount; i++) {
    let listItem = $("<li>");
    listItem.addClass("zip new").
    appendTo("#zipper");

    if (i == amount) listItem.addClass('last-zip');
  }

  $('.new').each(zipperAnimation);

  //add scene to new list item
  new ScrollMagic.Scene(zipHooks).
  addTo(controller).
  on('enter', function (e) {
    addBoxes(18);
  });
}