# Responsive 2048 with Mobile Touch support

A Pen created on CodePen.io. Original URL: [https://codepen.io/simoberny/pen/QOrjLP](https://codepen.io/simoberny/pen/QOrjLP).

Really simple 2048 app. I'm not used to make fully javascript application. 
This JS code is not even closely optimised. 
This is only a test of responsive design and swipe detection velocity on mobile phone