# Playing cards zoom

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/BYmbGy](https://codepen.io/ainalem/pen/BYmbGy).


Playful zoom slide show using playing cards suit as clipping shapes

Photos from unsplash.com by
Ines Ferreira
Jack Hamilton
Michal Parzuchowski