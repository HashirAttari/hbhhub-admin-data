let select = s => document.querySelector(s),
  selectAll = s =>  document.querySelectorAll(s),
		mainSVG = select('#mainSVG'),
		mid = gsap.utils.toArray('#mid *')//.reverse()

gsap.set('svg', {
	visibility: 'visible'
})
const blendEases = (startEase, endEase, blender) => {
		var parse = function(ease) {
						return typeof(ease) === "function" ? ease : gsap.parseEase("power4.inOut");
				},
				s = gsap.parseEase(startEase),
				e = gsap.parseEase(endEase),
				blender = parse(blender);
		return function(v) {
			var b = blender(v);
			return s(v) * (1 - b) + e(v) * b;
		};
}	
let wave0 = 'sine.inOut';

let fatTl = gsap.timeline();
fatTl.fromTo('#fat *', {
	drawSVG: '0% 20%'
}, {
		drawSVG: '80% 100%',
	stagger: {
		each: 0.045,
		repeat: -1,
		//yoyo: true
	},
	duration: 0.5,
	ease: 'linear'
})
let fatTopTl = gsap.timeline({delay: 0});
fatTopTl.fromTo('#fatTop *', {
		drawSVG: '80% 100%',
}, {
	drawSVG: '0% 20%',
	stagger: {
		each: 0.045,
		repeat: -1,
		//yoyo: true
	},
	duration: 0.5,
	ease: 'linear'
})

//ScrubGSAPTimeline(mainTl)
//gsap.globalTimeline.timeScale(1.42)