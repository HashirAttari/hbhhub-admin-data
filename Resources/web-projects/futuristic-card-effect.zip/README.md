# Futuristic Card Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/Hyperplexed/pen/vYzgeYE](https://codepen.io/Hyperplexed/pen/vYzgeYE).

