# #divtober 22 - Power

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/WNxGNWp](https://codepen.io/ricardoolivaalonso/pen/WNxGNWp).

