/*
		Designed by: Su
		Original image: https://dribbble.com/shots/3177451-light-switch
*/