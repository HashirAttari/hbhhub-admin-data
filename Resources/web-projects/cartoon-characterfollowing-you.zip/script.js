const className = 'smiley__wrapper';
const smiley = document.getElementById(className);

const mouseFunction = (mouse) => {
  const clientX = mouse.clientX ? mouse.clientX : mouse.touches[0].clientX;
  const clientY = mouse.clientY ? mouse.clientY : mouse.touches[0].clientY;
  if (clientX > window.innerWidth / 2 + 20) {
    smiley.classList.add(`${className}--right`);
    smiley.classList.remove(`${className}--left`);
  } else if (clientX < window.innerWidth / 2 - 20) {
    smiley.classList.add(`${className}--left`);
    smiley.classList.remove(`${className}--right`);
  } else {
    smiley.classList.remove(`${className}--right`);
    smiley.classList.remove(`${className}--left`);
  }
  if (clientY > window.innerHeight / 2 + 20) {
    smiley.classList.add(`${className}--bottom`);
    smiley.classList.remove(`${className}--top`);
  } else if (clientY < window.innerHeight / 2 - 20) {
    smiley.classList.add(`${className}--top`);
    smiley.classList.remove(`${className}--bottom`);
  } else {
    smiley.classList.remove(`${className}--bottom`);
    smiley.classList.remove(`${className}--top`);
  }
};

// In a PROD case we should use a "throttle function" for these events
window.addEventListener('mousemove', mouseFunction);
window.addEventListener('touchstart', mouseFunction);