# Cookie switch (pure CSS, no SVG)

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/RwrEqOG](https://codepen.io/agalliat/pen/RwrEqOG).

