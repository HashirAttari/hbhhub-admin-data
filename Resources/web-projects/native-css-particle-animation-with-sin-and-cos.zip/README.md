# Native CSS particle animation with sin() and cos()

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/LYaOdye](https://codepen.io/giana/pen/LYaOdye).

If I ever stop making these, call the priest. Tell him I've been overcome by sin().

Current soundtrack: Struggling Fans by My Laptop