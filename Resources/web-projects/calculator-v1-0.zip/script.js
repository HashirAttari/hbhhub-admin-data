/*global console, document, alert, $*/
/*jslint plusplus: true*/

var inputOne = document.getElementById("textOne"),
	inputTwo = document.getElementById("textTwo"),
	inputThree = document.getElementById("textThree"),
	btnPlus = document.getElementById("pluss"),
	btnx = document.getElementById("x"),
	btnSaleb = document.getElementById("saleb"),
	btnala = document.getElementById("kasm"),
	btnReset = document.getElementById("reset"),
	btnWare = document.getElementById("Ware");

btnPlus.onclick = function () {
	"use strict";
	if (inputOne.value === "" || isNaN(inputOne.value)) {
		inputThree.style.display = "none";
		inputTwo.style.zIndex = "0";
		inputOne.style.zIndex = "100";
	} else {
		inputThree.style.display = "block";
		inputTwo.style.zIndex = "0";
		inputOne.style.zIndex = "0";
		inputTwo.value = btnPlus.value;
	}
};

btnx.onclick = function () {
	"use strict";
	if (inputOne.value === "" || isNaN(inputOne.value)) {
		inputThree.style.display = "none";
		inputTwo.style.zIndex = "0";
		inputOne.style.zIndex = "100";
	} else {
		inputThree.style.display = "block";
		inputTwo.style.zIndex = "0";
		inputOne.style.zIndex = "0";
		inputTwo.value = btnx.value;
	}
};

btnSaleb.onclick = function () {
	"use strict";
	if (inputOne.value === "" || isNaN(inputOne.value)) {
		inputThree.style.display = "none";
		inputTwo.style.zIndex = "0";
		inputOne.style.zIndex = "100";
	} else {
		inputThree.style.display = "block";
		inputTwo.style.zIndex = "0";
		inputOne.style.zIndex = "0";
		inputTwo.value = btnSaleb.value;
	}
};

btnala.onclick = function () {
	"use strict";
	if (inputOne.value === "" || isNaN(inputOne.value)) {
		inputThree.style.display = "none";
		inputTwo.style.zIndex = "0";
		inputOne.style.zIndex = "100";
	} else {
		inputThree.style.display = "block";
		inputTwo.style.zIndex = "0";
		inputOne.style.zIndex = "0";
		inputTwo.value = btnala.value;
	}
};

btnReset.onclick = function () {
	"use strict";
	inputOne.value = "";
	inputTwo.value = "";
	inputThree.value = "";
	inputThree.style.display = "none";
	inputTwo.style.zIndex = "0";
	inputOne.style.zIndex = "100";
};

btnWare.onclick = function () {
	"use strict";
	if (
		inputOne.value === "" ||
		inputThree.value === "" ||
		isNaN(inputThree.value) ||
		isNaN(inputOne.value)
	) {
		inputThree.style.display = "none";
		inputTwo.style.zIndex = "0";
		inputOne.style.zIndex = "100";
		inputThree.value = "";
		inputTwo.value = "";
		inputOne.value = "";
	} else {
		inputThree.value = eval(inputOne.value + inputTwo.value + inputThree.value);
	}
};