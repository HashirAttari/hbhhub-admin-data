# Button animated linear gradient border with border radius

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/XWmRNyP](https://codepen.io/ig_design/pen/XWmRNyP).

