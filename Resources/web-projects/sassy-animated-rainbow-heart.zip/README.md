# Sassy animated rainbow heart

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/XmOWvN](https://codepen.io/giana/pen/XmOWvN).

Done during Eva Ferreira's awesome workshop "Looping for Animation" at SassConf 2015.

Modified from <a href="http://codepen.io/anon/pen/yYQWVq">my anon pen</a>.