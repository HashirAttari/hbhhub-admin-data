// looking to create a css transformer controlled by a range slider input element

const rangeSlider = document.getElementById('slider');
const bagTop = document.querySelector('.bag-top');
const bagBottom = document.querySelector('.bag-bottom');

rangeSlider.addEventListener('input', (e) => {
  bagTop.style.transform = `rotate(${e.target.value / 9}deg) skew(${e.target.value / 20}deg, -${e.target.value / 30}deg)`
    bagTop.style.transformOrigin = `${e.target.value}% 100%`
    
    bagBottom.style.transform = `skew(${e.target.value / 50}deg, -${e.target.value / 33}deg)`
    bagBottom.style.transformOrigin = `${e.target.value}% 100%`
    

});