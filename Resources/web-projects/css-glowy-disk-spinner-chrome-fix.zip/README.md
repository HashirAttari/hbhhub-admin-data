# CSS glowy disk spinner [Chrome fix]

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/NGQjMV](https://codepen.io/giana/pen/NGQjMV).

Chrome-compatible version of <a href="http://codepen.io/giana/pen/JYgXLJ">this pen</a>.

The transform/animation was making the disks render on their own layer, blending with each other but not the background. Here, the animation is added to the parent div, a blended radial gradient to one pseudo element, and the background to blend into to the second pseudo element.

Closest I could get it to the Firefox version. Correct rendering:  
<img src="http://i.imgur.com/EkxekzV.gif">