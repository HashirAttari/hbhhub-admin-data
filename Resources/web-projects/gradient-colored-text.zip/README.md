# gradient colored text

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/yEbzvv](https://codepen.io/joshonweb/pen/yEbzvv).

