var bw=document.getElementById("bookwrapper");

function createBookBox(obj){
  var bm=document.createElement("div");
  bm.className="bookmarklet";
  bm.id=obj.name;
  var header=bm.addTextElement("h2",obj.name);
  header.onclick=toggleVisible;
  header.setAttribute("expanded",true);
  
  var box=document.createElement("div");
  box.className="bookbox";
  box.addTextElement("span",obj.description,"Description");
  
  var clbl=box.addTextElement("h3","Code");
  addCopyGroup(clbl,obj,true);
  var ta=document.createElement("textarea");
  ta.value=obj.code;
  ta.setAttribute("readonly","");
  box.appendChild(ta);
  
  if (obj.notes) box.addTextElement("span",obj.notes,"Notes");
  box.addTextElement("span",obj.changelog,"Changelog");
  var third=document.createElement("div");
  third.className="third";
  var third2=third.cloneNode(),
      third3=third.cloneNode();
  third.addTextElement("span",obj.version,"Version");
  var time=third2.addTextElement("span",toTimeString(obj.published),"Latest revision");
  time.classList="timestamp";
  time.timestamp=obj.published;
  third3.addTextElement("span",obj.domain,"Domain");
  
  box.appendChild(third);
  box.appendChild(third2);
  box.appendChild(third3);
  
  addContentItem(obj);
  
  bm.appendChild(box);
  bw.appendChild(bm);
}

function addContentItem(obj,elem,inner){
  var wrapper=document.createElement("div");
  wrapper.className="contentitem";
  var link=document.createElement("a");
  link.innerHTML=obj.name;
  link.href="#"+obj.name;
  document.getElementById("quicklinks").appendChild(link.cloneNode(true));
  wrapper.appendChild(link);
  addCopyGroup(wrapper,obj);
  (elem || document.getElementById("contents")).appendChild(wrapper);
}

function addCopyGroup(elem,obj,preventJump){
  var group=document.createElement("div");
  group.className="copygroup";
  var btn=document.createElement("button");
  btn.innerHTML="copy";
  btn.addEventListener("click",function(){
    relayCopy(obj.name,preventJump);
  });
  group.appendChild(btn);
  var a=document.createElement("a");
  a.className="dragbtn";
  a.href=minify(obj.code);
  a.innerHTML=obj.name+" v"+obj.version;
  a.addEventListener("click",function(evt){
    msg("Drag this to the bookmark bar!");
    evt.preventDefault();
  });
  group.appendChild(a);
  elem.appendChild(group);
}

function relayCopy(name,preventJump){
  var h2=document.getElementById(name).children[0];
  if (h2.getAttribute("expanded")=="false") h2.click();
  if (!preventJump) window.location.href=window.location.href.split("#")[0]+"#"+name;
  copy(name,preventJump?0:300);
}

function copy(name,timeout){
  var ta=document.getElementById(name).getElementsByTagName("textarea")[0];
  ta.select();
  setTimeout(function(){
    msg(document.execCommand("copy")?("Copied "+name+"!"):"Copy failed.");
  },timeout);
}

function msg(m){
  var msg=document.getElementById("msg");
  msg.innerHTML=m;
  msg.classList.add("pop");
  setTimeout(function(){
    msg.classList.remove("pop");
  },5000);
}

Element.prototype.addTextElement=function(tag,content,title){
  if (title) this.addTextElement("h3",title);
  var elem=document.createElement(tag);
  elem.innerHTML=content;
  this.appendChild(elem);
  return elem;
};

function toggleVisible(){
  this.setAttribute("expanded",this.getAttribute("expanded")=="false");
}

function minify(str){
  return str.replace(/\n/g,"").replace(/ +/g," ");
}

function updateTimestamps(){
  var times=document.getElementsByClassName("timestamp");
  for (var i=0;i<times.length;i++){
    times[i].innerHTML=toTimeString(times[i].timestamp);
  }
}

setInterval(updateTimestamps,10000);

function toTimeString(epoch) {
  var time = Math.floor((new Date().getUTCTime() / 1000) - epoch) / 60;
  var units = [525960, "year", 43830, "month", 1440, "day", 60, "hour", 1, "minute"],
      out = [];
  for (var i = 0; i < units.length; i += 2) {
    var newTime = Math.floor(time / units[i]);
    if (newTime)
      out.push(newTime + " " + units[i + 1] + (newTime == 1 ? '' : 's'));
    time = time % units[i]
  }
  out = out.splice(0, 3);
  return out.join(", ") + " ago";
}

Date.prototype.getUTCTime=function(){
  return this.getTime()+this.getTimezoneOffset()*60000;
};

document.onscroll=function(){
  var ht=document.getElementsByTagName("h2")[0].getBoundingClientRect().top,
      header=document.getElementById("header"),
      lg=document.getElementById("logowrapper").getBoundingClientRect().height,
      ql=document.getElementById("quicklinks").getBoundingClientReccot().height;
  if (ht-lg>0) header.classList.remove("minimized");
  else header.classList.add("minimized");
  
  var sel=header.getElementsByClassName("selected")[0];
  if (sel) sel.classList.remove("selected");
  
  var urlArr=window.location.href.split("#"),
      h2s=document.getElementsByTagName("h2"),
      offs=document.body.scrollHeight-document.body.scrollTop-window.innerHeight;
  for (var i=h2s.length-1;i>=0;i--){
    if (h2s[i].getBoundingClientRect().top-ql<=0||!i||offs<20){
      header.getElementsByTagName("a")[i].classList.add("selected");
      break;
    }
  }
};

var xhr=new XMLHttpRequest();
xhr.onreadystatechange=function(){
  if (this.readyState==4&&this.status==200){
    var data=JSON.parse(xhr.responseText);
    for (var i in data){
      createBookBox(data[i]);
    }
  }
};
xhr.open("GET","https://picturelements.github.io/textfiles/bookmarklets.json",true);
xhr.send();