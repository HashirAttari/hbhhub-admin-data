# Toggle Adobe (II)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/RwOwXda](https://codepen.io/alvaromontoro/pen/RwOwXda).

Inspired by Adobe Stock #568462078
https://stock.adobe.com/images/realistic-toggle-switch-buttons-icon-on-and-off-green-and-gray-switch-interface-button-set-with-shadow-template-design-for-web-ui-ux-mobile-app-3d-vector-illustration/568462078