# Daily UI #20 | CSS loader 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/VjjJey](https://codepen.io/havardob/pen/VjjJey).

