# Circle Bar Chart

A Pen created on CodePen.io. Original URL: [https://codepen.io/frankieali4/pen/DeyjKj](https://codepen.io/frankieali4/pen/DeyjKj).

Animated circle bar chart created with D3.