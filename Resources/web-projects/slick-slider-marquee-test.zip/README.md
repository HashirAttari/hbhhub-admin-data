# Slick Slider Marquee Test

A Pen created on CodePen.io. Original URL: [https://codepen.io/michaelsmyth94/pen/wMJLaj](https://codepen.io/michaelsmyth94/pen/wMJLaj).

This is a test of a marquee slider using the popular Slick Carousel.