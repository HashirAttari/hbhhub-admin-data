# pencils - gradients only

A Pen created on CodePen.io. Original URL: [https://codepen.io/MarkBoots/pen/gOJmWRZ](https://codepen.io/MarkBoots/pen/gOJmWRZ).

