# Cute Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/larirabello/pen/qwGrgK](https://codepen.io/larirabello/pen/qwGrgK).

