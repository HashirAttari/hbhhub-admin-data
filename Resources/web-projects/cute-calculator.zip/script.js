$(document).ready(function() {
  
  var calc = $('#calculator');
  var buttons = calc.find('button');
  
  let num1 = '';
  let num2 = '';
  let operator = '$';
  let result = 0;
  
  buttons.on('click', (e) => {
    const key = e.target.value;    
    const screen = $('#result');
    //screen.html('0')
    
    switch (key) {
      case '+':
      case '-':
      case '*':
      case '/':
        operator = key;
        break;
      case '=':
        const n1 = parseInt(num1);
        const n2 = parseInt(num2);
        
        switch (operator) {
          case '+':
            result = n1 + n2;
            break;
          case '-':
            result = n1 - n2;
            break;
          case '*':
            result = n1 * n2;
            break;
          case '/':
            result = n1 / n2;
            break;
        }
        
        operator = key;
        
        break;
      case 'ac':
          num1 = '';
          num2 = '';
          operator = '$';
          result = 0;
        break;
      default:
        if (operator === '+'|| operator === '-' || operator === '*' || operator === '/') {
          num2 = num2 + key;
        } else {
          num1 += key;
        }
    }
    
    if (operator === '=') {
      screen.html(result);
    } else if (operator === '$') {
      screen.html(num1);
    } else {
      screen.html(num2);
    }
  });
 
});