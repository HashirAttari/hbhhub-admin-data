const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let particleArray = [];

let particleSize = 5;
        
let offsetX = 0;
let offsetY = 0;

let spacingX = 10;
let spacingY = 10;

let mouse = {
    x: null,
    y: null,
    radius: 50
}

function onMouseMove(evt) {
    const e = (evt.touches && evt.touches[0]) || evt;    
    mouse.x = e.clientX;
    mouse.y = e.clientY;
}

function onMouseLeave(evt) {
    mouse.x = null;
    mouse.y = null;
}

const body = document.body;

body.addEventListener('mousemove', onMouseMove);
body.addEventListener('touchmove', function(e) {
    e.preventDefault();
    e.stopPropagation();
    onMouseMove(e);
}, {passive: false});

body.addEventListener('mouseleave', onMouseLeave);
body.addEventListener('touchend', onMouseLeave);
body.addEventListener('touchcancel', onMouseLeave);

function drawImage() {
    let imageWidth = png.width;
    let imageHeight = png.height;
    
    const data = ctx.getImageData(0, 0, imageWidth, imageHeight);
    ctx.clearRect(0, 0, imageWidth, imageHeight);
    
    offsetX = (innerWidth / 2) - ((imageWidth * particleSize) / 2);
    offsetY = (innerHeight / 2) - ((imageHeight * particleSize) / 2);
    
    class Particle {
        constructor(x, y, color, size) {
            this.x = offsetX + x;
            this.y = offsetY + y;
            
            this.color = color;
            this.size = size;
            
            this.baseX = this.x;
            this.baseY = this.y;
            
            this.density = ((Math.random() * 10) + 2);
        }
        
        draw() {
            ctx.beginPath();
            //ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.rect(this.x, this.y, this.size, this.size);
            ctx.closePath();
            ctx.fill();
        }
        
        update() {
            ctx.fillStyle = this.color;
                
            let dx = mouse.x - this.x;
            let dy = mouse.y - this.y;
            
            let distance = Math.sqrt(dx * dx + dy * dy);
            
            let forceDirectionX = dx / distance;
            let forceDirectionY = dy / distance;
            
            var maxDistance = 50;
            var force = (maxDistance - distance) / maxDistance;
            
            if(force < 0)
                force = 0;
            
            let directionX = (forceDirectionX * force * this.density) * 0.9;
            let directionY = (forceDirectionY * force * this.density) * 0.9;
            
            if((distance < mouse.radius + this.size) && (mouse.x !== null || mouse.y !== null)) {
                this.x -= directionX;
                this.y -= directionY;
            }
            else {
                if(this.x !== this.baseX) {
                    let dx = this.x - this.baseX;
                    this.x -= dx / 5;
                }
                if(this.y !== this.baseY) {
                    let dy = this.y - this.baseY;
                    this.y -= dy / 5;
                }
            }
            
            this.draw();
        }
    }
    
    function init() {
        particleArray = [];
        
        for(let y = 0; y < data.height; y++) {
            for(let x = 0; x < data.width; x++) {
                let index = (y * 4 * data.width) + (x * 4);
                let r = data.data[index + 0];
                let g = data.data[index + 1];
                let b = data.data[index + 2];
                let a = data.data[index + 3];
                
                if(a > 128) {
                    let color = "rgb(" + r + ", " + g + ", " + b + ")";
                    particleArray.push(new Particle(x * (particleSize + spacingX), y * (particleSize + spacingY), color, particleSize));
                }
            }
        }
    }
    
    function animate() {
        requestAnimationFrame(animate);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.fillRect(0, 0, innerWidth, innerHeight);
        
        if(spacingX > 0 || spacingY > 0) {            
            if(spacingX > 0)
                spacingX--;
            
            if(spacingY > 0)
                spacingY--;
            
            init();
        }
        
        for(let i = 0; i < particleArray.length; i++) {
            particleArray[i].update();
        }
    }
    
    init();
    animate();
    
    window.addEventListener('resize', function() {
        canvas.width = innerWidth;
        canvas.height = innerHeight;
        init();
    });
}

var png = new Image();

png.addEventListener('load', function() {
    ctx.drawImage(png, 0, 0);
    drawImage();
}, false);

png.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEYAAABGCAIAAAD+THXTAAAS4klEQVR4nMybCXAU15mA3+tzejSHNIdGxwpJllCkbJZdRYAPMEWIMYoLQjC2ywEnOOAqZ4OT2MtuYjsVfKzXB0VhVwkfwhXCZr02aztb0ga0ZXAKYxksGWHJgERknehEGo2kOXqu7n5vS/Og3elujYQgu/uXaqpnpvvN/73/f//73/+emNraWvCXEQhhmm8xxn+h32VuYFuEwfhqKjglKtsNJLwBSKr2qsyJpINR8RBC16/PdSHBWUQLY0qlhdFSQQi1hAuTBSKp2lMUZcqTBklVV8ejFYTQgsEWgkSlxJRKSzsfJCMVgSHmWhjYtSERAJVBd2EcUWmQjDBkLGlhIIQoJddEdQ1IKozxdf7DKb3XqTwEhtyjgt1IJNUU86daGJKWh7yaOur1IhlhdBc6J0w/nIxzURoe0oj2Yj5OOAeSlmc2K+l8UhvxtFRaVXRBnFhDURS1Ta2V1Asic1KlQzLl0VkJY2yz2RBCyWSSpuk0vjcbEsaYoihZlgVBoCgqEomQdkx55kNFLYCHoig6JQAAp9PZ0NDQ09PjdDoBAPRVUe8xfasTjLHT6ezp6WloaHA6nRhj7YOz9ek1WykNj2ofu93e3t7+yiuv+Hy+V1991ePxqLbSTbg60c5IiqJkZGT4/f5nnnlmfHy8pKSkoqIiHA4TH55N0oQK88e0rmU0DrnmeT4ej+/Zs4eiqLGxsd27d2OMWZbV3Wm0ia4dlmUxxrt37x4fH6co6qWXXorFYjzPq+2k6db5IhnDmhEMAGC3219//fWhoSGEEEXTHR0db7zxhs795hTiurW1tR0dHTRNI4SGhoZqa2vtdjtpx5RKq+HcSNpoZhTyOXH9xsbGo0ePAgDys7Pp1Ofvvfdea2urw+GAEKYnIYpCCB0OR1tb27vvvktaz/d6AQBHjhz5+OOPMzMzSeTQUel6fL5IxufVpiGEPM+Hw+GamhoIoU0QTtbW7nvsMRKFDh8+rPqMqooRiWEY8hXP8++88w6ZkfY99tjJAwdsViuEcP/+/aFQiOf59J1rSkXNZqLZ3I+43KFDh0ZHRzHGex99tKSo6JHvf//B9esxxp81N4+OjgqCoLOJrl/IhSAIIyMjnzU3Y4wf3LDhkfvvLykq2vvzn2OMR0dHDx06RNxPl6OYJi7pkIzZgHEWam9vr6+vBwB8d+XKhzdvnp6ejsdie372swKfLxgKtX7+uSAIiqKQBhmG4TiOTwnHcQzDEA0URbFara2trcFQ6K98vj0//Wk8Fpuemnp48+ZNq1YBAOrr69vb2202m+p+Rvtop3sTJFMYowcyDHPw4EFJktwOx/O7d0/TNANAPJHw+nxbqqsBAE1NTZmZmV6v1+1222w2AEA0Gg2lJBaLAQBsNpvb7fZ6vU6ns7mpCQCwtbram50dlyQGwiBF/fOvf+12OCRJ+u3BgwzDmDpLGirG6HWzXWCMHQ5Ha2sr0eNX27aVL1oUmJjgKArLMkoktlRX733rrTMtLcePH29vb+/s7BwcHJyYmIhEIpIkAQA4jiM8BQUF5eXlFRUVn505Q9P01upqlExihCiGiYni1woKfrVt2z/U1DQ1NbW1tS1ZsoRMUyRV13a99hN1mmJ0VjLCaL2OZdn/qq/HGJcXFW3dti0SCAiJBOa4rKysWDT65aVLAs8PDg7+4Ac/MAYiIn6/v6+vr6WlRf3EbrV29veXFhRkZWWJomhJJqMTE9//4Q9fr6/vHhioq6tbunSpqjRxQvVVB0aoqPmMImJWq9Xa29v7yalTGIAff+97docjLkl2pxNh/Nrhw7f86Ef3Pv54JBqFqda0gUHXuBoDybgOR6P3PvHEzQ8+WPv++zMZidMZkySn0/mTu+/GAJw+daq3t9dqtRqjl070Y8l4h04PhJAgCB8ePx6LxXwuV/Vdd9GBgM9mqz95cuX27Tv37DnX1UWl2sVX0xxFUdTlgHb5gBAi36opDQXh+e7uHz///Irt2+tOnvTZ7XQgcNddd/lcrmgsdvz4cUEQZib0WZabOioTJCMhQshutyOETnz0EQDgW1VVrrKyiCw//Nxz39u161x3NzEIWmhZB6Uciabpc93dm3btevi55yKKklVWtrqqCgDw0YkTqgKmGLq3VHoeNSq43e62tra+vj6W4+556KHJgYF1Dz10oK6O+BYxyMJ4rlClTDcDRlEH6urW7dgRGBi4d8cOhmX7+vtbW1vdbrfD4SCjaG4rpTElSbcBhOFQ6NTHH9+2YkXDH/6w2O2uvu++ls5OlmFmSBCiAdD+pUuhNUL9+VM0IUOIZZiWzs7v3HffYo+n4ciRW2+77VRjYzgUghDa7XZd3DOuo2FtbS2ZbUwzFwhhbm7uZCDAcJxfFAMDA39saDjT1HTJ72doGqc6FkAIMAaqlcgnCNEYK7PA0AAoEM7caXwQYxohSNOyohR6vctuvfVb69Z5Cguz7XY5mXS5XCRrURRFlmV1WKoy45y1tbWzJf/k2paRIdjtfCxW98QTTzU2XtEJQqKugPHfAlAGQDYALEXFEBoBoB2ADgAwRUFSD9HAEOfAFAUQ+gYAXwcgDwCBoiSExgH4EoAvAIilOnsG++rgfPb22ze+8ELCao2FQhFR1JHo3jLG/Fw3lqLRKEVRZ7u65MbGdRB+QFEcQkkAbBj/CIB1FRWeW27hKiq4/HzI81gU4319yfPnLzU1vTc8/J9/vkaHAOCUHe5B6J68vEW33sovWcIVFlI2G04kksPDyY6Oiebm/7548V8BiEDIQZikqHUISY2Np7/88hulpWI0OlvBUFWeSfO1ehfHcX6/fy+E+yHsVJR+CMsx/pfs7OwdO8aWLg3k5uZkZyMAGIqWkYJuuWVs1Sph8+Z/OnZs9dtv/yqZjEBIk7IJhHaMn+P55Vu2jK9dO5aTk5+fj2acgVbQTEwPrFgRX7/+/rNnv/2b3zw5Pv4nCIsU5T6KegSAJ8fHua9/fbbdA33EM36n/5CigmNjMYxrIHwUwkKMX/D5kr/8ZXNZWTwWW5yV5VQQjEeHL3cJsuyGsCQzc0wUT69dW/rII89yHE6NHAVCDMCzPL94585P77hjNBIpycx0QyhI8vDlLhiPOhFe7HIl4vHmsrLEL37xos+3CONHIayBMIbx9OXL0LCOMLWEeXAyxpMxvx8C0AbAhwAchHBs/fp2CMXu7uLiYostg+cFf2yisfeTJJAphnX7fNlud/D8+VNFRSWrVm3AeDmEyyHcgHHJypWnioqmz5/3eTxun49i2CSUG3s/8ccmeF4QbLai4mKxu7uDoi5v2PBbCD9M/SgEYGxiQltvmtWn5qzjqUXdqakpnIoKRzDenJnZb7dH+vqsguDxeCCEFotlMjY5HBqOSBGP3QMY4PF6A8EgJctf5OU9DOEHqTixDoDP8/NDAwNIFN0eD83QAhDGxLHh0PBkbNJiscTluMfjESUp1t8v2Wy8w3EkGCShaEaBq8qk13leBWSE0PT0NCGkAIggFAgERIwT8TjDMCzL8gyfQAm/6McQsxwL6JlH/BMTMB7PnJ5upKiaVDtWANjp6XGaBpEISYIBBTDEftGfQAme5RWoMAwzNTUlxmJxCCOpnyMM09PT85zN09XxVBPLsiyKIgkmCICeUMhz4UJfINDV0dHf32+z2SAF7YJ9IjrhdrjJMvHixYsTo6NDwaC3vf2EooDU30eKkt3ePhgM+kdG/nTxot02M2+6He6J6IRdsEMK2my2/v7+7o6OvkDAc+FCTyiEUr0OIRRFUZblNP42t5USiYSafSQSiYKCApZlaYpSMO5C6F6WHbLZOhWlvq5u9cqVFM9WFVfuXPOTHHu2PdPZ39v71jvvDErS+o4O69jYorVryxkGQCgmk8Knn1ay7BGH498PH153552FxcVckNm55idVRZU2m1XBcl1dnZiRUW6zfU0Q3l26dBlFzTgeQjk5OZOTk7Isk3mWTJ6mTggPHDgw2yRL6h6k9LFly5bLly+rj5Xw/NMZGV2FhX/MyLjpm9+8Z9Omyr9Z4nO5JAiaTp/+x127Qv3922laHh4euvPON197DaT8FjidD+3cuejYMTo//6AsO4qL9+zde9uKFQwCY5OBtgvn3/v973vb2tZEImWXLj0jij3JpPqLOTk5b7/9tqIokiSZzrDq2xmk2aq7xHfJty+//PLo6ChFUZIkyclkOB63RaP3RKO5GLfLcsBuz12yhBIs5bl5X/T1WYaHvzk5+UEweBiAzKysloMHfW43SEWtZTt2TE1N3Q/Auqyssy6XnJtbUVjYeXkUJpKj5865QqFvMMwYhO9mZESsVrvFQrMzglJWeixVh1K1UswEIcTobKfbliOORwr5Q0NDpBjCsqyV56HD8R88fxNFVQHw14kENTAgxeP+pmbK4WjPzDxTWnpZlhdNTg4ODT395pv/9vzzAIC/f/HFUDBYVFj4mcvVR1HWaLS8t3eyra1EEBhBKM3PH77ppjqM+zBm4nEhHo9Eo5IkYYxlWc7JybHb7aFU8mq6vavqzxgxvvoulcuSorvP57NYLDzPk3tkRVFEEUYiHQC0pBInjmUZi4X2eimMbTTNJJMels0oLo7GYm81NDyQqrS81dCQm5u7qLBQDIfFRCLMst2ZmYrTiWRZVpSkKOJw2IoxD0AiFQPYlNuTwez1etXhQHxMN4RU/RlTEymKkkwm1WU2wzDLli07c+YMKVaRpRgp8Fpo2sMwLPNVrhhPJpcUFfmnpkYDAQTA18rKwpHInt/9DmOcYbPdVFwcCYdj8Xiu2+3NzDzX3S3wPE6VxYk1JEWRUy5E9KFTqwSO45YvXy6KYjweV5fGJDwY6/2M7jDFlcmHokjNjXQMx3ElJSUjIyOkajWbUBRFLAkQ+s6KFYN+/+Xx8ZGhIZ7jKoqKMACfXrhw6vTpgsJCjmX/bvHihk8+GZuYiKck/QQqCEJJSQnHcVarlZiIrCzUjSYtAr1hwwbTVaB2k1ySpOzs7EAg0NHRwTCMsfikJtySJMXj8YlAICaKSwoLk/H4Ip/v28uWHWtu7hoc/O6qVRzLWmh6yaJFZ86fv9DVFY/HZVnW1qd0yjCpVebdd9+9du3aYDCo7peptiJv1et0SDoBABQWFh49epRoYNzS05lrNBAYm5ryZmUhjE+2to5PTk5HIt1DQ57MTJZhznZ29g4PU6lEVuf52rfkdy0Wy5NPPslxHJmUtAxGtq+QTKm0H8qynJeXhxBqaWkhPZfGT4gZxVhsaHx82O9PShJpJJFMDvv9Q+Pj0Xh8PtkaiQTbt29fvXp1OBzW7kDPZqKvEiLTzXrtBYRwenp669atlZWVsiyTraE5qa4EmKvtQ81G9Xx4FEWprKzcunVrMBjU8aSJ45RWCa1ZjW/JuHzqqafy8vIURZkP1RUl1E+u1Evm3ugnPHl5eU8//TSJsUZldF2vPkvpNDA1FLkGAMRiMZfLtW/fvtzc3PlQLUwIT25u7r59+7KyskiYTUOVDsnUMlpzk038/Pz8mpqa8vJykj6m3ye+JqGuVgXLy8tramry8/MjkQip9ZryaF9NkIwjSkdFHA9CGA6HvV7v/v37N27cqM561wmmpgUIoY0bN9bU1Hi9XhIStIVo01ddrPoq4qliPCijXaKQQS9JEk3Td9xxR1lZWV9fXyAQUDe2romEbAioh6BKS0sff/zxBx54QJKkRCKhhgSdGH1P26Z+vaQmO+qpF3UgafHIeZKpqanbb7996dKlx44de//997u7u7XYpudWtSUeohDJfUpLSzdt2lRdXW21WskKGmhiiRbGaCV9NxlPIJOe0+2rqm/VftVuOjkcDlEUW1paTpw4cfbs2bGxsXlayefzVVVVrVmzpqqqKiMjIxQKSalJTKUlrzorqZ+QG+ZG0h5NSX+SQvU0ApaRkUHT9OTkZE9PT2dnZ1dX18jIyNTUlCiKydRijtzjcrny8vJKS0vLy8tLSkpcLlcqrRclSdJGgjSihTQqb75QN3U5o1yZQFMWUxSFTIgcx1VWVt58881qypdIJIh30TTN87zFYmFZFkKYTCYTiYRa+tGOnPRUplFhDqT5nG/W7TGqaa6UEhV1ZgFisajGRAiJqaI2uUH7c7qcbU5bzabYrEhpTER+WMdjukeiTf7JJ6rrGxenxtGfBixNX6er45lSEQCjlWbL31UAbVNzHqc2ne61jrdAJG2WZMqjdrbpQVDjzGZ6sFWXXuoujLa6AdVW9aym0T6qcXSGMm4XqNdznm1Nn5TdmOO66kFAU39TVwqmay0dzzUd5U+f9VwvEhHVUPMcRaZ7QfNBSp+V3kgkrbl0PMSApseP53OaX50zTH3vmjRc4P9cqBOxGhXUbZLZwoMRSVfWMR1R/3v/RqLNG0wdj9yjixDGx3VgOlmYYtf7/0vqb89zIGkfnG04XY8+RG7MP87p2K4V6f/dP85pRdvT/1f/3vg/AQAA///FP1EP0mDOtwAAAABJRU5ErkJggg==";