# Interactive Image made out of Particles (no Library used!)

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/qBRWWyX](https://codepen.io/agalliat/pen/qBRWWyX).

