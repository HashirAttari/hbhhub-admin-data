# meo's transition/easing sandbox

A Pen created on CodePen.io. Original URL: [https://codepen.io/meodai/pen/bBVYBb](https://codepen.io/meodai/pen/bBVYBb).

the pen I use to explore different kind of bezier functions.