document.querySelectorAll('.box').forEach(e => e.addEventListener('click', e => e.preventDefault()));


const $boxes = document.querySelector('.js-boxes');

document.querySelector('.js-select').addEventListener('change', e => {
  const effect = e.target.value;
  const $visible = $boxes.querySelector('.box--visible');

  if ($visible) {
    $visible.classList.remove('box--visible');
  }

  if (effect === 'all') {
    $boxes.classList.remove('show-single');
  } else {
    $boxes.classList.add('show-single');
    $boxes.querySelector('.' + effect).parentElement.classList.add('box--visible');
  }
});