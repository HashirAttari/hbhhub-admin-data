# Ghost Button Hover Effects

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/xyKNqw](https://codepen.io/markmead/pen/xyKNqw).

Hover effects for ghost buttons (buttons without a background)