# Animated Gauge Chart

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/zYKXxrb](https://codepen.io/kitjenson/pen/zYKXxrb).

