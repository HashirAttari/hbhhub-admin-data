# CSS Gears (2)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/MWRMmRz](https://codepen.io/amit_sheen/pen/MWRMmRz).

