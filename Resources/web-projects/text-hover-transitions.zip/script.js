$('h2').on("touchstart",function (){
  //simply starts listening for touchstart - allows for hover state on touch devices
});