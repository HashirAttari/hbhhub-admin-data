# Directionally aware Pure CSS button hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/LJMxWL](https://codepen.io/jcoulterdesign/pen/LJMxWL).

Directionally aware hover button with just css using segments and hover state checks