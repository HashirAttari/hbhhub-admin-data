# Dropdown without JavaScript

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/KKqYGYj](https://codepen.io/havardob/pen/KKqYGYj).

A  different take on another pen I've created (https://codepen.io/havardob/pen/vYyVXRK), but this time designed to look like this Dribbble shot: https://dribbble.com/shots/14114013-BlueReceipt-Design-System-Dropdown/attachments/5736330?mode=media