# flying heart envelope CSS animation

A Pen created on CodePen.

Original URL: [https://codepen.io/cornetespoir/pen/QaVXob](https://codepen.io/cornetespoir/pen/QaVXob).

A flying love letter for valentine's day