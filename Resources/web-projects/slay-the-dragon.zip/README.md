# Slay the Dragon! 🐉

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/KKeqErj](https://codepen.io/kitjenson/pen/KKeqErj).

Decided to try my hand at creating the Angry Birds mechanic in Vanilla JavaScript. 

The finale battle from Disney's Sleeping Beauty felt an appropriate setting to make this more fun.