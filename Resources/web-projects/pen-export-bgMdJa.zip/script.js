var cssColors=[["Pink","LightPink","HotPink","DeepPink","PaleVioletRed	","MediumVioletRed"],["LightSalmon","Salmon","DarkSalmon","LightCoral","IndianRed","Crimson","FireBrick","DarkRed","Red"],["OrangeRed","Tomato","Coral","DarkOrange","Orange	"],["Yellow	","LightYellow","LemonChiffon","LightGoldenrodYellow","PapayaWhip","Moccasin","PeachPuff","PaleGoldenrod","Khaki","DarkKhaki","Gold"],["Cornsilk","BlanchedAlmond","Bisque","NavajoWhite","Wheat","BurlyWood","Tan","RosyBrown","SandyBrown","Goldenrod","DarkGoldenrod","Peru","Chocolate","SaddleBrown","Sienna","Brown","Maroon"],["DarkOliveGreen","Olive","OliveDrab","YellowGreen","LimeGreen","Lime","LawnGreen","Chartreuse","GreenYellow","SpringGreen","MediumSpringGreen","LightGreen","PaleGreen","DarkSeaGreen	","MediumAquamarine","MediumSeaGreen","SeaGreen","ForestGreen","Green","DarkGreen"],["Aqua","Cyan","LightCyan","PaleTurquoise","Aquamarine","Turquoise","MediumTurquoise","DarkTurquoise","LightSeaGreen","CadetBlue","DarkCyan","Teal"],["LightSteelBlue","PowderBlue","LightBlue","SkyBlue","LightSkyBlue","DeepSkyBlue","DodgerBlue","CornflowerBlue","SteelBlue","RoyalBlue","Blue","MediumBlue","DarkBlue","Navy","MidnightBlue"],["Lavender","Thistle","Plum","Violet","Orchid	","Fuchsia","Magenta","MediumOrchid","MediumPurple","BlueViolet","DarkViolet","DarkOrchid","DarkMagenta","Purple","Indigo","DarkSlateBlue","SlateBlue","MediumSlateBlue"],["White","Snow","Honeydew","MintCream","Azure","AliceBlue","GhostWhite","WhiteSmoke","Seashell","Beige","OldLace","FloralWhite","Ivory","AntiqueWhite","Linen","LavenderBlush","MistyRose"],["Gainsboro","LightGray","Silver","DarkGray","Gray","DimGray","LightSlateGray","SlateGray","DarkSlateGray","Black","Transparent"]];
createColorboxes();
createPixels();

var currentCol="Transparent",prevColElem=document.querySelector("div[title='Transparent']"),clicked=false,erase=false,linked=true,animated=true,onion=true;
var draw=document.getElementById("drawarea"),size=0,frame=0;
prevColElem.classList.add("selected","raster");

draw.addEventListener("mousedown",function(event){
  if (event.target.className.includes("frame")){
    erase=event.which==3;
    event.target.style.background=erase?"Transparent":currentCol;
    if (frame==0&&linked){event.target.nextSibling.style.background=erase?"Transparent":currentCol;}
    clicked=true;
  }
});

draw.addEventListener("mousemove",function(event){
  if (clicked&&event.target.className.includes("frame")){
    event.target.style.background=erase?"Transparent":currentCol;
    if (frame==0&&linked){event.target.nextSibling.style.background=erase?"Transparent":currentCol;}
  }
});

draw.addEventListener("mouseup",function(event){
  clicked=false;
});
//alert(cssColors.length);

function createColorboxes(){
  for (var i in cssColors){
    var bx=document.createElement("div");
    bx.className="boxcontainer";
    for (var j in cssColors[i]){
      var cb=document.createElement("div");
      cb.className="colorbox";
      cb.style.background=cssColors[i][j];
      cb.title=cssColors[i][j];
      bx.appendChild(cb);
    }
    document.getElementById("selectionbox").appendChild(bx);
  }
}

function createPixels(){
  var da=document.getElementById("drawarea");
  var rect=da.getBoundingClientRect();
  var rows=Math.ceil((rect.height/rect.width)*50);
  for (var i=0;i<rows*50&&i<7500;i++){
    var pixel=document.createElement("div");
    pixel.className="pixel";
    var f1=document.createElement("div");
    f1.className="frame1";
    var f2=document.createElement("div");
    f2.className="frame2";
    pixel.appendChild(f1);
    pixel.appendChild(f2);
    da.appendChild(pixel);
  }
}

function selectCol(evt){
  if (evt.target.classList.contains("colorbox")){
    evt.target.classList.add("selected");
    currentCol=evt.target.title;
    prevColElem.classList.remove("selected");
    prevColElem=evt.target;
  }
}

function toggleFrames(elem,id){
  document.body.setAttribute("show",id);
  frame=id;
  setButtons(elem,id);
}

function setSize(evt){
  size=parseInt(evt.target.getAttribute("size"));
  setButtons(evt.target,size);
}

function toggleLinked(elem){
  linked=!linked;
  elem.setAttribute("state",linked);
}

function toggleAnimated(elem){
  animated=!animated;
  elem.setAttribute("state",animated);
}

function toggleOnion(elem){
  onion=!onion;
  elem.setAttribute("state",onion);
  document.body.setAttribute("onion",onion);
}

function clearAll(){
  document.getElementById("drawarea").innerHTML="";
  createPixels();
}

function setButtons(elem,index){
  var btns=elem.parentElement.getElementsByClassName("btn");
  for (var i=0;i<btns.length;i++){
    btns[i].classList.remove("active");
  }
  btns[index].classList.add("active");
}

function genCode(){
  var f1=document.getElementsByClassName("frame1"),f2=document.getElementsByClassName("frame2");
  var minX=50,maxX=0,minY=Infinity,maxY=0;
  for (var i=0;i<f1.length;i++){
    if (isFilled(f1[i])||isFilled(f2[i])){
      if (i%50<minX){minX=i%50;}
      if (i%50>maxX){maxX=i%50;}
      var div=Math.floor(i/50);
      if (div<minY){minY=div;}
      if (div>maxY){maxY=div;}
    }
  }
  if (minY==Infinity){alert("No pixels painted"); return;}
  var resultStr=duplicate(size,"#####smaller\n");
  resultStr+="####start image\n\n";
  for (var y=minY;y<=maxY;y++){
    var offs=y*50;
    var count=0;
    var prev=toIdString(f1[offs+minX],f2[offs+minX]);
    for (var x=minX;x<=maxX;x++){
      var id=toIdString(f1[offs+x],f2[offs+x]);
      if (id!=prev){
        resultStr+=genStr(f1[offs+x-1],f2[offs+x-1],count,false);
        count=1;
        prev=id;
      }else{
        count++;
      }
    }
    resultStr+=genStr(f1[offs+maxX],f2[offs+maxX],count,true)+"\n\n";
  }
  resultStr+="####end image";
  console.log(resultStr);
}

function isFilled(elem){
  return elem.style.background!=""&&elem.style.background!="transparent";
}

function areSame(elem,elem2){
  return elem.style.background==elem2.style.background&&(isFilled(elem)||isFilled(elem2));
}

function toIdString(elem,elem2){
  return getColor(elem)+"-"+getColor(elem2);
}

function genStr(elem,elem2,count,ignoreTrans){
  if (toIdString(elem,elem2)=="transparent-transparent"&&ignoreTrans){return "";}
  if (areSame(elem,elem2)||!animated){
    return "["+duplicate(count,"..")+"](//"+getColor(elem)+")";
  }else{
    return "["+duplicate(count,"..")+"](//"+getColor(elem)+" /to_"+getColor(elem2)+")";
  }
}

function getColor(elem){
  var col=elem.style.background;
  if (isFilled(elem)){return col;}
  return "transparent";
}

function duplicate(count,str){
  var res="";
  for (var i=0;i<count;i++){
    res+=str;
  }
  return res;
}