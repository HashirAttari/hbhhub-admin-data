# #Codevember - Day 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/GpBvME](https://codepen.io/giana/pen/GpBvME).

Celebrating 100 followers. Thanks so much!