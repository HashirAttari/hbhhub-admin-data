# Image Slider with Masking Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/pasaribu/pen/JXrjXK](https://codepen.io/pasaribu/pen/JXrjXK).

The animation idea is to change the value of CSS clip path, thus make a masking effect. Works great on chrome and opera. There's some issue with Safari and Firefox doesn't support CSS Clip Path yet.