$(document).ready(function () {

    var expression = "";

    $(".on-off").click(function () {
      if ($(this).data("enabled") == false) {
        $(this).data("enabled", true);
        turnOnCalc();
        $(".flash").show();
        $(this).toggleClass('on-off-glow');
      } else {
        $(this).data("enabled", false);
        turnOffCalc();
        $(".flash").hide();
        $(this).toggleClass('on-off-glow');
      }
    });

    function turnOnCalc () {
      $(".num-keys").on("click", function() {
        $(this).addClass('num-keys-glow');
        var entry = $(this).html();
        expression += entry;
        $(".display-output").html(expression); 
      });

      $("#clear-all").click(function () {
        $(".display-output").html(""); 
        expression = "";
        $(".num-keys").removeClass('num-keys-glow');
      });

      $("#enter-button").click(function () {

        $(".num-keys").removeClass('num-keys-glow');

        try {
            eval(expression); 
        } catch (e) {
            if (e instanceof ReferenceError) {
               $(".display-output").html("Error"); 
               expression = "";
            }
            if (e instanceof SyntaxError) {
               $(".display-output").html("Error"); 
               expression = "";
            }
        }
        $(".display-output").html(eval(expression));

        expression = "";

      });
    }

    function turnOffCalc () {
      $(".num-keys").off('click');
      $(".num-keys").removeClass('num-keys-glow');
      $(".display-output").html(""); 
      expression = "";
    }
    
    


    
  });