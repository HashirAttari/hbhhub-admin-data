# Kawaii Sun | Sun & Cloud Animation 

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/rNmzxWE](https://codepen.io/yudizsolutions/pen/rNmzxWE).

We have made kawaii sun and cloud and gave animation effect. Weather cloud and sun are made using pure Html & CSS, without using any images. 

We have taken reference from this dribble shot:-
https://dribbble.com/shots/6171153-Kawaii-Sun

Made by Kinnari Vasavada from Yudiz