# CSS Toggle Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/GRegoaL](https://codepen.io/jh3y/pen/GRegoaL).

