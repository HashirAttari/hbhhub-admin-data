# Fidget Spinner Loader SVG

A Pen created on CodePen.io. Original URL: [https://codepen.io/leimapapa/pen/JjVVzLr](https://codepen.io/leimapapa/pen/JjVVzLr).

