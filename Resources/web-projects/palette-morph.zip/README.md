# Palette Morph

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/dyMQQGW](https://codepen.io/chrisgannon/pen/dyMQQGW).

One of the UI designers in the team I am working with put these gorgeous circular palettes together as colour shade assets. So I animated them.