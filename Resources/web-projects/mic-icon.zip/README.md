# Mic Icon 

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/OJmxepL](https://codepen.io/chrisgannon/pen/OJmxepL).

A simple mic icon that uses the glowing strikethrough for both on and off states.

