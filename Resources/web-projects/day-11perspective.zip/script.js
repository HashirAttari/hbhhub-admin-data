/*
Designed by: Valentin Kirilov
Original image: https://dribbble.com/shots/2859750-Tour-de-France
*/