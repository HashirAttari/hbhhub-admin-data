# Mobile Flavor

A Pen created on CodePen.io. Original URL: [https://codepen.io/yoann-b/pen/wvEjbKG](https://codepen.io/yoann-b/pen/wvEjbKG).

