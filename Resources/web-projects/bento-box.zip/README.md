# Bento Box

A Pen created on CodePen.io. Original URL: [https://codepen.io/stoumann/pen/GRzWVjZ](https://codepen.io/stoumann/pen/GRzWVjZ).

