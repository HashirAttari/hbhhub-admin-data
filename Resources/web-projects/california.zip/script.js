/*
Designed by: Anthony Gribben
Original image: 
https://dribbble.com/shots/7806331-Nighttime-Camping-Illustration
*/