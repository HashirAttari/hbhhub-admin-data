# Random Donut Generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/oxwaLj](https://codepen.io/giana/pen/oxwaLj).

A quick and super badly coded doughnut generator. This had been sitting in my drafts forever until I realized today is national donut day.