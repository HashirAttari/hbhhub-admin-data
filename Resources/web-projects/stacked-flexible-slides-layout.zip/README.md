# Stacked flexible slides layout

A Pen created on CodePen.io. Original URL: [https://codepen.io/KamilDyrek/pen/rPKOaV](https://codepen.io/KamilDyrek/pen/rPKOaV).

This example illustrates how to create layout of slides stacked on each  other (especially useful for fade in/out transitions). It's achieved without setting their height and avoiding position: absolute; so they are fully flexible and easy to keep in normal page flow.