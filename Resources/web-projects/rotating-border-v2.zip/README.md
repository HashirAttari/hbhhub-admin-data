# Rotating border v2

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/ZEqwErj](https://codepen.io/cbolson/pen/ZEqwErj).

