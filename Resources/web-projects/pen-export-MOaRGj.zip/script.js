var c=document.getElementById("canv"),
		ctx=c.getContext("2d"),
		out=document.getElementById("out"),
		stepL=5,
		p=100,
		r=50,
		opacity=0.05,
		walkerStack=[];

function initWalker(){
	ctx.strokeStyle="black";
	w=window.innerWidth;
	h=window.innerHeight;
	c.width=w;
	c.height=h;
	new Walker(w/2,h/2,Math.random()*2*Math.PI,0,2);
	setInterval(paint,30);
}

function Walker(x,y,deg,hue,speed){
	this.x=x;
	this.y=y;
	this.deg=deg;
	this.hue=hue;
	this.speed=speed;
	this.avgWidth=0;
	
	this.spawn=function(delta){
		this.deg-=delta/2;
		new Walker(this.x,this.y,this.deg+delta/2,this.hue,this.speed);
	};
	
	this.dispose=function(){
		this.kill=true;
	};
	
	walkerStack.push(this);
}

function relayStep(){
	for (var i=0;i<4;i++)
		step();
}

function paint(){
	ctx.fillStyle="rgba(0,0,0,"+opacity+")";
	ctx.fillRect(0,0,w,h);
	for (var i=0;i<walkerStack.length;i++){
		var wa=walkerStack[i];
		for (var j=0;j<wa.speed;j++)
			step(wa);
	}
	
	//clear stack
	for (var i=0;i<walkerStack.length;i++){
		if (walkerStack[i].kill){
			walkerStack.splice(i,1);
			i--;
		}
	}
}

function step(wa){
	var xC=Math.cos(wa.deg)*stepL,
		yC=Math.sin(wa.deg)*stepL,
		xO=0,
		yO=0,
		deg2=wa.deg;
	
	if (wa.x<p)
		xO=p-wa.x
	else if (wa.x>w-p)
		xO=(w-p)-wa.x;
	
	if (wa.y<p)
		yO=p-wa.y
	else if (wa.y>h-p)
		yO=(h-p)-wa.y;
	
	if (xO||yO)
		wa.deg=Math.atan2(yC+yO/r,xC+xO/r);
	
	wa.deg+=Math.random()*0.8-0.4;
	wa.avgWidth=(wa.avgWidth*3+Math.abs(deg2-wa.deg))/4
	var lw=Math.min(1+wa.avgWidth*10,40);
	ctx.lineWidth=lw*Math.pow((40-lw)/35,2);
	ctx.strokeStyle="hsl("+wa.hue+", 100%, 50%)";
	ctx.beginPath();
	ctx.moveTo(wa.x,wa.y);
	wa.x+=Math.cos(wa.deg)*stepL;
	wa.y+=Math.sin(wa.deg)*stepL;
	ctx.lineTo(wa.x,wa.y);
	ctx.stroke();
	wa.hue=(wa.hue+1)%360;
}

initWalker();