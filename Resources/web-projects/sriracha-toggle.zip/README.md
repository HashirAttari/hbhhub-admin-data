# Sriracha Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/cobra_winfrey/pen/GyPZoR](https://codepen.io/cobra_winfrey/pen/GyPZoR).

Yeah it's another food toggle, in pure html/css. Perhaps it's time to retire the format but it's just too fun. H/T @chrisgannon