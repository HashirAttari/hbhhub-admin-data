# fractal leaves

A Pen created on CodePen.io. Original URL: [https://codepen.io/yukulele/pen/zYXmQyj](https://codepen.io/yukulele/pen/zYXmQyj).

