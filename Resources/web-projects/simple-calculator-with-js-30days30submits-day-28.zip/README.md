# Simple Calculator with Js #30days30submits #day-28

A Pen created on CodePen.io. Original URL: [https://codepen.io/Web_Cifar/pen/XWdVgXr](https://codepen.io/Web_Cifar/pen/XWdVgXr).

