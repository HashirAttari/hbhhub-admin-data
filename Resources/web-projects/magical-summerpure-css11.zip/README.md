# Magical Summer - pure css - #11

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/KKVZdPq](https://codepen.io/ig_design/pen/KKVZdPq).

