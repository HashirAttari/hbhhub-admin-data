# Animate Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/Raphael/pen/AjepoX](https://codepen.io/Raphael/pen/AjepoX).

Inspired by the work of Yoann & @musHo