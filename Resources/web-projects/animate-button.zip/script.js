//Animate version of: https://codepen.io/yoannhel/pen/dqKzF

//  Inspired by @musHo
//  http://dribbble.com/shots/350018-Lock-screen