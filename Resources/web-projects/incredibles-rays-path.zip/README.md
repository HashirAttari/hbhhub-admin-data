# incredibles / Rays (path)

A Pen created on CodePen.io. Original URL: [https://codepen.io/wodniack/pen/poOGZoX](https://codepen.io/wodniack/pen/poOGZoX).

Cosmic rainbow rays, for https://incredibles.dev website.