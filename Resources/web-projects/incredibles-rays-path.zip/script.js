/**
 * Rays emitter
 */
class Rays {
  /**
   * Constructor
   */
  constructor () {
    this.container = document.querySelector('.a-rays')
    
    this.width = this.container.clientWidth
    this.height = this.container.clientHeight
    
    this.rays = []
    
    this.init()
  }
  
  /**
   * Init
   */
  init () {
    this.resizeHandler()
    this.bindEvents()
    
    requestAnimationFrame(this.tick.bind(this))
  }
  
  /**
   * Bind events
   */
  bindEvents () {
    window.addEventListener('resize', this.resizeHandler.bind(this))
  }
  
  /**
   * Resize handler
   */
  resizeHandler () {
    this.width = this.container.clientWidth
    this.height = this.container.clientHeight
    
    this.emit()
  }
  
  /**
   * Emit
   */
  emit () {
    this.rays = []
    this.totalRays = this.height * 0.75
    
    for (let i = 0; i < this.totalRays; i++) {
      const ray = new Ray(this)
      this.rays.push(ray)
    }
  }
  
  /**
   * Tick
   */
  tick () {    
    let path = ''
    
    this.rays.forEach(ray => {
      ray.tick()
      
      path += ray.d
    })
    
    this.container.style.clipPath = 'path("' + path + '")'
    requestAnimationFrame(this.tick.bind(this))
  }
}

/**
 * Ray object
 */
class Ray {
  /**
   * Constructor
   */
  constructor (emitter) {
    this.emitter = emitter
    const gap = 12
    
    this.x = Math.random() * this.emitter.width
    this.y = Math.floor(Math.random() * ((this.emitter.height / gap) + 1)) * gap
    
    this.width = 50 * Math.random()
    this.velocity = 0.25 + this.width / 50
    
    this.d = ''
  }
  
  /**
   * Update position
   */
  update () {
    this.x += this.velocity
    if (this.x > this.emitter.width) {
      this.x = -this.width
    }
  }
  
  /**
   * Draw line
   */
  draw () {
    this.d = 'M ' + this.x + ',' + this.y + ' h ' + this.width + ' v 1 h -' + this.width + ' z '
  }
  
  /**
   * Tick
   */
  tick () {
    this.update()
    this.draw()
  }
}

const rays = new Rays()