# smart mouse tracker

A Pen created on CodePen.io. Original URL: [https://codepen.io/meodai/pen/KKrmWbj](https://codepen.io/meodai/pen/KKrmWbj).

