window.addEventListener('pointermove', e => {
  document.documentElement.style.setProperty('--x', e.pageX / window.innerWidth);
  document.documentElement.style.setProperty('--y', e.pageY / window.innerHeight);
});