# infinite text loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/meodai/pen/QWmemNP](https://codepen.io/meodai/pen/QWmemNP).

