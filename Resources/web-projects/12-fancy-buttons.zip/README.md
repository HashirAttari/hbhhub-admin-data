# 12 fancy buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/bartekd/pen/DrmmbB](https://codepen.io/bartekd/pen/DrmmbB).

A little exploration I did for the Tool website (http://toolofna.com/). 12 buttons with a unique rollover effect each using only CSS. Most work on most browsers, but some require tweaking on FF and/or IE. 