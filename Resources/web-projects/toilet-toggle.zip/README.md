# Toilet Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/mdGvGjJ](https://codepen.io/chrisgannon/pen/mdGvGjJ).

The interactive version of Mr Bingo's [The Correct Way](https://shop.mr.bingo/products/the-correct-way-1)