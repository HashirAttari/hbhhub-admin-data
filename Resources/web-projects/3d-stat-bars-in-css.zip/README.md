# 3D Stat Bars in CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/QEyNzj](https://codepen.io/jcoulterdesign/pen/QEyNzj).

Some nice 3D bar charts in pure CSS. Taken design inspiration from the following dribbble. https://dribbble.com/shots/1013895-Fantasy-Soccer-Stats