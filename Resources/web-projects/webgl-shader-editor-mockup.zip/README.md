# WebGL Shader Editor mockup

A Pen created on CodePen.io. Original URL: [https://codepen.io/xgundam05/pen/WbxdxZ](https://codepen.io/xgundam05/pen/WbxdxZ).

Node-based fragment shader editor. Mockup of the UI as the app would be a little too big for codepen. Elements are draggable and re-connectable. Add nodes by right-clicking on grid.

Well, that and as I get into the compilation-to-glsl part...I'm finding out just how much of a pain in the rear end it can be >.>