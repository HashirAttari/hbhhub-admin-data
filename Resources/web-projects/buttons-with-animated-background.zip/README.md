# Buttons with animated background

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/dMdyaX](https://codepen.io/giana/pen/dMdyaX).

Buttons with pattern animation hover effect in CSS.

Check out <a href="https://codepen.io/collection/AObpre/">my button collection</a> for more.

Zigzag pattern from here:
https://lea.verou.me/css3patterns/#zig-zag