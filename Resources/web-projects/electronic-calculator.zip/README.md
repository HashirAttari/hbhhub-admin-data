# Electronic Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/prashcr/pen/yVxbRm](https://codepen.io/prashcr/pen/yVxbRm).

A simple, general-purpose calculator implemented using a handwritten parser (no eval). Works with keyboard input as well.