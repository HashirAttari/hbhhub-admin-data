# AI05: Java

A Pen created on CodePen.io. Original URL: [https://codepen.io/cjgammon/pen/poOGjxE](https://codepen.io/cjgammon/pen/poOGjxE).

Alien Interfaces: 05 - Designed by AI / ML with Midjourney, Adobe Firefly and Figma.

See the process here: 
https://alieninterfaces.com/cases/java.html