# Styled native range input #2 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/ogoXwG](https://codepen.io/thebabydino/pen/ogoXwG).

**February 2020 update description**

Added an extra element for the glow, ditched thumb pseudos (that technique wasn't working anymore), so now there's a cross-browser glow.

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.


See my other styled sliders in [this collection](https://codepen.io/collection/DgYaMj?sort_by=id).

---

**Original description**

Goal: create a nicely styled crossbrowser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling. Fallback for no JS: simply display the same background for the entire track, both before and after the thumb. The pulsing animation when dragging the thumb works only in Chrome. No Firefox, IE or Opera in this case.

---

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. 

Inspired by this Dribbble shot: [Scrubber + Pulse FX](https://dribbble.com/shots/438740-Scrubber-Pulse-FX). 