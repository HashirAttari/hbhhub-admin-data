# Ocean - Codevember #19

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/WXdPQP](https://codepen.io/ainalem/pen/WXdPQP).

Low-poly morph between dolphin and logo