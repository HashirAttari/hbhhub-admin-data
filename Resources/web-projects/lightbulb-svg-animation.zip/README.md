# Lightbulb |  SVG animation 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/xEayMB](https://codepen.io/havardob/pen/xEayMB).

