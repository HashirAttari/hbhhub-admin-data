// Click for Squigglevision

$me = $('.js-me');

$me.on('click', function() {
    $me.toggleClass('isSquiggle');
});