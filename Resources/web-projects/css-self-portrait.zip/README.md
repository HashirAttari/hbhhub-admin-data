# CSS Self Portrait

A Pen created on CodePen.io. Original URL: [https://codepen.io/WithAnEs/pen/wGVOpN](https://codepen.io/WithAnEs/pen/wGVOpN).

Created a css self portrait to see what I could do using just css.