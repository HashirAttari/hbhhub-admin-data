# Styled native range input #8 (updated 2021, no JS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/XJzppz](https://codepen.io/thebabydino/pen/XJzppz).

**May 2021 changes**

* removed Compass and Modernizr, both of which were never needed anyway and somehow has managed to stay in

* removed now useless workarounds for bugs that have been fixed in the meanwhile

* cleaned up and compacted the CSS a bit more

* not providing free support for IE/ pre-Chromium Edge

---

**September 2020 description**

Since CSS got better in the meanwhile and I'd like to believe I did too, I updated the code to use CSS grid, get rid of some redundancy and improve maintainability.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 (weirdish at the ends, thumb gets cut out) on Windows 8.

Inspiration:

![image](http://i.imgur.com/4WXHYIg.jpg) 