# Smart watch - Clock object

A Pen created on CodePen.io. Original URL: [https://codepen.io/MarkBoots/pen/zYbjaoR](https://codepen.io/MarkBoots/pen/zYbjaoR).

