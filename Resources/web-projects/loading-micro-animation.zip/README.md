# Loading Micro Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/khadkamhn/pen/ORVNMW](https://codepen.io/khadkamhn/pen/ORVNMW).

This loader is based on dribbble shot that is build with svg and css.

Dribbble Shot Link:
https://dribbble.com/shots/2887008-Loading-Micro-Animation