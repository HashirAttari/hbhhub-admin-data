# Border transformations

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/zpvQvV](https://codepen.io/yuanchuan/pen/zpvQvV).

 CSS patterns made with transformations on the borders.