document.body.addEventListener('click', update);
document.body.addEventListener('mouseover', update);
  
function update(e) {
  if (e.target.update) {
    e.target.update();
  } 
}