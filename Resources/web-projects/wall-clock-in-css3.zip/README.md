# Wall Clock in CSS3

A Pen created on CodePen.io. Original URL: [https://codepen.io/rassadin/pen/kVeObN](https://codepen.io/rassadin/pen/kVeObN).

Pure CSS3. No scripts. No images. No SVG. 

CSS3 browser testbed is available at
http://rassadin.github.com/css3-experiments/wall-clock/

The wall clock shows current GMT time.
Time is set up with CSS constructed by server.
