# Ferris wheel (CSS only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/bGQgGOx](https://codepen.io/amit_sheen/pen/bGQgGOx).

