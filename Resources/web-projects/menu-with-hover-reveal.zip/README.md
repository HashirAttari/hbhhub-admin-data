# Menu with hover reveal ⚪⚫

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/rNWBXqz](https://codepen.io/havardob/pen/rNWBXqz).

Hover to see the effect