# windows 10 20h1 explorer

A Pen created on CodePen.io. Original URL: [https://codepen.io/nathel/pen/WNvvOLp](https://codepen.io/nathel/pen/WNvvOLp).

A pen inspired by the work of Abrark.  https://codepen.io/AbrarK/full/gwyrRq
with some change in the explorer file and add animation to the user pic.