# SVG Hamburger Menu Icon Animation Collection

A Pen created on CodePen.io. Original URL: [https://codepen.io/matthewmain/pen/NWKoPXJ](https://codepen.io/matthewmain/pen/NWKoPXJ).

A collection of juicy hamburger menu icon animations. SVG manipulations handled with my brand spanking new [AnimateAnythingJS](https://github.com/matthewmain/AnimateAnythingJS) JavaScript library.