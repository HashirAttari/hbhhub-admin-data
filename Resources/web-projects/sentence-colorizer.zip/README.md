# Sentence Colorizer

A Pen created on CodePen.io. Original URL: [https://codepen.io/chriscoyier/pen/LbbxRY](https://codepen.io/chriscoyier/pen/LbbxRY).

- Original tweet: https://twitter.com/lfoulkesy/status/715077404700631041/photo/1
- https://twitter.com/davatron5000/status/799245795287592963
- https://twitter.com/davatron5000/status/799246780324081664
- https://tone-analyzer-demo.mybluemix.net/
- https://gist.github.com/PimDerks/02bc04b7c6ab28683e624027085774e9
- http://codepen.io/brandonbrule/pen/qqqRLZ/
- http://www.hemingwayapp.com/
- https://github.com/DigiExam/ng-annotate-text
- http://codepen.io/acjdesigns/pen/eBBggb?editors=0010
- http://codepen.io/jon-w1/pen/YpNPQr
- http://sanstream.nl/portfolio/visualised-poems/