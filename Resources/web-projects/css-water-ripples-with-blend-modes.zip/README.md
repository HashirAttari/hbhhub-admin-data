# CSS water ripples with blend modes

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/YdwYZG](https://codepen.io/giana/pen/YdwYZG).

There's something dark swimming at the bottom of your pool