# Combination Lock

A Pen created on CodePen.io. Original URL: [https://codepen.io/carsonf92/pen/OGyyGQ](https://codepen.io/carsonf92/pen/OGyyGQ).

A front-end implementation of a four digit combination lock.