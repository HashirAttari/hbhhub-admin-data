document.body.addEventListener('click', function(e) {
  e.target.update && e.target.update();
});

if (!window.customElements || !document.head.attachShadow) {
  document.querySelector('html').className += ' oldie'
}