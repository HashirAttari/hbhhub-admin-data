var el = document.querySelector('.mainwrapper')
el.scrollLeft = 810 - (window.innerWidth*.5);
el.scrollTop = 540 - (window.innerHeight*.5);

window.addEventListener('load', function(){
  document.querySelector('#door').classList.add('open_please')
})