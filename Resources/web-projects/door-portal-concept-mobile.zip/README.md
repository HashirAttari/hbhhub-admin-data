# Door/Portal concept (mobile)

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/oNGjxXP](https://codepen.io/kitjenson/pen/oNGjxXP).

