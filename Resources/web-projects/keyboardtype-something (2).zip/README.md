# Keyboard - Type something

A Pen created on CodePen.

Original URL: [https://codepen.io/ricardoolivaalonso/pen/KKwqLQy](https://codepen.io/ricardoolivaalonso/pen/KKwqLQy).

