# CSS only box-shadow animation, 2022

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/GRyZLWJ](https://codepen.io/giana/pen/GRyZLWJ).

Another spin on my old box-shadow particles
https://codepen.io/collection/DVvwxW