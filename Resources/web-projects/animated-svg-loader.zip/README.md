# Animated SVG Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/thgaskell/pen/KmRjOx](https://codepen.io/thgaskell/pen/KmRjOx).

Saw an oddly satisfying loader gif on reddit and decided to try do it with CSS and SVG!