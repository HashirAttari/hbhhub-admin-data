# Toggle Dead or Alive

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/ExJxpeb](https://codepen.io/alvaromontoro/pen/ExJxpeb).

Inspired by Heath Taskis' CSS Toggle - Dead Or Alive: https://dribbble.com/shots/4610017-CSS-Toggle-Dead-Or-Alive

Also on CodePen: https://codepen.io/fantaskis/pen/XqoqNM

Note: animating background positions is not efficient, I do as part of a small component for this demo, but it is not a good idea to do it at a large scale.