score = 0
const gs = document.querySelector('#game_score')
const gt = document.querySelectorAll('.game_target')
const gc = document.querySelector('#game_console')

function radiusNum() {
  return Math.random()*50 + 'px'
}

const explode = document.querySelector('#explode_balloon')
particles = 25
for(var i=0;i<particles;i++) {
  var p = document.createElement('div')
  p.className = 'particle'
  p.style.borderRadius = radiusNum() + ' ' + radiusNum() + ' ' + radiusNum() + ' ' + radiusNum()
  explode.appendChild(p)
}
var ps = document.querySelectorAll('.particle')

gt.forEach(function(elm){
  elm.addEventListener('click', function(e){
    var respawn = Math.random() < .5 ? 3000 : 1500
    var points = parseInt(elm.innerHTML)
    score += points
    gs.innerHTML = score
    elm.classList.add('dead')

    gc.classList.toggle('shake')
    setTimeout(function(){
      gc.classList.toggle('shake')
    }, 300)

    var x = e.clientX
    var y = e.clientY
    explode.style.left = x + 'px'
    explode.style.top = y + 'px'

    ps.forEach(function(elm) {
      elm.style.transition = '.3s'
      elm.style.background = Math.random() < .5 ? 'red' : 'white'
      var x = Math.random() < .5 ? -1 : 1;
      var y = Math.random() < .5 ? -1 : 1;
      elm.style.transform = 'translate('+Math.random()*100*x+'px,'+Math.random()*100*y+'px)'
      elm.style.opacity = '0'

      setTimeout(function(){
        elm.style.transition = ''
        elm.style.transform = ''
        elm.style.background = ''
        elm.style.opacity = ''
      }, 300)
    })

    // respawn target
    setTimeout(function(){
      var nope = Math.random() < .25 ? true : false;
      if(nope) {
        elm.className = 'game_object game_target nope'
        elm.innerHTML = 00
      } else {
        elm.className = 'game_object game_target'
        elm.innerHTML = parseInt(elm.innerHTML) + 10
      }
    }, respawn)

    // increase speed based on score
    if(score >= 50) {
      setTimeout(function(){
        document.documentElement.style.setProperty('--roll-speed', '5s')
      }, 500)      
    }
    if(score >= 150) {
      setTimeout(function(){
        document.documentElement.style.setProperty('--roll-speed', '3s')
      }, 500)      
    }
  })
})

// window.addEventListener('dblclick', function(){
//   gt.forEach(function(elm){
//     elm.className = 'game_object game_target'
//     score = 0
//     gs.innerHTML = score
//   })
// })