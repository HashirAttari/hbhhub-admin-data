# Daily UI #09 | Search-input with inset shadow

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/ZWjgjo](https://codepen.io/havardob/pen/ZWjgjo).

