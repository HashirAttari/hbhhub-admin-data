const rand = (min, max) => Math.random() * (max - min) + min;

const swirls = document.querySelectorAll(".swirl");

function randomize() {
	swirls.forEach((swirl) => {
		const hue = rand(0, 360);
		const sat = rand(90, 100);
		const lightness = rand(30, 90);
		const blur = rand(10, 30);

		swirl.style.filter = `blur(${blur}px)`;
		swirl.style.transform = `scale(${rand(1, 2)}) rotate(${rand(0, 90)}deg)`;
		swirl.style.width = rand(5, 70) + "%";
		swirl.style.height = rand(20, 50) + "%";
		swirl.style.background = `hsl(${hue}deg, ${sat}%, ${lightness}%)`;
		swirl.style.left = rand(0, 70) + "%";
		swirl.style.top = rand(0, 70) + "%";
	});
}

document.querySelector(".marble").addEventListener("click", () => {
	randomize();
});

randomize();