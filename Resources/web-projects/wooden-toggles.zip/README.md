# Wooden Toggles

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/mdomqGR](https://codepen.io/nicolasjesenberger/pen/mdomqGR).

Wooden Toggles design from Sebastiano Guerriero: https://dribbble.com/shots/1085557-AppExecute-Wood-Style