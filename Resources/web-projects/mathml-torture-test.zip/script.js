function updateMathFont()
  {
  var mathFont = document.getElementById("MathFont").value;
  if (mathFont == "Default") {
    document.body.removeAttribute("class");
  } else {
    document.body.setAttribute("class", mathFont);
  }
  }
 
  function load()
  {
  document.getElementById("MathFont").
  addEventListener("change", updateMathFont, false)
  }

  window.addEventListener("load", load, false);