# Responsive Dark Dashboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/Tbgse/pen/KzaKpm](https://codepen.io/Tbgse/pen/KzaKpm).

A minimalist flat dashboard for sales / logistic data.