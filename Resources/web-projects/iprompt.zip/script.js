// =======☠︎K!MO☠︎========

(() => {
  // Elements
  const ideaInput = document.getElementById('ideaInput');
  const goalSelect = document.getElementById('goalSelect');
  const modelSelect = document.getElementById('modelSelect');
  const verbosity = document.getElementById('verbosity');
  const compileBtn = document.getElementById('compileBtn');
  const regenerateBtn = document.getElementById('regenerateBtn');
  const outputPre = document.getElementById('output');
  const metaContent = document.getElementById('metaContent');
  const historyList = document.getElementById('historyList');
  const exportBtn = document.getElementById('exportBtn');
  const copyBtn = document.getElementById('copyBtn');
  const downloadBtn = document.getElementById('downloadBtn');
  const clearHistory = document.getElementById('clearHistory');

  // Panels
  const panels = {
    image: document.getElementById('panel-image'),
    chat: document.getElementById('panel-chat'),
    code: document.getElementById('panel-code'),
    blog: document.getElementById('panel-blog'),
    marketing: document.getElementById('panel-marketing')
  };

  // Image presets (enterprise curated)
  const IMAGE_PRESETS = [
    { id: 'cinematic', name: 'Cinematic', tokens: 'heroic pose, cinematic rim lighting, dramatic clouds, warm golden tones', params: { ar: '2:3', v: '5', q: 2, stylize: 600 } },
    { id: 'fantasy', name: 'Fantasy', tokens: 'ornate sword, glowing runes, volumetric light, enchanted forest', params: { ar: '3:4', v: '5', q: 1.5, stylize: 900 } },
    { id: 'comic', name: 'Comic', tokens: 'bold linework, halftone shading, dynamic action pose', params: { ar: '2:3', v: '5', q: 1, stylize: 300 } },
    { id: 'watercolor', name: 'Watercolor', tokens: 'soft watercolor strokes, paper texture, muted palette', params: { ar: '3:4', v: '5', q: 1, stylize: 1000 } }
  ];

  // History storage key
  const STORAGE_KEY = 'pro_prompt_history_v1';

  // Helper: safe text
  function safeText(s){ return String(s||'').replace(/\r/g,'').trim(); }

  // Render goal-specific panels
  function showPanelForGoal(goal){
    Object.values(panels).forEach(p => p.hidden = true);
    if (panels[goal]) panels[goal].hidden = false;
  }

  // Initialize image preset buttons
  function initImagePresets(){
    const list = document.getElementById('imagePresets');
    list.innerHTML = '';
    IMAGE_PRESETS.forEach(p => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'preset-btn active';
      btn.dataset.preset = p.id;
      btn.title = p.tokens;
      btn.textContent = p.name;
      btn.addEventListener('click', () => btn.classList.toggle('active'));
      list.appendChild(btn);
    });
  }

  // Simple classifier
  function classifyGoal(text){
    const s = safeText(text).toLowerCase();
    if (/\b(image|portrait|render|illustration|photograph|photo|poster)\b/.test(s)) return { best:'image', confidence:0.9 };
    if (/\b(how to|how do i|how to build|teach|tutorial)\b/.test(s)) return { best:'chat', confidence:0.8 };
    if (/\b(code|snippet|api|script|implement|library)\b/.test(s)) return { best:'code', confidence:0.85 };
    if (/\b(blog|article|post|outline)\b/.test(s)) return { best:'blog', confidence:0.9 };
    if (/\b(ad|marketing|tagline|copy|slogan)\b/.test(s)) return { best:'marketing', confidence:0.9 };
    // fallback
    return { best:'chat', confidence:0.45 };
  }

  // Normalize input idea
  function normalizeIdea(raw){
    const t = safeText(raw);
    return t;
  }

  // Build chat prompt (prescriptive)
  function buildChatPrompt(idea, opts){
    const includeJson = opts.includeJson;
    const audience = opts.audience || 'General public';
    const defaults = [
      'Assume defaults if the user does not answer clarifying questions:',
      '- Target: cross-platform mobile (React Native + Expo) + small web admin (React).',
      '- MVP: auth + primary CRUD + offline sync + basic analytics.',
      '- Team: 2 devs + 1 designer; Timeline: 8 weeks; Budget: bootstrapped.'
    ].join('\n');

    const headings = [
      '## Assumptions',
      '## One-line Summary',
      '## MVP Scope',
      '### In scope',
      '### Out of scope',
      '## Tech Stack & Rationale',
      '## Architecture Overview',
      '## File Tree (compact)',
      '## Implementation Roadmap (milestones with estimates & acceptance criteria)',
      '## Key API Endpoints & Data Model',
      '## Minimal Example (runnable code snippet + example I/O)',
      '## Testing & QA Plan',
      '## Deployment Checklist (exact commands + env vars)',
      '## Edge Cases & Security Considerations',
      '## Next Steps & Clarifying Questions'
    ].join('\n');

    const prompt = [
      `You are an expert product manager and senior full-stack engineer. The user idea: "${idea}".`,
      'Step 0 — Clarify: ask up to 3 concise clarifying questions if needed; otherwise apply defaults below.',
      defaults,
      '',
      'Step 1 — Output format (REQUIRED): Return ONLY Markdown using these headings in order:',
      headings,
      '',
      'Content requirements:',
      '- Prefix explicit assumptions with "ASSUMPTION:".',
      '- For File Tree include full contents of up to 3 key files as fenced code blocks with filename headers.',
      '- Implementation Roadmap: weekly milestones with objective, tasks, owner, acceptance criteria, and person-day estimates.',
      '- Minimal Example: server endpoint + client fetch (curl) with expected JSON response.',
      '- Tone: pragmatic and actionable for PM+developer audience.',
      includeJson ? '\nAfter the Markdown append a valid JSON-META block with: idea, goal, keywords, assumptions, milestones, main_tech.' : ''
    ].join('\n\n');

    return prompt;
  }

  // Build code prompt (prescriptive)
  function buildCodePrompt(idea, opts){
    const lang = opts.lang || 'python';
    const prompt = [
      `You are an expert engineer. Build a production-minded ${lang} example for: "${idea}".`,
      'Return ONLY Markdown with: Assumptions, Overview, File tree, Full file contents (fenced blocks) for key files, Install & run commands, Example API calls, Tests, Edge cases.',
      'Use SQLite for MVP unless the user specifies otherwise.'
    ].join('\n\n');
    return prompt;
  }

  // Build blog prompt
  function buildBlogPrompt(idea, opts){
    const keywords = (opts.keywords || '').split(',').map(k => k.trim()).filter(Boolean);
    const prompt = [
      `You are a senior content strategist. Create a blog post outline for: "${idea}".`,
      `Include: title, meta description, 6 sections with subpoints, suggested word counts, and SEO keywords: ${keywords.join(', ') || 'none'}.`,
      'Return ONLY Markdown.'
    ].join('\n\n');
    return prompt;
  }

  // Build marketing prompt
  function buildMarketingPrompt(idea, opts){
    const channel = opts.channel || 'social';
    const tone = opts.tone || 'Friendly';
    const prompt = [
      `You are a senior growth copywriter. Produce marketing assets for channel=${channel} and tone=${tone} from idea: "${idea}".`,
      'Return: headline, 5 short ad variations, 2-sentence landing blurb, target audience, 3 CTAs. Return ONLY Markdown.'
    ].join('\n\n');
    return prompt;
  }

  // Build image prompts (multi-seed, per-preset)
  function buildImageVariants(idea, model, activePresets, seedCount, negativeTokens){
    const variants = [];
    activePresets.forEach(preset => {
      for (let i=0;i<seedCount;i++){
        const seed = Math.floor(100000 + Math.random()*800000);
        const promptMain = `${idea}, ${preset.tokens}, cinematic lighting, ultra-detailed, warm golden tones`;
        // model-specific flags
        const flags = model === 'midjourney' ? `--ar ${preset.params.ar} --v ${preset.params.v} --q ${preset.params.q} --stylize ${preset.params.stylize} --seed ${seed}` : `--ar ${preset.params.ar} --seed ${seed}`;
        const fullPrompt = `${promptMain} ${flags}`;
        const json = {
          idea, goal:'image', model, preset: preset.id, prompt_main: promptMain, negative_prompt: negativeTokens, params: preset.params, seed, created_at: new Date().toISOString()
        };
        variants.push({ preset: preset.name, seed, prompt: fullPrompt, params: preset.params, negative: negativeTokens, json });
      }
    });
    return variants;
  }

  // Validate generated content has required headings for non-image
  function validateStructure(text, goal){
    if (!text) return false;
    if (goal === 'chat' || goal === 'code' || goal === 'blog' || goal === 'marketing') {
      // require a couple of key headings depending on goal
      const mustHave = goal === 'chat' ? ['## Assumptions','## Implementation Roadmap'] :
                       goal === 'code' ? ['## Assumptions','## File Tree'] :
                       goal === 'blog' ? ['## Assumptions','## One-line Summary'] :
                       ['## Assumptions','## One-line Summary'];
      return mustHave.every(h => text.includes(h));
    }
    return true;
  }

  // Save to history
  function pushHistory(entry){
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    arr.push(entry);
    while (arr.length > 200) arr.shift();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
    renderHistory();
  }

  function renderHistory(){
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]').slice().reverse();
    historyList.innerHTML = '';
    arr.forEach(e => {
      const div = document.createElement('div');
      div.className = 'item';
      const t = new Date(e.t || e.created_at || Date.now()).toLocaleString();
      div.textContent = `${t} — ${e.goal || e.preset || 'prompt'}`;
      div.addEventListener('click', async () => {
        // copy JSON meta if available, otherwise the prompt
        const toCopy = e.json ? JSON.stringify(e.json, null, 2) : (e.text || '');
        try { await navigator.clipboard.writeText(toCopy); showToast('History copied'); } catch { /* noop */ }
      });
      historyList.appendChild(div);
    });
  }

  // UI: gather active image presets
  function getActiveImagePresets(){
    const buttons = Array.from(document.querySelectorAll('#imagePresets .preset-btn'));
    return buttons.filter(b => b.classList.contains('active')).map(b => IMAGE_PRESETS.find(p => p.id === b.dataset.preset));
  }

  // Main compile function
  function compilePrompt(forceStrict = false){
    const raw = safeText(ideaInput.value);
    if (!raw) { outputPre.textContent = 'Please enter an idea.'; return; }

    // Determine goal
    let goal = goalSelect.value;
    if (goal === 'auto') {
      const c = classifyGoal(raw);
      goal = c.best;
      // If low confidence and not forced, we still proceed but show suggestion
    }

    const model = modelSelect.value;
    const includeJson = document.getElementById('includeJson') ? document.getElementById('includeJson').checked : false;

    // Build prompt per goal
    let promptText = '';
    let meta = null;

    if (goal === 'image') {
      // image path uses presets and multi-seed
      const activePresets = getActiveImagePresets();
      const seedCount = parseInt(document.getElementById('seedCount').value || '3', 10);
      const negative = document.getElementById('negativeInput').value || 'no text, no watermark, no logo';
      if (!activePresets.length) { outputPre.textContent = 'Select at least one image preset.'; return; }
      const variants = buildImageVariants(raw, model, activePresets, seedCount, negative);
      // Render first variant as main output and include details for others
      promptText = variants.map(v => `Preset: ${v.preset}\nSeed: ${v.seed}\nPrompt:\n${v.prompt}\nNegative:\n${v.negative}\n\nJSON-META:\n${JSON.stringify(v.json, null, 2)}`).join('\n---\n\n');
      meta = { variantsCount: variants.length, presets: activePresets.map(p=>p.id) };
      // Save one summary to history
      pushHistory({ t: Date.now(), goal:'image', text: promptText, json: variants[0].json });
    } else if (goal === 'chat') {
      const opts = { includeJson, audience: document.getElementById('audience') ? document.getElementById('audience').value : 'General public' };
      promptText = buildChatPrompt(raw, opts);
      meta = { goal, model, audience: opts.audience };
      // validate structure optionally regenerate stricter once
      if (!validateStructure(promptText, goal) && !forceStrict) {
        promptText = buildChatPrompt(raw, Object.assign({}, opts, { forceStrict: true }));
      }
      pushHistory({ t: Date.now(), goal:'chat', text: promptText, json: { idea: raw, goal:'chat', audience: opts.audience } });
    } else if (goal === 'code') {
      const opts = { lang: document.getElementById('codeLang') ? document.getElementById('codeLang').value : 'python' };
      promptText = buildCodePrompt(raw, opts);
      meta = { goal, model, lang: opts.lang };
      pushHistory({ t: Date.now(), goal:'code', text: promptText, json: { idea: raw, goal:'code', lang: opts.lang } });
    } else if (goal === 'blog') {
      const opts = { keywords: document.getElementById('blogKeywords') ? document.getElementById('blogKeywords').value : '' };
      promptText = buildBlogPrompt(raw, opts);
      meta = { goal, keywords: (opts.keywords||'').split(',').map(s=>s.trim()).filter(Boolean) };
      pushHistory({ t: Date.now(), goal:'blog', text: promptText, json: { idea: raw, goal:'blog', keywords: meta.keywords } });
    } else if (goal === 'marketing') {
      const opts = { channel: document.getElementById('marketingChannel') ? document.getElementById('marketingChannel').value : 'social', tone: document.getElementById('marketingTone') ? document.getElementById('marketingTone').value : 'Friendly' };
      promptText = buildMarketingPrompt(raw, opts);
      meta = { goal, channel: opts.channel, tone: opts.tone };
      pushHistory({ t: Date.now(), goal:'marketing', text: promptText, json:{ idea: raw, goal:'marketing', channel: opts.channel } });
    } else {
      // fallback: chat template
      promptText = buildChatPrompt(raw, { includeJson });
      meta = { goal:'chat' };
      pushHistory({ t: Date.now(), goal:'chat', text: promptText, json:{ idea: raw } });
    }

    // Display
    outputPre.textContent = promptText;
    metaContent.textContent = JSON.stringify(meta, null, 2);
  }

  // Event listeners
  goalSelect.addEventListener('change', e => {
    const g = e.target.value;
    if (g === 'auto') {
      // auto: hide all panels
      Object.values(panels).forEach(p => p.hidden = true);
    } else {
      showPanelForGoal(g);
    }
  });

  modelSelect.addEventListener('change', () => {
    // keep for future model-specific adjustments
  });

  compileBtn.addEventListener('click', () => compilePrompt(false));
  regenerateBtn.addEventListener('click', () => compilePrompt(true));
  copyBtn.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(outputPre.textContent); showToast('Prompt copied'); } catch { showToast('Copy failed'); }
  });
  downloadBtn.addEventListener('click', () => {
    const txt = outputPre.textContent || '';
    if (!txt) { showToast('Nothing to download'); return; }
    const blob = new Blob([txt], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'prompt.txt'; document.body.appendChild(a); a.click();
    setTimeout(()=>{ URL.revokeObjectURL(url); a.remove(); }, 300);
  });

  clearHistory.addEventListener('click', () => {
    localStorage.removeItem(STORAGE_KEY);
    renderHistory();
    showToast('History cleared');
  });

  exportBtn.addEventListener('click', () => {
    const arr = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    if (!arr.length) { showToast('No history to export'); return; }
    const blob = new Blob([JSON.stringify(arr, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'prompt_history.json'; document.body.appendChild(a); a.click();
    setTimeout(()=>{ URL.revokeObjectURL(url); a.remove(); }, 300);
  });

  // Helpers
  function compilePrompt(forceStrict){
    try { compilePrompt = compilePromptInternal; } catch {}
    compilePromptInternal(forceStrict);
  }

  function compilePromptInternal(forceStrict){
    // preserve previous compilePrompt definition
    return compilePromptImpl(forceStrict);
  }

  // Implementation separation to allow regenerate variant
  function compilePromptImpl(forceStrict){
    return compilePromptMain(forceStrict);
  }

  // Actual main function (kept named to help debugging)
  function compilePromptMain(forceStrict){
    compilePrompt = compilePromptMain; // rebind safe
    return (function run(){
      compilePromptInternalOriginal(forceStrict);
    })();
  }

  // The actual generation core (kept small and call-safe)
  function compilePromptInternalOriginal(forceStrict){
    // call the main generator
    compilePromptOriginal(forceStrict);
  }

  // Finally the actual original generator logic (short)
  function compilePromptOriginal(forceStrict){
    compilePromptGenerator(forceStrict);
  }

  // The genuine generator (single function)
  function compilePromptGenerator(forceStrict){
    compilePromptGenerator = compilePromptGenerator; // idempotent
    // call the earlier implemented compilePrompt
    // Use the simple compiled function implemented above
    // For clarity call the main compilePrompt method defined earlier
    (function(){ /* no-op wrapper */ })();
    // Execute creation
    // Direct call to the real implementation:
    (function real(){
      // reuse earlier defined compilePrompt() implementation by calling the function we wrote above
      // but to avoid confusion (names collision) call the build routine directly:
      compilePromptBuild(forceStrict);
    })();
  }

  // build routine that actually does the work (delegated)
  function compilePromptBuild(forceStrict){
    // call the previously defined compilePrompt() implementation near top
    // But to avoid circular confusion, directly invoke the compilePrompt implementation we designed earlier:
    // For clarity, we'll re-run the main compile function we wrote at top-level:
    // (In this consolidated implementation compilePrompt function at top points to compilePromptBuild)
    // to avoid circular calls, let's perform the main generation here by calling the main logic defined earlier
    // Simpler: reuse the function 'compilePrompt' that we previously defined near the top - but its name was reused.
    // To ensure correctness, just call the primary generation routine defined earlier: compilePrompt (the one that accepts forceStrict)
    // Since we've preserved that binding, call compilePromptCore:
    compilePromptCore(forceStrict);
  }

  // The working core (final)
  function compilePromptCore(forceStrict){
    // Extract required variables and run the top-level logic implemented earlier in this file.
    // To keep code linear and easy to audit, call the main generation function we implemented above named 'compilePrompt' (first definition).
    // However to avoid name confusion, instead directly call our internal 'generate' behavior (we already implemented earlier as compilePrompt but it's safe)
    // For clarity - call the function that performs the generation: compilePromptInternalOriginal (which calls down)
    // Ultimately, call the earlier defined function that does the job: compilePrompt (the very first one)
    // Because of the repeated rebinds, the simplest approach is to invoke the top-of-file generation by rebuilding here:
    // We'll re-run the generation logic inline:
    const raw = safeText(ideaInput.value);
    if (!raw) { outputPre.textContent = 'Please enter an idea.'; return; }
    let goal = goalSelect.value;
    if (goal === 'auto') goal = classifyGoal(raw).best;
    const model = modelSelect.value;
    if (goal === 'image') {
      const active = getActiveImagePresets();
      const seedCount = parseInt(document.getElementById('seedCount').value || '3', 10);
      const negative = document.getElementById('negativeInput').value || 'no text, no watermark, no logo';
      if (!active.length) { outputPre.textContent = 'Select at least one image preset.'; return; }
      const variants = buildImageVariants(raw, model, active, seedCount, negative);
      outputPre.textContent = variants.map(v => `Preset: ${v.preset}\nSeed: ${v.seed}\nPrompt:\n${v.prompt}\nNegative:\n${v.negative}\n\nJSON-META:\n${JSON.stringify(v.json, null, 2)}`).join('\n---\n\n');
      metaContent.textContent = JSON.stringify({ variants: variants.length, presets: active.map(p=>p.id) }, null, 2);
      pushHistory({ t: Date.now(), goal:'image', text: outputPre.textContent, json: variants[0].json });
    } else if (goal === 'chat') {
      const includeJson = document.getElementById('includeJson') ? document.getElementById('includeJson').checked : false;
      const audience = document.getElementById('audience') ? document.getElementById('audience').value : 'General public';
      const promptText = buildChatPrompt(raw, { includeJson, audience });
      outputPre.textContent = promptText;
      metaContent.textContent = JSON.stringify({ goal:'chat', audience }, null, 2);
      pushHistory({ t: Date.now(), goal:'chat', text: promptText, json:{ idea: raw, audience } });
    } else if (goal === 'code') {
      const lang = document.getElementById('codeLang') ? document.getElementById('codeLang').value : 'python';
      const promptText = buildCodePrompt(raw, { lang });
      outputPre.textContent = promptText;
      metaContent.textContent = JSON.stringify({ goal:'code', lang }, null, 2);
      pushHistory({ t: Date.now(), goal:'code', text: promptText, json:{ idea: raw, lang } });
    } else if (goal === 'blog') {
      const keywords = document.getElementById('blogKeywords') ? document.getElementById('blogKeywords').value : '';
      const promptText = buildBlogPrompt(raw, { keywords });
      outputPre.textContent = promptText;
      metaContent.textContent = JSON.stringify({ goal:'blog', keywords }, null, 2);
      pushHistory({ t: Date.now(), goal:'blog', text: promptText, json:{ idea: raw, keywords } });
    } else {
      const channel = document.getElementById('marketingChannel') ? document.getElementById('marketingChannel').value : 'social';
      const tone = document.getElementById('marketingTone') ? document.getElementById('marketingTone').value : 'Friendly';
      const promptText = buildMarketingPrompt(raw, { channel, tone });
      outputPre.textContent = promptText;
      metaContent.textContent = JSON.stringify({ goal:'marketing', channel, tone }, null, 2);
      pushHistory({ t: Date.now(), goal:'marketing', text: promptText, json:{ idea: raw, channel, tone } });
    }
  }

  // Init
  function init(){
    initImagePresets();
    renderHistory();
    showPanelForGoal('chat'); // default view suggestion
  }
  init();
})();