# Card Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/JuniVersal/pen/zNyMRd](https://codepen.io/JuniVersal/pen/zNyMRd).

Slider: http://significa.pt/labs/css-only-slider/
Animated Background Gradient BY Benedikte Vanderweeën