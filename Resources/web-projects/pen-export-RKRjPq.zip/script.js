var client="https://unsplash.it/800/800";
var imgs=[1069,1050,1044,1043,1041,1028,1019,993,976,972,959,953,940,933,931,925,912,901,899,862,807,763,737,724,704,693,678,666,611,601,600];

var back=document.getElementById("background");
back.src=client+"?image="+imgs[Math.floor((Math.random()*imgs.length))];
back.onload=function(){
  document.getElementById("cover").className="noncover";
};

function addEvents(){
  var searchBtns=document.getElementsByClassName("gobtn");
  for (var i=0;i<searchBtns.length;i++){
    searchBtns[i].addEventListener("mousedown",function(event){search(event);});
  }
  var inputs=document.getElementsByClassName("input");
  for (var i=0;i<inputs.length;i++){
    inputs[i].addEventListener("keydown",function(event){
      if (event.keyCode==13){
        search(event);
      }
    });
  }
}

function setTime(){
  var d=new Date();
  var days=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  var months=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  document.getElementById("clock").innerHTML=zeroComplete(d.getHours())+":"+zeroComplete(d.getMinutes());
  document.getElementById("date").innerHTML=days[d.getDay()]+" "+d.getDate()+" "+months[d.getMonth()]+" "+d.getFullYear();
}

function zeroComplete(inp){
  return inp<10?"0"+inp:inp;
}

function toggleState(elem,evt){
  var col=elem.getAttribute("collapsed");
  collapseAll();
  if (elem.getAttribute("collapsed")=="true"&&col=="true"){
    elem.setAttribute("collapsed",false);
    elem.getElementsByClassName("icon")[0].innerHTML="-";
    evt.stopPropagation();
  }
}

function collapseAll(){
  var elems=document.getElementsByClassName("actionbutton");
  var icons=document.getElementsByClassName("icon");
  for (var i=0;i<elems.length;i++){
    elems[i].setAttribute("collapsed",true);
    icons[i].innerHTML="+";
  }
}

function search(evt){
  var field=evt.target.className=="gobtn"?evt.target.parentElement.getElementsByClassName("input")[0]:evt.target;
  window.location.href=field.getAttribute("link").replace("KEYWORD",field.value);
}

setTime();
addEvents();
setInterval(setTime,500);