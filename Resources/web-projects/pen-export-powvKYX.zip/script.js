/*

type anything which looks like a color string at the following link to see how they render...

http://davealger.com/color/

*/


// helper functions to get and set css variables
const getCssVar = k => getComputedStyle(document.documentElement).getPropertyValue(k)
const setCssVar = (k,v) => document.documentElement.style.setProperty(k,v)