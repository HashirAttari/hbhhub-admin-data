# gradient spinner

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/abZYGeM](https://codepen.io/run-time/pen/abZYGeM).

