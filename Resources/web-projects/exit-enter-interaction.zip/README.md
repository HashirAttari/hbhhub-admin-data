# Exit/Enter Interaction

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/OJXpLbp](https://codepen.io/benhatsor/pen/OJXpLbp).

Simple exit/enter interaction.