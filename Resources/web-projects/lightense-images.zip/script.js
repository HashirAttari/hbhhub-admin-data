window.addEventListener('load', function () {
  Lightense('img:not(.no-lightense),.lightense');
}, false);