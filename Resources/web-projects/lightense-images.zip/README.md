# Lightense Images

A Pen created on CodePen.io. Original URL: [https://codepen.io/sparanoid/pen/yOJyjV](https://codepen.io/sparanoid/pen/yOJyjV).

A dependency-free pure JavaScript image zooming library less than 2 KB (gzipped). See [Project Page](http://sparanoid.com/work/lightense-images/) for more information