# No text duplication slice & offset (SVG filter magic 🪄)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/RwmPZVR](https://codepen.io/thebabydino/pen/RwmPZVR).

[Inspiration](https://www.pinterest.com/pin/639933428330469717/). Live coded in Professor Mode in under 15 minutes on the 14th of May 2024.

The trick here is a combination of 2 feColorMatrix uses:

✨ [RGB fill](https://codepen.io/thebabydino/full/LYamwrz)
 
✨ [alpha mask from RGB](https://codepen.io/thebabydino/full/OJqZvQO)

---

If the work I've been putting out since early 2012 has helped you in any way or you just like it and you wish me to be able to continue putting out stuff, please consider one of the following:

* being a cool cat 😼🎩 and becoming a patron on Patreon

[![become a patron button](https://assets.codepen.io/2017/btn_patreon.png)](https://www.patreon.com/anatudor)

* making a one time donation via Ko-fi

[![ko-fi](https://assets.codepen.io/2017/btn_kofi.svg)](https://ko-fi.com/anatudor)

* making a weekly anonymous donation via Liberapay 

[![Liberapay](https://assets.codepen.io/2017/btn_liberapay.svg)](https://liberapay.com/anatudor/)

* getting me something off my Amazon WishList 

[🎁 🇺🇸](https://www.amazon.com/gp/registry/wishlist/2Y3C4722GXH0I/) / [🎁 🇬🇧](https://www.amazon.co.uk/gp/registry/wishlist/2I25W7U0KADSR/)

* or at least sharing this to show the world what can be done with CSS these days

Thank you!

---

Dedicated to the memory of someone dear who passed away in January 2019. Missing you every day.