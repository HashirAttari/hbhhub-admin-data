# Border-image

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/aQjKwO](https://codepen.io/yuanchuan/pen/aQjKwO).

CSS Challenge: https://twitter.com/yuanchuan23/status/1066555792122241024