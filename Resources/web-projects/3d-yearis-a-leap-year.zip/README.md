# 3D Year - is a leap year?

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pedro-Ondiviela/pen/GReByom](https://codepen.io/Pedro-Ondiviela/pen/GReByom).

3D based letters showing the year. Check if it's a leap year or not. Letters form, color and styles will tell you!

Done with THREE.js for Codepen weekly challenge!