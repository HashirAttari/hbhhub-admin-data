const yearInput = document.getElementById("year");
const cursor = document.getElementById("cursor");
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
const threeWrapper = document.getElementById("3d");
const wrapper = document.getElementById("wrapper");
const text = document.getElementById("text");

const width = 800;
const height = 400;
const division = 50;

canvas.width = width;
canvas.height = height;

const scene = new THREE.Scene();
let camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);

const renderer = new THREE.WebGLRenderer({ antialias: false, alpha: false });
renderer.setSize(width, height);
threeWrapper.appendChild(renderer.domElement);

function getRandomArbitrary(min, max) {
	return Math.random() * (max - min) + min;
}

const draw = (value) => {
	const year = value ?? yearInput.value;
	const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
	if (isLeapYear) {
		wrapper.classList.add("leap-year--green");
		text.innerHTML = "is a leap year";
	} else {
		wrapper.classList.remove("leap-year--green");
		text.innerHTML = "is not a leap year";
	}
	// 2D step
	ctx.fillStyle = "white";
	ctx.fillRect(0, 0, width, height);
	ctx.fillStyle = "black";
	ctx.font = "bold 280px 'Arial Black', 'Archivo Black', sans-serif";
	ctx.fillText(year, 0, 320);
	// Pixelating
	const pxSize = width / division;

	const pixelRowLength = division;
	const pixelColumnLength = Math.ceil(height / pxSize);

	// Getting the color value of all pxs in advance
	const pxValues = [];

	for (let i = 0; i < pixelColumnLength; i++) {
		for (let j = 0; j < pixelRowLength; j++) {
			let pixelData = ctx.getImageData(
				pxSize * j + pxSize / 2,
				pxSize * i + pxSize / 2,
				1,
				1
			).data;

			if (!pxValues[i]) {
				pxValues.push([]);
			}
			if (pixelData[0] === 0) {
				pxValues[i].push("black");
			} else {
				pxValues[i].push("white");
			}
		}
	}

	// 3D step
	scene.clear();

	const bgGeometry = new THREE.PlaneGeometry(500, 500);
	const bgMaterial = new THREE.MeshBasicMaterial({ color: 0x282732 });
	const bgMesh = new THREE.Mesh(bgGeometry, bgMaterial);
	bgMesh.position.set(0, 0, -21);
	scene.add(bgMesh);

	for (let i = 0; i < pixelColumnLength; i++) {
		for (let j = 0; j < pixelRowLength; j++) {
			if (pxValues[i][j] === "black") {
				const x = pxSize * (j - 0.5);
				const y = pxSize * (i - 0.5);

				const pixelGeometry = isLeapYear
					? new THREE.SphereGeometry(getRandomArbitrary(0.3, 1), 8, 4)
					: new THREE.OctahedronGeometry(getRandomArbitrary(0.3, 1.2), 0);

				const pixelMaterial = new THREE.MeshToonMaterial({
					color: isLeapYear ? 0x00cc55 : 0xee0033
				});

				const pixel = new THREE.Mesh(pixelGeometry, pixelMaterial);
				pixel.name = "pixel";
				pixel.castShadow = true;
				pixel.receiveShadow = true;
				pixel.position.set(x / 10 - 35, (y / 10 - 16) * -1, 0);
				scene.add(pixel);
			}
		}
	}

	const light = new THREE.PointLight(0xffffff, 500);
	light.position.set(20, 10, 10);
	scene.add(light);

	const light2 = new THREE.PointLight(0xffffff, 500);
	light2.position.set(-20, 10, 10);
	scene.add(light2);
	// Final conditions for scene
	camera.position.z = 26;
};

draw();

let t = 0;
function animate() {
	requestAnimationFrame(animate);
	t += 0.01;
	const pixels = scene.getObjectsByProperty("name", "pixel");
	pixels.forEach((pixel, index) => {
		const odd = index % 2 === 1;
		pixel.rotation.y += 0.0015;
		pixel.rotation.x += 0.0015;
		pixel.scale.x += odd ? 0.003 * Math.sin(t) : -0.003 * Math.cos(t);
		pixel.scale.y += odd ? 0.003 * Math.sin(t) : -0.003 * Math.cos(t);
		pixel.scale.z += odd ? 0.005 * Math.sin(t) : -0.003 * Math.cos(t);
		pixel.position.x += (odd ? 0.001 : -0.001) * Math.sin(t);
		pixel.position.y += (odd ? 0.001 : -0.001) * Math.sin(t);
	});
	renderer.render(scene, camera);
}

let currentPointer = 4;

const positionTextCursor = (pointerPosition) => {
	currentPointer = pointerPosition;
	yearInput.focus();
	yearInput.setSelectionRange(pointerPosition, pointerPosition);
	cursor.style = `--position: ${(pointerPosition * width) / 4}px`;
};

positionTextCursor(currentPointer);

const isKeyAllowed = (key) =>
	isFinite(event.key) ||
	key === "Backspace" ||
	key === "ArrowLeft" ||
	key === "ArrowRight";

yearInput.addEventListener("keydown", (e) => {
	if (!isKeyAllowed(e.key)) {
		e.stopPropagation();
		e.preventDefault();
		e.returnValue = false;
		e.cancelBubble = true;
		return false;
	}
});

yearInput.addEventListener("keyup", (e) => {
	if (isKeyAllowed(e.key)) {
		draw(e.target.value);
		if (event.key === "Backspace" || event.key === "ArrowLeft") {
			currentPointer = Math.max(currentPointer - 1, 0);
			positionTextCursor(currentPointer);
		} else {
			currentPointer = Math.min(currentPointer + 1, 4);
			positionTextCursor(currentPointer);
		}
	}
});

threeWrapper.addEventListener("click", (e) => {
	const realWidth = threeWrapper.getBoundingClientRect().width;
	const pointerPosition = Math.floor((e.clientX * 4) / realWidth);
	const realPointerPosition = Math.min(pointerPosition, yearInput.value.length);
	positionTextCursor(realPointerPosition);
});

// Waiting a little before animating for thumbnail purposes
setTimeout(() => {
	animate();
}, 100);