var headerImage = $(".header-image");
var imageContainer = $('.site-header');

// Hacky object-fit polyfill
function setImageSize(container, image) {
  if (image.css('object-fit') != 'cover') {
    var headerWidth = container.outerWidth();
    var headerHeight = container.outerHeight();

    var imageWidth = image.outerWidth();
    var imageHeight = image.outerHeight();
    var imageRatio =  imageHeight / imageWidth; 

    if(headerWidth * imageRatio > headerHeight) {
      image.css('width', '100%');
      image.css('height', 'auto');
    } else {
      image.css('height', '100%');
      image.css('width', 'auto');
    }
  }
}

// Hacky image loading
function imageIsLoaded(image) {
  if(image.prop('complete')) { 
    setImageSize(imageContainer, headerImage);
    image.addClass('image-loaded'); 
  }
  
  image.on('load', function() {
    setImageSize(imageContainer, headerImage);
    image.addClass('image-loaded');
  });
}

imageIsLoaded(headerImage);

$(window).on('resize', function() {
  setImageSize(imageContainer, headerImage);
});