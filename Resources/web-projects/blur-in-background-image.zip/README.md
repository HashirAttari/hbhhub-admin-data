# Blur-in background image

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/LWYGbY](https://codepen.io/giana/pen/LWYGbY).

Using images instead of background image.