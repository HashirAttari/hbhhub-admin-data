# Particle image- #CodePenChallenge

A Pen created on CodePen.

Original URL: [https://codepen.io/emi_hermit/pen/GRwdVGd](https://codepen.io/emi_hermit/pen/GRwdVGd).

This project is a unique visual representation of an image using particle motion, achieved using JavaScript and HTML5 canvas. 

In essence, it starts by loading an image into a canvas, while creating an array of particles based on the image's pixel data. Each particle is defined with properties such as color, original position and current position. The particles are initially scattered randomly across the canvas. Then taking the shape of the image by the one formed by particles.