# Volume Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/emilcarlsson/pen/PPNLPy](https://codepen.io/emilcarlsson/pen/PPNLPy).

A simple volume slider based on Ray Villalobos Volume Slider which can be found here: http://codepen.io/planetoftheweb/pen/HCLzc