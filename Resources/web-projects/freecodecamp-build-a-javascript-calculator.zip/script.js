var app = new Vue({
  el: 'calculator',
  data: {
    number: '0',
    calc: '0',
    lastCalc: '',
    lastWasOperator: false,
    lastWasEquals: false,
    input: function(num){
      if(app.number.length>14)return false
      if(app.lastWasEquals){
        app.clearCalc()
      }
      app.lastWasEquals = false
      if(app.clearNext){
        app.number = ''
        app.clearNext = false
      }
      if(app.number=='0'&&num!='.'){
        app.number = ''
        app.calc = app.calc.slice(0,-1)
      }
      app.number += num.toString()
      app.calc += num.toString()
      app.lastWasOperator = false
    },
    clearInput: function(){
      app.lastWasOperator = true
      app.number = '0'
      var match = app.calc.match(/[e\d+\-×÷.]*[+\-×÷]/)
      app.calc = match ? match[0]+'0' : '0'
      app.lastWasEquals = false
    },
    clearCalc: function(){
      app.lastWasOperator = false
      app.lastWasEquals = false
      app.number = '0'
      app.calc = '0'
    },
    operator: function(op){
      console.log(app.calc,op,app.calc+op)
      if(app.lastWasEquals){
        console.log(app.number)
        app.calc = app.number
      }
      app.lastWasEquals = false
      if(app.lastWasOperator){
        app.calc = app.calc.slice(0,-2)
      }
      app.lastWasOperator = true
      app.calc += op
      app.clearInput()
    },
    minus: function(){
      if(app.number=='0'&&app.calc.slice(-2)!='-0'&&!app.lastWasEquals){
        app.number = '-'
        app.calc = app.calc.toString().slice(0,-1) + '-'
        app.lastWasOperator = true
      }else{
        app.operator('-')
      }
    },
    calculate: function(){
      app.lastWasOperator = false
      if(app.lastWasEquals){
        app.calc = app.number.toString()
        app.lastWasEquals = false
      }else{
        var res = parseFloat(eval(app.calc.replace('÷','/').replace('×','*')).toPrecision(10))
        app.number = res>=10000000 ? res.toExponential(9) : res.toString()
        app.calc += '=' + app.number
        app.lastWasEquals = true
      }
    }
  }
})