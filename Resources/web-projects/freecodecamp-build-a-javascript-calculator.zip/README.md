# FreeCodeCamp: Build a JavaScript Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/GabbeV/pen/VjxNbr](https://codepen.io/GabbeV/pen/VjxNbr).

Calculator for "Build a JavaScript Calculator" challenge on Free Code Camp
https://www.freecodecamp.com/challenges/build-a-javascript-calculator