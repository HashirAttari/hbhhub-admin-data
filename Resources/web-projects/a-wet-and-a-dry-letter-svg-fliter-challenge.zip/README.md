# A wet and a dry letter svg fliter challenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/TidyCoder/pen/BaeNYoV](https://codepen.io/TidyCoder/pen/BaeNYoV).

