# Fibonacci In Fibonacci

A Pen created on CodePen.io. Original URL: [https://codepen.io/Manoylov/pen/jGmQrL](https://codepen.io/Manoylov/pen/jGmQrL).

phyllotaxis spiral + image

processing version: processing version: https://www.openprocessing.org/sketch/158305