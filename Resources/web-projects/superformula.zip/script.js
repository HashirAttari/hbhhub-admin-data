var canv=document.getElementsByTagName("canvas")[0],
    ctx=canv.getContext("2d"),
    inps=document.getElementsByTagName("input"),
    resolution=1000,
    side=150;

function superFormula(theta,a,b,m,m2,n,n2,n3){
  var t=Math.pow(Math.abs((Math.cos(m*theta)/4)/a),n2),
      t2=Math.pow(Math.abs((Math.sin(m2*theta)/4)/b),n3);
  return Math.pow(t+t2,-1/n);
}

function plot(data){
  ctx.clearRect(0,0,canv.width,canv.height);
  ctx.strokeStyle="#06f";
  var radii=[],
      maxR=0;
  for (var i=0;i<resolution;i++){
    var theta=i/resolution*Math.PI*2;
    data[0]=theta;
    var r=superFormula.apply(this,data);
    radii.push(r);
    if (r>maxR)
      maxR=r;
  }
  var scale=(side-20)/maxR;
  for (var i=0;i<resolution;i++){
    var theta=i/resolution*Math.PI*2,
        x=side+Math.cos(theta)*radii[i]*scale,
        y=side+Math.sin(theta)*radii[i]*scale;
    
    if (!i){
        ctx.beginPath();
        ctx.moveTo(x,y);
    }else
      ctx.lineTo(x,y);
  }
  ctx.closePath();
  ctx.stroke();
}

function scanAndPlot(){
  var data=[0];
  for (var i=0;i<inps.length;i++)
    data.push(parseFloat(inps[i].value));
  console.log(data);
  plot(data);
}

function init(){
  for (var i=0;i<inps.length;i++)
    inps[i].addEventListener("input",scanAndPlot);
  scanAndPlot();
}

init();