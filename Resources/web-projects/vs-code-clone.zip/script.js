//INFORMAÇÕES:

//Link Ace Editor para emplementar no projeto:

//https://ace.c9.io/

//Temas para editor:

//https://gist.github.com/RyanNutt/cb8d60997d97905f0b2aea6c3b5c8ee0

//https://pt.stackoverflow.com/questions/418443/textarea-semelhante-a-um-editor-de-texto-ex-

//Editor de texto Ace Edito for VS Code

var editor = ace.edit("editor");
//MUDAR TAMANHO DA FONTE
document.getElementById("editor").style.fontSize = "18px";

function mudaFonte() {
  var menu = document.getElementById("menu_fonte");
  var fonte = menu.options[menu.selectedIndex].value;
  var linkFonte = fonte;
  return (document.getElementById("editor").style.fontSize = linkFonte);
}
mudaFonte();

editor.setTheme("ace/theme/dracula");

//MUDAR TEMAS
editor.setTheme("ace/theme/dracula");

function mudaTemas() {
  var menu = document.getElementById("menu_tema");
  var cor = menu.options[menu.selectedIndex].value;
  var link = `ace/theme/${cor}`;
  return editor.setTheme(link);
  console.log(link);
}
mudaTemas();
//MUDAR FUNDO
function mudaFundo() {
  var menu = document.getElementById("menu_fundo");
  var fundoCor = menu.options[menu.selectedIndex].value;
  console.log(fundoCor);
  document.body.style.backgroundColor = fundoCor;
}
mudaFundo();
//MUDAR LIGUAGEM
editor.session.setMode("ace/mode/javascript");
function mudaLinguagem() {
  var menu = document.getElementById("menu_linguage");
  var lingua = menu.options[menu.selectedIndex].value;
  var linkLing = `ace/mode/${lingua}`;
  return editor.session.setMode(linkLing);
  console.log(linkLing);
}
mudaLinguagem();

editor.session.setTabSize(4);

editor.setOptions({
  autoScrollEditorIntoView: true,
  copyWithEmptySelection: true
});

setTimeout(() => {
  var beautify = ace.require("ace/ext/beautify"); // get reference to extension
  beautify.beautify(editor.session);
}, 500);

//beautify.beautify(editor.session);
document.getElementById("formatar").onclick = function () {
  var beautify = ace.require("ace/ext/beautify"); // get reference to extension
  beautify.beautify(editor.session);
};

//Salvar arquivo
function download(content, fileName, contentType) {
  var a = document.createElement("a");
  var file = new Blob([content], {
    type: contentType + encodeURIComponent(content)
  });
  a.href = URL.createObjectURL(file);
  a.download = fileName;
  a.click();
}

//Nome do arquivo na entrada

//var nomeFile = document.getElementById("nome_arquivo").value;

//Função para biaxar o arquivo
var textoSave = editor.getValue();

var button = document.getElementById("salvar_final");

button.addEventListener("click", function () {
  var textoSave = editor.getValue();
  if (document.getElementById("nome_arquivo").value !== "") {
    if (confirm("Deseja salvar o Codigo?")) {
      var content = textoSave;
      var fileName = document.getElementById("nome_arquivo").value;
      var contentType = "text/html";
      download(content, fileName, contentType);
    } else {
      alert("Cancelado!");
    }
  } else {
    alert("Informe o nome do arquivo e o tipo, Ex.: index.html");
  }
});

// Ativar pagina oculta para salvar arquivo

var buttonFecha = document.getElementById("xxx");

buttonFecha.addEventListener("click", function () {
  console.log("cliclou");
  if (confirm("deseja sair sem salvar?")) {
    var telaExporte = document.getElementById("exportar");
    telaExporte.setAttribute("id", "fecha_exportar");
  }
});

var buttonSalvaEx = document.getElementById("salvar_exporte");

buttonSalvaEx.addEventListener("click", function () {
  console.log("cliclou");
  var telaSalvaExporte = document.getElementById("fecha_exportar");
  telaSalvaExporte.setAttribute("id", "exportar");
});

//Open file in Ace editor

//https://stackoverflow.com/questions/59004560/how-can-i-open-a-file-into-ace-text-editor

function openCode(files) {
  var file = files[0];
  if (!file) return;
  var modelist = ace.require("ace/ext/modelist");
  var modeName = modelist.getModeForPath(file.name).mode;
  editor.session.setMode(modeName);
  reader = new FileReader();
  reader.onload = function () {
    editor.session.setValue(reader.result);
  };
  reader.readAsText(file);
}