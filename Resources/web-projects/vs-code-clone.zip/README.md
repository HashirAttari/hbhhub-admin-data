# VS Code Clone

A Pen created on CodePen.io. Original URL: [https://codepen.io/talilo-tarlison/pen/OJaNGpy](https://codepen.io/talilo-tarlison/pen/OJaNGpy).

