# Another Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/valaxin/pen/BjepPG](https://codepen.io/valaxin/pen/BjepPG).

