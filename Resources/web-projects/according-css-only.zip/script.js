// Version without any unneccessary styles
// https://codepen.io/aaroniker/pen/wvRvXKe