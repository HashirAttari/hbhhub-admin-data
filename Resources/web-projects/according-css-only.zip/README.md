# According CSS only 

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/NWOYWgR](https://codepen.io/aaroniker/pen/NWOYWgR).

