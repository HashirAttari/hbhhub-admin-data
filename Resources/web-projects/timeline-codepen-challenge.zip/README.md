# Timeline | CodePen Challenge 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/xxPqXdO](https://codepen.io/havardob/pen/xxPqXdO).

Recreation of this Dribbble shot: https://dribbble.com/shots/16839933-Crew-work-Timeline-Events 

