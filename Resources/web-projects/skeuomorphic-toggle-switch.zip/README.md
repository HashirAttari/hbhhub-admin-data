# Skeuomorphic Toggle Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/BaOVdwE](https://codepen.io/nicolasjesenberger/pen/BaOVdwE).

