/*
		Original image: https://dribbble.com/shots/6557741-Painter
		Designed by: Uran
		
*/