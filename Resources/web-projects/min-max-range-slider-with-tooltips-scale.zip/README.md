# Min Max Range Slider with Tooltips & Scale

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/ExzKdjG](https://codepen.io/cbolson/pen/ExzKdjG).

Range slider adapted from: https://medium.com/@predragdavidovic10/native-dual-range-slider-html-css-javascript-91e778134816

I added the tooltips and the scale below the slider