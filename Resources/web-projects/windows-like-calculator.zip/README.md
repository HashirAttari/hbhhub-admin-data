# Windows like calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/bajzarpa/pen/nVvqYX](https://codepen.io/bajzarpa/pen/nVvqYX).

WIP ;-)