# Particle Text Effect

A Pen created on CodePen.

Original URL: [https://codepen.io/tomncurry/pen/wXKReQ](https://codepen.io/tomncurry/pen/wXKReQ).

