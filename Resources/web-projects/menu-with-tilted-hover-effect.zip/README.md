# Menu with tilted hover effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/YzQwMyY](https://codepen.io/havardob/pen/YzQwMyY).

Icons by https://akaricons.com/

The design itself is inspired by a Tailwind UI component, but written with vanilla HMTL and CSS (SCSS): https://tailwindui.com/components/marketing/elements/headers