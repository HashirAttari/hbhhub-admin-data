# Unicode triangles

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/YLyEvb](https://codepen.io/yuanchuan/pen/YLyEvb).

