# Styled native range input #37 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/MYQGvO](https://codepen.io/thebabydino/pen/MYQGvO).

**May 2021 update**

Major changes:

* ditched the 1 element restriction to make it functional again (the hacky `/deep/` technique from ealy 2015 had stopped working within the same year, so I've now eliminated all that completely useless code) and accessible

* now using an actual `label` element for the label and an `output` for displaying the slider value (the latter only if JS is enabled)

* simplified the JS **a lot** - it now only adds a 'js' class at the start and updates a `--val` custom property on the `form` containing everything every time the slider value changes

* ditched `absolute` positioning in favour of using a `grid` layout now

* cleaned up the CSS and made it more maintainable by using CSS variables

* added a subtle reflection using either `-webkit-box-reflect` or `-moz-element` depending on the browser

* actually bothered to look for fonts that would match the original design

* not providing free support for IE/ pre-Chromium Edge anymore

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

**Original description**

Goal: create a nicely styled cross-browser ***real*** 3D slider with just 1 range input. Tested & works in Chrome 40, 42 (canary)/ Opera 28. 2D in Firefox 35, 38 (nightly), IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling the range track. Chrome/ Opera have a bit of an extra, the 3D and value indicator. This is done using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). Fallback for no JS: simply display the same background for the entire track, both before and after the thumb and value indicator.

---

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/c7ZDw6b.jpg) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/).