const canvas1 = document.getElementById('canvas1');
const ctx = canvas1.getContext('2d');
const mutateBtn  = document.getElementById('mutateBtn');

const SIZE = 600;
canvas1.width = SIZE;
canvas1.height = SIZE;
ctx.lineCap = 'round';
ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
ctx.shadowBlur = 10;
ctx.shadowOffsetX = 3;
ctx.shadowOffsetY = 3;

function drawFractal(){
    // properties
    const lineWidth = Math.floor(Math.random() * 11) + 5;
    const hue = Math.random() * 360;
    const sides = Math.floor(Math.random() * 7) + 2;
    const maxLevel = 7;
    const spread = Math.random() * 1 + 0.1;;
    const scale = Math.random() * 0.15 + 0.65;
    const branches = Math.floor(Math.random() * 2) + 2; // 2-3 branches;

    ctx.clearRect(0, 0, SIZE, SIZE);
    ctx.lineWidth = lineWidth;

    ctx.save();
    ctx.translate(SIZE/2, SIZE/2);
    for (let i = 0; i < sides; i++){
        drawBranch(0, maxLevel,scale, spread, branches, hue);
        ctx.rotate((Math.PI * 2) / sides);
    }
    ctx.restore();
}

function drawBranch(level, maxLevel, scale, spread, branches, hue){
    if (level > maxLevel) return;
    const branchSize = SIZE * 0.15;
    const lightness = 40 + (level * 6);
    ctx.strokeStyle = `hsl(${hue}, 100%, ${lightness}%)`;

    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(branchSize, 0);
    ctx.stroke();

    for (let i = 0; i < branches; i++){
        ctx.save();
        const position = branchSize - (branchSize / branches) * i;
        ctx.translate(position, 0);
        ctx.scale(scale, scale);
        //ctx.rotate(spread * (i - (branches - 1) / 2));
        ctx.rotate(spread * (i - (branches - spread * 5) / 2));
        drawBranch(level + 1, maxLevel, scale, spread, branches, hue);
        ctx.restore();
    }

}

drawFractal();
mutateBtn.addEventListener('click', drawFractal);