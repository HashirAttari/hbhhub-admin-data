# SVG Loading icons

A Pen created on CodePen.io. Original URL: [https://codepen.io/aurer/pen/ZEJxpO](https://codepen.io/aurer/pen/ZEJxpO).

Animated SVG for use as loading animations.