# Line loader (CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/abyYOdq](https://codepen.io/amit_sheen/pen/abyYOdq).

