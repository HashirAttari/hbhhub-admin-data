# CSS Clock Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/mdgpBZg](https://codepen.io/yudizsolutions/pen/mdgpBZg).

We are using HTML and CSS to create a background animation of the clock. We're also using javascript for working clock .

Made by Ayushi Patel from Yudiz