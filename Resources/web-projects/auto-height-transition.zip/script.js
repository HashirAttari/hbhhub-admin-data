// auto height

function autoHeightTransition(element, heightTransition) {
	const observer = new MutationObserver(() => {
		// remove height and transition
		element.style.transition = "";
		element.style.height = "";

		requestAnimationFrame(() => {
			// measure new height
			const newHeight = element.scrollHeight;

			// apply prev height immediately
			element.style.height = element.dataset.height;

			requestAnimationFrame(() => {
				// add transition back
				element.style.transition = heightTransition;

				requestAnimationFrame(() => {
					// apply newHeight
					element.style.height = newHeight + "px";
					element.dataset.height = newHeight + "px";
				});
			});
		});
	});

	// save current height
	element.dataset.height = element.scrollHeight + "px";

	// set required styles
	element.style.overflow = "hidden";
	element.style.boxSizing = "border-box";

	observer.observe(element, {
		subtree: true,
		childList: true,
		characterData: true
	});
}

// using autoheight

const modal = document.querySelector(".modal");
autoHeightTransition(modal, "height 300ms ease");

// shuffling logic

const listEl = document.querySelector(".grid");
const shuffleButtonEl = document.querySelector(".shuffle-btn");

function rand(low, hi) {
	return low + Math.floor(Math.random() * (hi + 1));
}

function shuffle() {
	listEl.innerHTML = "";
	const boxesNum = rand(10, 40);
	for (let i = 0; i < boxesNum; i++) {
		const box = document.createElement("div");
		box.classList.add("box");
		box.classList.add(`box${rand(1, 3)}`);
		box.style.gridColumn = `auto / span ${rand(1, 2)}`;
		box.style.animationDuration = rand(100, 1000) + "ms";
		box.style.transformOrigin = rand(1, 2) === 1 ? "left" : "right";
		listEl.append(box);
	}
}

modal.addEventListener("click", shuffle);

shuffle();