# Valentine's day animation

A Pen created on CodePen.

Original URL: [https://codepen.io/ykosinets/pen/XJrQYbp](https://codepen.io/ykosinets/pen/XJrQYbp).

Simple and short animation for st. Valentine's day.
Heart svg animation.