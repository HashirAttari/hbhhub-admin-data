/*
Designed by: Gev Marotz
Original image: https://dribbble.com/shots/2318024-Halloween-Characters
*/