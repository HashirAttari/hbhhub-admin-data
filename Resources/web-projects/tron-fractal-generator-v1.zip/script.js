const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// CONFIGURATION
const MIN_RECURSION = 2;
const MAX_RECURSION = 3;
const MIN_BRANCHES = 1;
const MAX_BRANCHES = 2;

class NeonFractal {
    constructor() {
        this.centerX = canvas.width / 2;
        this.centerY = canvas.height / 2;

        this.sides = Math.floor(Math.random() * 5) + 4; // 4-8 arms
        this.maxLevel = Math.floor(Math.random() * (MAX_RECURSION - MIN_RECURSION + 1)) + MIN_RECURSION;
        this.branches = Math.floor(Math.random() * (MAX_BRANCHES - MIN_BRANCHES + 1)) + MIN_BRANCHES;

        this.baseSize = Math.min(canvas.width, canvas.height) * 0.25;
        this.scale = 0.55;
        this.spread = Math.random() * 0.8 + 0.2;

        this.baseHue = Math.random() * 360;
        this.baseSaturation = 100;
        this.baseLightness = 50;

        this.lineWidth = 2 + Math.random() * 3;
    }

    draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // background
        ctx.fillStyle = 'black';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.save();
        ctx.translate(this.centerX, this.centerY);

        // FIRST PASS: Neon lines
        for (let i = 0; i < this.sides; i++) {
            this.drawBranchLine(this.baseSize, 0);
            ctx.rotate((Math.PI * 2) / this.sides);
        }

        ctx.restore();

        ctx.save();
        ctx.translate(this.centerX, this.centerY);

        // SECOND PASS: Polygon shards on top
        for (let i = 0; i < this.sides; i++) {
            this.drawBranchPolygons(this.baseSize, 0);
            ctx.rotate((Math.PI * 2) / this.sides);
        }

        ctx.restore();
    }

    // Draw branch lines recursively
    drawBranchLine(branchSize, level) {
        if (level > this.maxLevel) return;

        const light = this.baseLightness + level * 5;
        ctx.strokeStyle = `hsl(${this.baseHue},${this.baseSaturation}%,${Math.min(light, 85)}%)`;
        ctx.lineWidth = this.lineWidth;
        ctx.shadowColor = ctx.strokeStyle;
        ctx.shadowBlur = 12;

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(branchSize, 0);
        ctx.stroke();

        for (let i = 1; i <= this.branches; i++) {
            ctx.save();
            const branchPos = (branchSize / this.branches) * i;
            ctx.translate(branchPos, 0);
            const newScale = this.scale * (0.85 + Math.random() * 0.3);
            ctx.scale(newScale, newScale);
            ctx.rotate(this.spread * (Math.random() > 0.5 ? 1 : -1));
            this.drawBranchLine(branchSize, level + 1);
            ctx.restore();
        }
    }

    // Draw polygon shards recursively
    drawBranchPolygons(branchSize, level) {
        if (level > this.maxLevel) return;

        const shards = 1 + Math.floor(Math.random() * 2);
        for (let s = 0; s < shards; s++) {
            const size = branchSize * (0.3 + Math.random() * 0.5);
            const sides = 3 + Math.floor(Math.random() * 2);
            const vertices = [];
            for (let i = 0; i < sides; i++) {
                const angle = (i / sides) * Math.PI * 2 + (Math.random() - 0.5) * 0.2;
                const radius = size * (0.5 + Math.random() * 0.5);
                vertices.push({ x: Math.cos(angle) * radius, y: Math.sin(angle) * radius });
            }

            const light = this.baseLightness + level * 5;
            ctx.fillStyle = `hsla(${this.baseHue},${this.baseSaturation}%,${Math.min(light, 85)}%,0.3)`;
            ctx.beginPath();
            ctx.moveTo(vertices[0].x, vertices[0].y);
            for (let v = 1; v < vertices.length; v++) ctx.lineTo(vertices[v].x, vertices[v].y);
            ctx.closePath();
            ctx.fill();

            ctx.strokeStyle = `hsl(${this.baseHue},${this.baseSaturation}%,${Math.min(light, 85)}%)`;
            ctx.lineWidth = this.lineWidth;
            ctx.shadowColor = ctx.strokeStyle;
            ctx.shadowBlur = 8;
            ctx.beginPath();
            ctx.moveTo(vertices[0].x, vertices[0].y);
            for (let v = 1; v < vertices.length; v++) ctx.lineTo(vertices[v].x, vertices[v].y);
            ctx.closePath();
            ctx.stroke();
        }

        for (let i = 1; i <= this.branches; i++) {
            ctx.save();
            const branchPos = (branchSize / this.branches) * i;
            ctx.translate(branchPos, 0);
            const newScale = this.scale * (0.85 + Math.random() * 0.3);
            ctx.scale(newScale, newScale);
            ctx.rotate(this.spread * (Math.random() > 0.5 ? 1 : -1));
            this.drawBranchPolygons(branchSize, level + 1);
            ctx.restore();
        }
    }
}


// INITIAL DRAW
let fractal = new NeonFractal();
fractal.draw();

// REGENERATE BUTTON
document.getElementById('regenerateBtn').addEventListener('click',()=>{
    fractal = new NeonFractal();
    fractal.draw();
});

// RESIZE
window.addEventListener('resize',()=>{
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    fractal.centerX = canvas.width/2;
    fractal.centerY = canvas.height/2;
    fractal.draw();
});