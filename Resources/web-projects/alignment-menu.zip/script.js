var lines = document.querySelectorAll('.lines-wrapper'),
    active = document.querySelector('.active');

lines.forEach((line, index) => {
  line.addEventListener('click', e => {
    if (index == 0) {
      active.classList = 'active left';
    } else if (index == 1) {
      active.classList = 'active center';
    } else {
      active.classList = 'active right';
    }
  })
})