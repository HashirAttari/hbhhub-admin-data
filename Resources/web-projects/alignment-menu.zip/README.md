# Alignment Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/eYzwXVo](https://codepen.io/benhatsor/pen/eYzwXVo).

