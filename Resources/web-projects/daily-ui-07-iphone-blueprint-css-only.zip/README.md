# Daily UI #07 | iPhone blueprint | CSS only

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/LNrZEd](https://codepen.io/havardob/pen/LNrZEd).

