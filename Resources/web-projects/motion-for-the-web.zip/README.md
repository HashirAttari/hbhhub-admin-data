# ·● MOTION for the web ●·

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/EaJwKd](https://codepen.io/mselmany/pen/EaJwKd).

this pen repo: https://github.com/legomushroom/mojs-demo-1

Working on motion graphics library called mo · js. This is the first demo with v0.110.0 just to be sure I'm solving real world problems :)

mojs repo: https://github.com/legomushroom/mojs

Forked from [LegoMushroom](http://codepen.io/sol0mka/)'s Pen [·● MOTION for the web ●·](http://codepen.io/sol0mka/pen/ogOYJj/).