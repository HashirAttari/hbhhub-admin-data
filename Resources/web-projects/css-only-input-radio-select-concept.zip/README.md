# CSS only input radio select concept

A Pen created on CodePen.io. Original URL: [https://codepen.io/web-tiki/pen/JXwLGQ](https://codepen.io/web-tiki/pen/JXwLGQ).

Testing out some input radio selecting concept with an animated slide to whow which one is selected.