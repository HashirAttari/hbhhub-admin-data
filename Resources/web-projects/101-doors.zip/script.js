var h = document.querySelectorAll('.hall')
var b = document.querySelector('.char')
for(var i=0;i<101;i++){
  createDoor()
  if(i == 100) {
    var hh = h[3].getBoundingClientRect()
    h[0].style.width = hh.width + 200 + 'px'
  }
}

function createDoor() {
  var d = document.createElement('div')
  d.className = 'door'
  d.innerHTML = i+1
  d.style.boxShadow = 'inset 0 0 100px hsl('+Math.random()*360+'deg,25%,25%)'
  if(i % 2 === 0) {
    d.className = 'door even'
    d.style.boxShadow = 'none'
    d.style.backgroundColor = 'hsl('+Math.random()*360+'deg,25%,50%)'
    h[1].appendChild(d)
  } else {
    h[3].appendChild(d)
  }

}

// createDoor()

window.addEventListener('keydown', function(e){
  b.className = 'hall l3 char'
  b.classList.add('run')
  if(e.keyCode == 37) {
    b.classList.add('left')
  }
})

window.addEventListener('keyup', function(e){
  b.className = 'hall l3 char'
  if(e.keyCode == 37) {
    b.classList.add('left')
  }
})