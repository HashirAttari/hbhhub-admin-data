# Particle Photos

A Pen created on CodePen.io. Original URL: [https://codepen.io/callumacrae/pen/eYWWmXv](https://codepen.io/callumacrae/pen/eYWWmXv).

Generative particle art with user uploadable photos.

Source: https://github.com/callumacrae/sketchbook/blob/master/src/views/ParticlePhotoWebgl.vue