# To-Do App

A Pen created on CodePen.io. Original URL: [https://codepen.io/emilcarlsson/pen/RZOWgz](https://codepen.io/emilcarlsson/pen/RZOWgz).

A simple to-do app that saves your tasks for when you return later. You can complete, delete and even easily edit your tasks with inline-editing.