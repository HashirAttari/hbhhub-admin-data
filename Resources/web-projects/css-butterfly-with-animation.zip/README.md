# CSS Butterfly with animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/WNRqJNB](https://codepen.io/yudizsolutions/pen/WNRqJNB).

We have design the most beautiful creation of nature called "butterfly". We have used CSS properties for creative design and animation without using images. 

We took reference from our dribble shot:
https://dribbble.com/shots/6691331-Valley-Of-Flowers

Made by Rajnee Makwana from Yudiz