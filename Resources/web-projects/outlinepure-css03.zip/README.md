# Outline  - pure css - #03

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/zyEVBd](https://codepen.io/ig_design/pen/zyEVBd).

Really good shot! Check out the original: https://dribbble.com/shots/5748804-Outline-Illustration-animation