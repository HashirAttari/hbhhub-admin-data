# Daily UI #007 | Settings

A Pen created on CodePen.io. Original URL: [https://codepen.io/juliepark/pen/pLMxoP](https://codepen.io/juliepark/pen/pLMxoP).

Hulu settings redesign. Toggle between the tabs on the left hand bar!