# Particle Text

A Pen created on CodePen.

Original URL: [https://codepen.io/DonKarlssonSan/pen/reGPwZ](https://codepen.io/DonKarlssonSan/pen/reGPwZ).

In my Pen [Laser Writer](http://codepen.io/DonKarlssonSan/pen/VazvQx) I did not care about reading the pre-rendered text's color value of each pixel - it was just a matter of pixel or no pixel. I stored the x and y coordinates in a list.

With this Pen however I wanted to improve the font anti aliasing ("edge smoothness"). That is why I also store the color of each pixel.

I usually use fillRect to draw pixels but this time I use imageData both for reading and writing pixels.

There is an interesting performance comparison for different ways of pushing pixels to the screen: http://jsperf.com/canvas-pixel-manipulation/167
fillRect seems to suck.

Paper like CSS shadows from: http://www.sitepoint.com/pure-css3-paper-curls/ by Craig Buckler.