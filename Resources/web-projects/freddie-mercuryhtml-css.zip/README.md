# Freddie Mercury - HTML & CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/zYvLYbY](https://codepen.io/ricardoolivaalonso/pen/zYvLYbY).

