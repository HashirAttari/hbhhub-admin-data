# Slide Up Text Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/abdlkhn/pen/eYJPZYG](https://codepen.io/abdlkhn/pen/eYJPZYG).

