# Partners in crime

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/rNeeJWb](https://codepen.io/ricardoolivaalonso/pen/rNeeJWb).

