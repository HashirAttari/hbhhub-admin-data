var dot = $('.dot')
    level = 0,
    time=0,
    delayDot = 0,
    easing = 'cubic-bezier(0.175,  0.885, 0.320, 1.275)';


$('.level').click(function(){
	time = $(this).data('time');
	start();	
});

function start(){
	$('#start').addClass('off');	
	$('#Dots').removeClass('off');
	$('#levels').html(level+=1);
}

$('body').on('mouseover','.dot',function(){
	var self = $(this);
	self.addClass('on');
	if($('.dot.on').length==dot.length){		
		setTimeout(function(){
			dot.removeClass('on');
		},500);
		$('#Dots').addClass('off');
		$('#Continue').addClass('on');
		time+=200;
	}
	else {
		setTimeout(function(){
			self.removeClass('on');
		},time);
	}

});

$('#Continue').click(function(){
	$('#Continue').removeClass('on');	
    $('#Dots').append($('<li class="dot"></li><li class="dot"></li><li class="dot"></li><li class="dot"></li>'));    
	dot = $('.dot');
	start();
});