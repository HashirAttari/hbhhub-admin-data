# Text Animation - Reveal Effect 

A Pen created on CodePen.io. Original URL: [https://codepen.io/okawa-h/pen/qGJMMo](https://codepen.io/okawa-h/pen/qGJMMo).

JavaScript Animation