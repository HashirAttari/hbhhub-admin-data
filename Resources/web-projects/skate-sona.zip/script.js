var skate = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1647.39481 1775.8468'><title>Awesome Skate SVG</title><g id='Toestop'><path class='toestop' d='M1601.86957,1586.73913c11.47826-20.86956,44.34782-53.21739,90.7826-72s69.913-17.73913,84-17.21739,22.43479,3.65217,28.17392,10.95652,33.913,49.56522,41.73913,65.73913,11.47826,23.47826,8.86956,34.95652-6.26087,30.78261-40.69565,56.86957-60,40.69565-94.95652,45.913-54.26087,3.13044-64.69565-1.04348-21.39131-10.95652-29.73913-25.04347-29.2174-78.26087-28.17392-86.6087S1601.86957,1586.73913,1601.86957,1586.73913Z' transform='translate(-208.87512 -99.20034)' /></g><g id='Axle'><path class='axle' d='M1605,1521l4.17391,13.04348,22.43479,23.47826s12,0,22.43478-1.04348c0,0-1.56522,8.86957,7.30435,12s31.30434,4.17391,55.30434-13.56522,25.56522-16.69565,25.56522-25.56521-3.65217-9.913-9.3913-9.913c0,0,17.73913-11.47826,21.3913-20.34782a52.95008,52.95008,0,0,0-.52174-12c-1.04348-6.26087-9.913-17.73913-9.913-17.73913l-9.913-5.2174Z' transform='translate(-208.87512 -99.20034)' /><polygon class='axle' points='1217.69 1360.756 1190.56 1395.713 1255.255 1419.191 1274.038 1377.974 1217.69 1360.756' /><path class='axle' d='M1185,1489.69565s-16.17391,9.91305-18.78261,22.43478-1.04348,21.39131,5.21739,25.56522,4.69565,5.21739,4.69565,5.21739l1.04348,19.30435s-8.34782,1.04348-9.913,12.52174-2.6087,43.30435-1.04348,49.04348,3.65218,13.56522,17.21739,18.26087,17.21739,4.69565,19.30435,7.82609.52174,2.08695.52174,2.08695-8.34783,2.6087-6.78261,13.56522,5.21739,19.30435,9.913,21.3913,11.47827,6.78261,16.69566,8.34783,27.13043-6.78261,27.13043-6.78261l73.56522-174.78261s1.56522-16.69565-1.56522-21.3913-17.73913-18.78261-31.82609-21.39131S1185,1489.69565,1185,1489.69565Z' transform='translate(-208.87512 -99.20034)' /><polygon class='axle' points='129.342 1370.669 146.038 1412.93 211.777 1388.408 177.864 1341.452 129.342 1370.669' /><path class='axle' d='M504.13043,1504.30435s-7.82608-9.91305-3.65217-19.30435,10.43478-11.47826,16.69565-13.04348,30.78261-3.13043,30.78261-3.13043l80.86957,13.56521s17.21739,9.91305,22.95652,20.86957,5.21739,22.43478,3.65217,26.087-6.78261,8.86956-12.52174,12L642.3913,1557s7.30435,4.17391,9.39131,10.95652,0,39.65218-1.56522,49.04348-2.087,14.6087-12,19.30435-20.86956,9.3913-25.04348,9.3913c0,0,4.69566,4.17392,4.17392,13.04348s-4.69566,23.47826-19.30435,24S504.13043,1504.30435,504.13043,1504.30435Z' transform='translate(-208.87512 -99.20034)' /></g><g id='Wheels'><path class='wheel' d='M1232.02174,1732.6087c-6.51645-35.375-10.17391-63.78261-10.17391-80.2174s4.30434-38.34782,12.13043-57.52173,28.56522-47.73914,52.04348-64.95653,48.52174-32.47826,77.087-36.3913,42.65217-5.86957,66.52173-2.34783,55.17392,16.04348,80.6087,35.6087,37.95652,40.30435,47.73913,62.60869,17.21739,53.2174,20.73913,75.13044,9.78261,52.82609-1.17391,83.73913-25.82609,56.73913-48.52174,76.30435-29.34783,30.13043-93.13044,46.56521-134.21739-23.08695-149.47826-40.30434S1240.23913,1777.21739,1232.02174,1732.6087Z' transform='translate(-208.87512 -99.20034)' /><path class='wheel' d='M244.528,1724.7764c-4.02484-28.17392,1.34162-67.52795,4.472-88.54659s14.31056-69.31677,33.54037-90.78261,43.37888-44.27329,70.21118-52.323,58.13665-19.677,104.19876-11.62733,76.47205,31.30435,87.65217,40.24845,33.09317,32.646,44.2733,59.92547,17.441,66.63354,11.62733,102.40994-9.83851,57.24223-13.86336,69.764-26.38509,49.63975-47.40373,66.18634-45.1677,33.98757-80.49689,40.69565-74.236,3.13043-112.24845-11.18013-73.34161-58.58385-84.52174-77.36646S244.528,1724.7764,244.528,1724.7764Z' transform='translate(-208.87512 -99.20034)' /></g><g id='Bearings'><path class='bearing' d='M366.3913,1665.52174c8.09874-18.06642,21.39131-30.26087,33.39131-33.39131s30.26087-5.21739,47.47826,2.6087S474.913,1658.21739,478.56522,1677,474.3913,1710.913,465,1720.30435s-30.26087,26.08695-63.65217,15.13043S359.6087,1680.65217,366.3913,1665.52174Z' transform='translate(-208.87512 -99.20034)' /><path class='bearing' d='M1355.6087,1667.6087c15.41208-27.26754,52.17391-31.30435,75.13043-21.91305s34.43478,32.86957,31.82609,50.087-9.39131,41.73913-43.30435,50.60869-55.82609-13.04347-64.69565-26.60869S1348.82609,1679.6087,1355.6087,1667.6087Z' transform='translate(-208.87512 -99.20034)' /></g><g id='Hardware'><path class='hardware' d='M1376.21739,1662.56522l43.04348-7.82609,23.47826,26.6087L1449,1700.13043s-3.13043,22.69566-11.73913,32.087-26.6087,15.65218-41.47826,11.73913-34.43478-34.43478-34.43478-34.43478Z' transform='translate(-208.87512 -99.20034)' /><path class='hardware' d='M376.30435,1696.26087l18.78261-45.3913,41.47826-5.47827,25.04348,25.82609,2.34782,16.43478-14.86956,36s-16.43479,10.95653-33.65218,11.73913S381,1710.34783,376.30435,1696.26087Z' transform='translate(-208.87512 -99.20034)' /></g><g id='Plate'><path class='plate' d='M1773.52174,1361.34783a18.96848,18.96848,0,0,1,4.17391,13.04347c-.52174,7.82609-17.73913,65.2174-22.95652,70.95653s-8.86956,13.56521-16.17391,20.86956c0,0-21.39131,15.13044-40.69565,27.13044s-53.73914,26.60869-73.04348,29.21739-39.65218,2.087-51.13044-5.21739-14.60869-26.087-16.69565-27.13044-7.82609-1.04348-14.6087,2.6087-12,10.43478-18.7826,9.3913S1386.913,1446.913,1386.913,1446.913s-46.43478,3.13044-60,9.39131-14.60869,18.78261-18.78261,19.82608-108,18.26087-121.56521,19.30435-12.52174-4.69565-16.69565-7.82608-10.95653-8.86957-23.47827-10.43479-188.34782,1.56522-268.17391-2.08695-181.04348-3.65218-200.34782-2.087-16.69566,7.82609-27.13044,13.56522-36-5.21739-48.52174-6.26087S549,1469.86957,527.6087,1468.82609s-12-6.78261-16.17392-13.04348-6.26087-7.30435-13.56521-7.82609-48-10.43478-56.86957-9.3913-52.69565,16.17391-94.95652,35.47826-37.56522,16.69565-55.82609,15.13043S271.95652,1473,271.95652,1464.13043s-3.13043-65.21739-4.17391-75.65217-5.73913-17.73913-2.087-23.47826,12-14.087,12-14.087L577.17391,1329s62.087,4.17391,110.087,5.73913,160.69565,2.6087,160.69565,2.6087l174.26087,59.47826Z' transform='translate(-208.87512 -99.20034)' /></g><g id='Sole'><path class='sole' d='M245.86957,1113s-7.04348,10.17391-7.04348,26.6087,17.21739,133.04347,21.913,159.65217,7.82609,42.26087,8.6087,52.43478-3.913,13.30435,12.52174,21.13044,49.30434,29.73913,121.30434,29.73913,107.21739,5.47826,126.78261,7.82608,58.69565,3.91305,63.39131-10.95652-1.56522-43.04348,9.3913-56.34782,19.56522-18.78261,21.913-25.82609-5.47826-34.43478-3.13043-57.13044c0,0,129.913,32.087,184.69565,57.13044s122.087,68.86956,153.39131,84.52174,90,44.60869,134.60869,49.30435,175.30435,7.04347,302.86957-.78261,149.47826-9.39131,201.13043-21.91305,159.65218-41.47826,174.52174-54,17.21739-28.95652,18.78261-44.60869-8.6087-43.82609-8.6087-43.82609l-425.73913,86.86957-399.13043-57.13044L709.17391,1177.17391l-279.3913-53.21739Z' transform='translate(-208.87512 -99.20034)' /></g><g id='Boot'><path class='boot' d='M379.69565,456.02174s-23,45-33,90-53,156-68,191-50,132-59,174-17,82-4,145,25,83,55,100,113,36,153,39,98,3,195,28,193,63,239,86,136,72,207,83,119,11,196,11,239-6,317-23,148-39,178-53,43-40,46-60,1-49-7-74-36-81-101-98-275-99-374-165-177-127-212-206-76-232-93-286-44-81-59-90c0,0-20-55-44-105s-51-91-55-114-31-37-54-26-58,33-76,83c0,0-84,36-159,75s-165,77-180,110S379.69565,456.02174,379.69565,456.02174Z' transform='translate(-208.87512 -99.20034)' /></g><g id='Toecap'><path class='toecap' d='m 1541.5727,1481.8166 c 0,0 13.6799,46.3331 38.9801,59.6337 118,-8.4286 163.7143,-64.7143 193.7143,-78.7143 26.2703,-109.4214 54.2345,-124.182 40.4286,-286.8572 -66.5714,-103.5714 -61.7143,-73.8571 -196.7143,-123.7142 -29.8851,-11.9025 -97.2078,-45.8285 -112.4929,-41.1913 -14.6442,4.4427 10.1582,32.6235 9.6626,61.8358 -0.5731,33.7757 -12.0034,77.0507 -7.339,119.6664 8.3008,103.7708 18.9404,191.5448 33.7606,289.3411 z' transform='translate(-208.87512,-99.20034)' id='path963' /></g><g id='Eyelets'><path class='eyelet' d='M1529.6087,1183.69565c1.9459,23.3509,18.7826,24.52174,26.08695,25.56522s22.95652-.52174,25.56522-13.04348,1.04348-25.04348-7.30435-30.78261-28.17391-11.47826-36-1.04348S1529.087,1177.43478,1529.6087,1183.69565Z' transform='translate(-208.87512 -99.20034)' /><path class='eyelet' d='M921.65217,777.087c-1.04347,13.56521,4.17392,23.47826,8.86957,26.60869s17.73913,10.43478,31.30435,2.6087,13.56521-20.86957,11.47826-28.69565-8.34783-21.913-27.13044-19.82609S921.65217,777.087,921.65217,777.087Z' transform='translate(-208.87512 -99.20034)' /><path class='eyelet' d='M984.78261,845.95652c-6.26087,12-4.69565,21.913,0,28.17391s10.95652,10.43479,22.43478,10.95653,23.47826-12,25.04348-20.34783-.52174-28.17391-8.86957-30.78261-17.73913-3.65217-26.60869,2.087S984.78261,845.95652,984.78261,845.95652Z' transform='translate(-208.87512 -99.20034)' /><path class='eyelet' d='M1040.6087,915.34783c-6.26087,13.56521-2.6087,21.913,1.04347,29.21739S1058.34783,956.04348,1064.087,955s16.69565-5.21739,22.95652-15.13043,1.04348-20.86957-2.6087-25.56522-12-13.56522-25.04348-9.913S1040.6087,915.34783,1040.6087,915.34783Z' transform='translate(-208.87512 -99.20034)' /><path class='eyelet' d='M1108.43478,991c0,18.26832,9.39131,22.95652,15.13044,26.087s17.21739,2.60869,27.13043-2.6087,14.6087-20.86956,13.04348-25.56522-8.34783-19.82608-22.43478-20.86956-21.39131,2.60869-25.56522,8.34782S1108.43478,984.73913,1108.43478,991Z' transform='translate(-208.87512 -99.20034)' /><path class='eyelet' d='M1186.17391,1057.26087c1.795,19.74466,9.39131,21.3913,15.65218,25.04348s19.30434,3.65217,28.17391-2.087,14.087-12.52174,10.43478-26.60869-15.13043-17.73913-25.04348-19.30435S1185.13043,1045.78261,1186.17391,1057.26087Z' transform='translate(-208.87512 -99.20034)' /><path class='eyelet' d='M1263.913,1102.65217c-1.04224,21.3659,18.78261,26.087,24,27.13044s17.73913-2.087,24-12.52174,2.087-26.087-2.08695-28.69565-7.82609-8.34783-17.21739-8.86957S1264.95652,1081.26087,1263.913,1102.65217Z' transform='translate(-208.87512 -99.20034)' /><path class='eyelet' d='M1348.95652,1151.69565c-1.974,22.37212,29.21739,31.30435,40.69565,21.91305s16.69566-26.087,6.26087-36-13.04347-12-22.95652-10.43479S1350.52174,1133.95652,1348.95652,1151.69565Z' transform='translate(-208.87512 -99.20034)' /><path class='eyelet' d='M1436.087,1180.913c0,27.17555,23.47826,29.21739,30.78261,27.65218s19.30434-7.30435,22.43478-19.30435-6.26087-25.04348-15.13044-28.17391-7.30434-4.69566-19.30434-1.56522S1436.087,1174.13043,1436.087,1180.913Z' transform='translate(-208.87512 -99.20034)' /></g><g id='Laces'><path class='lace' d='M1575,1138c-2-13-10-32-10-32s-6-12-11-17-14-12-14-12,2-17,6-22,7-13,12-11c0,0,8-5,2-7s-14,3-20-1-9-6-21-7-14,25-14,25-18,3-40-11c0,0,8-22,14-28s-10-10-16-10-14-14-21-13-12,22-12,22-14,1-32-12c0,0,12-19,8-23s-21-5-28-14-11-12-19-5-11,4-16,0-18-8-17-14-2-25-11-26-20-15-27-18-9,2-9,2-20-12-22-16-9-27-20-36-31-15-35-25-11-38-30-39c0,0-65-131-76-154,0,0-18-72-24-89s-22-76-33-94c0,0-6-67-13-79s-41-48-66-11c0,0-2,12-28,23s-17,7-32,18-38,20-53,29-37,36-45,50,11,63,33,65,46-2,54-5a61.40619,61.40619,0,0,1-16,14c-10,6-36,24-40,38s3,49,13,58,20,18,34,20,51,10,66,5,28-9,39-15c0,0,2,31,6,48,0,0-32,34-39,49s-12,30,0,32,23,1,32-4a55.22841,55.22841,0,0,0,19-18l6,113s11,7,17-4c0,0,16-21,28-32s14-17,14-17,8,22,14,35c0,0-20,41-23,50s-6.25717,14.102-2.86957,17.913c4.17392,4.69566,8.34783,5.73913,15.13044,5.21739C1078.31111,935.58811,1087,933,1096,924s13-15,13-15a165.058,165.058,0,0,0,31,30s-13,28-11,46,13,17,25,14,27-19,35-38c0,0,25-12,36-30,0,0,5,44-4,70s-23,39-18,55,12,11,23,8,31-26,32-40,4-36,4-36l25,18s-10,55-9,73,1,26,9,29,21-1,29-14,17-40,15-56l27,15,5-10s2,23,0,41-2,59,8,63,12,4,25-7,17-29,19-42,0-18,0-18l20,10,4-10s8,8,7,18-7,37,0,56,6,22,15,27,16,0,23-9,12-36,11-43-5-19-5-19,21,7,28,8l4-12s16,26,16,45,4,30,10,32,14,3,21-4S1577,1151,1575,1138ZM841.02173,524.913c-19-13-14-47-14-47,90-9,132-79,139-77s11,5-16,40S841.02173,524.913,841.02173,524.913ZM872.5,644.5s-4,6-15-8-16-36-10-40c0,0,46-3,75-33s55-53,58-56c0,0,0,83,5,105C985.5,612.5,939.5,635.5,872.5,644.5ZM1046,686c2,5,3,15,3,15-4,5-8,6-8,6C1044,701,1046,686,1046,686Zm5.82617,101.43475c-7.43481,12-27.13049,31.82611-27.13049,31.82611l-1.43482-60.65216c1.17395-2.73913,3.03162-3.57025,3.913-2.6087,1.43481,1.56519-.52173,4.30432,8.86963,1.17389s21.52173-15,21.52173-15,1.43481,4.30438,2.2174,16.69568S1059.26086,775.43475,1051.82617,787.43475ZM1077,677s-7,10-12,12c0,0-5-37-2-45C1063,644,1078,661,1077,677Zm-28-116s30,50,38,65c0,0,16,61,19,76h-4s-3-14-6-22S1049,561,1049,561Zm53.82617,265.76086s-2.93481-5.47827-5.47827-17.413c0,0,7.82593-3.91309,8.60864-6.84784C1105.95654,802.5,1104.58691,821.08691,1102.82617,826.76086ZM1109,741c-9,9-6,8-16,14,0,0,5-25,7-39C1100,716,1118,732,1109,741Zm27.67383,88.8913s.97827-2.34784.39136-13.5c0,0,1.761,4.89129,3.52172,8.413A5.05344,5.05344,0,0,1,1136.67383,829.8913Zm27.0979,54c-.88037,10.4674-3.61963,16.23913-3.61963,16.23913-12.71729-8.02173-18.39124-14.86957-18.39124-14.86957,6.75-3.32611,16.337-16.72827,17.413-17.51086,1.07617-.78265,2.25,2.15216,3.52185,3.81519S1164.6521,873.42389,1163.77173,883.8913Zm43.66308-35.54346c-2.2174-4.95654-5.3479-8.087-3.39135-13.82611,0,0,5.60864,5.34784,7.30444,9.39129,1.69556,4.04346,6.39124,23.60871,8.739,28.43482C1220.08691,872.34784,1209.6521,853.30432,1207.43481,848.34784Zm51.39136,121.69562s-1.82617-42.7826-5.60876-68.087c-.69666-4.66009-.26087-7.17389.78259-8.86957s4.17383.65223,6.26086,5.21741,6.39124,13.30438,7.56531,23.47827c1.17383,10.17389,2.86951,27.7826,5.21729,31.56525C1273.04346,953.34784,1267.30432,966,1258.82617,970.04346Zm67.04346,52.43481s-5.3479-37.82611-9.91309-54.26092a153.21284,153.21284,0,0,0,8.86963-13.30433s7.43469,4.04346,11.47815,18.13044A118.108,118.108,0,0,0,1347.6521,999S1332.6521,1013.73914,1325.86963,1022.47827Zm89.21728,19.04346c-.39123,1.69556-7.69555,17.21741-9,15.6521s-7.43481-21.6521-11.47827-29.08692a64.0294,64.0294,0,0,0-6.78247-10.56518s5.08692-10.56525,7.17383-11.86957,9.6521,16.17389,12.26086,20.6087S1415.47827,1039.826,1415.08691,1041.52173Zm67.82618,56.60864s-10.69568-13.69556-13.43482-21-10.30444-23.21728-10.30444-23.21728a6.47551,6.47551,0,0,1,1.04358-3.78272c1.174-1.56518,8.34778,1.82617,16.56518,9.91309s15.26087,14.47827,16.17395,15.52173C1492.95654,1075.56519,1485.26086,1097.21729,1482.91309,1098.13037Z' transform='translate(-208.87512 -99.20034)' /></g><g id='Hooks'><path class='hook' d='M802.56522,364.82609c-18.08472-2.58353-37.04348,7.30434-40.69565,20.86956S762.3913,412.82609,765,419.087s11.47826,9.3913,16.17391,11.47826,31.30435,0,38.087-3.13044,9.913-4.69565,7.82609-9.3913a38.361,38.361,0,0,0-5.21739-8.34783s2.60869-8.34782-2.087-21.3913c0,0,5.73913-16.69565-.52174-18.78261S806.21739,365.34783,802.56522,364.82609Z' transform='translate(-208.87512 -99.20034)' /><path class='hook' d='M774.913,526.56522c-4.332-16.60622-3.65217-24,.52174-29.73913s1.56522-8.34783,5.21739-11.47826,27.13044-9.39131,27.13044-9.39131l-2.6087,7.30435S825,479.087,827.6087,480.65217s3.13043,14.6087-.52174,15.65218c0,0,4.69565,2.60869,5.21739,5.73913s1.56522,13.04348-.52174,15.65217c0,0,7.30435,2.6087,7.30435,6.78261s3.13043,8.34783-8.86957,12.52174-30.78261,8.86957-37.56522,7.30435S778.04348,538.56522,774.913,526.56522Z' transform='translate(-208.87512 -99.20034)' /><path class='hook' d='M832.30435,593.34783S818.73913,597.52174,813,600.65217s-14.6087,15.13044-13.56522,26.087,5.73913,23.47826,12,29.21739,20.34783,7.30435,26.6087,4.69565,25.56522-11.47826,28.69565-13.56521,2.087-9.913-4.17391-11.47826c0,0-.52174-9.39131-2.087-12s-2.60869-9.39131-7.30435-9.913c0,0,4.69566-18.78261,0-17.73913s-21.913,4.69565-21.913,4.69565Z' transform='translate(-208.87512 -99.20034)' /></g></svg>"
$(skate).appendTo('#skate');

var colors = {
  'Boot': {
    'Beach Bunny': {
      'Watermelon': '#ff7282',
      'Peach Blanket': '#e79f7c',
      'Strawberry Lemonade': '#fdea51',
      'Sky Blue': '#bbe2ec',
      'Periwinkle Sunset': '#6970dd',
    },
    'Boardwalk': {
      'Red': '#c23940',
      'Blue': '#029cbe',
      'Purple': '#694d87',
      'Pink': '#d8557f',
      'Tan': '#c2a073',
      'Black': '#13161b',
    },
    'Impala': {
      'Living Coral': '#f17461',
      'Voltage Green': '#e5d758',
      'Aqua': '#47c0b9',
      'Purple': '#6a5798',
      'Pink': '#e6b1b5',
      'White': '#f3f4f1',
      'Black': '#282325',
    },
    'Lolly': {
      'Poppy': '#e60327',
      'Clementine': '#da792a',
      'Pineapple': '#e9cb28',
      'Honeydew': '#b5d399',
      'Floss': '#c6e6e2',
      'Jade': '#0aacac',
      'Pool Blue': '#0090c1',
      'Taffy': '#502e80',
      'Fuchsia': '#ca0180',
      'Strawberry': '#fbb4b6',
      'Black': '#111113',
    },
  },
  'Laces': {
    'Beach Bunny': {
      'Watermelon': '#64d752',
      'Peach Blanket': '#765d9f',
      'Strawberry Lemonade': '#f7c3a5',
      'Sky Blue': '#dc55b4',
      'Periwinkle Sunset': '#d3906f',
    },
    'Boardwalk': {
      'Red': '#e64d63',
      'Blue': '#2498b9',
      'Purple': '#422c74',
      'Pink': '#e66aa3',
      'Tan': '#947c4f',
      'Black': '#383f3f',
    },
    'Derby Core': {
      'Red': '#d33333',
      'Peach': '#fcb797',
      'Fluorescent Orange': '#ff4e3b',
      'Carrot Orange': '#f48746',
      'Sunflower Yellow': '#ffd060',
      'Lemon Yellow': '#fbe97f',
      'Lime Green': '#accd42',
      'Olive Green': '#9baf5a',
      'Honeydew Green': '#bbf3da',
      'Aqua Spray Teal': '#6ca8b2',
      'Teal': '#005a64',
      'Pool Blue': '#3688ba',
      'Grape Purple': '#9d43a7',
      'Periwinkle Purple': '#acb8d2',
      'Hot Magenta': '#fc267c',
      'Hot Pink': '#f25987',
      'Pink Cotton Candy': '#ffbfc7',
      'Pomegranate': '#773d50',
      'Coffee Latte Brown': '#b58962',
      'Tan': '#d1ab87',
      'White': '#f0ebe8',
      'Slate Gray': '#3d414b'
    },
    'Impala': {
      'Living Coral': '#fcab91',
      'Aqua': '#ee9da9',
      'Voltage Green': '#f5e567',
      'Purple': '#598997',
      'Pink': '#e3c440',
      'White': '#77cfcd',
      'Black': '#383836',
    },
    'Moxi': {
      'Oyster': '#e5c39c',
      'Black': '#3d3d3d',
    },
  },
  'Wheels': {
    'Beach Bunny': {
      'Watermelon': '#04be2e',
      'Peach Blanket': '#7b5ea0',
      'Strawberry Lemonade': '#e5757a',
      'Sky Blue': '#9e1152',
      'Periwinkle Sunset': '#ce8250',    
    },
    'Boardwalk': {
      'Red': '#c90100',
      'Yellow': '#dfcf27',
      'Blue': '#78dae0',
      'Pink': '#e800a6',
      'Purple': '#710e96',
      'Black': '#020407',
    },
    'Fame Artistic': {
      'Clear Red': '#af0023',
      'Clear Blue': '#01a7db',
      'Clear Purple': '#402a7a',
      'Clear Pink': '#a4069b',
    },
    'Fundae': {
      'Bubble Gum': '#fec1dc',
      'Creme-de-Menthe': '#82c8ce',
      'Birthday Cake': '#76c4eb',
      'Lavender': '#bcb4d8'
    },
    'Gummy': {
      'Cherry': '#7b1417',
      'Clementine': '#dd743f',
      'Pineapple': '#eedd71',
      'Honeydew': '#b3da8f',
      'Seafoam': '#d0ebca',
      'Lavender': '#a4a2da',
      'Pink': '#f5d2e9',
      'Smoke': '#6c7071'
    },
    'Impala': {
      'Living Coral': '#f4896b',
      'Voltage Green': '#f3e753',
      'Aqua': '#47c0b9',
      'Purple': '#ab96c4',
      'Pink': '#f1bbb7',
      'White': '#ec9ca6',
      'Black': '#36383e',
    },
    'Radar' : {
      'Donut': '#ffb988',
    },
    'Radar 57': {
      'Red': '#f22c3a',
      'Orange': '#fe8549',
      'Yellow': '#fee000',
      'Aqua': '#67dac6',
      'Clear Blue': '#8bd7fe',
      'Navy': '#00308c',
      'Purple': '#e13fa8',
      'Pink': '#ff3379'
    },
    'Radar 62': {
      'Pink': '#df5166',
      'Clear Yellow': '#ddd550',
      'Clear Green': '#39cfba',
      'Teal': '#4194ac',
      'White': '#e6eaee'
    },
    'Radar 65': {
      'Clear Red': '#d41813',
      'Lime Green': '#88c45e',
      'Blue': '#64aeec',
      'Purple': '#af3b90',
      'Clear': '#fbfcfc',
      'Black': '#0b0d1a',
    },
    'Sonar Zen': {
      'Red': '#fe5831',
      'Orange': '#ff7c22',
      'Yellow': '#ffde32',
      'Green': '#6ce875',
      'Blue': '#019be5',
      'Purple': '#b2159e',
      'Pink': '#fe6b83',
      'Black': '#2c292a',
    },
    'Rollerbones Team': {
      'Green': '#5cdd00',
      'Purple': '#572b81',
      'Pink': '#fb006a',
      'White': '#ecede8',
      'Black': '#1b1b1b',
    },
    'Trick' : {
      'Orange': '#eab381',
      'Green': '#c1ce63',
    },
  },
  'Toestop': {
    'Break Petals' : {
      'Carnation Pink': '#ffcada',
      'Yellow Daisy': '#febb0c',
      'Red Hibiscus': '#f54b4b',
      'Violet Forget-Me-Not': '#856ed3',
    },
    'Chaya': {
      'Red': '#f33e56',
      'Orange': '#f05e32',
      'Yellow': '#d8ed71',
      'Blue': '#57cec1',
      'Pink': '#ff66ae',
      'Natural': '#ecc791',
    },
    'Gumball': {
      'Gumball': '#e6d3b6'
    },
    'Impala': {
      'Living Coral': '#f4896b',
      'Voltage Green': '#eee339',
      'Aqua': '#47c0b9',
      'Purple': '#d6c2db',
      'Pink': '#e4bebd',
      'White': '#ed9caa',
      'Black': '#71726f',
    },
    'Powerdyne': {
      'Black': '#302e38',
      'Gray': '#757880'
    },
    'Rx': {
      'Red': '#d3302f',
      'Yellow': '#f6ea1e',
      'Green': '#58b94b',
      'Light Blue': '#9ecdda',
      'Blue': '#549dd0',
      'Purple': '#724b8b',
      'Pink': '#ec4e73',
      'Black': '#383232',
      'Natural': '#b7a468',
    },
  },
  'Eyelets': {
    'Beach Bunny': {
      'Metal': '#d3d2dd',
    },
    'Boardwalk': {
      'Red': '#b1686d',
      'Blue': '#7bbece',
      'Purple': '#a087b4',
      'Pink': '#d07394',
      'Tan': '#a0724f',
      'Black': '#848b8e',
    },
    'Lolly': {
      'Oyster': '#fefae6',
      'Black': '#4c4c4c',
    },
    'Impala': {
      'Living Coral': '#f5af8c',
      'Voltage Green': '#c9be0a',
      'Aqua': '#f97087',
      'Purple': '#dadbdd',
      'Pink': '#e0e5e1',
      'White': '#e3e4df',
      'Black': '#070506',
    },
  },
  'Sole': {
    'Beach Bunny': {
      'Brown': '#784f3b',
    },
    'Boardwalk': {
      'Brown': '#735040',
      'Gray': '#9ea59e',
      'Black': '#32373a',
    },
    'Lolly': {
      'Brown': '#aa6742',
      'Black': '#3f3f3f',
    },
    'Impala': {
      'Voltage Green': '#c1bb35',
      'Default': '#ac7f5c',
      'Black': '#343434',
    },
  },
  'Plate': {
    'Beach Bunny': {
      'Metal': '#c3bfca',
    },
    'Boardwalk': {
      'Default': '#5a554f',
    },
    'Powerdyne': {
      'Black': '#39373a',
    },
  },
  'Toecap': {
    'None': {
      'Default': 'transparent',
    },
    'Beach Bunny': {
      'Watermelon': '#ff7282',
      'Peach Blanket': '#e79f7c',
      'Strawberry Lemonade': '#fdea51',
      'Sky Blue': '#bbe2ec',
      'Periwinkle Sunset': '#6970dd',
    },
    'Lolly': {
      'Poppy': '#e60327',
      'Clementine': '#da792a',
      'Pineapple': '#e9cb28',
      'Honeydew': '#b5d399',
      'Floss': '#c6e6e2',
      'Jade': '#0aacac',
      'Pool Blue': '#0090c1',
      'Taffy': '#502e80',
      'Fuchsia': '#ca0180',
      'Strawberry': '#fbb4b6',
      'Black': '#111113',
    },
  }
};

initializeUi(colors);
initializeSkate();
randomize();

function initializeUi(colors) {
  for (var part in colors) {
    var partString = part.replace(/\s+/g, '-').toLowerCase();
    var active = partString == 'boot' ? 'active' : '';
    var show = active ? 'show' : '';

    var partMarkup = `<li class="nav-item"><a href="#${partString}" class="nav-link ${active}" data-target="#${partString}" data-state="unlocked" data-toggle="tab">${part} <i class="fas fa-unlock fa-xs"></i></a></li>`;
    $('#ui #tabsMenu').append(partMarkup);
    $('#ui #tabsMenuContent').append(`<div class="tab-pane fade ${show} ${active}" id="${partString}"></div>`);

    for (var group in colors[part]) {
      var groupString = group.replace(/\s+/g, '-').toLowerCase();
      var groupMarkup = `<h4>${group}</h4><div class="${groupString}"></div>`;
      $(`#${partString}`).append(groupMarkup);

      for (var color in colors[part][group]) {
        var hexValue = colors[part][group][color];
        var colorString = color.replace(/\s+/g, '-').toLowerCase();
        var colorMarkup = `<span data-part=${partString} data-color=${hexValue} class="color-swatch" style="background: ${hexValue}" title="${color}"></span>`;
        $(`.${groupString}`, `#${partString}`).append(colorMarkup);
      }
    }
    var customMarkup = `<h3>Custom</h3>`;
    customMarkup += `<input type="color" data-part=${partString} id="${partString}-custom" class="custom-color" name="${partString}-custom" value="#eeeeee">`;
    customMarkup += `<label for="${partString}-custom">Choose a color</label>`;
    $(`#${partString}`).append(customMarkup);
  }
}

function changeColor(element, color) {
  element.each(function() {
    this.style.fill = color;
  });
}

$('.custom-color').change(function() {
  var part = $(this).data('part');
  var element = getPart(part);
  var color = $(this).val();
  changeColor(element, color);
});

$('.color-swatch').on('click', function() {
  var part = $(this).data('part');
  var color = $(this).data('color');
  var element = getPart(part);
  changeColor(element, color);
});

function getPart(name) {
  var part;
  
  switch (name) {
    case "axle":
    case "axles":
      part = $('#skate #axle');
      break;
      
    case "bearing":
    case "bearings":
      part = $('#skate .bearing');
      break;
    
    case "boot":
      part = $('#skate .boot');
      break;
    
    case "hook":
    case "hooks":
    case "eyelet":
    case "eyelets":
      part = $('#skate .eyelet, #skate .hook');
      break;
      
    case "hardware":
      part = $('#skate .hardware');
      break;
    
    case "lace":
    case "laces":
      part = $('#skate .lace');
      break;
    
    case "plate":
      part = $('#skate .plate');
      break;
    
    case "sole":
      part = $('#skate .sole');
      break;
    
    case "toecap":
      part = $('#skate .toecap');
      break;
      
    case "toestop":
    case "toestops":
      part = $('#skate .toestop');
      break;
    
    case "wheel":
    case "wheels":
      part = $('#skate .wheel');
      break;
  }
  
  return part;
}

$('#randomize').on('click', function(e) {
  e.preventDefault();
  randomize();
})

function initializeSkate() {
  var black = '#333333';
  var metal = '#888888'; 
  var plate = '#c3bfca';
  
  var axle = getPart('axle');
  changeColor(axle, metal);
  
  var bearings = getPart('bearing');
  changeColor(bearings, black);
  
  var hardware = getPart('hardware');
  changeColor(hardware, plate);
}

function randomize() {
  for (var part in colors) {
    var list = [];
    for (var group in colors[part]) {
      for (var color in colors[part][group]) {
        var hexColor = colors[part][group][color];
        list.push(hexColor);
      }
    }
    var partString = part.replace(/\s+/g, '-').toLowerCase();

    var state = $(`[data-target="#${partString}"]`).data('state');
    if (state == 'unlocked') {
      var randomColor = list[Math.floor(Math.random() * list.length)];
      var element = getPart(partString);
      changeColor(element, randomColor);
    }
  }
};

$( ".nav-link" ).dblclick(function() {
  var state = $(this).data('state');
  if (state == 'locked') {
    $(this).data('state', 'unlocked');  
  }
  else {
    $(this).data('state', 'locked');
  }
  
  $("i", $(this)).toggleClass("fa-lock fa-unlock");
});

$('.preset').on('click', function(e) {
  e.preventDefault();
  var preset = $(this).data('preset');
  var color = $(this).text();
  
  switch (preset) {
    case "beach-bunny":
      colorBeachBunny(color);
      break;
      
    case "lolly":
      colorLolly(color);
      break;
    
    case "boardwalk":
      colorBoardwalk(color);
      break;
      
    case "impala":
      colorImpala(color);
      break;
  }
});

function colorImpala(name) {
  var boot = colors['Boot']['Impala'][name];
  var laces = colors['Laces']['Impala'][name];
  var wheels = colors['Wheels']['Impala'][name];
  var toestop = colors['Toestop']['Impala'][name];
  var eyelets = colors['Eyelets']['Impala'][name];
  
  if (typeof colors['Sole']['Impala'][name] === 'undefined') {
    var sole = colors['Sole']['Impala']['Default'];
  }
  else {
    var sole = colors['Sole']['Impala'][name];
  }
  
  var plate = colors['Plate']['Beach Bunny']['Metal'];

  colorSkate(boot, laces, wheels, toestop, eyelets, sole, plate);
}

function colorBoardwalk(name) {
  var boot = colors['Boot']['Boardwalk'][name];
  var laces = colors['Laces']['Boardwalk'][name];
  
  if (name == 'Tan') {
    var wheels = colors['Wheels']['Boardwalk']['Red']; 
  }
  else {
    var wheels = colors['Wheels']['Boardwalk'][name];  
  }
  
  var toestop = colors['Toestop']['Powerdyne']['Black'];
  var eyelets = colors['Eyelets']['Boardwalk'][name];
  
  if (name == 'Tan') {
    var sole = colors['Sole']['Boardwalk']['Brown']; 
  }
  else {
    var sole = colors['Wheels']['Boardwalk']['Black'];  
  }
  
  var plate = colors['Plate']['Boardwalk']['Default'];
  
  colorSkate(boot, laces, wheels, toestop, eyelets, sole, plate);
}

function colorLolly(name) {
  var boot = colors['Boot']['Lolly'][name];
  
  if (name === "Black") {
    var laces = colors['Laces']['Moxi'][name];
  }
  else {
    var laces = colors['Laces']['Moxi']['Oyster'];
  }
  
  
  switch (name) {
    case "Clementine":
    case "Pineapple":
    case "Honeydew":
      var wheels = colors['Wheels']['Gummy'][name];
      break;
    case "Floss":
      var wheels = colors['Wheels']['Gummy']['Seafoam'];
      break;
    case "Taffy":
      var wheels = colors['Wheels']['Gummy']['Lavender'];
      break;
    case "Strawberry":
      var wheels = colors['Wheels']['Gummy']['Pink'];
      break;
    default:
      var wheels = colors['Wheels']['Gummy']['Smoke'];
      break;
  }
  
  var toestop = colors['Toestop']['Powerdyne']['Black'];
  
  if (name === "Black") {
    var eyelets = colors['Eyelets']['Lolly'][name];
  }
  else {
    var eyelets = colors['Eyelets']['Lolly']['Oyster'];
  }
  
  if (name === "Black") {
    var sole = colors['Sole']['Lolly'][name];
  }
  else {
    var sole = colors['Sole']['Lolly']['Brown'];  
  }
  
  var plate = colors['Plate']['Powerdyne']['Black'];
  
  colorSkate(boot, laces, wheels, toestop, eyelets, sole, plate);
}

function colorBeachBunny(name) {
  var boot = colors['Boot']['Beach Bunny'][name];
  var laces = colors['Laces']['Beach Bunny'][name];
  var wheels = colors['Wheels']['Beach Bunny'][name];
  var toestop = colors['Toestop']['Powerdyne']['Black'];
  var eyelets = colors['Eyelets']['Beach Bunny']['Metal'];
  var sole = colors['Sole']['Beach Bunny']['Brown'];
  var plate = colors['Plate']['Beach Bunny']['Metal'];
  var toecap = colors['Toecap']['Beach Bunny'][name];

  colorSkate(boot, laces, wheels, toestop, eyelets, sole, plate, toecap);
}

function colorSkate(boot, laces, wheels, toestop, eyelets, sole, plate, toecap = 'transparent') {
  var element = getPart('boot');
  changeColor(element, boot);

  element = getPart('laces');
  changeColor(element, laces);

  element = getPart('wheels');
  changeColor(element, wheels);

  element = getPart('toestop');
  changeColor(element, toestop);
  
  element = getPart('eyelets');
  changeColor(element, eyelets);
  
  element = getPart('sole');
  changeColor(element, sole);
  
  element = getPart('plate');
  changeColor(element, plate);
  
  element = getPart('toecap');
  changeColor(element, toecap);
}

var svg = document.getElementsByTagName('svg')[0];

var svg_xml = (new XMLSerializer()).serializeToString(svg),
    blob = new Blob([svg_xml], {type:'image/svg+xml;charset=utf-8'}),
    url = window.URL.createObjectURL(blob);

var img = new Image();
img.width = 800;
img.height = 800;
img.onload = function(){
    var canvas = document.createElement('canvas');
    canvas.width = img.width;
    canvas.height = img.height;

    var ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, img.width, img.height);

    window.URL.revokeObjectURL(url);
    var canvasdata = canvas.toDataURL('image/png');
    var a = document.getElementById('download');
    a.download = "skatesona_" + Date.now() + ".png";
    a.href = canvasdata;   
}
img.src = url