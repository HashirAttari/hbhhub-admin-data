window.addEventListener(
  "load",
  function () {
    setTimeout(() => {
      document.getElementById("wrap").classList.add("loaded");
    }, 3500);
  },
  false
);