/**
 * A CSS grid layout showing the most trending open-source projects 
 * developed using web technologies (JavaScript, HTML, CSS). The box size 
 * is determined based on the number of weekly stars. The more weekly 
 * stars, the more trending the project is, and the larger the box is.
 *
 * Click on a box to open the project on GitHub.
 *
 * Special thanks to https://github.com/huchenme/github-trending-api for
 * their great, open-source API.
 */
const { useEffect, useState } = React;

const COLORS = ['#2e86de', '#8395a7', '#ee5253', '#0abde3', '#1dd1a1', '#5f27cd'];
const LANGUAGES = ['javascript', 'html', 'css']; // Other supported languages: https://github.com/huchenme/github-trending-api/blob/master/src/languages.json

const getData = async () => {
  const data = await Promise.all(
  LANGUAGES.map(lang => fetch(`https://ghapi.huchen.dev/repositories?language=${lang}`).then(r => r.json())));

  return data.reduce((acc, cur) => acc.concat(cur), []);
};

const rand = (min, max) => Math.floor(Math.random() * (max - min)) + min;

const Cell = ({ span, avatar, name, href, periodStars, stars, description, author }) => /*#__PURE__*/
React.createElement("a", { href: href, target: "_blank", className: "cell", style: {
    gridRow: `span ${span}`,
    gridColumn: `span ${span}`,
    backgroundColor: COLORS[rand(0, COLORS.length)] } }, /*#__PURE__*/

React.createElement("div", { className: "avatar", style: { backgroundImage: `url(${avatar})` } }), /*#__PURE__*/
React.createElement("div", { className: "name" }, name), /*#__PURE__*/
React.createElement("div", { className: "stars" }, "\u2606",
periodStars, " Weekly", /*#__PURE__*/React.createElement("br", null), "\u2605",
stars > 1000 ? (stars / 1000).toFixed(1) + 'k' : stars, " Total"), /*#__PURE__*/

React.createElement("div", { className: "description" },
description, /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("br", null), "Author: ",
author));




const EmptyCell = ({ span }) => /*#__PURE__*/
React.createElement("div", { className: "cell", style: {
    gridRow: `span ${span * rand(1, 5)}`,
    gridColumn: `span ${span}`,
    backgroundColor: COLORS[rand(0, COLORS.length)] } });



const TrendsGrid = ({ data }) => {
  const stars = [...new Set(data.map(d => d.currentPeriodStars).sort((a, b) => a - b))];
  return /*#__PURE__*/(
    React.createElement("div", { className: "grid" },
    data.map((repo, column) => {
      return /*#__PURE__*/(
        React.createElement(Cell, {
          avatar: repo.avatar,
          name: repo.name,
          href: repo.url,
          description: repo.description,
          author: repo.author,
          stars: repo.stars,
          periodStars: repo.currentPeriodStars,
          span: Math.max(Math.floor(stars.indexOf(repo.currentPeriodStars) / 2), 5) },
        repo.name));


    }),
    [...new Array(300)].map(() => /*#__PURE__*/React.createElement(EmptyCell, { span: 1 }))));


};

const App = () => {
  const [data, setData] = useState([...new Array(20)].map(() => ({ currentPeriodStars: rand(20, 100) })));
  useEffect(async () => {
    const data = await getData();
    setData(data);
  }, []);

  return /*#__PURE__*/(
    React.createElement("div", { id: "app" }, /*#__PURE__*/
    React.createElement(TrendsGrid, { data: data })));


};

ReactDOM.render( /*#__PURE__*/
React.createElement(App, null),
document.body);