VanillaTilt.init(document.querySelector(".container"), {
    max: 25,
    speed: 300,
    glare: true,
    "max-glare": .5,
	  transition: true,
		reset: true,
  });


/*
	Source Code for Vanilla Javascript Tilt: https://cdnjs.cloudflare.com/ajax/libs/vanilla-tilt/1.7.0/vanilla-tilt.min.js
*/