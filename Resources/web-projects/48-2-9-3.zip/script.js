const calc = operator =>
  `48 / 2 ${operator} (9 + 3) = ${eval(48 / 2 + operator + (9 + 3))}`;
const answer = document.querySelector("#answer");
const operators = ["*", "/", "+", "-"];

const maths = () => {
  for (let i = 0; i < operators.length; i++) {
    setTimeout(() => {
      answer.innerText = calc(operators[i]);
    }, i * 1000);
  }
};

maths();

setInterval(() => maths(), operators.length * 1000);