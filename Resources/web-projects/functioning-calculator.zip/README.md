# Functioning calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/Roemerdt/pen/YWRwoG](https://codepen.io/Roemerdt/pen/YWRwoG).

Design based on https://dribbble.com/shots/2311064-Calculator