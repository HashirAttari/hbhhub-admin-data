# Awesome input focus effects

A Pen created on CodePen.io. Original URL: [https://codepen.io/Takumari85/pen/RaYwpJ](https://codepen.io/Takumari85/pen/RaYwpJ).

