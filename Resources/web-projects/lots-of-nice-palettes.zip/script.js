let palettes = [];
const $b = document.querySelector('[data-colors]');
const $c = document.querySelector('[data-count]');

fetch('https://gist.githubusercontent.com/meodai/39d07c32a6d0b50346f12c6f447b51b6/raw/a21ba0653e43ea3c0d36bb126dc246dbd89889f3/named-palettes.json').then(d => d.json()).then(d => {
  palettes = d;
  $c.innerHTML = palettes.length;
  palettes.forEach(pal => {
    const $div = document.createElement('details');
    $div.innerHTML = `
      <summary>
        <span>
          ${pal.colors.map(c => {
      return `<i style="--c: ${c.hex};"></i>`;
    }).join('')}
        </span>
        <strong>${pal.title}</strong>
      </summary>
      <ol>${
    pal.colors.map(c => {
      return `<li style="--c: ${c.hex};"><strong>${c.hex}</strong><h3>${c.name}</h3></li>`;
    }).join('')
    }</ol>
    `;
    $b.appendChild($div);
  });
});