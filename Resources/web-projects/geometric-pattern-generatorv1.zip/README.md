# Geometric Pattern Generator - v1

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/BaNOXJz](https://codepen.io/MananTank/pen/BaNOXJz).

It really goes to show what just three spinning lines can generate