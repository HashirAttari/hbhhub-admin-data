let r1, r2;
let m1, m2;
let d1, d2;





function randomize() {
	r1 = Math.ceil(random(5, 10));
	r2 = Math.ceil(random(5, 20));
	m1 = Math.ceil(random(5));
	m2 = Math.ceil(random(5));
	d1 = random(["deg", "deg2"]);
	d2 = random(["deg", "deg2"]);

	console.log("config : ", { r1, r2, m1, m2, d1, d2 });
}

function setup() {
	createCanvas(innerWidth, innerHeight);
	stroke(255);
	background(0);
	randomize();
}

let p1, p2, p3;
let deg = 0;
let deg2 = 0;

function connector(x1, x2) {
	line(...x1, ...x2);
}

function onCircle(r, deg, centerX = 0, centerY = 0) {
	return [centerX + sin(deg) * r, centerY + cos(deg) * r];
}

function refreshPoints() {
	let _d1, _d2;
	p1 = onCircle(width / 5, deg);
	_d1 = d1 === "deg" ? deg : deg2;
	_d2 = d2 === "deg" ? deg : deg2;
	p2 = onCircle(width / r1, _d1 * m1, ...p1);
	p3 = onCircle(width / r2, _d2 * m2, ...p1);
}

function connectLines() {
	stroke(255, 50);
	connector(p1, p2);
	connector(p3, p2);
	stroke(0);
	connector(p1, p3);
}

function draw() {
	translate(width / 2, height / 2);
	refreshPoints();
	connectLines();
	deg += 0.1;
	deg2 += 0.2;
}

// respond to changes ------------------
function windowResized() {
	resizeCanvas(innerWidth, innerHeight);
	background(0);
}

function mouseClicked() {
	randomize();
	background(0);
}