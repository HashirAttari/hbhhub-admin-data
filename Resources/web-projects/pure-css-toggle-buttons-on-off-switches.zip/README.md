# Pure CSS Toggle Buttons | ON-OFF Switches

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/EddYjw](https://codepen.io/joshonweb/pen/EddYjw).

Collection of toggle buttons / on-off switches which can be practically used in a website.  Designed using CSS without any JavaScript :)

Which one is your fav?