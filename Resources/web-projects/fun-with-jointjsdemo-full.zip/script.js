joint.shapes.devs.Model = joint.shapes.devs.Model.extend({
markup: '<g class="element-node">'+
             '<rect class="body" stroke-width="0" rx="5px" ry="5px"></rect>'+
            '<text class="label" y="0.8em" xml:space="preserve" font-size="14" text-anchor="middle" font-family="Arial, helvetica, sans-serif">'+
              '<tspan id="v-18" dy="0em" x="0" class="v-line"></tspan>'+
            '</text>'+
          '<g class="inPorts"/>' +
          '<g class="outPorts"/>' +
        '</g>',
portMarkup: '<g class="port port<%= id %>"><circle class="port-body"/></g>'
});
  
var canvas = $('#canvas');
var filter = $('#filter');
var addColor = $('#addColor');
var cells = [];
var message = $('#message');
var graph = new joint.dia.Graph();

var paper = new joint.dia.Paper({
  el: canvas,
  width: canvas.outerWidth(),
  height: canvas.outerHeight(),
  model: graph,
  gridSize: 20,
  defaultRouter: { name: 'metro' },
  clickThreshold: 1
});

cells[0] = new joint.shapes.devs.Model({
  type: 'devs.Model',
  position: {x: 20, y: 20},
  attrs: {
    '.body': {
      width: '140',
      height: '60'
    },
    '.label': {
      text: 'blok 1',
    },
    '.element-node' : {
      'data-color': 'pink'
    }
  },
  inPorts: ['center']
});
cells[0].translate(140, 100);
cells[1] = cells[0].clone();
cells[1].translate(300, 60);
cells[1].attr('.label/text', 'blok 2');
graph.addCells(cells);

var link = new joint.dia.Link({
  source: {
    id: cells[0].id,
    port: 'center'
  },
  target: {
    id: cells[1].id,
    port: 'center'
  }
});
graph.addCells([link]);

function addCell(){
  var color = addColor.val();
  var number = cells.length;
  cells[number] = cells[0].clone();
  cells[number].translate(-140, -100);
  cells[number].attr('.element-node/data-color', color);
  cells[number].attr('.label/text', 'blok '+cells.length);
  graph.addCells(cells);
}

$('#addCell').on('click', addCell);

$(filter).on('change', function(e){
  canvas.attr('data-filter', e.target.value);
});

var svgZoom = svgPanZoom('#canvas svg', {
  center: false,
  zoomEnabled: true,
  panEnabled: true,
  controlIconsEnabled: true,
  fit: false,
  minZoom: 0.5,
  maxZoom:2,
  zoomScaleSensitivity: 0.5
});

(function(){
  paper.on('cell:pointerdown', function(){
    svgZoom.disablePan();
  });
  paper.on('cell:pointerup', function(){
    svgZoom.enablePan();
  });
  
  paper.on('cell:pointerclick', function(e){
    message.addClass('visible');
    message.html(e.el.textContent+' clicked');
  setTimeout(function(){  message.removeClass('visible');
                       }, 1000);
  });
})();