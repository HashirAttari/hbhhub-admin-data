# Hero with cursor tracking (GSAP)

A Pen created on CodePen.io. Original URL: [https://codepen.io/giomgio/pen/abxGyQX](https://codepen.io/giomgio/pen/abxGyQX).

