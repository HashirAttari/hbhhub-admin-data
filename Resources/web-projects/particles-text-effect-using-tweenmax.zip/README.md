# Particles text effect using TweenMax

A Pen created on CodePen.

Original URL: [https://codepen.io/bazooki/pen/kYoOGO](https://codepen.io/bazooki/pen/kYoOGO).

a nice text to particles effect using TweenMax by GreenSock.
inspired by JASSON QASQANT pen: http://codepen.io/yeco/pen/cIKbn