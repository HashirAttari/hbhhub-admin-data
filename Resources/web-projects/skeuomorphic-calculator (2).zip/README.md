# Skeuomorphic Calculator

A Pen created on CodePen.

Original URL: [https://codepen.io/jkantner/pen/RwKxwdr](https://codepen.io/jkantner/pen/RwKxwdr).

An attempt to create a basic calculator that works (and also looks) like one in real life. It includes the common function buttons like the %, square root, and even the memory buttons. It’s also usable by keyboard! For functions not easily figured out by keyboard, refer to this table:

| Operation                 | Key/Shortcut     |
|---------------------------|------------------|
| Square Root (√)           | S                |
| Negate Value (+/-)        | Alt/Option + [-] |
| Clear (C)                 | C                |
| Recall/Clear Memory (MRC) | M                |
| Subtract From Memory (M-) | <                |
| Add To Memory (M+)        | >                |