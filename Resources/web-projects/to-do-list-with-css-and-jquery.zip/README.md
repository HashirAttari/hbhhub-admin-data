# To-do List with CSS and jQuery

A Pen created on CodePen.io. Original URL: [https://codepen.io/hilotacker/pen/ONwpVy](https://codepen.io/hilotacker/pen/ONwpVy).

UI of simple Todo list app. The GUI is created only with CSS.