# CSS Only Exploding Modal

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/GZzqxr](https://codepen.io/jcoulterdesign/pen/GZzqxr).

