$('input[type="text"]').each(function(){
  var val = $(this).attr("value");
  var easing = 'animation-timing-function: ' + val;
  
  $(this).after('<div style="' + easing + '"></div>');
});

$('input[type="text"]').focus(function(){
  $("body").addClass("reset");
}).blur(function(){
  $("body").removeClass("reset");

});