var glass = document.getElementById('eye_glass')
window.addEventListener('mousemove', function(e){
  var x = e.clientX
  var y = e.clientY
  glass.style.left = x - 125 + 'px'
  glass.style.top = y - 125 + 'px'
})