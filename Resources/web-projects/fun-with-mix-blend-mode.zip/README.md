# Fun with mix-blend-mode

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/JjKZPXx](https://codepen.io/kitjenson/pen/JjKZPXx).

