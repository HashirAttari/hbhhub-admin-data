# UI Statistic Pop Out CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/jExQGd](https://codepen.io/jcoulterdesign/pen/jExQGd).

Another UI piece in CSS. Hover over the stat box for a nice scale etc. This does need tidying up slightly and i will make it responsive at some point so it looks top banana on mobile.