# 3D(ish) Product showcase

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/mJoqXd](https://codepen.io/jcoulterdesign/pen/mJoqXd).

A product showcase using -webkit-filter:blur and box reflects.