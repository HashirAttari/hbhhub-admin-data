# Demo #2 for article (Chrome only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/abBbVzg](https://codepen.io/yuanchuan/pen/abBbVzg).

https://yuanchuan.dev/time-uniform-for-css-animation