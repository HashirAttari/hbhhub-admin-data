# slick slider center mode

A Pen created on CodePen.io. Original URL: [https://codepen.io/semenchenko/pen/ppJJOJ](https://codepen.io/semenchenko/pen/ppJJOJ).

