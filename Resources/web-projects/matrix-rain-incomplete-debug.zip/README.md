# Matrix rain incomplete debug

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/gOGdjNR](https://codepen.io/franksLaboratory/pen/gOGdjNR).

