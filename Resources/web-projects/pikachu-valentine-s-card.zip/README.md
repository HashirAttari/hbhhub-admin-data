# Pikachu Valentine’s Card

A Pen created on CodePen.

Original URL: [https://codepen.io/pokecoder/pen/YzExLZR](https://codepen.io/pokecoder/pen/YzExLZR).

