# Sierpinski cube

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/YzXrjZE](https://codepen.io/yuanchuan/pen/YzXrjZE).

