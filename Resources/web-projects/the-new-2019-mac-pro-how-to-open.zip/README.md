# The New 2019 Mac Pro: How to Open

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshbader/pen/dByQxN](https://codepen.io/joshbader/pen/dByQxN).

Demonstrating how the new 2019 Mac Pro case opens. Made with pure CSS and responsive just for fun. I figured out an interesting technique to show depth when the handle is lifted. Let me know what you think. 