# Toggle Effects

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/qBaLegX](https://codepen.io/havardob/pen/qBaLegX).

Showcasing different silly toggle effects 