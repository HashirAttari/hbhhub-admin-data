var analyser = null;
var firstRun = true;
var running = false;

const oscElem = document.querySelector('#oscilloscope');
const svgElem = document.querySelector('#graph');
const waveElem = document.querySelector('#wave');

setMessage('Press Play to start.');

const playBtn = document.querySelector('#play-btn');
playBtn.addEventListener('click', (e) => {
    e.preventDefault();
    running = true;
    setMessage('');
    if(firstRun)
        init();
    else
        render();
});

const stopBtn = document.querySelector('#stop-btn');
stopBtn.addEventListener('click', (e) => {
    e.preventDefault();
    running = false;
    setMessage('Press Play to start.')
});

const modeBtn = document.querySelector('#light-mode-checkbox');
modeBtn.addEventListener('change', (e) => {
    const body = document.body;
    const fgColor = getComputedStyle(body).getPropertyValue('--fgcolor');
    const bgColor = getComputedStyle(body).getPropertyValue('--bgcolor');
    body.style.setProperty('--fgcolor', bgColor);
    body.style.setProperty('--bgcolor', fgColor);
});

function init() {
    firstRun = false;

    initMediaDevices();
    
    // set up forked web audio context, for multiple browsers
    // ('window.' is needed otherwise Safari explodes)
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if(audioCtx.state === "suspended") {
        audioCtx.resume();
    }

    analyser = audioCtx.createAnalyser();
    analyser.fftSize = 2048;
    
    //main block for doing the audio recording
    if(navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ audio: true })
            .then( stream => {
                source = audioCtx.createMediaStreamSource(stream);
                source.connect(analyser);
            })
            .catch( e => {
                setErrorMessage("Access to the microfone failed. (" + e.name + ": " + e.message + ")");
            });
    } else {
        setErrorMessage('getUserMedia() not supported on your browser!');
    }
    
    /*
    const osc = audioCtx.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = 1000;
    osc.start();

    osc.connect(analyser);
    */
    
    render();
}

function render() {
    var bufferLength = analyser.frequencyBinCount;
    var dataArray = new Uint8Array(bufferLength);
    
    analyser.getByteTimeDomainData(dataArray);
    
    const clientWidth = svgElem.clientWidth;
    const clientHeight = svgElem.clientHeight;
    
    waveElem.points.clear();

    for(let i = 0; i < bufferLength; i++) {
        const value = dataArray[i];
        
        let point = waveElem.points.appendItem(svgElem.createSVGPoint());

        point.x = i * (clientWidth / bufferLength);
        point.y = value * (clientHeight / 256);
    }
    
    if(running)
        requestAnimationFrame(render);
}

function setMessage(msg) {
    const msgElem = document.querySelector('#overlay-msg');
    if(msg.length > 0)
        msgElem.style.removeProperty('display');
    else
        msgElem.style.display = 'none';
    
    const msgTextElem = document.querySelector('#overlay-msg-text');
    msgTextElem.innerText = msg;
}

function setErrorMessage(msg) {
    const msgElem = document.querySelector('#message');
    msgElem.innerText = msg;
    if(msg.length > 0)
        msgElem.style.removeProperty('display');
    else
        msgElem.style.display = 'none';
}

function initMediaDevices() {
    // Older browsers might not implement "mediaDevices" at all, so we set an empty object first
    if (navigator.mediaDevices === undefined) {
        navigator.mediaDevices = {};
    }

    // Some browsers partially implement "mediaDevices". We can't just assign an object
    // with "getUserMedia()" as it would overwrite existing properties.
    // Here, we will just add the "getUserMedia()" property if it's missing.
    if (navigator.mediaDevices.getUserMedia === undefined) {
        navigator.mediaDevices.getUserMedia = function(constraints) {

            // First get ahold of the legacy "getUserMedia()", if present
            var getUserMedia = navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;

            // Some browsers just don't implement it - return a rejected promise with an error
            // to keep a consistent interface
            if (!getUserMedia) {
                return Promise.reject(new Error('getUserMedia() is not implemented in this browser'));
            }

            // Otherwise, wrap the call to the old navigator.getUserMedia with a Promise
            return new Promise(function(resolve, reject) {
                getUserMedia.call(navigator, constraints, resolve, reject);
            });
        }
    }
}

window.addEventListener('resize', (e) => {
    waveElem.points.clear();
});