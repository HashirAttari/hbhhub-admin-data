# Terminal Style Portfolio in ReactJS

A Pen created on CodePen.io. Original URL: [https://codepen.io/HuntingHawk/pen/rNaEZxW](https://codepen.io/HuntingHawk/pen/rNaEZxW).

* Comment if you have a feature idea!

A basic terminal made with ReactJS that doubles as a portfolio. This project was inspired by this pen by Jatin Rao, a 15 yo developer from India: https://codepen.io/jatinrao/full/abzRLGj.