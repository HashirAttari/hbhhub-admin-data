# CSS Background Buttons with mixin

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/GoYqOj](https://codepen.io/jcoulterdesign/pen/GoYqOj).

I made these buttons by accident in photoshop by applying a clipping mask to a button rather than the header. Thought id go with it and this is what i ended up with