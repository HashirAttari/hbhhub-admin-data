# Border

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/bQKpWO](https://codepen.io/yuanchuan/pen/bQKpWO).

CSS Challenge: https://twitter.com/yuanchuan23/status/10665557921222410