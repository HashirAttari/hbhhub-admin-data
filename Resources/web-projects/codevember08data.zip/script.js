/* Colors */
let blue1 = "#007CF0";
let blue2 = "#0066D3";
let blue3 = "#0763c6";
let green1 = "#00D1E5";
let white1 = "#EFE5F9";
let white2 = "#e0d8e8";
let pink1 = "#DFA9FC";
let pink2 = "#cf9beb";
let red1 = "#FF5D6E";
let yellow1 = "#FFAE9B";


let illo = new Zdog.Illustration({
    element: '.zdog-canvas',
    rotate: { y: .5, x: -.3 },
});
/* ========== */
var dash = new Zdog.Group({
    addTo: illo,
    width: 600,
    height: 350,
});
/* ========== */
let bar = new Zdog.Box({
    addTo: dash,
    width: 600,
    height: 50,
    depth: 50,
    stroke: false,
    color: blue2,
    topFace: blue1,
    rightFace: blue3,
    translate: { y: -150 },

});
    let barSquare = new Zdog.Rect({
        addTo: bar,
        width: 10,
        height: 10,
        depth: 1,
        stroke: false,
        fill: true,
        color: red1,
        translate: { x: 280, y: 0, z: 26 },
        backface: false,

    });
    barSquare.copy({
        color: pink1,
        translate: { x: 260, y: 0, z: 26 },
    });
    barSquare.copy({
        color: green1,
        translate: { x: 240, y: 0, z: 26 },
    });

let shadow = new Zdog.RoundedRect({
    addTo: dash,
    width: 650,
    height: 200,
    cornerRadius: 18,
    stroke: false,
    fill: true,
    color: pink2,
    rotate: { x: Zdog.TAU/ 4.1 },
    translate: { x: 0, y: 125, z: 0 },

});
/* ========== */
let left = new Zdog.Box({
    addTo: dash,
    width: 100,
    height: 250,
    depth: 50,
    stroke: 1,
    color: green1,
    topFace: blue2,
    translate: { x: -250 , y: 0 },

});
/* ========== */
    let leftLine = new Zdog.Rect({
        addTo: left,
        width: 80,
        height: 10,
        depth: 1,
        stroke: false,
        fill: true,
        color: white1,
        translate: { x: 0, y: -110, z: 26 },
        backface: false,
    });
    leftLine.copy({
        width: 20,
        translate: { x: -30, y: -90, z: 26 },
    });
    leftLine.copy({
        width: 50,
        translate: { x: 15, y: -90, z: 26 },
    });
    leftLine.copy({
        width: 70,
        translate: { x: -5, y: -60, z: 26 },
    });
    leftLine.copy({
        width: 60,
        translate: { x: -10, y: -40, z: 26 },
    });
    leftLine.copy({
        width: 70,
        translate: { x: -5, y: -20, z: 26 },
    });
    leftLine.copy({
        translate: { x: 0, y: 110, z: 26 },
    });
/* ========== */
let right = new Zdog.Box({
    addTo: dash,
    width: 500,
    height: 250,
    depth: 50,
    stroke: false,
    color: white1,
    topFace: blue2,
    rightFace: white2,
    translate: { x: 50 , y: 0 },
});
    let rightLine = new Zdog.Rect({
        addTo: right,
        width: 480,
        height: 50,
        depth: 1,
        stroke: false,
        fill: true,
        color: red1,
        translate: { x: 0, y: -90, z: 26 },
        backface: false,

    });
    let rightSquare = new Zdog.Rect({
        addTo: right,
        width: 150,
        height: 100,
        depth: 1,
        stroke: false,
        fill: true,
        color: pink1,
        translate: { x: -165, y: -5, z: 26 },
        backface: false,

    });
    rightSquare.copy({
        width: 160,
        translate: { x: 0, y: -5, z: 26 },
    });
    rightSquare.copy({
        translate: { x: 165, y: -5, z: 26 },
    });
    let rightBottom = new Zdog.Rect({
        addTo: right,
        width: 100,
        height: 60,
        depth: 1,
        stroke: false,
        fill: true,
        color: yellow1,
        translate: { x: -190, y: 85, z: 26 },
        backface: false,
    });
    rightBottom.copy({
        translate: { x: -80, y: 85, z: 26 },
    });
    rightBottom.copy({
        translate: { x: 30, y: 85, z: 26 },
    });
    rightBottom.copy({
        translate: { x: 140, y: 85, z: 26 },
    });
    rightBottom.copy({
        width: 40,
        color: green1,
        translate: { x: 220, y: 85, z: 26 },
    });

/* ========== */
var conx = 0;
var cony = 0;
window.addEventListener("mousemove", showPointer);

function showPointer(event) {
    var y = event.clientX;
    var wb = document.body.clientWidth / 2 ;

    var x = event.clientY;
    var hb = document.body.clientHeight / 2 ;

    if ( illo.rotate.y < .5 ) {
        if ( y < wb ) {
            illo.rotate.y += 0.02;
            conx++;
        }
    }
    if ( illo.rotate.y > 0 ) {
        if ( y > wb ) {
            illo.rotate.y -= 0.02;
            conx--;
        }
    }
    if ( illo.rotate.x > -.3 ) {
        if ( x > hb ) {
            illo.rotate.x -= 0.02;
            cony--;
        }
    }
    if ( illo.rotate.x < 0 ) {
        if ( x < hb ) {
            illo.rotate.x += 0.02;
            cony--;
        }
    }
}

/* ========== */

Zfont.init(Zdog);


var font = new Zdog.Font({
    src: 'https://cdn.jsdelivr.net/gh/jaames/zfont/demo/fredokaone.ttf'
});


new Zdog.Text({
    addTo: illo,
    font: font,
    value: '#CODEVEMBER',
    fontSize: 14,
    color: white1,
    fill: true,
    translate: { x: -300, y: -205, z: 26 },
});

/**/
function animate() {
    illo.updateRenderGraph();
    requestAnimationFrame( animate );

}
animate();