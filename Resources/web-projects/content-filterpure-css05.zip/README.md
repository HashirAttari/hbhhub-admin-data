# Content filter - pure css - #05

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/aXXOqw](https://codepen.io/ig_design/pen/aXXOqw).

