# Neumorphic Calculator Light/Dark Themed - Pen #14 - 2020

A Pen created on CodePen.io. Original URL: [https://codepen.io/rickyeckhardt/pen/eYNzRQJ](https://codepen.io/rickyeckhardt/pen/eYNzRQJ).

I wanted to jump on the neumorphic bandwagon, so here is a light and dark neumorphic themed calculator for all your calculating needs! 

Personally I love the dark. The light is just "too" light for me. It'd probably be okay on my phone, but it's hit or miss depending on my monitor. 

Which one is your favorite?