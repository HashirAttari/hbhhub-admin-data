# Generative square blobs

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/PoKewzQ](https://codepen.io/amit_sheen/pen/PoKewzQ).

