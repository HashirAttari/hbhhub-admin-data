import SimplexNoise from "https://cdn.skypack.dev/simplex-noise@3.0.0";

const simplex = new SimplexNoise();
const gridColumns = 10;
const gridRows = 10;

const sqrs = document.querySelectorAll('.sqr');
sqrs.forEach(sqr => {
    sqr.style.setProperty('--hue', Math.random() * 360);
})

render();
function render() {

    const time = performance.now() * 0.0004;
    const values = [];

    for (let x = 0; x < gridColumns; x++) {
        values[x] = [];
        for (let y = 0; y < gridRows; y++) {
            values[x][y] = simplex.noise3D(x, y, time);

            if ((x > 0) && (y > 0)) {
                const sqrIX = (y - 1) * (gridColumns - 1) + (x - 1);

                sqrs[sqrIX].style.setProperty('--br-tl', value2br(values[x - 1][y - 1]) + '%');
                sqrs[sqrIX].style.setProperty('--br-tr', value2br(values[x][y - 1]) + '%');
                sqrs[sqrIX].style.setProperty('--br-br', value2br(values[x][y]) + '%');
                sqrs[sqrIX].style.setProperty('--br-bl', value2br(values[x - 1][y]) + '%');
            }
        }
    }

    const sqr = sqrs[Math.floor(Math.random() * sqrs.length)];
    sqr.style.setProperty('--hr', ((Math.random() * 360) - 180) + 'deg');

    requestAnimationFrame(render);
}

function value2br(v) {
    return (v + 1) * 50;
}