# UI with rotating color scheme

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/XXwvzg](https://codepen.io/mselmany/pen/XXwvzg).



Forked from [Vincent De Oliveira](http://codepen.io/iamvdo/)'s Pen [UI with rotating color scheme](http://codepen.io/iamvdo/pen/wMbPMj/).