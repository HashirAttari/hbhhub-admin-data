# Catwalk(cycle)

A Pen created on CodePen.io. Original URL: [https://codepen.io/rachelnabors/pen/ApvavZ](https://codepen.io/rachelnabors/pen/ApvavZ).

Simple CSS background transitions plus keyframes used w/ stepping to animate this cat I drew, walking.

I will never get tired of this. Ever.