(function() {
  'use strict';

  const arraySelectors = [...document.querySelectorAll('.selector')];
  const wrapSelectors = document.querySelector('.wrap-inner');
  const rotateValue = 360 / arraySelectors.length;

  for (let i = 0; i < arraySelectors.length; i++) {
    // Set Selector Colors
    arraySelectors[i].style.backgroundColor = arraySelectors[i].getAttribute(
      'data-color'
    );

    // Default Active Class
    arraySelectors[0].classList.add('selector--active');

    // Set Root CSS
    document.documentElement.style.setProperty(
      '--selected-color',
      arraySelectors[0].getAttribute('data-color')
    );

    // Selector OnClick Function
    arraySelectors[i].addEventListener('click', function() {
      
      // Toggle Active Class
      arraySelectors.forEach(
        selector =>
        this === selector
        ? selector.classList.add('selector--active')
        : selector.classList.remove('selector--active')
      );

      // Check Selector Index
      if (this === arraySelectors[0]) {
        wrapSelectors.style.transform = 'rotate(90deg)';
      } else if (this === arraySelectors[1]) {
        wrapSelectors.style.transform = 'rotate(0deg)';
      } else {
        wrapSelectors.style.transform = `rotate(${i * rotateValue}deg)`;
      }

      // Update Root CSS
      document.documentElement.style.setProperty(
        '--selected-color',
        this.getAttribute('data-color')
      );
    });
  }
})();