# Toggle Match

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/gOyrbmK](https://codepen.io/alvaromontoro/pen/gOyrbmK).

Based on my own CSS drawing: https://codepen.io/alvaromontoro/pen/abLRomw

May not be a good idea to animate it... still, it is animated.