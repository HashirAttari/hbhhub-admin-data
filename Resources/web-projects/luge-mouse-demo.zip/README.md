# luge / Mouse demo

A Pen created on CodePen.io. Original URL: [https://codepen.io/wodniack/pen/abyoKEa](https://codepen.io/wodniack/pen/abyoKEa).

Luge mouse animation and custom cursor demo. Visit https://luge.cool for more information.