# CSS Party

A Pen created on CodePen.io. Original URL: [https://codepen.io/davideast/pen/vYPZdWV](https://codepen.io/davideast/pen/vYPZdWV).

