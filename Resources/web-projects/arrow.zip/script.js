/*
Designed by: Dennis Hoogstad
Original image: https://dribbble.com/shots/1937726-Bow-And-Arrow
*/