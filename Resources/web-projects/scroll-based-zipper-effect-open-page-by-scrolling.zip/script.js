const ZIP_RULE_HEIGHT = 8;

// Factory
const createZipAtPos = y => {
  let zip = document.createElement("div");
  zip.classList.add("zip");
  zip.style.top = `${y}px`;
  zip.style.height = `${ZIP_RULE_HEIGHT}px`;
  return zip;
};

const normalize = (value, minimum, maximum) => {
  return (value - minimum) / (maximum - minimum);
};

const interpolate = (normValue, minimum, maximum) => {
  return minimum + (maximum - minimum) * normValue;
};

const map = (value, min1, max1, min2, max2) => {
  return interpolate(normalize(value, min1, max1), min2, max2);
};

const zips = { l: [], r: [] };
const notecard = document.getElementById("notecard");

// create elements
const zipper = document.createElement("div");
zipper.classList.add("zipper");
const zip_left = document.createElement("div");
zip_left.classList.add("zipper-left");
zipper.appendChild(zip_left);
const zip_right = document.createElement("div");
zip_right.classList.add("zipper-right");
zipper.appendChild(zip_right);
const zip_handle = document.createElement("div");
zip_handle.classList.add("zipper-handle");
zipper.appendChild(zip_handle);
document.body.appendChild(zipper);

// calc basics
const zip_rect = zip_left.getBoundingClientRect();
const numZips = Math.ceil(zip_rect.height / ZIP_RULE_HEIGHT) + 1;

// draw zips on both sides
for (let i = 0; i < numZips; i++) {
  zips.l.push(
  zip_left.appendChild(
  createZipAtPos(
  -0.25 * ZIP_RULE_HEIGHT + i * ZIP_RULE_HEIGHT - 0.25 * ZIP_RULE_HEIGHT)));



  zips.r.push(
  zip_right.appendChild(
  createZipAtPos(
  -0.25 * ZIP_RULE_HEIGHT + i * ZIP_RULE_HEIGHT + 0.25 * ZIP_RULE_HEIGHT)));



}

// handle scrolling
const scrollHandler = () => {
  normScrollY = normalize(
  Math.min(window.pageYOffset, zip_rect.height),
  0,
  zip_rect.height);


  // show / hide notecard
  if (window.pageYOffset >= 180 && !notecard.classList.contains("hide")) {
    notecard.classList.add("hide");
  } else if (window.pageYOffset < 180 && notecard.classList.contains("hide")) {
    notecard.classList.remove("hide");
  }

  // move zips
  let n, p, j;
  for (let i = 0; i < numZips; i++) {
    p = Math.max(0, interpolate(normScrollY, -i * 1, 100)); // make it 101% to get rid of the zip endings
    // store index for handle
    if (p > 0) {
      j = i;
    }
    zips.l[i].style.transform = `translateX(-${p}%)`;
    zips.r[i].style.transform = `translateX(${p}%)`;
  }

  // move handle (positioning is non-linear, so we have to determine)
  y = j * ZIP_RULE_HEIGHT;
  zip_handle.style.transform = `translate(-50%, ${y}px)`;
};

// normalize scrolling
let normScrollY;
document.addEventListener("scroll", scrollHandler.bind(this));

// DEBUG
// window.scrollTo(0, 0.6 * zip_rect.height);