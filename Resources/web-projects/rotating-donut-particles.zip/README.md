# Rotating donut particles

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/RwrZQMr](https://codepen.io/agalliat/pen/RwrZQMr).

