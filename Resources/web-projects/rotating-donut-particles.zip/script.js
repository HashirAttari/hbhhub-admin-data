const ParticleCountX = 5;
const ParticleCountY = 100;

function setup() {
    createCanvas(window.innerWidth, window.innerHeight, WEBGL);
}

function windowResized() {
    resizeCanvas(window.innerWidth, window.innerHeight);
}

function draw() {
    const frameCounter = frameCount + 1000;
    
    noStroke();
    noFill();
    
    colorMode(RGB, 255, 255, 255);
    background(0, 0, 0);

    rotateY(radians((frameCounter * 0.01) % 360));

    colorMode(HSL, 360, 100, 100);
    for (let j = 0; j < ParticleCountX; j++) {
        push();
        translate(0, window.innerHeight / 8 * 3, 0);
        for (let i = 0; i < ParticleCountY; i++) {
            translate(
                sin(frameCounter * 0.001 + j * sin(frameCounter * 0.001)) * 100,
                -i * (0.02 * (window.innerHeight / 4 * 3) / 100),
                sin(frameCounter * 0.001 + j * sin(frameCounter * 0.001)) * 100
            );
            rotateY(frameCounter * 0.002);

            stroke(i * (360 / ParticleCountY), 70, 50);
            torus(6, 2);
        }
        pop();
    }
}