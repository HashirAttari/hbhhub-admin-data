//magic to be.
$(document).ready(function() {
  var buttonPressed; //current button pressed.
  var firstNum = []; //first array value.
  var secondNum = []; //second array value.
  var first = 0; //first number value.
  var second = 0; //second number value.
  var operator = ""; // value of the operator( /, *, -, + or  =).
  var array = ["/", "*", "-", "+"]; //array with oparator values;
  var lockedButton = true; //"switch" to change from puting values from the first array to the second.

  //real calculator.
  var performCalc = function(one, two, opera) {
    
    //if(one.indexOf(".")>=0){
      //one = one * 10;
      //console.log("inside perfcalc");
    //}
    //else if(two.indexOf(".")>=0){
      //two = two * 10;
    //}
    switch (opera) {
      case '*':
        first = one * two;
        secondNum = [];
        break;
      case '/':
        first = one / two;
        secondNum = [];
        break;
      case '+':
        first = one + two;
        secondNum = [];
        break;
      case '-':
        first = one - two;
        secondNum = [];
        break;
    }
    console.log("x is: " + x);
    var x = first.toString();
    //makes total result equal to 15 digits.
    if(x.length > 14){
      first = x.substring(0,14);
      $("#screen").text(first);
      console.log("total is = " + first);
    }
    else{
      $("#screen").text(first);
      console.log("total is = " + first);
    }
  };

  //on C or CE click.
  $('.clean').on('click', function(evt) {
    // reseting the locked button in order to start the firstNum again.
    buttonPressed = $(this).val();
    if (buttonPressed == "C") {
      lockedButton = true;
      firstNum = [];
      secondNum = [];
      operator = "";
      $("#screen").text(0);
    } else if (buttonPressed == "CE") {
      //if the user didnt gave the operator a value it clears the first number.
      if (operator === "") {
        firstNum = [];
        $("#screen").text(0);
      } else {
        secondNum = [];
        $("#screen").text(0);
      }
    }
  });

  //on number click.
  $('.number').on('click', function(evt) {
    buttonPressed = $(this).val();
    console.log("button pressed = " + buttonPressed);

    // every time the locked button equal true    
    if (lockedButton) {
      //makes unable for a value to start with 0(05) or the screen to show more than one.
      if (buttonPressed === "0" && firstNum.length === 0) {
        $("#screen").text(buttonPressed);
      }
      else {
        //doesnt allow the user to press more than 1 dots (.).
        if (buttonPressed == "."){
          if (firstNum.indexOf(".") == -1) {
            secondNum = [];
            //if the first button the user is pressing is '.' then it turns it to '0.'
            if(firstNum.length === 0){
              firstNum.push("0");
            }
            //sets max length of characters on the screen to 15.
            if(firstNum.length < 15){
              firstNum.push(buttonPressed);
            }
            $("#screen").html(firstNum.join(""));
            //console.log("firstNum is equal = " + firstNum);
          }
        }
        else{
          secondNum = [];
          //sets max length of characters on the screen to 15.
          if (firstNum.length < 15) {
            firstNum.push(buttonPressed);
          }
          $("#screen").html(firstNum.join(""));
          //console.log("firstNum is equal = " + firstNum);
        }
      }
    }
    // Locked Button equal to false when user press an operator
    if (lockedButton === false) {
      //makes unable for a value to start with 0(05) or the screen to have more than 1 0.
      if (buttonPressed === "0" && firstNum.length === 0) {
        $("#screen").text(buttonPressed);
      }
      else {
        //doesnt allow the user to press more than 1 dots (.).
        console.log("im in second num");
        if (buttonPressed == ".") {
          if (secondNum.indexOf(".") == -1) {
            //if the first button the user is pressing is '.' then it turns it to '0.'
            if(secondNum.length === 0){
              secondNum.push("0");
            }
            //sets max length of characters on the screen to 15.
            if (secondNum.length < 15) {
              secondNum.push(buttonPressed);
            }
            $("#screen").html(secondNum.join(""));
            //console.log("secondNum is equal = " + secondNum);
          }
        } else {
          //sets max length of characters on the screen to 15.
          if (secondNum.length < 15) {
            secondNum.push(buttonPressed);
          }
          $("#screen").html(secondNum.join(""));
          //console.log("secondNum is equal = " + secondNum);
        }
        console.log("second num: " + secondNum);
      }
    }
  });

  //on ( /, *, -, +, =) click.
  $('.oper').on('click', function(evt) {
    lockedButton = false; //the moment an operator is pressed.That means first number has a value.
    buttonPressed = $(this).val();

    //if buttonPressed is an operator.
    if (array.indexOf(buttonPressed) != -1) {
      //if operator wasnt used.
      if (operator === "") {
        first = parseFloat(firstNum.join(""));
        console.log("first is equal = " + first);
        operator = buttonPressed;
        console.log("operator is equal = " + operator);
        $("#screen").text(operator);
      } else {
        //will run only if secondNum has a value.
        if (secondNum.length !== 0) {
          second = parseFloat(secondNum.join(""));
          console.log("second is equal = " + second);
          performCalc(first, second, operator);
        }
        operator = buttonPressed;
        console.log("first: " + first + " second: " + second + " operator: " + operator);
        $("#screen").text(operator);
      }
    }
    //if buttonPressed is =.
    else if (buttonPressed == "=") {
      if (secondNum.length !== 0) {
        second = parseFloat(secondNum.join(""));
        console.log("second is equal = " + second);
      }
      performCalc(first, second, operator);
      console.log("first: " + first + " second: " + second + " operator: " + operator);
    }
  });

  //shows 0 on screen when nothing else is pressed.
  $("#screen").text(0);
});