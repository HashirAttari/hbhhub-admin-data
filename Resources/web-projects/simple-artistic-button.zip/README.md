# Simple Artistic Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/wvaRvNR](https://codepen.io/markmead/pen/wvaRvNR).

