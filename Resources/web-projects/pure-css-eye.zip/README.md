# Pure CSS "Eye"

A Pen created on CodePen.io. Original URL: [https://codepen.io/miocene/pen/rNOVWor](https://codepen.io/miocene/pen/rNOVWor).

