// Changing character items
const changePrev = (elements, className) => {
  const selectedElement = document.querySelector(`.${className}`);
  let index = Array.from(elements).indexOf(selectedElement);
  index = index - 1 < 0 ? elements.length - 1 : index - 1;
  elements.forEach((element) => element.classList.remove(className));
  elements[index].classList.add(className);
};

const changeNext = (elements, className) => {
  const selectedElement = document.querySelector(`.${className}`);
  let index = Array.from(elements).indexOf(selectedElement);
  index = (index + 1) % elements.length;
  elements.forEach((element) => element.classList.remove(className));
  elements[index].classList.add(className);
};

const registerControls = (id) => {
  const elements = document.querySelectorAll(`.character__${id}`);
  document
    .getElementById(`${id}-left`)
    .addEventListener("click", () =>
      changePrev(elements, `character__${id}--active`)
    );
  document
    .getElementById(`${id}-right`)
    .addEventListener("click", () =>
      changeNext(elements, `character__${id}--active`)
    );
};

// Register controls of character items
registerControls("hat");
registerControls("face");
registerControls("hair");
registerControls("eyebrows");
registerControls("eyes");
registerControls("glasses");
registerControls("nose");
registerControls("mole");
registerControls("ears");
registerControls("ear-rings");
registerControls("blush");
registerControls("beard");
registerControls("mouth");

// Changing general values
let skinIndex = 0;
let hairIndex = 0;
let bodyIndex = 0;
let backgroundIndex = 0;
const skinTones = [
  "#ffdbac",
  "#f1c27d",
  "#e0ac69",
  "#c68642",
  "#8d5524",
  "#FFFFFF"
];
const hairTones = [
  "#000038",
  "#9a3300",
  "#4f1a00",
  "#241c11",
  "#f5fccd",
  "#aa8866",
  "#e2e2e2",
  "#80c0a1"
];
const bodyTones = [
  "#ff7d66",
  "#f5fccd",
  "#eb80b1",
  "#12486b",
  "#80c0a1",
  "#bdc3c6",
  "#ffffff",
  "#419197",
  "#000038",
  "#ffa500"
];
const backgroundTones = [
  "#419197",
  "#ff7d66",
  "#eb80b1",
  "#12486b",
  "#80c0a1",
  "#bdc3c6",
  "#000038",
  "#ffa500",
  "#78D6C6",
  "#66777F"
];

const changeCSSVars = () =>
  (document.body.style = `--skin: ${skinTones[skinIndex]}; --hair: ${hairTones[hairIndex]}; --body: ${bodyTones[bodyIndex]}; --background: ${backgroundTones[backgroundIndex]};`);

document.getElementById("skin-left").addEventListener("click", () => {
  skinIndex = skinIndex - 1 < 0 ? skinTones.length - 1 : skinIndex - 1;
  changeCSSVars();
});
document.getElementById("skin-right").addEventListener("click", () => {
  skinIndex = (skinIndex + 1) % skinTones.length;
  changeCSSVars();
});

document.getElementById("hair-color-left").addEventListener("click", () => {
  hairIndex = hairIndex - 1 < 0 ? hairTones.length - 1 : hairIndex - 1;
  changeCSSVars();
});
document.getElementById("hair-color-right").addEventListener("click", () => {
  hairIndex = (hairIndex + 1) % hairTones.length;
  changeCSSVars();
});

document.getElementById("body-left").addEventListener("click", () => {
  bodyIndex = bodyIndex - 1 < 0 ? bodyTones.length - 1 : bodyIndex - 1;
  changeCSSVars();
});
document.getElementById("body-right").addEventListener("click", () => {
  bodyIndex = (bodyIndex + 1) % bodyTones.length;
  changeCSSVars();
});

document.getElementById("background-left").addEventListener("click", () => {
  backgroundIndex =
    backgroundIndex - 1 < 0 ? backgroundTones.length - 1 : backgroundIndex - 1;
  changeCSSVars();
});
document.getElementById("background-right").addEventListener("click", () => {
  backgroundIndex = (backgroundIndex + 1) % backgroundTones.length;
  changeCSSVars();
});

// Character following cursor
const className = "character";
const character = document.getElementById(className);
const frame = document.getElementById("frame");

const mouseFunction = (mouse) => {
  const clientX = mouse.offsetX ? mouse.offsetX : mouse.touches[0].offsetX;
  const clientY = mouse.offsetY ? mouse.offsetY : mouse.touches[0].offsetY;

  if (clientX > frame.offsetWidth / 2 + 20) {
    character.classList.add(`${className}--right`);
    character.classList.remove(`${className}--left`);
  } else if (clientX < frame.offsetWidth / 2 - 20) {
    character.classList.add(`${className}--left`);
    character.classList.remove(`${className}--right`);
  } else {
    character.classList.remove(`${className}--right`);
    character.classList.remove(`${className}--left`);
  }
  if (clientY > frame.offsetHeight / 2 + 20) {
    character.classList.add(`${className}--bottom`);
    character.classList.remove(`${className}--top`);
  } else if (clientY < frame.offsetHeight / 2 - 20) {
    character.classList.add(`${className}--top`);
    character.classList.remove(`${className}--bottom`);
  } else {
    character.classList.remove(`${className}--bottom`);
    character.classList.remove(`${className}--top`);
  }
};

// In a PROD case we should use a "throttle function" for these events
frame.addEventListener("mousemove", mouseFunction);
frame.addEventListener("touchstart", mouseFunction);