# Styled native range input #30 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/qExrJz](https://codepen.io/thebabydino/pen/qExrJz).

**May 2021 description**

Major changes: 

* switched to smarter state changes using CSS variables - the technique is explained in this [two](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) [part](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/) article I wrote for CSS-Tricks 3 years ago

* the above techniques also accounts for the different look of the four sliders being achieved with the help of CSS variables for whether there's a fill/ progress, whether the thumb has a bigger height, whether there are value labels, whether there's a ruler and so on

* got rid of `absolute` positioning in favour of a CSS `grid` layout

* made it CSS-only in Firefox

* simplified the JS (which is now only needed for WebKit browsers) - it's now just updating a custom property `--val` to always have the current input value - this is only needed for the fill/ progress of the second slider

* made it degrade gracefully in WebKit browsers in the no JS case (check with JS disabled)

* compacted the CSS

* not providing free support for IE/ pre-Chromium Edge anymore

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling the range track in the case of the third slider. Fallback for no JS: simply display the same background for the entire track of the third slider, both before and after the thumb. 

---

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/AOuj3DY.jpg) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/).