# Tri-state Toggle Button (CSS only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/goldsteinr/pen/JjqzOm](https://codepen.io/goldsteinr/pen/JjqzOm).

