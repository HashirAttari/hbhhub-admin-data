# Sorry Cards

A Pen created on CodePen.io. Original URL: [https://codepen.io/WithAnEs/pen/rLjmwr](https://codepen.io/WithAnEs/pen/rLjmwr).

Sorry cards html/css. Click a card to show card.