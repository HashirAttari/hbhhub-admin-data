$(function(){

    var model = {
        num: 0,        // the current integer that we are inputing
        renderString: '', // the display output
        result: null,     // the result of the last calculation
        operation: [],    // an array of operations to be performed
        calcClicked: false,
    }

    var calculator = {

        init: function(){
            this.cacheDOM();
            this.bindEvents();
        },

        cacheDOM: function(){
            this.$btnNums = $('.btn-num');
            this.$btnC = $('.btn-c');
            this.$btnOperator = $('.btn-operator');
            this.$btnEquals = $('.btn-equals');

            this.$secondaryDisplay = $('#secondaryDisplay');
            this.$primaryDisplay = $('#primaryDisplay');
        },

        bindEvents: function(){
            this.$btnC.on('click', this.clear.bind(this));
            this.$btnNums.on('click', this.number.bind(this));
            this.$btnOperator.on('click', this.operator.bind(this));
            this.$btnEquals.on('click', this.calc.bind(this));
        },

        clear: function(){
            model.num = 0;
            model.renderString = [];
            model.result = null;
            model.operation = [];
            view.clearScreens();
        },

        number: function(e){

            if (model.calcClicked) {
                this.clear();
                model.calcClicked = false;
            }

            if (model.num === null) {
                model.num = 0;
            }
            // get the number from the value attribute
            var number = $(e.target).attr('value');
            // check if number is a dot using regex and if there already is a dot in model.current number
            if (number === '.' && String(model.num).match(/\.+/)) {
                // there already is a dot!
            } else {
                // build up the current number
                var s = String(model.num + number);
                // remove any leading zeros
                model.num = s.replace(/^0+/, '');
                // show the number
                if (s.length > 12) {
                    this.$primaryDisplay.text('limit').addClass('error');
                } else {
                    this.$primaryDisplay.text(model.num);
                }
                // if the number is too big for the display shrink it
                view.shrinkFont();
            }
        },

        operator: function(e){
            // we are continuing with another operation
            model.calcClicked = false;
            // get the operator from the value attribute
            var operator = $(e.target).attr('value');
            // if we want to change our operator
            if (model.num === null) {
                // change the last operations array to the new operator
                model.operation[model.operation.length - 1] = operator;
                // and the render string operator
                model.renderString = model.renderString.replace(/.$/, operator);
            } else {
                // if there is a result already then add to that result
                if (model.result !== null) {
                    model.renderString += ', ' + model.result + operator;
                } else {
                    // else add the current number
                    model.operation.push(model.num);
                    // and add to the renderString
                    model.renderString += model.num + operator;
                }
                // add the operator to the operator array
                model.operation.push(operator);
            }
            // show the operator
            this.$primaryDisplay.text(operator);
            // operator has been clicked
            model.num = null;
            // show model.renderString
            view.renderSecondary();
        },

        calc: function(){
            // add the last number to the operations queue
            model.operation.push(model.num);
            // calculate the result from the operation string
            var result = eval(model.operation.join(""));
            // add the new result as the first item on the operation array
            model.operation    = model.operation.splice(0, 1);
            model.operation[0] = result;
            model.result       = result;
            // add the last number to the renderString and add it as a calculation
            model.renderString += model.num;
            model.renderString += '=' + result;
            // signal that a calculation has been made
            model.calcClicked = true;
            // show the result
            this.$primaryDisplay.text(result);
            this.$primaryDisplay.addClass('answer');
            view.renderSecondary();
            view.shrinkFont();
        }
    }

    var view = {

        clearScreens: function(){
            calculator.$secondaryDisplay.text('0');
            calculator.$primaryDisplay.text('0');
            calculator.$primaryDisplay.removeClass('answer error');
            calculator.$primaryDisplay.removeClass('text-small text-smaller text-smallest');
        },

        shrinkFont: function(){
            if (model.num.length > 12 || String(model.result).length > 12) {
                calculator.$primaryDisplay.removeClass('text-small text-smaller').addClass('text-smallest');
            } else if (model.num.length > 10 || String(model.result).length > 10) {
                calculator.$primaryDisplay.removeClass('text-small text-smaller').addClass('text-smallest');
            } else if (model.num.length > 8 || String(model.result).length > 8) {
                calculator.$primaryDisplay.removeClass('text-small text-smallest').addClass('text-smaller');
            } else if (model.num.length > 6|| String(model.result).length > 6) {
                calculator.$primaryDisplay.removeClass('text-smaller text-smallest').addClass('text-small');
            }
        },

        renderSecondary: function(){
            calculator.$secondaryDisplay.text(model.renderString);
        }
    }

    calculator.init();
});