# Production ready confetti generator, yo.

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/VmPmjG](https://codepen.io/run-time/pen/VmPmjG).

