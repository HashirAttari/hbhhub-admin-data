# Zipper (Drag&Drop&Touch)

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/ZELNxmQ](https://codepen.io/kitjenson/pen/ZELNxmQ).

