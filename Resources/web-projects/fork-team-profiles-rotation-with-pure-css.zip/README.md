# [FORK] Team Profiles rotation with pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/QWPYQBe](https://codepen.io/cbolson/pen/QWPYQBe).

Forked from my iiCodeThis project https://icodethis.com/code/2455

This is essentially the same as the original but without using Tailwind.