# Hexagaonal  profiles

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/YzMMBVW](https://codepen.io/cbolson/pen/YzMMBVW).

