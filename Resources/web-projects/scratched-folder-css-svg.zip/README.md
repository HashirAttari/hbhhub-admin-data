# Scratched Folder (CSS, SVG)

A Pen created on CodePen.io. Original URL: [https://codepen.io/konstantindenerz/pen/zYXONxz](https://codepen.io/konstantindenerz/pen/zYXONxz).

Inspired by this post, I created a CSS version that uses a SVG filter to create scratches.

https://twitter.com/sekachov/status/1762160697876828569 🔥

Unfortunately, `mask` and `backdrop-filter` did not work together, so I needed a few more elements. 😅

Another optimization idea would be the implementation of a responsive filter that generates the pattern according to the size.