function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}import React, { useState, useRef, cloneElement, Children } from 'https://cdn.skypack.dev/react@17.0.2';
import ReactDOM from 'https://cdn.skypack.dev/react-dom@17.0.2';
import { Canvas, useFrame } from 'https://cdn.skypack.dev/@react-three/fiber@7.0.24';
import { useControls } from 'https://cdn.skypack.dev/leva@0.9.10';

const Plane = (props) => /*#__PURE__*/
React.createElement("mesh", { position: props.position, receiveShadow: props.receiveShadow }, /*#__PURE__*/
React.createElement("planeGeometry", { args: [props.width, props.height] }), /*#__PURE__*/
React.createElement("shadowMaterial", { color: "white" }));



// Wrap a single component with this to create a set
// of Leva controls based on the given props
const LevaControls = ({ name, children, ...props }) => {
  const controls = useControls(name, props);
  return cloneElement(Children.only(children), controls);
};

function Box(props) {
  const ref = useRef();
  useFrame((state, delta) => ref.current.rotation.z += 0.01);

  return /*#__PURE__*/(
    React.createElement("mesh", _extends({},
    props, {
      ref: ref }), /*#__PURE__*/
    React.createElement("boxGeometry", { args: props.size }), /*#__PURE__*/
    React.createElement("meshStandardMaterial", { color: props.color })));


}

const App = () => /*#__PURE__*/
React.createElement(Canvas, { shadows: true, camera: { position: [0, -15, 5], fov: 22 } }, /*#__PURE__*/
React.createElement("ambientLight", { intensity: 0.3 }), /*#__PURE__*/
React.createElement(LevaControls, { name: "spotlight", position: [-10, 10, 10], angle: 0.15, penumbra: 1, power: 10, castShadow: true }, /*#__PURE__*/
React.createElement("spotLight", { "shadow-mapSize-width": 1024, "shadow-mapSize-height": 1024 })), /*#__PURE__*/

React.createElement(LevaControls, { name: "pointlight", position: [-10, -10, 10], power: 10, castShadow: true }, /*#__PURE__*/
React.createElement("pointLight", { "shadow-mapSize-width": 1024, "shadow-mapSize-height": 1024 })), /*#__PURE__*/

React.createElement(LevaControls, { name: "plane", position: [0, 0, 0], width: 10, height: 10, receiveShadow: true }, /*#__PURE__*/
React.createElement(Plane, null)), /*#__PURE__*/

React.createElement(LevaControls, { name: "box", position: [0, 0, 1], size: [2, 2, 2], color: "orange", castShadow: true }, /*#__PURE__*/
React.createElement(Box, null)));




ReactDOM.render( /*#__PURE__*/
React.createElement(App, null),
document.body);