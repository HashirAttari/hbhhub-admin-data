const doodle = document.querySelector('css-doodle');

document.addEventListener('mousemove', function(e) {
  let [ mx, my ] = [
    (e.clientX || e.pageX) / window.innerWidth * 100,
    (e.clientY || e.pageY) / window.innerHeight * 100
  ];
  doodle.style.setProperty('--mx', mx);
  doodle.style.setProperty('--my', my);
});

document.addEventListener('mouseleave', function(e) {
  doodle.style.removeProperty('--mx');
  doodle.style.removeProperty('--my');
})