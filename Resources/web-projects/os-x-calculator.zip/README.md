# OS X Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/mrlubos/pen/reqPro](https://codepen.io/mrlubos/pen/reqPro).

### About
This is a fork of a [Pen](http://codepen.io/samsaari/pen/qZMzrr/) by [Sampsa Saari](http://codepen.io/samsaari/). I liked the original work, but it was missing a few features, so I decided to work on them. One note: Do not depend on the accuracy of this calculator.

### What's new:

- removed the jQuery dependency
- the output scales to fit the display as it gets longer
- the calculator is more responsive
- added minimise/close/open calculator animations

### Contribution & Suggestions
You can usually reach me on [Twitter](https://www.twitter.com/lmenus).

### Want to build cool stuff?
I am always looking forward to meeting new people. If you want to work with me or just want to connect, message me at [lmenus@lmen.us](mailto:lmenus@lmen.us).