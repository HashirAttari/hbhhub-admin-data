window.onload = function() {
    var a, b, operator, equalOperator, total,
        calculator  = document.getElementById('calculator'),
        openBtn     = document.getElementById('open'),
        label       = document.getElementById('label'),
        closeBtn    = document.getElementById('close'),
        minimiseBtn = document.getElementById('minimise'),
        maximiseBtn = document.getElementById('maximise'),
        result      = document.getElementById('result'),
        screen      = document.getElementById('screen'),
        clearBtn    = document.getElementById('clear'),
        equalBtn    = document.getElementById('equal'),
        percentage  = document.getElementById('percentage'),
        operators   = document.getElementsByClassName('operator'),
        numbers     = document.getElementsByClassName('num'),
        text        = document.getElementById('text'),
        signBtn     = document.getElementById('toggleSign');
  
    var animationSpeed  = 400, // in ms
        minimisedHeight = 88,
        offset = {x: 16, y: 16}; // Positioned in left bottom.
  
    // Set up the initial state.  
    reset();
  
    // Reveal the calculator when ready.
    // Ugly ugly hack to maintain the correct
    // ratio from the start.
    calculator.style.transition = 'transform 0';
    calculator.style.transform = 'scale(1)';
    setTimeout(function () {
        calculator.style.transition = '';
        scaleCalculator();
        setTimeout(function () {
            calculator.classList.add('active');
        }, animationSpeed);
    }, 0);

    clearBtn.addEventListener('click', function (event) {
        reset();
    });
  
    for (var i = 0; i < numbers.length; i++) {
        (function (index) {
            numbers[index].addEventListener('click', function (event) {
                if (equalOperator) {
                    reset();
                }
                addToNumber(numbers[index].innerText);
                renderNumber();
            });
        })(i);
    }
  
    for (var i = 0; i < operators.length; i++) {
        (function (index) {
            operators[index].addEventListener('click', function (event) {
                if (operator) {
                    performOperation();
                    renderNumber();
                }
              
                operator = operators[index].innerText;
              
                if (equalOperator) {
                    b = '0';
                    equalOperator = false;
                }
            });
        })(i);
    }
  
    closeBtn.addEventListener('click', function () {
        closeApp();
    });
  
    equalBtn.addEventListener('click', function() {
        renderNumber(performOperation());
    });
  
    maximiseBtn.addEventListener('click', function () {
        maximiseApp();
    });
  
    minimiseBtn.addEventListener('click', function () {
        minimiseApp();
    });
  
    openBtn.addEventListener('click', function () {
        openApp();
    });
  
    percentage.addEventListener('click', function () {
        convertToPercentage();
    });

    signBtn.addEventListener('click', function () {
        renderNumber(toggleSign());
    });
  
    function addToNumber (char) {
        var number     = getDisplayNumber(),
            isNumber   = !isNaN(parseInt(char)),
            floatIndex = getFloatIndex(number);
      
        // Handle the case for zero.  
        if ((parseFloat(number) === 0 && (number.length - 1 !== floatIndex) && isNumber) || (operator && parseFloat(b) === 0)) {
            if (operator) {
                b = char;
            }
            else {
                a = char;
            }
        }
        // Allow only one floating point in the number.
        else if (!isNumber && floatIndex !== -1) {
            return;
        }
        else {
            if (operator) {
                b += char;
            }
            else {
                a += char;
            }
        }
      
        total = (operator) ? b : a;
    }
  
    function centerApp (skipAnimation) {
        var size   = calculator.getBoundingClientRect(),
            height = (document.body.offsetHeight - size.height) / 2,
            width  = (document.body.offsetWidth - size.width) / 2;
        
        if (skipAnimation) {
            calculator.style.transition = 'transform 0';
        }
      
        calculator.style.transform = 'translateX(' + width + 'px) translateY(' + height + 'px)';
        setTimeout(function () {
            calculator.style.transition = '';
        }, 0);
    }
  
    function closeApp () {
        calculator.classList.remove('active');
        setTimeout(function () {
            openBtn.classList.add('active');
        }, animationSpeed * 2);
    }
    
    // Improve this - be able to calculate 50% of 25 for example.
    function convertToPercentage() {
        var string     = getDisplayNumber(),
            isNegative = parseFloat(string) < 0,
            integer,
            length,
            floatIndex;
        
        // Work only with natural numbers.
        if (isNegative) {
            string = toggleSign(parseFloat(string));
        }
      
        integer    = parseInt(string).toString();
        length     = string.length;
        floatIndex = getFloatIndex(string);
        
        // Do not touch zero!
        if (parseFloat(string) === 0) {
            return;
        }
      
        // Work with strings to avoid scientific notation. :(
        if (floatIndex !== -1) {
            if (integer.length === 1) {
                string = '0' + getFloatSymbol() + '0' + string.substr(floatIndex - 1, 1) + string.substr(floatIndex + 1);
            }
            else if (integer.length === 2) {
                string = '0' + getFloatSymbol() + string.substr(0, floatIndex) + string.substr(floatIndex + 1);
            }
            else {
                string = string.substr(0, floatIndex - 2) + getFloatSymbol() + string.substr(floatIndex - 2, floatIndex - 1) + string.substr(floatIndex + 1);
            }
        }
        else {
            if (length === 1) {
                string = '0' + getFloatSymbol() + '0' + string;
            }
            else if (length === 2) {
                string = '0' + getFloatSymbol() + string;
            }
            else {
                string = string.substr(0, length - 2) + getFloatSymbol() + string.substr(length - 2);
            }
        }
        
        // Switch back the sign if necessary.
        if (isNegative) {
            string = toggleSign(parseFloat(string));
        }
      
        string = removeTrailingZeros(string);
        
        if (operator) {
            b = string;
        }
        else {
            a = string;
        }
        renderNumber();
    }
  
    function getDisplayNumber (returnFloat) {
        return (returnFloat) ? parseFloat(total) : total;
    }
  
    function getFloatIndex (string) {
        if (!string) {
            string = getDisplayNumber();
        }
        else {
            string = string.toString();
        }
        return string.indexOf(getFloatSymbol());
    }
  
    function getFloatSymbol () {
        return '.';
    }
    
    function maximiseApp () {
        calculator.classList.remove('minimised');
        centerApp();
        setTimeout(function () {
            scaleCalculator(true);
        }, animationSpeed);
    }
  
    function minimiseApp (skipAnimation) {
        var size  = calculator.getBoundingClientRect(),
            style = {
                x: offset.x,
                y: document.body.offsetHeight - minimisedHeight - offset.y,
            };
      
        if (skipAnimation) {
            calculator.style.transition = 'transform 0';
        }
      
        calculator.classList.add('minimised');
        calculator.style.transform = 'translateX(' + style.x + 'px) translateY(' + style.y + 'px)';
      
        setTimeout(function () {
            calculator.style.transition = '';
            scaleLabel();
        }, 0);
    }
  
    // Moves floating point only to the left as multiplying is safer.
    function moveFloatPoint (string, pos) {
        var integer, floatIndex, first, oldValue,
            moved = 0;
      
        while (moved < pos) {
            floatIndex = getFloatIndex(string);
          
            integer  = parseInt(string).toString();
            first    = integer.substr(0, integer.length - 1) || '0';
            oldValue = string;
            string   = first + getFloatSymbol() + integer[integer.length - 1];
            
            if (floatIndex !== -1) {
                string += oldValue.substr(floatIndex + 1);
            }
          
            moved++;
        }
      
        string = removeTrailingZeros(string);
        
        return string;
    }
  
    function openApp () {
        maximiseApp();
        openBtn.classList.remove('active');
        setTimeout(function () {
            calculator.classList.add('active');
        }, animationSpeed * 2);
    }
  
    function performOperation () {
        // Prepare numbers for operation.
        var a_float = getFloatIndex(a),
            b_float = getFloatIndex(b),
            shift   = 0,
            action  = operator || equalOperator,
            result,
            temp_b;
        
        // Division by zero? Are you mad?
        if (parseFloat(b) === 0 && action === '/') {
            return;
        }
      
        if (a_float > b_float) {
            shift = a.length - a_float - 1;
        }
        else if (b_float !== -1) {
            shift = b.length - b_float - 1;
        }
        
        a = shiftNumber(parseFloat(a), shift);
        b = shiftNumber(parseFloat(b), shift);
        
        result = eval(a + action + b);
        temp_b = b;
      
        reset();
      
        result = removeScientificNotation(result.toString());
        a = result;
        b = shiftNumber(temp_b, -shift).toString();
        
        total = result;
        
        // Store the operator so if we keep clicking
        // the button, the same action will be performed.
        equalOperator = action;
        
        return result;
    }
  
    function removeScientificNotation (string) {
        string = string.toString();
        var index = string.indexOf('e'),
            integer,
            shift;
        
        if (index === -1) {
            return string;
        }
      
        integer = string.substr(0, index) || '0';
        shift   = parseInt(string.substr(index + 1));
        
        if (shift >= 0) {
            return shiftNumber(integer, shift);
        }
        
        return moveFloatPoint(integer, -shift);
    }
  
    function removeTrailingZeros (string) {
        while (parseInt(string[string.length - 1]) === 0) {
            string = string.substr(0, string.length - 1);
        }
        if (string[string.length - 1] === getFloatSymbol()) {
            string = string.substr(0, string.length - 1);
        }
        return string;
    }
  
    function renderNumber (string) {
        result.innerText = string || total;
        text.style.transform = 'scale(1)';
      
        // Scale the text to fit in the display.
        var size    = result.getBoundingClientRect().width,
            display = screen.getBoundingClientRect().width,
            ratio   = (size < display) ? 1 : (display / size);

        text.style.transform = 'scale(' + ratio + ')';
    }
  
    function reset () {
        a = '0';
        b = '0';
        total = '0';
        operator = false;
        equalOperator = false;
      
        // Render changes.
        renderNumber();
    }
  
    function scaleCalculator (skipAnimation) {
        var height = calculator.getBoundingClientRect().height;
        calculator.style.width  = (height * .75) + 'px';
        centerApp(skipAnimation);
    }
  
    function scaleLabel () {
        label.style.transform = 'scale(1)';
      
        // Scale the text to fit in the display.
        var size    = label.getBoundingClientRect(),
            display = screen.getBoundingClientRect(),
            ratio   = (size.width < display.width) ? 1 : (display.width / size.width);

        label.style.transform = 'scale(' + ratio + ')';
    }
    
    function shiftNumber (number, decimals) {
        if (decimals === 0) {
            return number;
        }
      
        if (decimals > 0) {
            number *= Math.pow(10, decimals);
        }
        else {
            number = moveFloatPoint(removeScientificNotation(number).toString(), -decimals);
        }
        return number;
    }

    function toggleSign (number) {
        if (!number) {
            number = getDisplayNumber(true);
        }
        
        var string = -1 * number;
        string = string.toString();
        
        if (operator) {
            b = string;
        }
        else {
            a = string;
        }
        return string;
    }
    
    window.onresize = function () {
        renderNumber();
        if (!calculator.classList.contains('minimised')) {
            scaleCalculator(true);
        }
        else {
            minimiseApp(true);
        }
    }
};