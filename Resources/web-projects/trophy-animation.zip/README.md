# Trophy Animation 🏆

A Pen created on CodePen.io. Original URL: [https://codepen.io/motionharvest/pen/PoLmjdj](https://codepen.io/motionharvest/pen/PoLmjdj).

