# AirPods Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/visnuravichandran/pen/JjXXjXy](https://codepen.io/visnuravichandran/pen/JjXXjXy).

Created an AirPods Animation with Plug and Play Charging using Greensock

Implemented Dark and Light Mode