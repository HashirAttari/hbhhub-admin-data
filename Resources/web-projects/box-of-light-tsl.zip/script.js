import * as THREE from "three";
import * as tsl from "three/tsl";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";

import { pass, mrt, output, emissive } from "three/tsl";
import { bloom } from 'three/addons/tsl/display/BloomNode.js';

console.clear();

class Postprocessing extends THREE.PostProcessing {
  constructor(renderer) {
    const scenePass = pass(scene, camera);
    scenePass.setMRT(
      mrt({
        output,
        emissive
      })
    );

    const outputPass = scenePass.getTextureNode();
    const emissivePass = scenePass.getTextureNode("emissive");

    const bloomPass = bloom(emissivePass, 0.2, 0);

    super(renderer);
    
    // patch the result to add the BeerJS logo
    this.outputNode = outputPass.add( bloomPass );
  }
}

class BoxOfLight extends THREE.Mesh{
  constructor(){
    let g = new THREE.BoxGeometry();
    let m = new THREE.MeshPhysicalNodeMaterial({
      side: THREE.DoubleSide,
      metalness:0,
      roughnessNode: tsl.smoothstep(
        tsl.abs(
          tsl.dot(
            tsl.normalView, 
            tsl.positionView.normalize().negate()
          )
        ), 
        0.1, 
        0.25
      ).oneMinus(),
      transmission: 1,
      ior: 1.345,
      thickness: 1,
      emissiveNode: tsl.Fn(() => {
        let uv = tsl.uv().toVar();
        let absUV = uv.sub(0.5).abs().toVar();
        let maxUV = tsl.max(absUV.x, absUV.y);
        
        let fn = tsl.smoothstep(0.48, 0.49, maxUV);
        
        let col = tsl.color(0xaaccff).mul(2);
        
        return col.mul(fn);
      })()
    });
    super(g, m);

    [
      [ 1, 0, 0], 
      [-1, 0, 0], 
      [ 0, 1, 0], 
      [ 0,-1, 0], 
      [ 0, 0, 1], 
      [ 0, 0,-1]
    ].forEach(l => {
      let v = new THREE.Vector3(...l);
      let light = new THREE.SpotLight(0xaaccff, Math.PI * 10, 10, Math.PI * 0.75, 1, 2);
      light.position.copy(v);
      light.target.position.copy(v.multiplyScalar(2));
      this.add(light);
      this.add(light.target);
    });
    
    this.inits = {
      rot: {x: Math.PI * 2 * Math.random(), y: Math.PI * 2 * Math.random(), z: Math.PI * 2 * Math.random()}
    }
  }
  
  update(t){
    this.rotation.set(
      this.inits.rot.x + t * 0.4 * Math.PI * 2,
      this.inits.rot.y + t * 0.2 * Math.PI * 2,
      this.inits.rot.z
    )
    this.position.y = 0.25 + Math.sin(t * Math.PI * 2 * 0.125) * 0.75;
  }
}

class HollySurface extends THREE.Mesh{
  constructor(){
    let shape = new THREE.Shape([[1, 1], [-1, 1], [-1, -1], [1, -1]].reverse().map(p => {return new THREE.Vector2(...p).multiplyScalar(10)}));
    let size = 1.5;
    let radius = 0.5;
    let center = size - radius;
    let hole = new THREE.Path()
      .absarc( center, center, radius, Math.PI * 0.5 * 0, Math.PI * 0.5 * 1)
      .absarc(-center, center, radius, Math.PI * 0.5 * 1, Math.PI * 0.5 * 2)
      .absarc(-center,-center, radius, Math.PI * 0.5 * 2, Math.PI * 0.5 * 3)
      .absarc( center,-center, radius, Math.PI * 0.5 * 3, Math.PI * 0.5 * 4)
    shape.holes.push(hole);
    
    let g = new THREE.ExtrudeGeometry(
      shape, 
      {
        depth: 0.875, 
        bevelSize: 0.05,
        bevelThickness: 0.05,
        bevelSegments: 10
      }
    ).rotateX(-Math.PI * 0.5).rotateY(Math.PI * 0.25).translate(0, -1, 0);
    let m = new THREE.MeshStandardMaterial({
      color: 0x444444,
      metalness: 0.6,
      roughness: 0.4
    });
    
    super(g, m);
  }
}

let scene = new THREE.Scene();
scene.backgroundNode = tsl.color(0x000000);
let camera = new THREE.PerspectiveCamera(45, innerWidth / innerHeight, 0.1, 100);
camera.position.set(-0.1, 0.25, 1).setLength(5);
let renderer = new THREE.WebGPURenderer({ antialias: true });
renderer.setPixelRatio(devicePixelRatio);
renderer.setSize(innerWidth, innerHeight);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
document.body.appendChild(renderer.domElement);

let postprocessing = new Postprocessing(renderer);

window.addEventListener("resize", (event) => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

let controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.enablePan = false;
controls.minDistance = 5;
controls.maxDistance = 10;
controls.maxPolarAngle = Math.PI * 0.45;
controls.autoRotate = true;

let hollySurface = new HollySurface();
scene.add(hollySurface);

let boxOfLight = new BoxOfLight();
boxOfLight.position.set(0, 1, 0);
scene.add(boxOfLight);

let clock = new THREE.Clock();
let t = 0;

renderer.setAnimationLoop(() => {
  let dt = clock.getDelta();
  t += dt;
  controls.update();
  boxOfLight.update(t);
  //renderer.render(scene, camera);
  postprocessing.render();
});