# Box of Light [TSL]

A Pen created on CodePen.io. Original URL: [https://codepen.io/prisoner849/pen/RNbRNRO](https://codepen.io/prisoner849/pen/RNbRNRO).

