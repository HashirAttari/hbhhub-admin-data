# Styled native range input #7 (updated 2020)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/gbXrNy](https://codepen.io/thebabydino/pen/gbXrNy).

**February 2020 update**

Created the label with an actual `label` element, made the cog icon SVG and cleaned up the CSS and especially JS (old Edge/ IE and Firefox don't need JS, only WebKit browsers which do no have a separate progress pseudo-element for the range `input`).

---

**Original description**

Goal: create a nicely styled crossbrowser 1 element slider. IE needs  no JS. Firefox and Chrome/ Opera need a little JS help when it comes to styling the slider track. Inspiration:

![image](http://i.imgur.com/8HW8iNe.jpg) 

See also: [#1](http://codepen.io/thebabydino/pen/JoOomG/), [#2](http://codepen.io/thebabydino/pen/ogoXwG), [#3](http://codepen.io/thebabydino/pen/PwOPMG/), [#4](http://codepen.io/thebabydino/pen/Bymjmm), [#5](http://codepen.io/thebabydino/pen/ogoxgZ/)