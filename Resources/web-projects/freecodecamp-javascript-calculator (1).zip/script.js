/* jshint esversion: 6 */
// Maximum length of characters
// to display for result.
const MAX_RESULT_LENGTH = 8;
// Maximum positive number to display
// which is dependent on MAX_RESULT_LENGTH.
const MAX_NUMBER = 9999999;
// Maximum number of decimal places
// to display for exponential
const MAX_RESULT_EXP_DEC = 3;
// Maximum length of characters
// to display for result.
const MAX_EQUATION_LENGTH = 20;
// Object for memory value and
// available functions.
var mValue = {
  // Store memory value.
  _mValue: 0,
  // Increase memory by amount supplied.
  addToMValue: (val) => {
    if (val) {
      this._mValue = this._mValue ? this._mValue + parseFloat(val) : 0 + parseFloat(val);
    }
  },
  // Subtract amount supplied from memory.
  subtractFromMValue: (val) => {
    if (val) {
      this._mValue = this._mValue ? this._mValue - val : 0 - val;
    }
  },
  // Return memory value stored or zero.
  getMValue: () => {
    return this._mValue ? this._mValue : 0;
  },
  // Clear value held in memory.
  clearMValue: () => {
    this._mValue = 0;
  }
};
// Object for result value and
// available functions.
var result = {
  // Store result value.
  _result: '',
  // Store is calculated value.
  _isCalc: false,
  // Return result value stored or empty string.
  getResult: () => {
    return this._result ? this._result : '';
  },
  // Return result is calculated value or false.
  getIsCalc: () => {
    return this._isCalc ? this._isCalc : false;
  },
  // Set result with supplied value.
  setResult: (val) => {
    this._result = val;
  },
  // Set if result is calculated with supplied value.
  setIsCalc: (val) => {
    this._isCalc = val;
  }
};
// Object for equation value and
// available functions.
var equation = {
  // Store equation value.
  _equation: '',
  // Return equation value stored or empty string.
  getEquation: () => {
    return this._equation ? this._equation : '';
  },
  // Return the length of equation string or zero.
  getLength: () => {
    return this._equation ? this._equation.length : 0;
  },
  // Set equation with supplied value.
  setEquation: (val) => {
    this._equation = val;
  }
};
// An object that returns the operator function
// that is required to perform the calculation.
var operators = {
  // Division.
  '&divide;': (a, b) => {
    return parseFloat(a) / parseFloat(b);
  },
  // Multiplication.
  '&times;': (a, b) => {
    return parseFloat(a) * parseFloat(b);
  },
  // Addition.
  '&plus;': (a, b) => {
    return parseFloat(a) + parseFloat(b);
  },
  // Subtraction.
  '&minus;': (a, b) => {
    return parseFloat(a) - parseFloat(b);
  },
  // Percentage.
  '%': (a, b) => {
    return parseFloat(a) / parseFloat(b) * 100;
  },
  // Exponentiation.
  '^': (a, b) => {
    return Math.pow(a, b);
  }
};
// Output Result string
// to display.
function updateResult() {
  // Check if result length fits screen
  if (result.getResult().length > MAX_RESULT_LENGTH) {
    // Check if result contains a decimal place.
    var decimalIndex = result.getResult().toString().indexOf('.');
    if (decimalIndex > 0) {
      // Truncate float.
      result.setResult(parseFloat(result.getResult()).toFixed(MAX_RESULT_LENGTH - decimalIndex));
    } 
  }
  // Display result (as exponential if needed).
  $('#result-text').html(function() {
    return "<span>" + (result.getResult().toString().length > MAX_RESULT_LENGTH ? Number(result.getResult()).toExponential(MAX_RESULT_EXP_DEC) : result.getResult()) + "</span>";
  });
}
// Output Equation string
// to display.
function updateEquation() {
  // Count characters after converting html entity names.
  var eqString = $("<span>" + equation.getEquation() + "</span>").text();
  var eqLength = eqString.length;
  // Display equation after trimming if required.
  $('#equation-text').html(function() {
    return "<span>" + (eqLength > MAX_EQUATION_LENGTH ? eqString.substring(eqLength - MAX_EQUATION_LENGTH) : eqString) + "</span>";
  });
}
// Calculate the total of 2 parameters
// using the third as the operator type.
function calculate(lOperand, operator, rOperand) {
  var total = 0;
  total = (operators[operator](lOperand, rOperand));
  return total;
}
// Calculate the equation array
// from left to right not BODMAS.
function equate(eq) {
  var equat = [];
  // Loop through array calculating the first 3 arguments
  // and return result to the beginning of the array
  while (eq.length >= 3) {
    equat[0] = (calculate(eq[0], eq[1], eq[2]));
    eq = equat.concat(eq.slice(3, eq.length));
  }
  return eq;
}
// Return the result of processing string parameter 
// as a mathematical equation array.
function processEquation(eq) {
  // Create an array of operands and operators from string.
  var eqArray = eq.replace(/\^/g, ',^,').replace(/%/g, ',%,').replace(/&/g, ',&').replace(/;/g, ';,').split(/,/g);
  // Pass array to function for result of equation.
  result.setResult(equate(eqArray));
  // Clear equation to empty display.
  return result.getResult();
}
// Remove string representing an operator
// from equation if it is the first or last entry.
function trimOperator() {
  var operator;
if (equation.getLength() > 0) {
  // Trim from front.
  if (equation.getEquation()[0] == '&') {
    operator = equation.getEquation().indexOf(';');
  } else if (equation.getEquation()[0] == '^') {
    operator = equation.getEquation().indexOf('^');
  } else if (equation.getEquation()[0] == '%') {
    operator = equation.getEquation().indexOf('%');
  }
  equation.setEquation(equation.getEquation().substring(operator != -1 ? operator + 1 : 0));
  // Trim from end.
  if ((equation.getEquation()[equation.getLength() - 1]) == ';') {
    operator = equation.getEquation().lastIndexOf('&');
  } else if ((equation.getEquation()[equation.getLength() - 1]) == '^') {
    operator = equation.getEquation().indexOf('^');
  } else if ((equation.getEquation()[equation.getLength() - 1]) == '%') {
    operator = equation.getEquation().indexOf('%');
  }
  equation.setEquation(equation.getEquation().substring(0, operator != -1 ? operator : equation.getLength()));
  }
}
// Process input data from both
// interface and keyboard.
function processInput(data) {
  // Check that data is valid.
  if (data !== undefined && equation) {
    // Detect data type and process.
    switch (data) {
      // Calculate equation
      case '=':
        {
          // Escape if last operation was a calculation.
          if (result.getIsCalc()) break;
          // Add current result to equation.
          equation.setEquation(equation.getEquation() + '' + result.getResult());
          // Remove operators from both ends of equation.
          trimOperator();
          // Calculate and set result value.
          result.setResult(processEquation(equation.getEquation()));
          result.setIsCalc(true);
          break;
        }
        // Calculate and display square root.
      case '√':
        {
          // Calculate result if exists and not negative
          // otherwise clear result and equation.
          if (Math.sqrt(result.getResult()) && result.getResult() > 0) {
            equation.setEquation('√' + parseFloat(result.getResult()));
            result.setResult(Math.sqrt(result.getResult()));
          } else {
            result.setResult('');
            equation.setEquation('');
          }
          result.setIsCalc(true);
          break;
        }
        // Add to memory value.
      case 'M+':
        {
          // Add result to memory value.
          mValue.addToMValue(result.getResult());
          // Set calculated result and clear equation.
          result.setResult(mValue.getMValue());
          equation.setEquation('');
          // Set to result is displaying input.
          result.setIsCalc(true);
          break;
        }
        // Subtract from memory value.
      case 'M-':
        {
          // Subtract result from memory value.
          mValue.subtractFromMValue(result.getResult());
          // Set calculated result and clear equation.
          result.setResult(mValue.getMValue());
          equation.setEquation('');
          // Set to result is displaying input.
          result.setIsCalc(true);
          break;
        }
      case 'MR':
        {
          // Set result to stored memory value.
          result.setResult(mValue.getMValue());
          // Set to result is displaying input.
          result.setIsCalc(true);
          break;
        }
      case 'MC':
        {
          // Clear value stored memory.
          mValue.clearMValue();
          // Set to result is displaying input.
          result.setIsCalc(true);
          break;
        }
        // Clear All.
      case 'CA':
        {
          // Set result to empty string.
          result.setResult(0);
          // Set equation to empty array.
          equation.setEquation([]);
          // Set to result is displaying input.
          result.setIsCalc(false);
          break;
        }
        // Clear last operand and/or operator.
      case 'C':
        {
          // Clear result.
          result.setResult("");
          // Check equation for operands.
          var expIndex = equation.getEquation().lastIndexOf('^');
          var opIndex = equation.getEquation().lastIndexOf('&');
          // Store index of last found.
          var index = expIndex > opIndex ? expIndex : opIndex;
          if (index > 0) {
            equation.setEquation(equation.getEquation().substring(0, index != -1 ? index : equation.getLength()));
          } else {
            equation.setEquation('');
          }
          // Set to result is displaying input.
          result.setIsCalc(false);
          break;
        }
        // Add operator to equation and clear result.
      case '^':
      case '%':
      case '&divide;':
      case '&times;':
      case '&plus;':
      case '&minus;':
        {
          if (result.getIsCalc()) {
            equation.setEquation('');
          } 
          // Set to result is displaying input.
          result.setIsCalc(false);
          // Check if operator is last entry and update.
          // trimOperator();
          // Add result value to equation.
          equation.setEquation(equation.getEquation() + '' + parseFloat(result.getResult()));
          // Check if operator is last entry and update.
          trimOperator();
          equation.setEquation(equation.getEquation() + data);
          // Clear result.
          result.setResult("");
          break;
        }
        // Add numerals to both variables.
      case (data.match(/^\d/) || {}).input:
        {
          // Clear result and equation display if just calculated.
          if (result.getIsCalc()) {
            result.setResult('');
            equation.setEquation('');
          }
          // TODO Disallow scientific notation overflow for decimal
          result.setResult(result.getResult() + data);
          // Set to result is displaying input.
          result.setIsCalc(false);
          break;
        }
        // Add period to both variables
      case '.':
        {
          // Set to result is displaying input.
          result.setIsCalc(false);
          // Only add period if there isn't one.
          if (result.getResult().indexOf('.') < 0) {
            result.setResult(result.getResult() + data);
          }
          break;
        }
        // Make number negative.
      case '-':
        {
          if (Math.sign(result.getResult()) > 0) {
            result.setResult(data + result.getResult());
          } else {
            result.setResult(Math.abs(result.getResult()));
          }
          break;
        }
    }
    // Display data currently held in variables.
    updateResult();
    updateEquation();
  }
}
// Register interface button click
// and process input.
$('.button').on('click', function(e) {
  var buttonText;
  switch (e.target.outerText) {
      // Division.
    case '÷':
      {
        buttonText = '&divide;';
        break;
      }
      // Multiplication.
    case '×':
      {
        buttonText = '&times;';
        break;
      }
      // Addition.
    case '+':
      {
        buttonText = '&plus;';
        break;
      }
      // Subtraction.
    case '−':
      {
        buttonText = '&minus;';
        break;
      }
      // Catch click on y.
    case 'y':
      // Exponentiation.
    case 'xy':
      {
        buttonText = '^';
        break;
      }
      // Sign toggle.
    case '+/-':
      {
        buttonText = '-';
        break;
      }
      // All other button presses.
    default:
      {
        buttonText = e.target.outerText;
      }
  }
  processInput(buttonText);
});
// Detect key press for valid
// characters and process.
$(document).on("keyup", function(e) {
  // Store key pressed data, defaults to undefined.
  var keyPressed;
  switch (e.key) {
      // Clear result and equation.
    case 'Delete':
      {
        keyPressed = 'CA';
        break;
      }
      // Clear result and last operand and/or operator from equation.
    case 'Backspace':
      {
        keyPressed = 'C';
        break;
      }
      // Multiplication.
    case '*':
      {
        keyPressed = '&times;';
        break;
      }
      // Division.
    case '/':
      {
        keyPressed = '&divide;';
        break;
      }
      // Addition.
    case '+':
      {
        keyPressed = '&plus;';
        break;
      }
      // Subtraction.
    case '-':
      {
        keyPressed = '&minus;';
        break;
      }
      // Percentage.
    case '%':
      {
        keyPressed = e.key;
        break;
      }
      // Exponential.
    case '^':
      {
        keyPressed = e.key;
        break;
      }
      // Only numbers.  
    case (e.key.match(/^\d/) || {}).input:
      {
        keyPressed = e.key;
        break;
      }
      // Decimal place.
    case '.':
      {
        keyPressed = e.key;
        break;
      }
      // Calculate.
    case 'Enter':
      {
        keyPressed = '=';
        break;
      }
  }
  // If key pressed is undefined log message
  // otherwise process input.
  if (keyPressed !== undefined) { 
    processInput(keyPressed);
  } else {
    // Log input for troubleshooting incorrect data.
    console.log('unknown input key = '+keyPressed);
  }
});