# Waves #2

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/jrvaWM](https://codepen.io/hakimel/pen/jrvaWM).

Experimenting with animated backgrounds for an upcoming project, here's one that didn't make the cut.