const canvas = document.createElement('canvas');
const context = canvas.getContext('2d');

document.body.appendChild(canvas);

const lines = [];

const colors = [
['#222', '#fff'],
['#fff', '#222']];


var colorIndex = -1;

var step = 0,
width = 0,
height = 0;

document.ontouchstart = color;
document.onmousedown = color;

setup();
color();
update();

function setup() {

  width = window.innerWidth,
  height = window.innerHeight;

  lines.length = 0;

  let radius = Math.min(width, height) * 0.5;
  let lineCount = 16;
  let pointCount = 20;
  let spacingH = radius * 2 / pointCount;
  let spacingV = radius * 2 / lineCount;

  for (let v = 1; v < lineCount; v++) {

    let line = { points: [], ran: Math.random() };
    let spreadFactor = 1.1 - Math.abs(v - lineCount / 2) / (lineCount * 0.6);
    let points = pointCount * spreadFactor;

    let offsetX = width / 2 - pointCount * spacingH / 2;
    offsetX += radius - points * spacingH / 2;

    let offsetY = height / 2 - lineCount * spacingV / 2;

    for (let h = 0; h < points; h++) {
      line.points.push({
        nx: offsetX + h * spacingH,
        ny: offsetY + v * spacingV });

    }

    lines.push(line);

  }

}

function color() {

  colorIndex = ++colorIndex % colors.length;
  canvas.style.backgroundColor = colors[colorIndex][0];

}

function update() {

  step += 1;

  canvas.width = width;
  canvas.height = height;

  context.clearRect(0, 0, width, height);

  context.lineJoin = 'round';
  context.lineCap = 'round';
  context.lineWidth = 6;
  context.strokeStyle = colors[colorIndex][1];
  context.fillStyle = colors[colorIndex][1];

  lines.forEach((line, v) => {

    context.beginPath();

    line.points.forEach((point, h) => {

      point.x = point.nx,
      // point.y = point.ny + ( Math.sin( ( point.x / 20 ) + ( step / 50 ) ) * 20 );
      point.y = point.ny + Math.sin((point.x + step) / 50) * 30;

    });

    line.points.forEach((point, h) => {

      let nextPoint = line.points[h + 1];

      if (h === 0) {
        context.moveTo(point.x, point.y);
      } else
      if (nextPoint) {
        let cpx = point.x + (nextPoint.x - point.x) / 2;
        let cpy = point.y + (nextPoint.y - point.y) / 2;
        context.quadraticCurveTo(point.x, point.y, cpx, cpy);
      }

    });

    context.stroke();

  });

  requestAnimationFrame(update);

}