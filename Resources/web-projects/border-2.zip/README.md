# Border 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/dyvKdzz](https://codepen.io/yuanchuan/pen/dyvKdzz).

