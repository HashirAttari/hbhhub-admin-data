# Avatar Design with Clip & Blending

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/xaawVj](https://codepen.io/markmead/pen/xaawVj).

Clip path and mix blend combine to make some sweet things my dudes