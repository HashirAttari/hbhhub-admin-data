// Tiger image from Pixabay on Pexels https://www.pexels.com/photo/adult-tiger-64152/
// Man image from Ali Marel on Unsplash https://unsplash.com/photos/1V8Yt7_ZRnw
// Inspired from Martial's avatar https://twitter.com/AnthonyMartial