# Mix-Blend-Mode With The Three Primary Colors 💛💙🧡

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/LMqBwQ](https://codepen.io/leenalavanya/pen/LMqBwQ).

Red + Yellow = Green? Blue + Yellow = Turquoise?
Experimenting with Mix-Blend-Mode on the three primary colors of red, yellow and blue for this month's #CodePenChallenge #CPC-Primary. 
No correct secondary color found so far. *sighs*