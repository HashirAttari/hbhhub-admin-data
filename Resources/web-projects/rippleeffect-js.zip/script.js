var ripple_effect = document.getElementsByClassName("ripple_effect");
for (var i = 0; i < ripple_effect.length; i++) {
  ripple_effect[i].innerHTML = '<div class="ripple_effector"></div><span class="ripple_effectHolder">' + ripple_effect[i].innerHTML + '</span>';
  ripple_effect[i].onclick = function(e) {
    var ripple = e.currentTarget.getElementsByClassName('ripple_effector')[0];
    ripple.style.top = (e.clientY - ripple.parentNode.offsetTop) + 'px';
    ripple.style.left = (e.clientX - ripple.parentNode.offsetLeft) + 'px';
    ripple.classList.add('ripple_effectOut');
    setTimeout(function() {
      ripple.classList.remove('ripple_effectOut');
      ripple.style.opacity = "0.5"
    }, 1000)
  }
}
var ripple_effector = document.getElementsByClassName("ripple_effector");
for (var i = 0; i < ripple_effector.length; i++) {
  ripple_effector[i].style.background = ripple_effector[i].parentNode.getAttribute('data-ripple-effect')
}