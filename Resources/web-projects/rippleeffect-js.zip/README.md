# RippleEffect.JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/wWWZGM](https://codepen.io/leenalavanya/pen/wWWZGM).

A ripple bubble for material buttons :)

To use it add: (and then, use the class 'ripple_effect' on  any button)

&lt;script src="http://codepen.io/arianalynn/pen/wWWZGM.js"&gt;&lt;/script&gt;
&lt;link rel="stylesheet" href="http://codepen.io/arianalynn/pen/wWWZGM.css"/&gt;


Also, if you've found the bug where the bubble fails to open, wait a few seconds before clicking the button again. Remember, most buttons lead to something and nobody usually presses them for more than 2 times.