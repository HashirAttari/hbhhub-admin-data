const wrapper = document.querySelector( 'div' );
const quantity = 32;

let ranges = [];
let value = 50;
let velocity = 0;
let easedVelocity = 0;
let currentRange;

const build = () => {
  wrapper.innerHTML = '';
  ranges = new Array(quantity).fill(undefined).map( (o,i) => {
    const el = document.createElement( 'input' );
    el.setAttribute( 'type', 'range' );
    el.setAttribute( 'step', '0.1' );
    el.oninput = () => rangeChanged(i);
    el.value = value;
    wrapper.appendChild( el );
    return {
      el,
      value,
      degrees: 180+(i/quantity*360),
      velocity: 0,
      shift: 0,
      drag: 1
    };
  } );
}

const rangeChanged = ( index ) => {
  currentRange = ranges[index];
  value = currentRange.el.valueAsNumber;
  velocity = value - currentRange.value;
  easedVelocity += ( velocity - easedVelocity ) * 0.05;

  ranges.forEach( ( range, i ) => {
    let toRight = (index - i + quantity) % quantity;
    let toLeft = (i - index + quantity) % quantity;
    let distance = Math.min( toRight, toLeft );
    range.drag = 0.75 - distance / ( ranges.length - 1 );
    range.velocity = easedVelocity * range.drag;
  } );
}

const animate = () => {
  requestAnimationFrame( animate );

  ranges.forEach( ( range, i ) => {
    range.value += ( value - range.value ) * range.drag * 0.15;
    range.shift += range.velocity * 0.25;
    range.shift *= 0.96;
    range.velocity = range.velocity * 0.9;
    range.el.value = range.value;
    range.el.style.transform = `rotate(${range.degrees}deg) translateX(${range.shift}px)`;
  } );
}

window.onresize = build;

build();
animate();