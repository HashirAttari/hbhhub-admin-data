# <input type="range">

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/gOoPyjm](https://codepen.io/hakimel/pen/gOoPyjm).

