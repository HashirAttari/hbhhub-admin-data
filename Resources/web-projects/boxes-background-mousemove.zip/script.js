const wrapper = document.querySelector("#wrapper");
const boxes = document.querySelectorAll(".box");
const cursor = document.getElementById("cursor");

const move = (e) => {
    const rect = wrapper.getBoundingClientRect();
    // Mouse position relative to container
    var x = e.clientX - rect.left;
    var y = e.clientY - rect.top;

   wrapper.style.setProperty('--shadow-left', `${x}px`);
    wrapper.style.setProperty('--shadow-top', `${y}px`);
};

boxes.forEach(box => {
    box.addEventListener("mousemove", (e) => {
      box.style.setProperty('--shadow-opacity', '0.8');
      box.style.setProperty('--box-bg', 'transparent');
      
      move(e);
    });
    box.addEventListener("mouseout", (e) => {
      box.style.setProperty('--shadow-opacity', '0');
      box.style.setProperty('--box-bg', '#000');
    });
})