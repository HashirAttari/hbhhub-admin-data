# Triangular thoughts

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/ZxRLVL](https://codepen.io/ainalem/pen/ZxRLVL).

I toke this pen https://codepen.io/rachsmith/pen/XKyvWV modified it  a bit and added 1. a gradient 2. drop shadow and 3. clip-path et voila!