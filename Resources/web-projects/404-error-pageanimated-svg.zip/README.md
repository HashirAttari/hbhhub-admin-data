# 404 Error page - Animated SVG

A Pen created on CodePen.io. Original URL: [https://codepen.io/henrywr/pen/XezdRr](https://codepen.io/henrywr/pen/XezdRr).

