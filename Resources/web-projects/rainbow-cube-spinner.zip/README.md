# rainbow cube spinner

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/rRpJoo](https://codepen.io/run-time/pen/rRpJoo).

