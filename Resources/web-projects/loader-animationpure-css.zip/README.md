# Loader Animation - Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/dui77/pen/WNmqjRN](https://codepen.io/dui77/pen/WNmqjRN).

