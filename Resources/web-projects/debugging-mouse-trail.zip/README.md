# Debugging mouse trail

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/dyzyBYB](https://codepen.io/franksLaboratory/pen/dyzyBYB).

