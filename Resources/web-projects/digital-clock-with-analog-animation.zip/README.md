# Digital Clock with analog animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/umarcbs/pen/KKMwOjW](https://codepen.io/umarcbs/pen/KKMwOjW).

Digital clock with canvas