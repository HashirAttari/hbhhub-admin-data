document.addEventListener("DOMContentLoaded", function () {
	const filterSelect = document.getElementById("filter-select");
	const filters = document.querySelectorAll(".filter");
	const original = document.querySelector(".filter.original");

	filterSelect.addEventListener("change", function () {
		const selectedFilter = this.value;

		filters.forEach((filter) => {
			if (selectedFilter === "all") {
				filter.classList.add("active");
			} else if (
				filter.classList.contains(selectedFilter) ||
				filter.classList.contains("original")
			) {
				filter.classList.add("active");
			} else {
				filter.classList.remove("active");
			}
		});

		if (selectedFilter === "all") {
			original.classList.add("active");
		} else {
			original.classList.remove("active");
		}
	});

	filterSelect.value = "all";
	filterSelect.dispatchEvent(new Event("change"));
});