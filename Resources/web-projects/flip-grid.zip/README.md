# Flip grid

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/DOjbRM](https://codepen.io/hakimel/pen/DOjbRM).

