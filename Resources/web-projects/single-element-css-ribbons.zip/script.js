// there are many different tag combinations
// which can be created by using CSS to style
// a single element

const size = document.getElementById("inputSize");

size.addEventListener("input", function() {
  let s = parseInt(size.innerText,10) || 20;
  document.documentElement.style.setProperty('--global-size', s+'px');
}, false);