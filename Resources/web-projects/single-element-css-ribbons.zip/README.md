# Single Element CSS Ribbons

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/BqeBJd](https://codepen.io/run-time/pen/BqeBJd).

Pure single element CSS only ribbon with drop shadow!