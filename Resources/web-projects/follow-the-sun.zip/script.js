var card = document.querySelector('.card')
var card2 = document.querySelector('.card2')
var svg = document.querySelector('svg')
var stem = document.querySelector('.stem')
var stem2 = document.querySelector('.stem2')
var flower = document.querySelector('.flower')
var ant = document.querySelectorAll('.ant')
var bug = document.querySelector('.bug')
var halfW = window.innerWidth/2
var halfH = window.innerHeight/2

window.addEventListener('click', color)

function color(){
var color = "hsl("+Math.floor(Math.random()*360)+"deg,100%,30%)"
var colorr = "hsl("+Math.floor(Math.random()*360)+"deg,100%,30%)"

document.getElementsByTagName('body')[0].style.background = "linear-gradient(to top right,"+color+","+colorr+")"
}

color()

window.addEventListener('mousemove', function(e){
  var x = e.clientX;
  var y = e.clientY
  var rx = x < halfW ? -(1-(x/halfW)) : (1-(halfW/x))*2;
  var ry = y < halfH ? (1-(y/halfH)) : -(1-(halfH/y))*2;
    
  card.style.transform = "rotateY("+rx*25+"deg) rotateX("+ry*25+"deg)"
  flower.style.transform = "skewX("+ -(rx*50) +"deg) scaleY(-1)"
  
  for(var i=0;i<ant.length;i++){
    ant[i].style.boxShadow = -(rx*10)+"px 8px 4px #630"
  }
      
  bug.style.left = x-18+"px"
  bug.style.top = y-18+"px"
  
})