# Scroll progress indicator border frame (Chrome only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/YzgLWRV](https://codepen.io/giana/pen/YzgLWRV).

I'm so good at naming.

Currently works only in desktop/Android Chrome. Here's a hacked-together version using the [scroll polyfill](https://github.com/flackr/scroll-timeline):

https://codepen.io/giana/pen/xxBjRpQ