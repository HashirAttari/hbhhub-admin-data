# Victrola

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/VwaKxex](https://codepen.io/ricardoolivaalonso/pen/VwaKxex).

