# Details Interaction (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/Rwavxqv](https://codepen.io/benhatsor/pen/Rwavxqv).

Using HTML `<details>` to power an SVG menu toggle.