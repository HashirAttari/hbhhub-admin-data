import React, { useState, useRef } from 'https://cdn.skypack.dev/react';
import ReactDOM from 'https://cdn.skypack.dev/react-dom';
import { useDimensions } from 'https://cdn.skypack.dev/webrix@1.5.9/hooks';

const DATA = [
[1131, 1604, 1240, 1731, 1304, 2101, 1701],
[708, 1401, 1140, 1503, 1020, 1751, 902]];


const COLORS = ['#00baf0', '#5637f4'];
const LABELS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL'];

const Line = ({ path, color }) => {
  const dx = 100 / (path.length - 1);
  const d = `M0,${path[0]} ${path.slice(1).map((p, i) =>
  `C${dx * i + dx / 2},${path[i]} ` +
  `${dx * (i + 1) - dx / 2},${path[i + 1]} ` +
  `${dx * (i + 1)},${path[i + 1]} `).
  join(' ')}`;
  return /*#__PURE__*/(
    React.createElement(React.Fragment, null, /*#__PURE__*/
    React.createElement("path", { stroke: color, d: d, fill: "none", className: "stroke" }), /*#__PURE__*/
    React.createElement("path", { d: d + ` V0 H0 Z`, fill: `url(#gradient-${color})`, className: "gradient" }), /*#__PURE__*/
    React.createElement("defs", null, /*#__PURE__*/
    React.createElement("linearGradient", { id: `gradient-${color}`, x1: "0", x2: "0", y1: "0", y2: "1" }, /*#__PURE__*/
    React.createElement("stop", { offset: "0%", stopColor: color, stopOpacity: 0 }), /*#__PURE__*/
    React.createElement("stop", { offset: "100%", stopColor: color, stopOpacity: 0.15 })))));




};

const Points = ({ data, width, height, setActive, range }) => {
  const timeout = useRef();
  const dr = Math.abs(range[1] - range[0]);
  const activate = (path, point) => {
    clearTimeout(timeout.current);
    setActive({ path, point });
  };
  const deactivate = (path, point) => {
    clearTimeout(timeout.current);
    timeout.current = setTimeout(() => {
      setActive(cur => {
        if (cur.path === path && cur.point === point) {
          return null;
        }
        return cur;
      });
    }, 200);
  };
  return /*#__PURE__*/(
    React.createElement("div", { className: "points" },
    data.map((row, r) => row.map((y, i) => /*#__PURE__*/
    React.createElement("div", { style: { '--x': `${i * width / (row.length - 1)}px`, '--y': `${height - y * (height / dr)}px` }, onMouseEnter: () => activate(r, i), onMouseLeave: () => deactivate(r, i) })))));



};

const Legend = ({ labels, colors }) => /*#__PURE__*/
React.createElement("div", { className: "legend" },
labels.map((l, i) => /*#__PURE__*/
React.createElement("div", { key: l }, /*#__PURE__*/React.createElement("span", { style: { '--color': colors[i] } }), l)));




const Marker = ({ colors, labels, data, active, width, height, range }) => {var _data$path, _data$path2, _value$toLocaleString;
  const { path, point } = active || {};
  const value = (_data$path = data[path]) === null || _data$path === void 0 ? void 0 : _data$path[point];
  const dr = Math.abs(range[1] - range[0]);
  return /*#__PURE__*/(
    React.createElement("div", { className: "marker", style: {
        opacity: active ? 1 : 0,
        '--color': colors[path],
        '--x': `${point * width / (((_data$path2 = data[path]) === null || _data$path2 === void 0 ? void 0 : _data$path2.length) - 1)}px`,
        '--y': `${height - value * (height / dr)}px` } }, /*#__PURE__*/

    React.createElement("div", { className: "tooltip" }, /*#__PURE__*/
    React.createElement("span", null, labels[point]), /*#__PURE__*/
    React.createElement("span", null, "$", value === null || value === void 0 ? void 0 : (_value$toLocaleString = value.toLocaleString) === null || _value$toLocaleString === void 0 ? void 0 : _value$toLocaleString.call(value))), /*#__PURE__*/

    React.createElement("div", { className: "line" }), /*#__PURE__*/
    React.createElement("div", { className: "circle" })));


};

const Graph = ({ data, colors, range, labels, title, subtitle, legend }) => {
  const [active, setActive] = useState({ path: 1, point: 2 });
  const graph = useRef();
  const { width, height } = useDimensions(graph);
  return /*#__PURE__*/(
    React.createElement("div", { className: "graph", ref: graph }, /*#__PURE__*/
    React.createElement("div", { className: "heading" }, /*#__PURE__*/
    React.createElement("div", { className: "title" }, title), /*#__PURE__*/
    React.createElement("div", { className: "subtitle" }, subtitle)), /*#__PURE__*/

    React.createElement(Marker, { colors: colors, data: data, active: active, labels: labels, width: width, height: height, range: range }), /*#__PURE__*/
    React.createElement(Legend, { colors: colors, labels: legend }), /*#__PURE__*/
    React.createElement("svg", { viewBox: `0 ${range[0]} 100 ${range[1]}`, preserveAspectRatio: "none" },
    data.map((path, i) => /*#__PURE__*/
    React.createElement(Line, { key: i, path: path, color: colors[i] }))), /*#__PURE__*/


    React.createElement("div", { className: "labels" },
    labels.map((label) => /*#__PURE__*/
    React.createElement("div", { key: label }, label))), /*#__PURE__*/


    React.createElement(Points, { data: data, width: width, height: height, setActive: setActive, range: range })));


};

const App = () => /*#__PURE__*/
React.createElement(Graph, { data: DATA, colors: COLORS, range: [0, 3000], labels: LABELS, title: "$11,3K", subtitle: "YTD Revenue", legend: ['Stream A', 'Stream B'] });


ReactDOM.render( /*#__PURE__*/
React.createElement(App, null),
document.body);