# Interactive SVG Graph

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/GRxoWMR](https://codepen.io/ykadosh/pen/GRxoWMR).

A basic interactive & responsive graph made with SVG.

Based on this beautiful design by Dan Klenkov https://dribbble.com/shots/15725741-Sales-Dashboard/attachments/7527877?mode=media