# CSS box shadow particles v2

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/KVpxyV](https://codepen.io/giana/pen/KVpxyV).

Same as <a href="http://codepen.io/giana/pen/JGdbje">the first version</a>, only with different numbers.