# Styled native range input #18 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/WbXyba](https://codepen.io/thebabydino/pen/WbXyba).

**May 2021**

* minor CSS cleanups, in particular made most of the code for `::-moz-range-track` and `::-moz-range-progress` common to slash a few more lines of code

* minor accessibility tweak: give the `output` elements `display: none` in the no JS case since they can't get updated on dragging the handles anyway

---

**December 2020 update**

The original version was relying on buggy browser behaviour/ things that have since been removed from the spec to work, so I updated the code to use modern techniques in order to make the whole thing functional again.

Gave up using absolute positioning and switched to using CSS grid.

Using CSS variables to keep the code DRY.

Using an `output` element and CSS variables for the current value in the tooltip and the remaining time at the end of the slider. These values won't be displayed if JS is not supported. The tooltip arrow uses `conic-gradient` and gets displayed only if this property is supported.

Not providing free support for IE/ pre-Chromium Edge anymore.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling range track. There's a bit of an extra in Chrome/ Opera with a nicely styled tooltip (not a separate element, a pseudo on the thumb) for some of the ranges. This is done using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). Fallback for no JS: simply display the same background for the entire track, both before and after the thumb and no tooltip. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/lwErdsw.jpg) 