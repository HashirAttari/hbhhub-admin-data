var box = document.querySelectorAll('.box')

for(var i=0;i<box.length;i++) {
  var x = Math.random()*7
  box[i].style.animationDelay = x + "s"
  box[i].style.animationDuration = x + 1 + "s"
  box[i].style.outline ="2px solid hsla("+Math.random()*360+", 100%, 50%, 1)"
  // box[i].style.background = "hsla("+Math.random()*360+", 100%, 50%, 1)"
  
}