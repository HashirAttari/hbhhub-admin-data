var denElem=null;
var consts=[],accuracy=30;

function addFract(c,d){
  denElem.innerHTML="";
  var cnst=document.createElement("const");
  cnst.innerHTML=c+" +";
  var fract=document.createElement("fract");
  var num=document.createElement("num");
  num.innerHTML="1";
  var den=document.createElement("den");
  den.innerHTML=d;
  
  fract.appendChild(num);
  fract.appendChild(den);
  denElem.appendChild(cnst);
  denElem.appendChild(fract);
  denElem=den;
}

function scale(){
  var probe=document.createElement("div");
  probe.id="probe";
  probe.innerHTML=denElem.innerHTML;
  denElem.appendChild(probe);
  for (var i=100;i<1500;i+=50){
    document.getElementById("fractcontainer").style="width:"+i+"px; margin-left:"+-i/2+"px";
    if (denElem.offsetWidth>probe.offsetWidth){
      denElem.removeChild(probe);
      break;
    }
  }
}

/*addFract(3,0);
addFract(7,0);
addFract(15,0);
addFract(1,0);
addFract(292,"...");
scale();*/

function approximate(input,acc){
  denElem=document.getElementById("fractcontainer");
  consts=[];
  for (var i=0;i<acc;i++){
    if (i!=0){input=roundExact(1/input);}
    consts.push(input-input%1);
    input=input%1;
    if (i<25){
      addFract(consts[i],"...");
    }
    if (input==0){
      denElem=denElem.parentElement.parentElement;
      denElem.innerHTML=consts[i];
      break;
    }
  }
  calcFract();
  scale();
}

function roundExact(inp){
  var mod=inp%1;
  if (mod<1e-4){return inp-mod;}
  else if(1-mod<1e-4){return inp+1-mod;}
  return inp;
}

function setNum(val,str){
  var inputs=document.getElementsByClassName("input1")[0].getElementsByClassName("input");
  inputs[0].value=val;
  inputs[1].value=str;
  approximate(val,accuracy);
}

function approx(elem){
  var input=elem.parentElement.getElementsByClassName("input")[0];
  if (!isNaN(input.value)){
    approximate(parseFloat(input.value),accuracy);
  }else{
    alert("ERROR");
  }
}

function approxJS(elem){
  var input=elem.parentElement.getElementsByClassName("input")[0];
  var script=document.createElement("script"),scriptElem=document.getElementById("custom_script");
  script.innerHTML="function eval(){return "+input.value+"}";
  scriptElem.appendChild(script);
  var val=undefined;
  try{val=eval();}catch(e){}
  if (!isNaN(val)){
    approximate(val,accuracy);
    document.getElementsByClassName("input1")[0].getElementsByClassName("input")[0].value=val;
  }else{
    alert("ERROR");
  }
  scriptElem.removeChild(script);
}

function calcFract(){
  var a=consts[consts.length-1],b=1;
  for (var i=consts.length-2;i>=0;i--){
    var tmpA=a;
    a=consts[i]*a+b;
    b=tmpA;
  }
  alert(a+"/"+b);
}