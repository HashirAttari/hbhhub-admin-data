# Playing with pentagons

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/GREmrze](https://codepen.io/amit_sheen/pen/GREmrze).

