# Windy Day (no images)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/OrmeEg](https://codepen.io/ig_design/pen/OrmeEg).

