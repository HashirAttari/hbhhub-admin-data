# Smooth Scrolling track of Plasma Pods!  With ZIM for CodePen Challenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/zimjs/pen/zYQwNKp](https://codepen.io/zimjs/pen/zYQwNKp).

Here we feature the ZIM List which has smooth scrolling as you drag and also on the scrollbar if damp is set.

ZIM provides JavaScript conveniences, components and controls for the Canvas. Code Creativity with ZIM!  See the CodePen Topic page for ZIM at https://codepen.io/topic/zim
