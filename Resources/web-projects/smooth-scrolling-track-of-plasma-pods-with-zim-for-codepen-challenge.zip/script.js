import zim from "https://zimjs.org/cdn/016/zim";

// REFERENCES for ZIM at https://zimjs.com
// see https://zimjs.com/intro.html for an intro example
// see https://zimjs.com/learn.html for video and code tutorials
// see https://zimjs.com/docs.html for documentation
// see https://codepen.io/topic/zim/ for ZIM on CodePen

// MidJourney for the orbs...


const frame = new Frame(FIT, 1024, 768, granite, dark, ready, "plasmapods.jpg", "https://zimjs.org/assets/");
function ready() {

  // given F (Frame), S (Stage), W (width), H (height)
  // put code here

  const pods = [];
  loop(30, i => {
    const pod = new Sprite("plasmapods.jpg", 10, 10).sca(1.5);
    pod.frame = i;
    pods.push(pod);
  });

  const list = new List({
    width: W * .4,
    height: H,
    list: pods,
    damp: .1, // adds smooth scrolling
    optimize: false,
    backdropColor: black,
    borderColor: -1,
    scrollBarColor: white,
    scrollBarAlpha: .5 }).
  center();
  list.scrollBar.size = 20;
  list.resize();

  F.madeWith({ box: darker }).sca(1.5).pos(30, 30, RIGHT, BOTTOM);

}

// Docs for items used
// https://zimjs.com/docs.html?item=Frame
// https://zimjs.com/docs.html?item=Sprite
// https://zimjs.com/docs.html?item=List
// https://zimjs.com/docs.html?item=loop
// https://zimjs.com/docs.html?item=pos
// https://zimjs.com/docs.html?item=sca
// https://zimjs.com/docs.html?item=center