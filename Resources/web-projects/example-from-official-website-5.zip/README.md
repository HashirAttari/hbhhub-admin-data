# Example from official website #5

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/dyprLgO](https://codepen.io/yuanchuan/pen/dyprLgO).

https://css-doodle.com