# Fractal Rain (work in progress)

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/MWOKvqv](https://codepen.io/franksLaboratory/pen/MWOKvqv).

