# No JavaScript - File Explorer

A Pen created on CodePen.io. Original URL: [https://codepen.io/sean_codes/pen/QqEVwE](https://codepen.io/sean_codes/pen/QqEVwE).

