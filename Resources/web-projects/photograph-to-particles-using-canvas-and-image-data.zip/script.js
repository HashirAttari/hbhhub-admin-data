function prepareCanvas(id, target, image, accuracy) {

  // Let's start off by creating a canvas element and appending it to the target.
  let canvas = document.createElement('canvas');
  let ctx = canvas.getContext("2d");

  canvas.id = id;

  canvas.style.display = 'none';
  canvas.style.border = "1px solid";

  // Append the dynamically generated canvas to the target element.
  let t = document.getElementsByClassName(target)[0];
  t.innerHTML = '';
  t.appendChild(canvas);

  // Now draw the specified image.
  let img = new Image();

  img.src = image + '?' + new Date().getTime();
  img.setAttribute('crossOrigin', '');

  // Wait for the image to load then draw it onto the canvas
  img.onload = function () {
    img.crossOrigin = "Anonymous";

    canvas.width = img.width;
    canvas.height = img.height;

    ctx.drawImage(img, 0, 0);

    // Create an empty pixels array
    pixels = [];

    img.crossOrigin = "Anonymous";

    // Now we need to get all the pixel data from the canvas.
    for (var y = 0; y < canvas.width; y += accuracy) {
      for (var x = 0; x < canvas.height; x += accuracy) {

        // Get current pixel
        let pixel = ctx.getImageData(x, y, 1, 1).data;

        if (pixel[0] > guiControls.Threshold) {

          // Get r,g,b values from pixel
          let r = pixel[0],
          g = pixel[1],
          b = pixel[2];

          // Create a pixel object and stroe that information to it
          let pixelData = {
            x: x,
            y: y,
            a: r };

          // Push this object to a pixel data array
          pixels.push(pixelData);
        }
      }
    }

    // So now we have an array filled with all the pixels in the canvas. We can now draw all of them onto a
    // fresh canvas and animate them as we please.

    // Let's start off by creating a canvas element and appending it to the target.
    let canvasEnd = document.createElement('canvas');
    let ctxEnd = canvasEnd.getContext("2d");

    canvasEnd.id = id + 'end';
    canvasEnd.width = img.width;
    canvasEnd.height = img.height;

    // Append the dynamically generated canvas to the target element.
    let t = document.getElementsByClassName(target)[0];
    t.appendChild(canvasEnd);
    timer = '';
    clearInterval(timer);
    timer = setInterval(function () {
      ctxEnd.clearRect(0, 0, canvasEnd.width, canvasEnd.height);
      pixels.forEach(function (pixel) {
        ctxEnd.beginPath();
        let x = pixel.x + Math.floor(Math.random() * guiControls.Movement) - guiControls.Movement / 2;
        let y = pixel.y + Math.floor(Math.random() * guiControls.Movement) - guiControls.Movement / 2;
        let radius = 1 + pixel.a / guiControls.ParticleSize;
        let shade = 34 + pixel.a * guiControls.Contrast;

        ctxEnd.arc(x, y, radius, 0, 2 * Math.PI, false);
        ctxEnd.fillStyle = `rgb(${shade}, ${shade}, ${shade})`;
        ctxEnd.fill();
      });
    }, 1);
  };
}



/* datGUI
--------------------------------------*/
const gui = new dat.GUI();
const guiControls = new function () {
  this.ParticleSize = 173;
  this.Movement = 1.5;
  this.Contrast = 0.82;
  this.accuracy = 4;
  this.Threshold = 20;
}();


gui.add(guiControls, 'ParticleSize', 50, 1200);
gui.add(guiControls, 'Movement', 1.5, 1000);
gui.add(guiControls, 'Contrast', 0.2, 2);

prepareCanvas('example', 'here', 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/gfdfdggddfg.jpg', guiControls.accuracy);