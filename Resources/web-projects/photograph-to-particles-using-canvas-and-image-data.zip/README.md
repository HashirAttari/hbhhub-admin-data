# Photograph to particles using Canvas and Image Data

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/VJQdXw](https://codepen.io/jcoulterdesign/pen/VJQdXw).

