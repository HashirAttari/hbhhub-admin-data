# Saint Valentine's Heart

A Pen created on CodePen.

Original URL: [https://codepen.io/Devin01/pen/QWyRmJ](https://codepen.io/Devin01/pen/QWyRmJ).

Original credits for the code go to http://www.script-tutorials.com/demos/234/ex5.html

I've just played slightly w/ the colours and added more hearts within the main one for a neater effect.

Go get your girl!

@alexia
