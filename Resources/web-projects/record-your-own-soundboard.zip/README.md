# ⌨️ 🔉Record Your Own Soundboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/dyomYQM](https://codepen.io/joshonweb/pen/dyomYQM).

Create your own custom soundboard by recording sounds, and playing them with your keyboard.

This started out as Wes Bos's js 30 drumkit:  https://www.youtube.com/watch?v=VuN8qwZoego

but I wanted it to make it my own.