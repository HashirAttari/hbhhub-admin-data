/*********
 * made by Matthias Hurrle (@atzedent)
 */

/** @type {HTMLCanvasElement} */
const canvas = window.canvas;
const gl = canvas.getContext("webgl2");
const dpr = Math.max(1, 0.5 * window.devicePixelRatio);

const vertexSource = `#version 300 es
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

in vec2 position;

void main(void) {
    gl_Position = vec4(position, 0., 1.);
}
`;
const fragmentSource = `#version 300 es
/*********
* made by Matthias Hurrle (@atzedent)
*/

#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

out vec4 fragColor;

uniform vec2 resolution;
uniform float time;

#define T time
#define S smoothstep
#define hue(a) (.24+.4*cos(10.3*(a)+vec3(0,83,21)))

float rnd(vec2 p) {
  return fract(
    sin(
      dot(
        p,
        vec2(12.342165, 78.39911)
      )
    )*78.57137
  );
}

float noise(vec2 p) {
  vec2 f = fract(p),
  i = floor(p);
  float
  a = rnd(i),
  b = rnd(i+vec2(1, 0)),
  c = rnd(i+vec2(0, 1)),
  d = rnd(i+vec2(1, 1));

  vec2 u = f*f*(3.-2.*f);

  return mix(a, b, u.x)+
  (c-a)*u.y*(1.-u.x)+
  (d-b)*u.y*u.x;
}

float fbm(vec2 p) {
  float f = .0;
  mat2  m = mat2(1.6, 1.2, -1.2, 1.6);

  f += .5000*noise(p); p *= m;
  f += .2500*noise(p); p *= m;
  f += .1250*noise(p); p *= m;
  f += .0625*noise(p); p *= m;

  return f;
}

float _fbm(vec2 p) {
  float f = .0,
  a = .5;
  vec2 s = vec2(100);
  mat2 m = mat2(cos(.5), -sin(.5), sin(.5), cos(.5));

  for (float i = .0; i < 6.; i++) {
    f += a*noise(p);
    p = p*m*2.+s;
    a *= .5;
  }

  return f;
}

void main() {
  vec2 uv = (
    gl_FragCoord.xy-.5*resolution
  )/min(resolution.x, resolution.y),
  st = uv;

  uv *= exp(-cos(T*.1)*.25)+2.25;
  uv.y += cos(T*.1)*.5;
  uv.x -= sin(T*.3)*.5;
  vec3 col = vec3(0);

  vec2 p = vec2(0);
  p.x = fbm(uv+vec2(0, 1));
  p.y = fbm(uv+vec2(1, 0));

  vec2 q = vec2(0);
  q.x = fbm(
    uv + p + vec2(1.5, 7.5) + 2.00 * T
  );
  q.y = fbm(
    uv + p + vec2(7.5, 2.5) + .125 * T
  );

  float f = fbm(uv + q);

  col += clamp(length(q.x), .0, 1.);
  col = (.9*f*f*f+.6*f*f+.3*f) * col;
  col = exp(-col*16.);
  col = abs(col);
  col = sqrt(col);
  col = exp(-col*4.);
  col = vec3(col.r+col.g+col.b)/3.;
  col = hue(col);
  float c = S(.0, 1.,col.r+col.g+col.b);
  col = vec3(c*c*c, c*c, 1.125*c)*c;
  col = sqrt(col);
  col = (abs(st.y) > .4 || abs(st.x) > .9)?vec3(0): col;

  fragColor = vec4(col, 1.0);
}
`;
let time;
let buffer;
let program;
let resolution;
let vertices = [];

function resize() {
	const { innerWidth: width, innerHeight: height } = window;

	canvas.width = width * dpr;
	canvas.height = height * dpr;

	gl.viewport(0, 0, width * dpr, height * dpr);
}

function compile(shader, source) {
	gl.shaderSource(shader, source);
	gl.compileShader(shader);

	if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
		console.error(gl.getShaderInfoLog(shader));
	}
}

function setup() {
	const vs = gl.createShader(gl.VERTEX_SHADER);
	const fs = gl.createShader(gl.FRAGMENT_SHADER);

	program = gl.createProgram();

	compile(vs, vertexSource);
	compile(fs, fragmentSource);

	gl.attachShader(program, vs);
	gl.attachShader(program, fs);
	gl.linkProgram(program);

	if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
		console.error(gl.getProgramInfoLog(program));
	}

	vertices = [-1.0, -1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0];

	buffer = gl.createBuffer();

	gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

	const position = gl.getAttribLocation(program, "position");

	gl.enableVertexAttribArray(position);
	gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);

	time = gl.getUniformLocation(program, "time");
	resolution = gl.getUniformLocation(program, "resolution");
}

function draw(now) {
	gl.clearColor(0, 0, 0, 1);
	gl.clear(gl.COLOR_BUFFER_BIT);

	gl.useProgram(program);
	gl.bindBuffer(gl.ARRAY_BUFFER, buffer);

	gl.uniform1f(time, now * 0.001);
	gl.uniform2f(resolution, canvas.width, canvas.height);
	gl.drawArrays(gl.TRIANGLES, 0, vertices.length * 0.5);
}

class Player {
	constructor(...urls) {
		this.idx = 0;
		this.urls = urls;
		this.audio = new Audio();
		this.audio.src = urls[this.idx];
		this.audio.crossOrigin = "anonymous";
		this.audio.loop = true;
		//this.audio.onended = () => this.next()

		this.initialized = false;
	}
	setup() {
		this.audioCtx = new window.AudioContext();
		this.audioSource = this.audioCtx.createMediaElementSource(this.audio);
		this.audioSource.connect(this.audioCtx.destination);

		this.initialized = true;
	}
	next() {
		this.idx = (this.idx + 1) % this.urls.length;
		this.audio.src = this.urls[this.idx];
		this.audio.play();
	}
	resume() {
		this.audio.play();
	}
	pause() {
		this.audio.pause();
	}
	toggle() {
		if (this.audio.paused) {
			this.audio.play();
		} else {
			this.audio.pause();
		}
	}
}

let player;

function loop(now) {
	draw(now);
	requestAnimationFrame(loop);
}

function init() {
	setup();
	resize();
	loop(0);
}

document.body.onload = init;
window.onresize = resize;
window.play.onclick = (e) => {
	if (!player) {
		player = new Player("https://maz25.de/artifacts/creek.mp3");

		player.setup();
	}

	e.target.closest("div").classList.remove("initial");
	player.toggle();
};