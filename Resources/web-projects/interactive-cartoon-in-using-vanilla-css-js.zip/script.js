(function () {
  document.onmousemove = handleMouseMove;
  function handleMouseMove(event) {
    const face = document.getElementsByClassName("face")[0];
    const forehead = document.getElementsByClassName("hair__forehead")[0];
    const irides = document.getElementsByClassName("iris");
    const vw = Math.max(
      document.documentElement.clientWidth,
      window.innerWidth || 0
    );
    const vh = Math.max(
      document.documentElement.clientHeight,
      window.innerHeight || 0
    );
    let eventDoc, doc, body;
    event = event || window.event;

    const iris_top = (event.pageY / vh) * 20;
    const iris_left = (event.pageX / vw) * 12;

    Array.prototype.map.call(irides, (x) => {
      x.style.top = iris_top + "px";
      x.style.left = iris_left + "px";
    });

    const face_skewX = (event.pageX / vw) * 3;
    const face_skewY = (event.pageY / vh) * 3;
    face.style.transform = `skew(${face_skewX}deg, ${face_skewY}deg)`;

    const forehead_rotate = (event.pageX / vw) * 5;
    forehead.style.transform = `rotate(${face_skewX}deg)`;
  }
})();