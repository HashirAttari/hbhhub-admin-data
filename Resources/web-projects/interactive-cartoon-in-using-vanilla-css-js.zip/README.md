# Interactive Cartoon in using Vanilla CSS/JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/AmruthPillai/pen/qBOVpqz](https://codepen.io/AmruthPillai/pen/qBOVpqz).

