////////////////////////////////////////////////////////////////////////////////
console.clear();

let canvas, canvasCtx;
let canvasSize = [0, 0], scale = 1;
let state;

requestAnimationFrame(main);

////////////////////////////////////////////////////////////////////////////////
function main(){
	canvas = document.createElement('canvas');
	document.body.appendChild(canvas);
	document.body.style.margin = '0';
	canvas.style.display = 'block';

	canvasCtx = canvas.getContext('2d');

	checkResizeAndInit();
	reset();
	
	canvas.addEventListener('mousemove', (e) => {
		state.pointer.pos[0] = e.offsetX;
		state.pointer.pos[1] = e.offsetY;
	});
	
	canvas.addEventListener('click', reset);
	
	window.addEventListener('resize', reset);

	requestAnimationFrame(mainLoop);

	function mainLoop(){
		tick();
		requestAnimationFrame(mainLoop);
	}
}

function reset(){
	state = {
		time: 0,
		timeDelta: 1 / 60,
		pointer: {pos: [0, 0]},
		hearts: [],
	};
	
	const min = Math.min(canvasSize[0], canvasSize[1]);
	const step = min / 13;
	
	const center = [
		canvasSize[0] / 2,
		canvasSize[1] / 2
	];
	drawHeart(
		center,
		min,
		Math.PI * state.time * 0,
		null, null,
	);
	
	state.hearts.length = 0;
	for(let y = 0; y < canvasSize[1]; y += step){
		for(let x = 0; x < canvasSize[0]; x += step){
			const isInside = canvasCtx.isPointInPath(x, y);
			if(!isInside) continue;
			const dist = Math.hypot(x - center[0], y - center[1]);
			state.hearts.push({
				pos: [
					x + step * Math.random() * 0.25,
					y + step * Math.random() * 0.25,
				],
				w: step * (0.25 + 0.75 * (1 - (dist / min))),
				a: (Math.random() - 0.5) * Math.PI * 0.5,
				//timeOffset: Math.random(),
				timeOffset: (1 - (dist / min)) * 2,
				timeScale: 1,//0.9 + Math.random() * 0.2,
				color1: '#ff0000',
				color2: '#ff00ff',
			});
		}
	}
}

function tick(){
	checkResizeAndInit();
	canvasCtx.fillStyle = `rgba(0, 0, 0, ${1})`;
	canvasCtx.fillRect(0, 0, canvasSize[0], canvasSize[1]);

	doIt();

	state.time += state.timeDelta;

}

function checkResizeAndInit(){
	if(
		window.innerWidth === canvasSize[0] &&
		window.innerHeight === canvasSize[1]
	) return;
	canvasSize[0] = canvas.width = window.innerWidth;
	canvasSize[1] = canvas.height = window.innerHeight;
}

function doIt(){
	const {timeDelta} = state;

	for(const heart of state.hearts){
		const time = state.time * heart.timeScale + heart.timeOffset;
		const s = ((Math.sin(time * Math.PI) + 1) / 2) ** 0.5 * 0.5 + 0.5;
		drawHeart(
			heart.pos,
			heart.w * s,
			heart.a,
			`color-mix(in hsl, ${heart.color1}, ${heart.color2} ${100 * Math.abs(((time / 3) % 2) - 1)}%)`,
			//'color-mix(in hsl, #00ff00, #ff0000 75%)',
		);
	}

	if(0){
		const s = ((Math.sin(state.time * Math.PI) + 1) / 2) ** 0.5 * 0.5 + 0.5;
		drawHeart(
			[canvasSize[0] / 2, canvasSize[1] / 2],
			256 * s,
			Math.PI * state.time * 0,
			'color-mix(in hsl, #00ff00, #ff0000 50%)',
			//'color-mix(in hsl, #00ff00, #ff0000 75%)',
		);
	}
	// drawSkull(
	// 	[canvasSize[0] / 2, canvasSize[1] / 2],
	// 	256,// * s,
	// 	Math.PI * state.time * 0,
	// 	'color-mix(in hsl, #00ff00, #ff0000 50%)',
	// 	//'color-mix(in hsl, #00ff00, #ff0000 75%)',
	// );
	
	// const isInside = canvasCtx.isPointInPath(state.pointer.pos[0], state.pointer.pos[1]);
	// canvasCtx.fillStyle = isInside ? '#ff0000' : '#7f7f7f';
	// canvasCtx.fillRect(
	// 	state.pointer.pos[0], state.pointer.pos[1],
	// 	8, 8,
	// );
}

function drawHeart(pos, w, a, color, color2){
	const s = w / 92;
	canvasCtx.save();
	
	canvasCtx.translate(pos[0], pos[1]);
	canvasCtx.rotate(a);
	
	// canvasCtx.strokeStyle = '#7f7f7f';
	// canvasCtx.beginPath();
	// canvasCtx.arc(
	// 	0, 0,
	// 	w * 0.5,
	// 	0, Math.PI * 2,
	// );
	// canvasCtx.stroke();
	
	canvasCtx.translate(0, 12 * s);
	
	canvasCtx.beginPath();
	canvasCtx.ellipse(
		-14 * s, -16 * s,
		25 * s, 32 * s,
		Math.PI * -0.25,
		Math.PI * 1, Math.PI * 0,
	);
	canvasCtx.ellipse(
		+14 * s, -16 * s,
		25 * s, 32 * s,
		Math.PI * +0.25,
		Math.PI * 1, Math.PI * 0,
	);
	canvasCtx.quadraticCurveTo(
		+14 * s, 20 * s,
		0 * s, 32 * s,
	);
	canvasCtx.closePath();
	if(color){
		canvasCtx.strokeStyle = color;
		canvasCtx.stroke();
	}
	if(color2){
		canvasCtx.fillStyle = color2;
		canvasCtx.fill();
	}
	
	canvasCtx.restore();
}

function drawSkull(pos, w, a, color, color2){
	const s = w / 92;
	canvasCtx.save();
	
	canvasCtx.translate(pos[0], pos[1]);
	canvasCtx.rotate(a);
	
	canvasCtx.strokeStyle = '#7f7f7f';
	canvasCtx.beginPath();
	canvasCtx.arc(
		0, 0,
		w * 0.5,
		0, Math.PI * 2,
	);
	canvasCtx.stroke();
	
	canvasCtx.translate(0, 12 * s);
	
	canvasCtx.beginPath();
	canvasCtx.ellipse(
		0 * s, -20 * s,
		44 * s, 32 * s,
		Math.PI * 0,
		Math.PI * 0.70, Math.PI * 0.3,
	);
	canvasCtx.lineTo(+20 * s, 28 * s);
	
	canvasCtx.lineTo(+20 * s, 0 * s);
	canvasCtx.arc(
		0 * s, -10 * s,
		10 * s,
		Math.PI * 0.4, Math.PI * -1.4,
		true,
	);
	
	canvasCtx.lineTo(-20 * s, 28 * s);
	// canvasCtx.quadraticCurveTo(
	// 	+14 * s, 20 * s,
	// 	0 * s, 32 * s,
	// );
	canvasCtx.closePath();
	if(color){
		canvasCtx.strokeStyle = color;
		canvasCtx.stroke();
	}
	if(color2){
		canvasCtx.fillStyle = color2;
		canvasCtx.fill();
	}
	
	canvasCtx.restore();
}

function rotateByVector(out, a, v, origin, s){
	const rx = v[0];
	const ry = v[1];
	const x = a[0] - origin[0];
	const y = a[1] - origin[1];
	out[0] = origin[0] + (x * rx - y * ry) * s;
	out[1] = origin[1] + (y * rx + x * ry) * s;
	return out;
}