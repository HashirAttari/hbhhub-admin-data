# AterCalculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aterbonus/pen/YWRNBg](https://codepen.io/Aterbonus/pen/YWRNBg).

A Calculator that uses the Reverse Polish Notation and the Shunting-yard Algorithm to solve problems.