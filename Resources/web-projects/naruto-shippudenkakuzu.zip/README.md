# Naruto Shippuden - Kakuzu

A Pen created on CodePen.io. Original URL: [https://codepen.io/tdullah/pen/VrvMqL](https://codepen.io/tdullah/pen/VrvMqL).

Kakuzu was an S-rank missing-nin from Takigakure and a member of Akatsuki who was partnered with Hidan. Kisame Hoshigaki jokingly referred to them as the Zombie Combo due to the fact that, in a sense, they could not die. 