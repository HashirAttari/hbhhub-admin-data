let p = document.querySelector('p'),
		p_width = p.getBoundingClientRect().width

function addBubbles() {
	for(var i=0;i<p_width/3;i++) {
		let b = document.createElement('div')
		b.className = 'bubble'
		b.style.width = Math.random() < .5 ? '5px' : '3px'
		b.style.left = Math.random() * 97 + '%'
		b.style.animationDelay = 4 * Math.random() + 's'
		p.appendChild(b)
	}	
}

addBubbles()