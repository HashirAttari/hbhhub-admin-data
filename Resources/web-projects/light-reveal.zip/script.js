const lamp = document.querySelector("#lamp");
const html = document.querySelector('html')

lamp.addEventListener("click", function () {
	if (!html.classList.contains('light_on')) {		
		document.documentElement.style.setProperty("--color-light", "rgba(255,248,220,.75)");
    document.querySelector('html').classList.add('light_on')
	} else {
		document.documentElement.style.setProperty("--color-light", "");
    document.querySelector('html').classList.remove('light_on')
	}
});