const slider = document.querySelector("#slider");
const photoWrapper = document.querySelector("#photo-wrapper")
slider.oninput = function() {
   photoWrapper.style=`--rotate: ${slider.value}deg`;
};