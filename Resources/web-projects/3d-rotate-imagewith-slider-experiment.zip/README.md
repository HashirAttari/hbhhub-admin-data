# 3D rotate image - with slider (experiment)

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/wvYQGRg](https://codepen.io/cbolson/pen/wvYQGRg).

