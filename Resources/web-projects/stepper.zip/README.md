# Stepper 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/dyKoOjX](https://codepen.io/havardob/pen/dyKoOjX).

A simple, stylistic stepper component using grid.