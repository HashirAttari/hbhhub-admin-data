// Another strange CSS spinner thing

// by Hakim El Hattab | @hakimel