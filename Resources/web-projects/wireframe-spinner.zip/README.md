# Wireframe Spinner

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/nYxEXW](https://codepen.io/hakimel/pen/nYxEXW).

A wireframy spinner animation.