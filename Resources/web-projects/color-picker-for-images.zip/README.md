# Color Picker For Images

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/zYbLMV](https://codepen.io/leenalavanya/pen/zYbLMV).

A Color Picker To Get The Value ( in RGB And Hex ) of Every Pixel On Any One Of Your Images.