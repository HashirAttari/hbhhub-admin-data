# Smooth Neon Toggle (v3)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/YzgdvBV](https://codepen.io/alvaromontoro/pen/YzgdvBV).

Inspired by Josh Dillon's Silky Smooth checkboxes: https://codepen.io/jdillon/pen/PoLBVmV