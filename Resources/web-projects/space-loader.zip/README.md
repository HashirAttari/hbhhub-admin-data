# Space Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/OwQyag](https://codepen.io/chrisgannon/pen/OwQyag).

It's a loader. In space.