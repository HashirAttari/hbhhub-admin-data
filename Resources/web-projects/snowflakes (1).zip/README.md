# Snowflakes

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/GoJvpw](https://codepen.io/leenalavanya/pen/GoJvpw).

Forked from [Valentin Radulescu](http://codepen.io/valentin/)'s Pen [Winter is Coming...](http://codepen.io/valentin/pen/tLiyc/).

Forked from [Valentin Radulescu](http://codepen.io/valentin/)'s Pen [Winter is Coming...](http://codepen.io/valentin/pen/tLiyc/).