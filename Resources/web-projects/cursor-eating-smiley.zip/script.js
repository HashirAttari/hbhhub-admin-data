/* Javascript is used for eye-tracking and virtual cursor on touch devices */

const cursorElem = document.querySelector('#virtual-mouse-cursor');

const wakeupAreaElem = document.querySelector('#wakeup-area');
const mouthCatchAreaElem = document.querySelector('#mouth__catch-area');
const smileyElem = document.querySelector('#smiley');

const leftEyeElem = document.querySelector('.left.eye');
const rightEyeElem = document.querySelector('.right.eye');
const leftPupilElem = document.querySelector('.left.eye .pupil');
const rightPupilElem = document.querySelector('.right.eye .pupil');

let cursorMoved = false;
let cursorEaten = false;
let smileySick = false;
let wakeupAreaHit = false;
let mouthCatchAreaHit = false;
let smileyAreaHit = false;

var leftEyeArea, leftPupilArea, rightEyeArea, rightPupilArea;
var wakeupArea, mouthCatchArea, smileyArea;

function updateCursor(x, y) {
    cursorElem.style.transform = `translate(${x}px, ${y}px)`;
}

function hideCursor(e) {
    cursorElem.style.display = 'none';
}

function showCursor(e) {
    cursorElem.style.display = '';
}

function calcEyePos(eyeArea, pupilArea, cursorX, cursorY) {
    let eyeMx = eyeArea.x + (eyeArea.w / 2);
    let eyeMy = eyeArea.y + (eyeArea.h / 2);
    
    let dx = cursorX - eyeMx;
    let dy = cursorY - eyeMy;
    
    let R = Math.sqrt(dx * dx + dy * dy);
    
    let maxRx = (eyeArea.w - pupilArea.w) / 2;
    let maxRy = (eyeArea.h - pupilArea.h) / 2;
    let maxR = Math.min(maxRx, maxRy);
    
    let offsetX = (R < maxR) ? dx : (maxR / R) * dx;
    let offsetY = (R < maxR) ? dy : (maxR / R) * dy;
    
    return {offsetX, offsetY};
}

function updateEyeTracking(cursorX, cursorY) {    
    let leftEyePos = calcEyePos(leftEyeArea, leftPupilArea, cursorX, cursorY);
    leftPupilElem.style.transform = `translate(${leftEyePos.offsetX}px, ${leftEyePos.offsetY}px)`;

    let rightEyePos = calcEyePos(rightEyeArea, rightPupilArea, cursorX, cursorY);
    rightPupilElem.style.transform = `translate(${rightEyePos.offsetX}px, ${rightEyePos.offsetY}px)`;
}

function resetEyeTracking() {
    leftPupilElem.style.transform = '';
    leftPupilElem.style.transition = 'transform 0.5s linear';
    
    rightPupilElem.style.transform = '';
    rightPupilElem.style.transition = 'transform 0.5s linear';
}

function onMouseMove(evt) {
    const e = (evt.touches && evt.touches[0]) || evt;    
    x = e.clientX;
    y = e.clientY;
    updateCursor(x, y);
    
    if(!cursorMoved) {
        cursorMoved = true;
        showCursor(e);
    }
    
    if(cursorEaten) {
        hideCursor(e);
    }
    else {
        if(wakeupAreaHit)
            updateEyeTracking(x, y);
        
        hitTest(x, y);
    }
}
window.addEventListener('mousemove', onMouseMove);
window.addEventListener('touchmove', function(e) {
    e.preventDefault();
    e.stopPropagation();
    onMouseMove(e);
}, {passive: false});

document.body.addEventListener('mouseenter', showCursor);
document.body.addEventListener('mouseleave', hideCursor);

function isMobileDevice() {
    return (typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1);
}

function getPosSize(element) {
    let xPosition = 0;
    let yPosition = 0;
    
    const elemRect = element.getBoundingClientRect();

    while(element)
    {
        xPosition += (element.offsetLeft - element.scrollLeft + element.clientLeft);
        yPosition += (element.offsetTop - element.scrollTop + element.clientTop);
        element = element.offsetParent;
    }
    return { x: xPosition, y: yPosition, w: elemRect.width, h: elemRect.height };
}

function updateHover(elem, hover) {
    const HOVER_CLASSNAME = 'hover';
    if(hover) {
        if(!elem.classList.contains(HOVER_CLASSNAME)) {
            elem.classList.add(HOVER_CLASSNAME);
        }
    }
    else {
        if(elem.classList.contains(HOVER_CLASSNAME))
        elem.classList.remove(HOVER_CLASSNAME);
    }
}

function hitTestArea(area, mouseX, mouseY) {
    if(mouseX >= area.x &&
       mouseX < (area.x + area.w) &&
       mouseY >= area.y &&
       mouseY < (area.y + area.h)
      ) {
        return true;
    }
    return false;
}

function hitTest(mouseX, mouseY) {
    wakeupAreaHit = hitTestArea(wakeupArea, mouseX, mouseY);
    mouthCatchAreaHit = hitTestArea(mouthCatchArea, mouseX, mouseY);
    smileyAreaHit = hitTestArea(smileyArea, mouseX, mouseY);
    
    updateHover(wakeupAreaElem, wakeupAreaHit);
    
    if(!smileySick) {
        updateHover(mouthCatchAreaElem, mouthCatchAreaHit);
        updateHover(smileyElem, smileyAreaHit);

        if(mouthCatchAreaHit) {
            cursorEaten = true;
            hideCursor();
            resetEyeTracking();
        }
    }
}

function updateElemPos() {
    leftEyeArea = getPosSize(leftEyeElem);
    leftPupilArea = getPosSize(leftPupilElem);

    rightEyeArea = getPosSize(rightEyeElem);
    rightPupilArea = getPosSize(rightPupilElem);

    wakeupArea = getPosSize(wakeupAreaElem);
    mouthCatchArea = getPosSize(mouthCatchAreaElem);
    smileyArea = getPosSize(smileyElem);
    
    //setDebugRect('0', wakeupArea.x, wakeupArea.y, wakeupArea.w, wakeupArea.h, '#00f');
    //setDebugRect('1', smileyArea.x, smileyArea.y, smileyArea.w, smileyArea.h, '#f00');
}

function onResize(e) {
    updateElemPos();
}

function initAnimListener() {
    const mouthElem = document.querySelector('#mouth');
    mouthElem.addEventListener('animationend', (e) => {
        if(cursorEaten) {
            setTimeout(() => {
                if(!smileyElem.classList.contains('sick')) {
                    smileyElem.classList.add('sick');
                    smileySick = true;
                    
                    if(smileyElem.classList.contains('hover')) {
                        smileyElem.classList.remove('hover');
                    }

                    if(mouthCatchAreaElem.classList.contains('hover')) {
                        mouthCatchAreaElem.classList.remove('hover');
                    }
                }
                else {
                    let animName = e.animationName;
                    if(animName === 'mouth-open') {
                        showCursor();
                        cursorEaten = false;
                        let mx = mouthCatchArea.x + (mouthCatchArea.w / 2);
                        let my = mouthCatchArea.y + (mouthCatchArea.h / 2);
                        cursorElem.style.transition = 'transform 0.5s ease-in';
                        cursorElem.style.transform = `translate(${mx}px, ${my}px)` + ' scale(0.1)';
                        setTimeout(() => { cursorElem.style.transform = `translate(${mx}px, ${my}px)` + ' scale(3)'; }, 100);
                        setTimeout(() => { cursorElem.style.transform = `translate(${mx}px, ${my}px)` + ' scale(1)'; }, 600);
                        setTimeout(() => { cursorElem.style.transition = ''; }, 1000);
                        setTimeout(() => { smileyElem.classList.remove('sick'); }, 2000);
                        setTimeout(() => { smileySick = false; }, 30000);
                    }
                }
            },1500);
        }
    })
}

function init() {
    const w = document.body.clientWidth;
    const h = document.body.clientHeight;
    
    //createDebugRect('0', 0, 0, 0, 0, '#00f');
    //createDebugRect('1', 0, 0, 0, 0, '#f00');
    //createDebugRect('2', 0, 0, 0, 0, '#f00');
    
    updateElemPos();
    updateCursor(w / 2, h / 10);
    if(!cursorMoved && !isMobileDevice())
        hideCursor();
    
    initAnimListener();
}
document.addEventListener('DOMContentLoaded', init);

window.addEventListener('resize', onResize);

function createDebugRect(e, x, y, w, h, c) {
    let elem = document.createElement('div');
    elem.classList.add('debugRect--' + e);
    
    elem.style.position = 'absolute';
    elem.style.left = x + 'px';
    elem.style.top = y + 'px';
    elem.style.width = w + 'px';
    elem.style.height = h + 'px';
    
    elem.style.border = '1px solid ' + c;
    
    document.body.appendChild(elem);
}

function setDebugRect(e, x, y, w, h, c) {
    let elem = document.querySelector('div.debugRect--' + e);    
    elem.style.left = x + 'px';
    elem.style.top = y + 'px';
    elem.style.width = w + 'px';
    elem.style.height = h + 'px';
    
    elem.style.borderColor = c;
}