# Cursor eating smiley

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/OJNzmKO](https://codepen.io/agalliat/pen/OJNzmKO).

