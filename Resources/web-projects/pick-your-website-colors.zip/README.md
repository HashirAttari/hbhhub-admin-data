# Pick Your Website Colors

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/bxLrjV](https://codepen.io/markmead/pen/bxLrjV).

Inputs don't work on Safari but you can still type in the color changes.