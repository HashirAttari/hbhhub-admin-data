const controlsInput = document.querySelectorAll('.controls input')
function inputUpdate() {
	document.documentElement.style.setProperty(`--${this.name}`, this.value);
} 
controlsInput.forEach(input => input.addEventListener('change', inputUpdate));