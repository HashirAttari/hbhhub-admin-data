var tl = new TimelineMax({
	repeat: -1,
	yoyo: true,
	repeatDelay: .5
});

tl.staggerTo(".wrapper > *", 0.5, {
	opacity: 0,
	cycle: {
		x: [-100, 100],
		rotation: [10, -10]
	}
}, 0.1);