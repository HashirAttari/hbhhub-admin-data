# Greensock zipper animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/Katrine-Marie/pen/aNZVXZ](https://codepen.io/Katrine-Marie/pen/aNZVXZ).

A simple GSAP animation based on an example shown in this video: https://youtu.be/0HhjSPVuRHA 