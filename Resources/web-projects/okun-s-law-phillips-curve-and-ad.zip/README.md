# Okun's Law, Phillips Curve and AD

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/xxbQvwx](https://codepen.io/leenalavanya/pen/xxbQvwx).

