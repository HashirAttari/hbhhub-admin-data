var gy = 3,
    gy_natural = 3,
    u = 5,
    u_natural = 5,
    p = 4,
    gm = 8,
    okun_beta = 0.4,
    phillip_coefficient = 1;

for (var i = 0; i < 30; i++) {
    gy =
        (gm -
            p +
            phillip_coefficient * (u + okun_beta * gy_natural - u_natural)) /
        (1 + phillip_coefficient * okun_beta);
    u = u - okun_beta * (gy - gy_natural);
    p = p - phillip_coefficient * (u - u_natural);

    document.body.innerHTML +=
        "<div>" +
        "g<sub>Y<sub>" +
        i +
        "</sub></sub> = " +
        Math.round(gy * 100) / 100 +
        "<br/>" +
        "u<sub>" +
        i +
        "</sub> = " +
        Math.round(u * 100) / 100 +
        "<br/>" +
        "π<sub>" +
        i +
        "</sub> = " +
        Math.round(p * 100) / 100 +
        "</div>";
}