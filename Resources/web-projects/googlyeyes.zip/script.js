$(document).ready(function(){
  
 $("body").mousemove(function (event) {
        var objLeft = $("body").offset().left;
        var objTop = $("body").offset().top;

        var objCenterX = objLeft + $("body").width() / 2;
        var objCenterY = objTop + $("body").height() / 2;
   
   var windowHalfWidth = $('body').width()/2;
   var windowHalfHeight = $('body').height()/2;
   
   var pupilleLeft = 25+(event.pageX - objCenterX)/windowHalfWidth*50;
   var pupilleTop = 25+(event.pageY - objCenterY)/windowHalfHeight*50;

   TweenMax.to(
     $('.pupille'),
     0.2,
     {'marginLeft':pupilleLeft+"px"}
   );
   TweenMax.to(
     $('.pupille'),
     0.2,
     {'marginTop':pupilleTop+"px"}
   );
   
        $("#results").text("Left:" + pupilleLeft + "px, Top:" + pupilleTop+"px");
    });

});