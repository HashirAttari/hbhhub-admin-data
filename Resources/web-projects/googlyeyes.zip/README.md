# GooglyEyes

A Pen created on CodePen.io. Original URL: [https://codepen.io/AlaricBaraou/pen/pRzRoX](https://codepen.io/AlaricBaraou/pen/pRzRoX).

Following mouse movement with jQuery and animating eyes direction with Greensock.
Basic stuff could be way improved.
Like the eye design thought.