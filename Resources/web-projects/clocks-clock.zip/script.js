let digit = document.getElementsByClassName('digit');

function setTime() {
    time_numbers = ((new Date()).toTimeString().substr(0,8)).split(':').join('');

    for (let i = 0; i < time_numbers.length; i++) {
        digit[i].className = 'digit digit_' + time_numbers.charAt(i);
    }
};

setTime();
setInterval(setTime, 1000);