var vh = window.innerHeight;

var body = document.body;
var block = document.querySelector('.block');
var parallax = document.querySelector('.parallax');

var str = document.querySelector('.wavy').innerHTML;

if (Math.abs(str.length % 2) == 1) {str += " "}

var out = '<a>';


for (let i = 0; i < str.length/2; i++) {
  
  let scrollOffset = (vh * (i + 1)) / (str.length/2);
  
  out += '<span data-'+ scrollOffset +'="top: 0vh;opacity:0;" data-0="top: -10vh;opacity:1;">'+str[i]+'</span>';
}
out += '</a><a data-250p="top: -10vh;opacity: 0" data-200p="top: 0vh;opacity: 1">';

let n = str.length/2;
for (let i = str.length/2; i < str.length; i++) {
  
  let scrollOffset = (vh * n) / (str.length/2);
  
  out += '<span data-'+ scrollOffset +'="top: 0vh;opacity:1;" data-0="top: -10vh;opacity:0;">'+str[i]+'</span>';
  n--;
}
out += '</a>';

document.querySelector('.wavy').innerHTML = out;


var str = document.querySelector('.word').innerHTML;

var out = '';

for (let i = 0; i < str.length; i++) {
  
  let scrollOffset = ((vh * (i + 1)) / str.length) + vh*4.5;
  
  out += '<span data-'+ scrollOffset +'="opacity:0;" data-450p="opacity:1;">'+str[i]+'</span>';
}

document.querySelector('.word').innerHTML = out;


var str = document.querySelector('.parallax .sentence').innerHTML;

var out = '';

for (let i = 0; i < str.length; i++) {
  
  let scrollOffset = (vh * (i + 1)) / str.length  + vh*5.5;
  
  out += '<span data-'+ scrollOffset +'="top: -10vh;opacity:1;" data-550p="top: -20vh;opacity:0;">'+str[i]+'</span>';
}

document.querySelector('.parallax .sentence').innerHTML = out;


var s = skrollr.init();

window.addEventListener('scroll', function(e) {
  
  // Window scroll position
  var scrolled = window.scrollY || window.pageYOffset;
  
  if (scrolled >= vh*4) {
    
    body.classList.remove('color');
    body.classList.add('black');
    
  } else if (scrolled >= vh) {
    
    body.classList.add('color');
    body.classList.remove('black');
    
  } else {
    
    body.classList.remove('color');
    body.classList.remove('black');
    
  }
  
  if (scrolled >= vh*7.5) {
    
    body.classList.remove('color');
    body.classList.remove('black');
    
    s.setScrollTop(1, true);
    
  }
  if (scrolled <= 0) {
    
    s.setScrollTop((vh*7.5 - 1), true);
    
  }
  
})