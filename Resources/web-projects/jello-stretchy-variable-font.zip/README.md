# Jello Stretchy Variable Font

A Pen created on CodePen.io. Original URL: [https://codepen.io/petebarr/pen/LYzBoeg](https://codepen.io/petebarr/pen/LYzBoeg).

A satisfying stretchy elastic text effect using GSAP SplitText plugin with a variable font. 

https://www.gt-flexa.com/

Jello/Jelly? Whatever  😉