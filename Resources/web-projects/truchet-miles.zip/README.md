# Truchet Miles

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/ZVEXJR](https://codepen.io/ykadosh/pen/ZVEXJR).

A generative SVG art made using 4 types of tiles, randomly rotated to create infinitely many patterns.