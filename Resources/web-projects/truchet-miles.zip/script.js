// The tile pattern below is created using a tiny 
// library called Truchet.js (of which i'm the author)
// https://github.com/ykadosh/truchet.js
const TILE_SIZE = 150;
const LAYERS = 2;
const ROAD_WIDTH = TILE_SIZE / 5;
const { innerWidth: SCREEN_WIDTH, innerHeight: SCREEN_HEIGHT } = window;

const createNode = (n, v) => {
  n = document.createElementNS("http://www.w3.org/2000/svg", n);
  Object.keys(v).forEach(p => {
    n.setAttributeNS(null, p, v[p]);
  });
  return n;
};

const path = (_class, d) => () => createNode('path', { class: _class, d });
const circle = (_class, cx, cy, r) => () => createNode('circle', { class: _class, cx, cy, r });
const layer1 = new Truchet(document.getElementById('layer1'), TILE_SIZE, TILE_SIZE);
const layer2 = new Truchet(document.getElementById('layer2'), TILE_SIZE, TILE_SIZE);

// 4 way with crosswalks
const TILE1 = [
path('road', `M 0,${TILE_SIZE / 2} H ${TILE_SIZE} M ${TILE_SIZE / 2},0 V ${TILE_SIZE}`),
path('road', `M 0,${TILE_SIZE / 2} H ${TILE_SIZE} M ${TILE_SIZE / 2},0 V ${TILE_SIZE}`),
path('lines', `M 0,${TILE_SIZE / 2} H ${TILE_SIZE} M ${TILE_SIZE / 2},0 V ${TILE_SIZE}`),
path('shoulders', `M 0,${ROAD_WIDTH * 2.1} H ${ROAD_WIDTH * 2.1} V ${ROAD_WIDTH * 2},0 M 0,${ROAD_WIDTH * 2.9} H ${ROAD_WIDTH * 2.1} V ${TILE_SIZE} M ${ROAD_WIDTH * 2.9},${TILE_SIZE} V ${ROAD_WIDTH * 2.9} H ${TILE_SIZE} M ${TILE_SIZE},${ROAD_WIDTH * 2.1} H ${ROAD_WIDTH * 2.9} V 0`),
path('crosswalk', `M ${ROAD_WIDTH * 2},${ROAD_WIDTH * 1.5} H ${ROAD_WIDTH * 3}  M ${ROAD_WIDTH * 2},${ROAD_WIDTH * 3.5} H ${ROAD_WIDTH * 3} `)];


// Curved roads
const TILE2 = [
path('road', `M 0,${TILE_SIZE / 2} Q ${TILE_SIZE / 2},${TILE_SIZE / 2} ${TILE_SIZE / 2},0 M ${TILE_SIZE / 2},${TILE_SIZE} Q ${TILE_SIZE / 2},${TILE_SIZE / 2} ${TILE_SIZE},${TILE_SIZE / 2}`),
path('lines', `M 0,${TILE_SIZE / 2} Q ${TILE_SIZE / 2},${TILE_SIZE / 2} ${TILE_SIZE / 2},0 M ${TILE_SIZE / 2},${TILE_SIZE} Q ${TILE_SIZE / 2},${TILE_SIZE / 2} ${TILE_SIZE},${TILE_SIZE / 2}`),
path('shoulders', `M 0,${ROAD_WIDTH * 2.1} Q ${ROAD_WIDTH * 2.12},${ROAD_WIDTH * 2.12} ${ROAD_WIDTH * 2.1},0 M 0,${ROAD_WIDTH * 2.9} Q ${ROAD_WIDTH * 2.92},${ROAD_WIDTH * 2.92} ${ROAD_WIDTH * 2.9},0 M ${ROAD_WIDTH * 2.9},${TILE_SIZE} Q ${ROAD_WIDTH * 2.92},${ROAD_WIDTH * 2.92} ${TILE_SIZE},${ROAD_WIDTH * 2.9} M ${ROAD_WIDTH * 2.1},${TILE_SIZE} Q ${ROAD_WIDTH * 2.12},${ROAD_WIDTH * 2.12} ${TILE_SIZE},${ROAD_WIDTH * 2.1}`)];


// 2 way over 2 way
const TILE3 = [
path('road', `M 0,${TILE_SIZE / 2} H ${TILE_SIZE}`),
path('lines', `M 0,${TILE_SIZE / 2} H ${TILE_SIZE}`),
path('shoulders', `M 0,${ROAD_WIDTH * 2.1} H ${TILE_SIZE} M 0,${ROAD_WIDTH * 2.9} H ${TILE_SIZE}`),
path('shadow', `M ${ROAD_WIDTH * 1.7},${ROAD_WIDTH * 2} H ${ROAD_WIDTH * 3.3} V ${ROAD_WIDTH * 3} H ${ROAD_WIDTH * 1.7} Z`),
path('road', `M ${TILE_SIZE / 2},0 V ${TILE_SIZE}`),
path('lines', `M ${TILE_SIZE / 2},0 V ${TILE_SIZE}`),
path('shoulders', `M ${ROAD_WIDTH * 2.1},0 V ${TILE_SIZE} M ${ROAD_WIDTH * 2.9},0 V ${TILE_SIZE}`)];


// 4 way roundabout
const TILE4 = [
circle('road', TILE_SIZE / 2, TILE_SIZE / 2, TILE_SIZE / 5),
circle('shoulders', TILE_SIZE / 2, TILE_SIZE / 2, TILE_SIZE / 3.5),
path('road', `M ${TILE_SIZE / 2},0 V ${TILE_SIZE} M 0,${TILE_SIZE / 2} H ${TILE_SIZE}`),
path('shoulders', `M ${ROAD_WIDTH * 2.1},0 V ${TILE_SIZE} M ${ROAD_WIDTH * 2.9},0 V ${TILE_SIZE}`),
path('shoulders', `M 0,${ROAD_WIDTH * 2.1} H ${TILE_SIZE} M 0,${ROAD_WIDTH * 2.9} H ${TILE_SIZE}`),
circle('road', TILE_SIZE / 2, TILE_SIZE / 2, TILE_SIZE / 5.7),
circle('grass', TILE_SIZE / 2, TILE_SIZE / 2, TILE_SIZE / 8),
circle('lines', TILE_SIZE / 2, TILE_SIZE / 2, TILE_SIZE / 4.5),
circle('shoulders', TILE_SIZE / 2, TILE_SIZE / 2, TILE_SIZE / 7),
path('lines', `M 0,${TILE_SIZE / 2} H ${TILE_SIZE / 3.7} M ${TILE_SIZE / 1.4},${TILE_SIZE / 2} H ${TILE_SIZE} M ${TILE_SIZE / 2},0 V ${TILE_SIZE / 3.7} M ${TILE_SIZE / 2},${TILE_SIZE / 1.4} V ${TILE_SIZE}`),
path('crosswalk', `M ${ROAD_WIDTH * 2},${ROAD_WIDTH * 0.7} H ${ROAD_WIDTH * 3}  M ${ROAD_WIDTH * 2},${ROAD_WIDTH * 4.3} H ${ROAD_WIDTH * 3} `)];


const TILES = [TILE1, TILE2, TILE3, TILE4];

[TILE1, TILE2, TILE3, TILE4].map((tile, id) => {
  const generator = ({ x, y, rotate }) => {
    const svg = createNode('svg', { width: TILE_SIZE, height: TILE_SIZE, style: `transform: translate(${x}px, ${y}px) rotate(${rotate}deg)`, 'transform-origin': `${TILE_SIZE / 2}px ${TILE_SIZE / 2}px` });

    tile.forEach(el => {
      svg.appendChild(el());
    });

    return svg;
  };

  layer1.addTile(`${id}`, generator);
  layer2.addTile(`${id}`, generator);
});

const render = (row, col, prevProps) => ({
  id: prevProps ? prevProps.id : `${Math.floor(Math.random() * 4)}`,
  rotate: prevProps ? prevProps.rotate : Math.floor(Math.random() * 2) * 90,
  x: col * TILE_SIZE,
  y: row * TILE_SIZE });


layer1.render(render);
layer2.render(render);

window.addEventListener('resize', () => {
  layer1.render(render);
  layer2.render(render);
});