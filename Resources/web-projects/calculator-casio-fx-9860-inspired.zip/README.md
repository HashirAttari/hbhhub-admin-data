# Calculator (Casio fx-9860 Inspired)

A Pen created on CodePen.io. Original URL: [https://codepen.io/sscchan/pen/NxRMpa](https://codepen.io/sscchan/pen/NxRMpa).

This CodePen is made to fulfill the requirements of the FreeCodeCamp's "Zipline: Build a JavaScript Calculator" exercise.

This Pen is made to above the minimum requirements specified by the user story. Since there are no Android emulator for the Casio fx-9860,  this pen aims to recreate part of the basic calculation function of that calculator so it can be used on an Android phone (or anywhere).

The following user stories are required to be fulfilled:
1) I can add, subtract, multiply and divide two numbers.
2) I can clear the input field with a clear button.
3) I can keep chaining mathematical operations together until I hit the equal button, and the calculator will tell me the correct output.
