# Gear Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/MiguelAraCo/pen/rNQVeQ](https://codepen.io/MiguelAraCo/pen/rNQVeQ).

Clock inspired by the watch designed by François Quentin, the 4N.
IN PROGRESS