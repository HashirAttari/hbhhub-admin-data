# MacBook Application Bar-VJL (Apple Only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/sjrh/pen/ezOaQb](https://codepen.io/sjrh/pen/ezOaQb).

