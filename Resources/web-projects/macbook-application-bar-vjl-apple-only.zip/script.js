$("img").hover( function(){
  $(this).animate({top: '-20', width: '+=50'})
},
  function() {
  $(this).animate({top: '0', width: '-=50'})
})