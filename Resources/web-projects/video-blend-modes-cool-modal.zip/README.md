# Video + Blend modes = Cool modal

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/QagxgJ](https://codepen.io/jcoulterdesign/pen/QagxgJ).

