# Perspective loader (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/rNLMogb](https://codepen.io/benhatsor/pen/rNLMogb).

