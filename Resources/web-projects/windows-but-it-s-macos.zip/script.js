const toolbar = document.getElementById("toolbar");
for (const child of toolbar.children) {
  child.addEventListener("click", () => {child.classList.toggle("selected")})
}