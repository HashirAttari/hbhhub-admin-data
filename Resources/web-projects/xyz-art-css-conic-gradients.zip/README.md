# XYZ  (Art, CSS, Conic Gradients ♡)

A Pen created on CodePen.io. Original URL: [https://codepen.io/konstantindenerz/pen/abaaWEE](https://codepen.io/konstantindenerz/pen/abaaWEE).

Demonstration of conic gradient love with CSS.