# Navbar Experiment

A Pen created on CodePen.io. Original URL: [https://codepen.io/MarioD/pen/yLBYXNL](https://codepen.io/MarioD/pen/yLBYXNL).

[Original design](https://dribbble.com/shots/6934545-Navbar-experiment) by [Björgvin Pétur Sigurjónsson](https://dribbble.com/bjorgvinpetur)

Alternative to the version that was live coded by [The Keyframers](https://www.twitch.tv/keyframers) [here](https://www.twitch.tv/videos/466311167).