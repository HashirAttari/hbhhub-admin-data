# Glow slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/BabJQqx](https://codepen.io/alvaromontoro/pen/BabJQqx).

