# Review Component w/ React (Animated)

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/XWoOxqb](https://codepen.io/aaroniker/pen/XWoOxqb).

