"use strict";
const { FC, useCallback, useState, useEffect, useRef } = React;
const Rating = ({ initialIndex, onChange }) => {
    const [current, setCurrent] = useState(initialIndex);
    const [last, setLast] = useState(null);
    const [animationClass, setAnimationClass] = useState(undefined);
    const ratingRef = useRef(null);
    const liRefs = useRef([]);
    useEffect(() => {
        if (animationClass) {
            setTimeout(() => {
                var _a, _b;
                setAnimationClass('');
                (_a = liRefs.current[last !== null && last !== void 0 ? last : 0]) === null || _a === void 0 ? void 0 : _a.classList.remove('move-from');
                (_b = liRefs.current[current !== null && current !== void 0 ? current : 0]) === null || _b === void 0 ? void 0 : _b.classList.remove('move-to');
            }, 800);
        }
    }, [animationClass, last]);
    const handleClick = useCallback((index) => {
        var _a, _b;
        if (!ratingRef.current || current === index) {
            return;
        }
        const isAnimating = ratingRef.current.classList.contains('animate-left') || ratingRef.current.classList.contains('animate-right');
        if (!isAnimating) {
            const li = liRefs.current[index];
            const x = (_a = li === null || li === void 0 ? void 0 : li.offsetLeft) !== null && _a !== void 0 ? _a : 0;
            setLast(current);
            setCurrent(-1);
            setTimeout(() => setCurrent(index), 800);
            if (onChange) {
                onChange(index);
            }
            li === null || li === void 0 ? void 0 : li.classList.add('move-to');
            (_b = liRefs.current[last !== null && last !== void 0 ? last : 0]) === null || _b === void 0 ? void 0 : _b.classList.add('move-from');
            ratingRef.current.style.setProperty('--x', `${x}px`);
            setAnimationClass(index > (last !== null && last !== void 0 ? last : 0) ? 'animate-right' : 'animate-left');
        }
    }, [ratingRef, liRefs, current, last, animationClass]);
    return (React.createElement("nav", { ref: ratingRef, className: `rating ${animationClass}` },
        React.createElement("ul", null, [1, 2, 3, 4, 5].map((_, i) => (React.createElement("li", { key: i, ref: (el) => liRefs.current[i] = el, className: `${current === i ? 'current' : ''} ${i < current ? 'active' : ''}`, onClick: () => handleClick(i) },
            i >= 4 && React.createElement("span", null),
            React.createElement("svg", null,
                React.createElement("use", { xlinkHref: "#star" })))))),
        React.createElement("div", { className: `${animationClass ? 'show' : 'hide'} moving` },
            React.createElement("span", null,
                React.createElement("svg", null,
                    React.createElement("use", { xlinkHref: "#star" }))))));
};
ReactDOM.render(React.createElement(Rating, { initialIndex: 0 }), document.getElementById('root'));