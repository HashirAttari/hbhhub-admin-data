# Course design cards #scss

A Pen created on CodePen.io. Original URL: [https://codepen.io/kristen17/pen/NPKrxBd](https://codepen.io/kristen17/pen/NPKrxBd).

