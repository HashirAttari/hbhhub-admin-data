/**
 * Interactive Particle Typography
 * @micjamking
 */
class ParticleTypography {

  /**
   * Setup DOM references, environment 
   * variables, and event listeners
   */
  constructor() {
    // External utilities
    this.w = window;
    this.$ = document.querySelectorAll.bind(document);
    this.utils = this.w.utils;
    this.requestAnimationFrame = this.w.requestAnimationFrame.bind(this.w);

    // DOM & Canvas object references
    this.$canvas = this.$('.canvas')[0];
    this.$textarea = this.$('.console')[0];
    this.context = this.$canvas.getContext('2d');

    // Set mouse coordinates to variable
    this.mouse = this.utils.captureMouse(this.$canvas);
    this.mouseBall = new Ball(100, 'transparent');

    // Image
    this.image = new Image();
    this.imageSrc = "https://s3-us-west-2.amazonaws.com/s.cdpn.io/3640/leila-jade.v3.png";
    this.imagePixels = [];

    // Particles
    this.particles = [];
    this.hueTopRange = 280;
    this.hueBotRange = 200;
    this.hueOffset = 60;

    // Set particle size based on screensize
    if (this.utils.screenSize().width > 1200) {
      this.particleSize = 8;
    } else if (this.utils.screenSize().width > 900) {
      this.particleSize = 6;
    } else {
      this.particleSize = 4;
    }

    // Environment Physics
    this.spring = 0.1;
    this.friction = 0.95;

    // Start animation
    this._init();
  }


  /**
   * Initialize canvas and image
   */
  _init() {
    // Set Canvas size to fullscreen
    this.$canvas.width = this.utils.screenSize().width;
    this.$canvas.height = this.utils.screenSize().height;

    // Set initial mouse ball position
    this.mouseBall.x = this.$canvas.width / 2;
    this.mouseBall.y = this.$canvas.height / 2;

    // Environment events
    this.w.addEventListener('resize', () => this._onWindowResize());
    this.$canvas.addEventListener('mousemove', () => this._onMouseMove(), false);

    // CORS enabled image
    // https://developer.mozilla.org/en-US/docs/Web/HTML/CORS_enabled_image
    this.image.crossOrigin = "Anonymous";
    this.image.src = this.imageSrc;
    this.image.addEventListener('load', () => this._drawImage());

    this._animate();

    console.log('initialized animation');
  }


  /**
   * Draw image to canvas (in-memory)
   */
  _drawImage() {

    // Create in-memory canvas to get image pixels
    let $analysisCanvas = document.createElement('canvas'),
    $analysisContext = $analysisCanvas.getContext('2d');

    $analysisCanvas.width = this.utils.screenSize().width;
    $analysisCanvas.height = this.utils.screenSize().height;

    // Get image proportions
    let ratio = this.image.width / this.image.height,
    imageWidth = this.$canvas.width,
    imageHeight = imageWidth / ratio;

    // If image is portrait, swap proportion ratio
    if (imageHeight > this.$canvas.height) {
      imageHeight = this.$canvas.height;
      imageWidth = imageHeight * ratio;
    }

    // Scale image down so there's some padding
    imageHeight = imageHeight * 0.9;
    imageWidth = imageWidth * 0.9;

    let verticalCenter = (this.$canvas.height - imageHeight) / 2,
    horizontalCenter = (this.$canvas.width - imageWidth) / 2;

    // Draw image to canvas and center it
    $analysisContext.clearRect(0, 0, $analysisCanvas.width, $analysisCanvas.height);
    $analysisContext.drawImage(this.image, horizontalCenter, verticalCenter, imageWidth, imageHeight);

    this._getPixelData($analysisCanvas, $analysisContext);

    console.log('created image in memory');
  }


  /**
   * Create image pixel map with x, y, and color properties
   * for individual pixels
  *
  * @param {Object} canvas - Canvas element
  * @param {Object} context - 2D canvas context
   */
  _getPixelData(canvas, context) {
    // Get canvas pixel data
    let imageData = context.getImageData(0, 0, canvas.width, canvas.height),
    pixels = imageData.data,
    x = 0,
    y = 0;

    // Iterate over canvas pixels
    for (let offset = 0; offset < pixels.length; offset += 4) {
      let r = pixels[offset],
      g = pixels[offset + 1],
      b = pixels[offset + 2],
      a = pixels[offset + 3];

      // Skip transparent or all-white pixels
      if (a > 0 && !(r === 255 && g === 255 && b === 255)) {
        let x = offset / 4 % canvas.width,
        y = Math.floor(Math.floor(offset / canvas.width) / 4);

        if (x && x % this.particleSize == 0 && y && y % this.particleSize == 0) {
          this.imagePixels.push({
            x: x,
            y: y,
            color: 'rgba(' + r + ', ' + g + ', ' + b + ', ' + a + ')' });

        }
      }
    }

    // Generate particles
    this._generateParticles(this.imagePixels);

    console.log('generated pixel data for particles');
  }


  /**
  * Generate particles
   *
  * @param {Array} pixels - Canvas pixel coordinates
  */
  _generateParticles(pixels) {

    for (let i = 0; i < pixels.length; i++) {
      let particle = new Ball(
      this.particleSize / 2, // size
      pixels[i].color);


      particle.x = particle.targetX = pixels[i].x;
      particle.y = particle.targetY = pixels[i].y;

      this.particles.push(particle);
    }

    console.log('generated particles');

    return this.particles;

  }


  /**
   * Draw particles
   *
   * @param {Object} particle - Instance 2D Ball context
   */
  _drawParticles(particle) {

    // Get distance to target
    let dx = particle.targetX - particle.x,
    dy = particle.targetY - particle.y,

    // Calculate acceleration (distance * spring)
    ax = dx * this.spring,
    ay = dy * this.spring;

    particle.range = this.image.height - particle.y;

    // Set hue based on Y coordinate (vertical)
    let hue = particle.range * (this.hueTopRange - this.hueBotRange) / this.image.height + this.hueOffset;

    particle.color = 'hsla(' + hue + ', 88%, 63%, 1.00)';

    // Calculate velocity (acceleration + distance)
    particle.vx += ax;
    particle.vy += ay;

    // Apply friction (velocity * friction)
    particle.vx *= this.friction;
    particle.vy *= this.friction;

    // Add velocity to positioning
    particle.x += particle.vx;
    particle.y += particle.vy;

    particle.draw(this.context);
  }


  /**
   * Collision detection between mouse and particles
   *
  * @param {Object} particle - Instance 2D Ball context
   */
  _collisionDetection(particle) {
    let dx = particle.x - this.mouseBall.x,
    dy = particle.y - this.mouseBall.y,
    dist = Math.sqrt(dx * dx + dy * dy),
    min_dist = particle.radius + this.mouseBall.radius;

    if (dist < min_dist) {
      let angle = Math.atan2(dy, dx),
      tx = this.mouseBall.x + Math.cos(angle) * min_dist,
      ty = this.mouseBall.y + Math.sin(angle) * min_dist;

      particle.vx += (tx - particle.x) * this.spring;
      particle.vy += (ty - particle.y) * this.spring;

    }

    return particle;
  }


  /**
  * Animation loop
  */
  _animate() {

    // Call request animation frame recursively
    this.requestAnimationFrame(this._animate.bind(this), this.$canvas);

    // Clear canvas every frame
    this.context.fillStyle = '#111';
    this.context.fillRect(0, 0, this.$canvas.width, this.$canvas.height);

    // Animate stuff...
    if (this.particles) {
      for (var i = 0; i < this.particles.length; i++) {
        this._collisionDetection(this.particles[i]);
        this._drawParticles(this.particles[i]);
      }
    }

  }


  /** 
   * Window resize callback
   */
  _onWindowResize() {

    // Change particle size with canvas size for performance
    if (this.utils.screenSize().width > 1200) {
      this.particleSize = 8;
    } else if (this.utils.screenSize().width > 900) {
      this.particleSize = 6;
    } else {
      this.particleSize = 4;
    }

    // Set canvas size to current window size
    this.$canvas.width = this.utils.screenSize().width;
    this.$canvas.height = this.utils.screenSize().height;

    // Reset initial mouse ball position
    this.mouseBall.x = this.$canvas.width / 2;
    this.mouseBall.y = this.$canvas.height / 2;

    // Reset particles
    this.particles = [];
    this.imagePixels = [];

    // Redraw image
    this._drawImage();
  }


  /** 
  * Mouse move callback
  */
  _onMouseMove() {

    // Set mouseBall to mouse coordinates
    this.mouseBall.x = this.mouse.x;
    this.mouseBall.y = this.mouse.y;

    if (!this.$textarea.classList.contains('inactive')) {
      setTimeout(() => {
        this.$textarea.classList.add('inactive');

        setTimeout(() => {
          this.$textarea.style.display = 'none';
        }, 2000);
      }, 1000);
    }
  }}


/* hello universe */
new ParticleTypography();