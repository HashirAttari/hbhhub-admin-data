/*
** try opening this pen on a mobile device to type and send messages
*/
(function() {
  var deviceMode = "unknown";
  var speed = null;
  var start = new Date().getTime();
  
  var isKeyRawEnter = function isKeyRawEnter(e) {
    return (
      !e.ctrlKey && !e.altKey && !e.shiftKey && !e.metaKey && e.keyCode === 13
    );
  };

  var interceptEnterKey = function interceptEnterKey($message) {
    start = new Date().getTime(); // initialize var start
    var keyTimes = []; // array to store times

    $message.keydown(function(e) {
      // event to determine key(s)
      start = new Date().getTime(); // set start to current time

      if (isKeyRawEnter(e)) {
        // if return was pressed
        if (!keyTimes.length) {
          // if it was the first key pressed
          e.preventDefault(); // cancel newline insertion and
          return; // exit function immediately
        }

        var sumKeyTime = keyTimes.reduce(function(x, y) {
          return parseInt(x) + parseInt(y);
        });
        var avgKeyTime = sumKeyTime / keyTimes.length; // find the average time
        
        speed = Math.floor(avgKeyTime,2);

        if (avgKeyTime > 26) {
          // match physical keyboards
          deviceMode = "physical";
          keyTimes = []; // reset the key press times
        } else {
          deviceMode = "virtual";
        }
        // cancel newline
        e.preventDefault();
        $(this.form).submit();
      }
    });

    $message.keyup(function() {
      let nStart = new Date();
      let diff = nStart.getTime() - start;
      start = nStart;
      
      keyTimes.push(diff); // store the difference
    });
  };

  var initTextArea = function initTextArea() {
    $message = $("#message_body");
    interceptEnterKey($message);
  };

  $(initTextArea);

  // A few extra tricks for static sites
  $(function() {
    $("#message_form").submit(function(e) {
      e.preventDefault();
      var $messageBody = $("#message_body");

      if ($messageBody.val()) {
        var $message = $('<div class="message"></div>').append(
          `<div class="device-marker device-${deviceMode}"></div>` + $messageBody.val().replace(/\n/g, "<br>") + `<div class="key-speed">${speed}</div>`
        );
        $(".messages").append($message);
        $messageBody.val("");
      }
    });
  });
})();