# Physical versus Virtual keyboard detection

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/qwjdQv](https://codepen.io/run-time/pen/qwjdQv).

