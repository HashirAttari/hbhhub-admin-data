# CSS Art: Motorola RAZR V3i

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/JjaMMXw](https://codepen.io/alvaromontoro/pen/JjaMMXw).

CSS drawing of a Motorola RAZR V3i (the most iconic flip phone ever). Coded in HTML and CSS.