# Alien shape

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/jOWrgqX](https://codepen.io/yuanchuan/pen/jOWrgqX).

https://css-doodle.com