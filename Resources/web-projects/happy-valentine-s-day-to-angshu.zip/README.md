# Happy Valentine's Day to Angshu

A Pen created on CodePen.

Original URL: [https://codepen.io/abhikmitra/pen/RNQLqL](https://codepen.io/abhikmitra/pen/RNQLqL).

Because handmade cards are too mainstream/