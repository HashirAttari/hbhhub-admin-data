dragging = false;

'use strict';

///console.clear();

class Grain {
  constructor(el) {
    /**
    * Options
    * Increase the pattern size if visible pattern
    */
    this.patternSize = 150;
    this.patternScaleX = 1;
    this.patternScaleY = 1;
    this.patternRefreshInterval = 3; // 8
    this.patternAlpha = 28; // int between 0 and 255,

    /**
    * Create canvas
    */
    this.canvas = el;
    this.ctx = this.canvas.getContext('2d');
    this.ctx.scale(this.patternScaleX, this.patternScaleY);

    /**
    * Create a canvas that will be used to generate grain and used as a
    * pattern on the main canvas.
    */
    this.patternCanvas = document.createElement('canvas');
    this.patternCanvas.width = this.patternSize;
    this.patternCanvas.height = this.patternSize;
    this.patternCtx = this.patternCanvas.getContext('2d');
    this.patternData = this.patternCtx.createImageData(this.patternSize, this.patternSize);
    this.patternPixelDataLength = this.patternSize * this.patternSize * 4; // rgba = 4

    /**
    * Prebind prototype function, so later its easier to user
    */
    this.resize = this.resize.bind(this);
    this.loop = this.loop.bind(this);

    this.frame = 0;

    window.addEventListener('resize', this.resize);
    this.resize();

    window.requestAnimationFrame(this.loop);
  }

  resize() {
    this.canvas.width = window.innerWidth * devicePixelRatio;
    this.canvas.height = window.innerHeight * devicePixelRatio;
  }

  update() {
    const { patternPixelDataLength, patternData, patternAlpha, patternCtx } = this;

    // put a random shade of gray into every pixel of the pattern
    for (let i = 0; i < patternPixelDataLength; i += 4) {
      // const value = (Math.random() * 255) | 0;
      const value = Math.random() * 255;

      patternData.data[i] = value;
      patternData.data[i + 1] = value;
      patternData.data[i + 2] = value;
      patternData.data[i + 3] = patternAlpha;
    }

    patternCtx.putImageData(patternData, 0, 0);
  }

  draw() {
    const { ctx, patternCanvas, canvas, viewHeight } = this;
    const { width, height } = canvas;

    // clear canvas
    ctx.clearRect(0, 0, width, height);

    // fill the canvas using the pattern
    ctx.fillStyle = ctx.createPattern(patternCanvas, 'repeat');
    ctx.fillRect(0, 0, width, height);
  }

  loop() {
    // only update grain every n frames
    const shouldDraw = ++this.frame % this.patternRefreshInterval === 0;
    if (shouldDraw) {
      this.update();
      this.draw();
    }

    window.requestAnimationFrame(this.loop);
  }}



/**
 * Initiate Grain
 */
const el = document.querySelector('.grain');
const grain = new Grain(el);



$('.phone').mousedown(function (e) {
  initX = e.clientX;
  dragging = true;
});

$('html').mouseup(function () {
  dragging = false;
  $('.dynamicCursor').css('width', '18px');
});
$('.phone').mousemove(function (e) {
  if (dragging) {
    let mouseX = e.clientX;
    difference = mouseX - initX;

    console.log(difference);

    $('.dynamicCursor').css('width', Math.abs(difference) + 'px');

    if (difference > 60) {
      $('.phone').addClass('open');
    }

    if (difference < -60) {
      $('.phone').removeClass('open');
    }

  }
});

function drawMouseSpeedDemo() {
  var mrefreshinterval = 30; // update display every 500ms
  var lastmousex = -1;
  var lastmousey = -1;
  var lastmousetime;
  var mousetravel = 0;
  var mpoints = [];
  var mpoints_max = 30;
  var direction;

  $('html').mousemove(function (e) {
    var mousex = e.pageX;
    var mousey = e.pageY;
    if (lastmousex > -1) {
      mousetravel += Math.max(Math.abs(mousex - lastmousex), Math.abs(mousey - lastmousey));
    }
    // console.log(mousex-lastmousex)

    if (mousex - lastmousex > 0) {
      direction = '+';
    } else {
      direction = '-';
    }

    //console.log(direction);

    lastmousex = mousex;
    lastmousey = mousey;
  });
  var mdraw = function () {
    var md = new Date();
    var timenow = md.getTime();
    if (lastmousetime && lastmousetime != timenow) {
      var pps = Math.round(mousetravel / (timenow - lastmousetime) * 1000);
      mpoints.push(pps);
      if (mpoints.length > mpoints_max)
      mpoints.splice(0, 1);
      mousetravel = 0;
      //console.log(pps)
      if (dragging) {

      }

    }
    lastmousetime = timenow;
    setTimeout(mdraw, mrefreshinterval);
  };
  // We could use setInterval instead, but I prefer to do it this way
  setTimeout(mdraw, mrefreshinterval);
};

drawMouseSpeedDemo();


/* -------------------------------------------------

Dynamic cursor

--------------------------------------------------- */

const cursorSettings = {
  'class': 'dynamicCursor',
  'size': '18',
  'expandedSize': '40',
  'expandSpeed': 0.4,
  'background': 'rgba(161, 142, 218, 0.25)',
  'opacity': '1',
  'transitionTime': '1.4s',
  'transitionEase': 'cubic-bezier(0.075, 0.820, 0.165, 1.000)',
  'borderWidth': '0',
  'borderColor': 'black',
  'iconSize': '11px',
  'iconColor': 'white',
  'triggerElements': {
    'trigger': {
      'className': 'trigger',
      'icon': '<i class="fa fa-plus"></i>' },

    'trigger2': {
      'className': 'slider_inner',
      'icon': '<i class="fa fa-arrows-h"></i>' } } };





function dynamicCursor(options) {

  document.write('<link rel="stylesheet" href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css">');

  var hold;
  cursor = document.createElement('div');
  let cursorIcon = document.createElement('div');

  cursorIcon.classList.add('cursorIcon');
  cursorIcon.style.position = 'absolute';
  cursorIcon.style.fontFamily = 'Raleway';
  cursorIcon.style.textTransform = 'uppercase';
  cursorIcon.style.fontWeight = '800';
  cursorIcon.style.textAlign = 'center';
  cursorIcon.style.top = '50%';
  cursorIcon.style.width = '100%';
  cursorIcon.style.transform = 'translateY(-50%)';
  cursorIcon.style.color = options.iconColor;
  cursorIcon.style.fontSize = options.iconSize;
  cursorIcon.style.opacity = 0;
  cursorIcon.style.transition = `opacity ${options.expandSpeed}s`;

  cursor.classList.add(options.class);
  cursor.style.boxSizing = 'border-box';
  cursor.style.width = `${options.size}px`;
  cursor.style.height = `${options.size}px`;
  cursor.style.borderRadius = `${options.expandedSize}px`;
  cursor.style.opacity = 0;

  cursor.style.pointerEvents = 'none';
  cursor.style.zIndex = 999;
  cursor.style.transition = `transform ${options.transitionTime} ${options.transitionEase}, width 0s, height ${options.expandSpeed}s .2s, opacity 1s .2s`;
  cursor.style.border = `${options.borderWidth}px solid ${options.borderColor}`;
  cursor.style.position = 'fixed';
  cursor.style.background = options.background;

  cursor.appendChild(cursorIcon);
  document.body.appendChild(cursor);

  setTimeout(function () {
    cursor.style.opacity = options.opacity;
  }, 500);

  var idle;

  document.onmousemove = e => {
    console.log('test');
    x = e.pageX;
    y = e.pageY;

    cursor.style.opacity = options.opacity;
    clearInterval(idle);

    idle = setTimeout(function () {
      cursor.style.opacity = 0;
    }, 4000);

    cursor.style.top = '0';
    cursor.style.left = '0';
    cursor.style.transform = `translateX(calc(${x}px - 50%)) translateY(calc(${y}px - 50%))`;
  };

  for (i in options.triggerElements) {

    let trigger = $(`.${options.triggerElements[i].className}`);

    console.log(trigger);


    let icon = options.triggerElements[i].icon;

    if (!trigger) {
      console.warn('You dont have any triggers');
    } else {
      trigger.each(function (el) {

        console.log();
        trigger[el].style.cursor = 'default';
        trigger[el].addEventListener('mouseover', () => {
          console.log('over');
          cursor.style.width = `${options.expandedSize}px`;
          cursor.style.height = `${options.expandedSize}px`;
          cursorIcon.innerHTML = icon;
          cursorIcon.style.opacity = 1;


          console.log($(this));


        });

        trigger[el].addEventListener('mouseout', () => {
          cursor.style.width = `${options.size}px`;
          cursor.style.height = `${options.size}px`;
          cursorIcon.style.opacity = 0;
        });
      });

    }
  }
}

dynamicCursor(cursorSettings);

$('.back').click(function () {
  $(this).parent().parent().removeClass('expand');
});