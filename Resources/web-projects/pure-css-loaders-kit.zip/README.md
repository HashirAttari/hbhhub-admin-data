# Pure CSS Loaders kit

A Pen created on CodePen.io. Original URL: [https://codepen.io/viduthalai1947/pen/nyrLee](https://codepen.io/viduthalai1947/pen/nyrLee).

Single Element pure CSS Spinners & Loaders