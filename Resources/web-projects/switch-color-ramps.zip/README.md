# Switch color ramps

A Pen created on CodePen.io. Original URL: [https://codepen.io/kekenes/pen/oNgdYaB](https://codepen.io/kekenes/pen/oNgdYaB).

