# Color Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/KNrMYw](https://codepen.io/run-time/pen/KNrMYw).

background color changes based on time of day