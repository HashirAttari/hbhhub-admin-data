setInterval(function () {
  document.body.style.backgroundColor = getTimeAsHexColor();
  document.body.innerHTML = getTimeAsHexColor();
}, 5);

function getTimeAsHexColor() {
  var d = new Date();
  var t = d.getMilliseconds() + (1000 * d.getSeconds()) + (1000 * 60 * d.getMinutes()) + (1000 * 60 * 60 * d.getHours());
  var c = Math.floor(t / 5.14984130859375);
  return '#' + ('000000' + c.toString(16)).slice(-6).toUpperCase();
}