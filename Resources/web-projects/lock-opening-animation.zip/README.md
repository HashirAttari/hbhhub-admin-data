# Lock opening animation!

A Pen created on CodePen.io. Original URL: [https://codepen.io/enotix364/pen/Gbpryg](https://codepen.io/enotix364/pen/Gbpryg).

Coolest lock opening animation I ever made 😎.

What do you think?