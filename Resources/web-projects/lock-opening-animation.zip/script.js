let h = window.innerH;
let lock = document.getElementsByClassName('lock')[0];
window.addEventListener('resize', resizeLock);
function resizeLock(){
   coef = 1000/600;
   console.log(window.innerHeight/1000);
   lock.style.transform = "translate(-50%, -50%) scale(" + window.innerHeight/1000 + ")"
   console.log(lock.style.transform);
   
}
resizeLock();
function refresh(){
var newone = lock.cloneNode(true);
lock.parentNode.replaceChild(newone, lock);
lock = newone;
}

function elemMaker(elem, classO, text) {
  var elem = document.createElement(elem);
  elem.classList.add(classO);
  if (text !== false) {
    elem.textContent = text;
  }
  return elem;
}
var contOfStick = document.getElementsByClassName("middleVisior")[0];
var short, long, number;
for (var i = 0; i < 40; i++) {
  if (i % 5 == 0) {
    long = elemMaker("div", "longStick");
    long.style.transform =
      "translatey(-50%) rotate(" + 9 * i + "deg) translatey(-130px)";
    contOfStick.appendChild(long);
    number = elemMaker("span", "nOfStick", i);
    long.appendChild(number);
  } else {
    short = elemMaker("div", "shortStick");
    short.style.transform =
      "translatey(-50%) rotate(" + 9 * i + "deg) translatey(-150px)";
    contOfStick.appendChild(short);
  }
} // make lock sticks