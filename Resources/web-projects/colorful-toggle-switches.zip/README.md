# Colorful Toggle Switches

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/WNaoBeP](https://codepen.io/nicolasjesenberger/pen/WNaoBeP).

