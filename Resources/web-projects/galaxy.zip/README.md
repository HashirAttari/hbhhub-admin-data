# Galaxy

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/bEGxoe](https://codepen.io/giana/pen/bEGxoe).

Fork of <a href="http://codepen.io/giana/pen/qbWNYy">Stars</a>