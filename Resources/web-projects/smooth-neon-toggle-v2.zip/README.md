# Smooth Neon Toggle (v2)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/XWGoYKO](https://codepen.io/alvaromontoro/pen/XWGoYKO).

Inspired by Josh Dillon's Silky Smooth checkboxes: https://codepen.io/jdillon/pen/PoLBVmV