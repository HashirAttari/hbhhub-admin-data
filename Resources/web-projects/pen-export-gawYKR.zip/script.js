var tetik=0;
function bilgi(event){
  if(tetik==1){

    document.getElementById("kontrol").style.width= "60px";
    document.getElementById("kontrol").style.height= "60px";
    var yuzey = document.getElementById("alan"),
        alan = yuzey.getBoundingClientRect(),
        x = event.clientX - alan.left,
        y = event.clientY - alan.top;
        yuzey.style.width = x + "px";
        yuzey.style.height = y + "px";
   }
}
function kucul(){
    document.getElementById("kontrol").style.width= "25px";
    document.getElementById("kontrol").style.height= "25px";
}