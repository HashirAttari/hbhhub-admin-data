# Shapes & Lights - CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/eYovPjw](https://codepen.io/josetxu/pen/eYovPjw).

Inspired by <strong>"Letter O"</strong> from <strong>Bogdan Dreava's</strong> <a href="https://bogdandreava.myportfolio.com/alphabet">"Alphabet"</a> project.

