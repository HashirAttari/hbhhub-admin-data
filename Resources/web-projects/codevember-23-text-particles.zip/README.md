# #codevember #23 Text Particles

A Pen created on CodePen.

Original URL: [https://codepen.io/DonKarlssonSan/pen/NbjmQB](https://codepen.io/DonKarlssonSan/pen/NbjmQB).

Move Mouse (or Touch)!