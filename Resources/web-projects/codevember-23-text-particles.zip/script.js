/*
  Johan Karlsson (DonKarlssonSan)

  All my #codevember Pens:
  https://codepen.io/collection/XwMkWm/
*/

var settings = {
  duration: 1,
  text: "#codevember 23",
  textSize: 80 };


class Particle {
  constructor(destX, destY, color) {
    this.destX = destX;
    this.destY = destY;
    this.x = destX;
    this.y = destY;
    this.factor = Math.random();
    this.color = color;
  }

  move(tickX, tickY) {
    this.x = this.destX + this.factor * 60 * tickX;
    this.y = this.destY + this.factor * 60 * tickY;
  }}


class Writer {
  constructor(canvasId) {
    var canvas = document.getElementById(canvasId);
    this.ctx = canvas.getContext("2d");
    this.w = canvas.width = window.innerWidth;
    this.h = canvas.height = window.innerHeight;
    // A list of all the particles that forms the text 
    this.particles = [];
    this.tickX = 0;
    this.tickY = 0;
    this.tick = 0;
    this.demoMode = true;
    this.x = this.w / 2;
    this.y = this.h / 2;

    this.onMove = this.onMove.bind(this);
    canvas.addEventListener("mousemove", this.onMove);
    canvas.addEventListener("touchmove", this.onMove);
  }

  init(text, size) {
    this.ctx.lineWidth = 2;
    this.ctx.fillStyle = "#229";
    this.ctx.shadowColor = "#222";
    this.ctx.shadowOffsetX = 6;
    this.ctx.shadowOffsetY = 6;
    this.ctx.shadowBlur = 5;
    this.ctx.font = "bold " + size + "px sans-serif";
    // Draw text on the canvas temporarily
    var textWidth = this.ctx.measureText(text).width;
    var marginLeft = (this.w - textWidth) * 0.5;
    var marginTop = (this.h - size) * 0.25;
    this.ctx.fillText(text, 0, size);

    var image = this.ctx.getImageData(0, 0, this.w, this.h);
    var buffer32 = new Uint32Array(image.data.buffer);

    for (var x = 0; x < this.w; x++) {
      for (var y = 0; y < this.h; y++) {
        // The buffer is linear, y*w+x is a trick
        // to calculate the linear index.
        var color = buffer32[y * this.w + x];
        if (color) {
          // There is a pixel here, add a particle
          var startX = marginLeft + x;
          var startY = marginTop + y;
          this.particles.push(new Particle(
          startX,
          startY,
          color));
        }
      }
    }
    this.ctx.clearRect(0, 0, this.w, this.h);
  }

  dist(x1, y1, x2, y2) {
    var dx = x1 - x2;
    var dy = y1 - y2;
    return Math.sqrt(dx * dx + dy * dy);
  }

  onMove(e) {
    this.demoMode = false;
    var x = e.touches ? e.touches[0].clientX : e.clientX;
    var y = e.touches ? e.touches[0].clientY : e.clientY;
    this.x = x;
    this.y = y;
  }

  draw() {
    this.ctx.clearRect(0, 0, this.w, this.h);
    this.tick++;
    if (this.demoMode) {
      this.x = Math.cos(this.tick / 50) * 40 + this.w / 2;
      this.y = Math.sin(this.tick / 50) * 40 + this.h / 2;
    }
    var tickX = this.x / document.body.clientWidth * 2 - 1;
    var tickY = this.y / document.body.clientHeight * 2 - 1;
    // Start every frame with an empty image
    var imageData = this.ctx.createImageData(this.w, this.h);
    var pixels = new Uint32Array(imageData.data.buffer);

    this.particles.forEach(p => {
      var x = Math.round(p.x);
      var y = Math.round(p.y);
      if (x >= 0 && x < this.w && y >= 0 && y < this.h) {
        pixels[x + this.w * y] = p.color;
      }
      p.move(tickX, tickY);
    });

    this.ctx.putImageData(imageData, 0, 0);
    this.ctx.beginPath();
    this.ctx.moveTo(this.w / 2, this.h / 2);
    this.ctx.lineTo(this.x, this.y);
    this.ctx.stroke();
    requestAnimationFrame(() => this.draw());
  }}


window.onload = function () {
  var writer = new Writer("canvas");
  writer.init(settings.text, settings.textSize);
  writer.draw();
};