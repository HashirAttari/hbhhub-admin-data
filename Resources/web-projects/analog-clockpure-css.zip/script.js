/*

A simple analog clock made with pure CSS. No scripts. No images. No SVG.

Design => https://dribbble.com/shots/6118476-Did-You/

*/