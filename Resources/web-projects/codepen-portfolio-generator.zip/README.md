# CodePen Portfolio Generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/alexzaworski/pen/PVRorZ](https://codepen.io/alexzaworski/pen/PVRorZ).

Takes a CodePen username and turns it into a static site :O Powered by [cpv2api](https://cpv2api.com/), React, the CodePen [prefill API](https://blog.codepen.io/documentation/api/prefill/), and some other goodies

## Quick notes

- big thanks to Nate Wiley (again) for the api
- plays nicely with custom Pen screenshots (for pro users)
- created Pens can be exported as a zip, uploaded to a Project, and deployed
- since it saves to a Pen it's totally hackable, make something sweet

## Exact steps to deploy a site with this

1. pick your Pens, sort 'em, etc
2. click `Save as Pen`
3. save the created Pen
4. click `Export` on the bottom right
5. choose `.zip`
6. create a new Project
7. upload the zip contents as files
8. save the Project
9. click `Deploy`