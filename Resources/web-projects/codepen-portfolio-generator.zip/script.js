function _extends() {_extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};return _extends.apply(this, arguments);}function _defineProperty(obj, key, value) {if (key in obj) {Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true });} else {obj[key] = value;}return obj;} // <Portfolio/> @ https://codepen.io/alexzaworski/pen/bf1b5bf5ca22d1128fb0ce4728b7f99d
// <Icon/> @ https://codepen.io/alexzaworski/pen/399b181db5aaa44edc0555cfb9c28eef

console.clear();

const CPV2 = "https://cpv2api.com";
const NO_PENS = "Error. No Pens.";
const STYLE_URL = "https://codepen.io/alexzaworski/pen/bf1b5bf5ca22d1128fb0ce4728b7f99d.scss";

const domainChecker = domain => str => {
  return !!str.match(new RegExp(`^https?:\/\/${domain}\/.+`));
};

const isGitHub = domainChecker("github.com");
const isTwitter = domainChecker("twitter.com");

const fetchJson = (url, settings) => {
  return fetch(url, settings).then(r => r.json());
};

const fetchText = (url, settings) => {
  return fetch(url, settings).then(r => r.text());
};

const START = Symbol("start");
const PROFILE = Symbol("profile");
const PICK_PENS = Symbol("pick-pens");
const SORT_PENS = Symbol("order-pens");
const PREVIEW = Symbol("preview");

const orderedSteps = [START, PROFILE, PICK_PENS, SORT_PENS, PREVIEW];

const defaultState = {
  pens: null,
  pensLoading: false,
  pensError: null,
  selectedPens: [],

  profile: null,
  profileLoading: false,
  profileError: null,

  currentStep: orderedSteps[0],

  markup: null,
  styles: null,

  inputs: {
    username: "",
    twitterLink: "",
    gitHubLink: "",
    codePenLink: "",
    personalLink: "",
    emailLink: "",
    search: "",
    location: "",
    includeAvatar: true,
    includeBio: true,
    selectAll: false } };



class App extends React.Component {constructor(...args) {super(...args);_defineProperty(this, "state",
    defaultState);_defineProperty(this, "handleInput",

    event => {
      const { target } = event;
      const { name, type } = target;
      const value = type === "checkbox" ? target.checked : target.value;
      this.setState(prevState => {
        return {
          inputs: {
            ...prevState.inputs,
            [name]: value } };


      });
    });_defineProperty(this, "handleMarkupReady",






    markup => {
      if (this.state.markup) return;
      this.setState({ markup });
    });_defineProperty(this, "createPen",

    async () => {
      const { markup, styles, profile: { nicename } } = this.state;

      const data = {
        title: `${nicename}'s CodePen Portfolio`,
        html: markup,
        css: styles,
        head: "<meta name='viewport' content='width=device-width'>",
        css_pre_processor: 'scss',
        editors: 110,
        parent: 32704787 //this Pen
      };

      const form = document.createElement('form');
      form.setAttribute('method', 'post');
      form.setAttribute('target', '_blank');
      form.setAttribute('action', 'https://codepen.io/pen/define');

      const input = document.createElement('input');
      input.setAttribute('value', JSON.stringify(data));
      input.setAttribute('name', 'data');
      form.appendChild(input);

      document.body.appendChild(form);
      form.submit();
      document.body.removeChild(form);
    });_defineProperty(this, "togglePen",

    event => {
      const { target: { checked, name } } = event;
      return this.setState(prevState => {
        const { selectedPens } = prevState;
        return {
          selectedPens: checked ?
          [...selectedPens, name] :
          selectedPens.filter(id => id !== name) };

      });
    });_defineProperty(this, "toggleAll",

    event => {
      const { target: { checked, name } } = event;
      const inputState = { selectAll: checked };
      return this.setState(prevState => {
        const { pens } = prevState;
        return {
          inputs: { ...prevState.inputs, ...inputState },
          selectedPens: checked ? [...pens.keys()] : [] };

      });
    });_defineProperty(this, "back",

    () => {
      const perStepStateResets = {
        [PROFILE]: [
        "profile",
        "profileLoading",
        "profileError",
        "inputs",
        "pens",
        "pensLoading",
        "pensError"],

        [PREVIEW]: ["markup"] };


      this.setState(prevState => {
        const { currentStep } = prevState;
        const keysToReset = perStepStateResets[currentStep] || [];

        const resetState = keysToReset.reduce((newState, key) => {
          return { ...newState, [key]: defaultState[key] };
        }, {});

        const stepIndex = orderedSteps.indexOf(currentStep);

        return {
          ...resetState,
          currentStep: orderedSteps[stepIndex - 1] || orderedSteps[0] };

      });
    });_defineProperty(this, "forward",

    () => {
      this.setState(prevState => {
        const { currentStep } = prevState;
        const stepIndex = orderedSteps.indexOf(currentStep);
        return {
          currentStep: orderedSteps[stepIndex + 1] };

      });
    });_defineProperty(this, "fetchUser",




























































































    async event => {
      event.preventDefault();
      this.setState({ profileLoading: true, profileError: null });
      await this.fetchProfile();
      if (this.state.profile) {
        this.setState({ pens: new Map(), pensLoading: true, pensError: null });
        this.fetchAllPens();
      }
    });_defineProperty(this, "sortSelectedPens",

    ({ oldIndex, newIndex }) => {
      this.setState(prevState => {
        const { selectedPens } = prevState;
        return {
          selectedPens: SortableHOC.arrayMove(selectedPens, oldIndex, newIndex) };

      });
    });}async componentDidMount() {const styles = await fetchText(STYLE_URL);this.setState({ styles });}addPens(newPens) {this.setState(({ pens: prevPens, selectedPens: prevSelected, currentStep, inputs: { selectAll } }) => {const newPensMap = new Map(prevPens);const newSelectedSet = [...prevSelected];newPens.forEach(pen => {// I was seeing some weird dupes come through in some
        // cases, not sure if it's a cpv2 bug or a CodePen
        // pagination bug or a me bug.
        if (newPensMap.has(pen.id)) return;newPensMap.set(pen.id, pen);if (selectAll && currentStep === PICK_PENS) newSelectedSet.push(pen.id);});return { pens: newPensMap, selectedPens: newSelectedSet };});}async fetchAllPens(page = 1, pens = []) {const { inputs: { username } } = this.state; // bailing here does 2 important things:
    //
    //    1. prevents us from accidentally fetching
    //       all of CodePen's front page
    //
    //    2. automatically stops fetching if the
    //       user hits 'back' from navigation and
    //       clears the username
    if (!username) return;const url = `${CPV2}/pens/popular/${username}?page=${page}`;const { error, data } = await fetchJson(url);if (error) {return this.setState(error === NO_PENS ? { pensLoading: false } : { pensError: error, pensLoading: false });}this.addPens(data);this.fetchAllPens(page + 1, [...pens, ...data]);}async fetchProfile() {const { inputs: { username } } = this.state;const { error, data } = await fetchJson(`${CPV2}/profile/${username}`);if (error) return this.setState({ profileError: error, profileLoading: false });const { links, location } = data;const twitterLink = links.find(isTwitter);const gitHubLink = links.find(isGitHub);const foundInputs = { codePenLink: `https://codepen.io/${username}`, ...(location && { location }), ...(twitterLink && { twitterLink }), ...(gitHubLink && { gitHubLink }) };return new Promise(resolve => {// this promise might actually be 
      // totally unnecessary? await seems
      // to be working as-is with setState
      // but I don't understand why :(
      this.setState(prevState => {return { currentStep: PROFILE, profile: data, profileLoading: false, inputs: { ...prevState.inputs, ...foundInputs } };}, resolve);});}fullSelectedPens() {const { selectedPens, pens } = this.state;return [...selectedPens].map(id => pens.get(id));}renderNav(opts = {}) {const { allowContinue = true, continueText = "Continue" } = opts;return /*#__PURE__*/React.createElement("div", { className: "content-row button-row" }, /*#__PURE__*/React.createElement("button", { className: "button button--secondary", onClick: this.back }, "Back"), /*#__PURE__*/React.createElement("button", { className: "button",
      onClick: this.forward,
      disabled: !allowContinue },

    continueText));



  }

  renderSettingsForm() {
    const {
      inputs: {
        codePenLink,
        twitterLink,
        gitHubLink,
        location,
        emailLink,
        personalLink,
        includeAvatar,
        includeBio },

      profile: { avatar, nicename } } =
    this.state;

    const displayName = nicename ? nicename.split(" ")[0] : null;

    return /*#__PURE__*/(
      React.createElement("div", { className: "content-wrap" }, /*#__PURE__*/
      React.createElement("div", { className: "content-row" }, /*#__PURE__*/
      React.createElement("h2", null, "Howdy ", displayName, " :)"), /*#__PURE__*/
      React.createElement("p", null, "What personal info do you want included?")), /*#__PURE__*/

      React.createElement("div", { className: "content-row" }, /*#__PURE__*/
      React.createElement(Toggle, {
        label: "CodePen avatar",
        name: "includeAvatar",
        checked: includeAvatar,
        onChange: this.handleInput }), /*#__PURE__*/

      React.createElement(Toggle, {
        label: "CodePen bio",
        name: "includeBio",
        checked: includeBio,
        onChange: this.handleInput })), /*#__PURE__*/


      React.createElement("div", { className: "content-row" }, /*#__PURE__*/
      React.createElement("p", { className: "notice" }, "(all optional, bank fields will be omitted)"), /*#__PURE__*/
      React.createElement(IconInput, {
        icon: "codepen",
        name: "codePenLink",
        placeholder: "CodePen profile",
        type: "url",
        value: codePenLink,
        onChange: this.handleInput }), /*#__PURE__*/

      React.createElement(IconInput, {
        icon: "twitter",
        name: "twitterLink",
        placeholder: "Twitter profile",
        type: "url",
        value: twitterLink,
        onChange: this.handleInput }), /*#__PURE__*/

      React.createElement(IconInput, {
        icon: "github",
        name: "gitHubLink",
        type: "url",
        placeholder: "GitHub profile",
        value: gitHubLink,
        onChange: this.handleInput }), /*#__PURE__*/

      React.createElement(IconInput, {
        icon: "globe",
        name: "personalLink",
        type: "url",
        placeholder: "Personal site",
        value: personalLink,
        onChange: this.handleInput }), /*#__PURE__*/

      React.createElement(IconInput, {
        placeholder: "Location",
        icon: "location",
        name: "location",
        value: location,
        onChange: this.handleInput }), /*#__PURE__*/

      React.createElement(IconInput, {
        icon: "email",
        name: "emailLink",
        type: "email",
        placeholder: "Email",
        value: emailLink,
        onChange: this.handleInput })),


      this.renderNav()));


  }

  renderUsernameForm() {
    const { inputs: { username }, profileError, profileLoading } = this.state;
    return /*#__PURE__*/(
      React.createElement("div", { className: "content-wrap" }, /*#__PURE__*/
      React.createElement(Loader, { loading: profileLoading, className: "loader--corner" }), /*#__PURE__*/
      React.createElement("div", { className: "content-row" }, /*#__PURE__*/
      React.createElement("h2", null, "Let's do this thing"), /*#__PURE__*/
      React.createElement("p", null, "What's your CodePen username?")), /*#__PURE__*/


      React.createElement("form", { onSubmit: this.fetchUser }, /*#__PURE__*/
      React.createElement("div", { className: "content-row" }, /*#__PURE__*/
      React.createElement(IconInput, {
        icon: "codepen",
        name: "username",
        placeholder: "you",
        required: true,
        value: username,
        onChange: this.handleInput }),

      profileError && /*#__PURE__*/
      React.createElement("div", { className: "form-error" }, "Yikes! Profile not found :( Try again?")), /*#__PURE__*/




      React.createElement("div", { className: "content-row" }, /*#__PURE__*/
      React.createElement("button", { className: "button", disabled: !username.length }, "Continue")))));






  }

  renderPenPicker() {
    const {
      pens,
      pensLoading,
      selectedPens,
      inputs: { search, selectAll } } =
    this.state;
    const pensArray = [...pens.values()];
    const filteredPens = search ?
    pensArray.filter(p => {
      return p.title.toLowerCase().includes(search);
    }) :
    pensArray;
    return /*#__PURE__*/(
      React.createElement("div", { className: "content-wrap" }, /*#__PURE__*/
      React.createElement(Loader, { loading: pensLoading, className: "loader--corner" }), /*#__PURE__*/
      React.createElement("h2", null, "Choose some Pens you're proud of"), /*#__PURE__*/
      React.createElement("p", null, "Roughly 7\u201310 would be good. You'll be able sort them in the next step."), /*#__PURE__*/



      React.createElement(IconInput, {
        icon: "search",
        name: "search",
        placeholder: "Search by title",
        value: search,
        onChange: this.handleInput }), /*#__PURE__*/

      React.createElement("div", { className: "notice" },
      pensArray.length, " Pens found",
      pensLoading && " (so far, still loadin')",
      `, ${selectedPens.length} selected`), /*#__PURE__*/

      React.createElement(Toggle, {
        label: "Toggle all",
        checked: selectAll,
        onChange: this.toggleAll }),

      pens.length, /*#__PURE__*/
      React.createElement("div", { className: "pen-pick-list" },
      !filteredPens.length && "No pens found ¯\\_(ツ)_/¯", /*#__PURE__*/
      React.createElement("ul", null,
      filteredPens.map(p => {
        const { id, title } = p;
        return /*#__PURE__*/(
          React.createElement("li", { key: id, className: "pen-pick-list__item" }, /*#__PURE__*/
          React.createElement(Toggle, {
            dangerouslySetInnerHTML: { __html: title },
            checked: selectedPens.includes(id),
            name: id,
            onChange: this.togglePen })));



      }))),


      this.renderNav({ allowContinue: selectedPens.length > 0 })));


  }

  renderPenSorter() {
    return /*#__PURE__*/(
      React.createElement("div", { className: "content-wrap" }, /*#__PURE__*/
      React.createElement("h2", null, "Drag 'em where you want 'em"), /*#__PURE__*/
      React.createElement("p", null, "Last step! What order should these go in? The first one gets extra special treatment \u2B50\uFE0F"), /*#__PURE__*/



      React.createElement("div", { className: "content-row" }, /*#__PURE__*/
      React.createElement(PenSortList, {
        pens: this.fullSelectedPens(),
        onSortEnd: this.sortSelectedPens })),


      this.renderNav({ continueText: "Party time!" })));


  }

  renderPortfolio() {
    const {
      profile,
      pensLoading,
      inputs: {
        emailLink,
        twitterLink,
        gitHubLink,
        codePenLink,
        location,
        personalLink,
        includeAvatar,
        includeBio } } =

    this.state;

    return /*#__PURE__*/(
      React.createElement(Portfolio, {
        settings: {
          emailLink,
          twitterLink,
          gitHubLink,
          codePenLink,
          location,
          personalLink,
          includeAvatar,
          includeBio },

        profile: profile,
        onMarkupReady: this.handleMarkupReady,
        pens: this.fullSelectedPens() }));


  }

  renderPreview() {
    const { markup } = this.state;
    return /*#__PURE__*/(
      React.createElement("div", { className: "preview" },
      markup && /*#__PURE__*/
      React.createElement("div", { className: "preview__header" }, /*#__PURE__*/
      React.createElement("p", { className: "preview__text" }, "All done! Here's a preview. You can go back and stuff or open this as a new Pen and make any changes you want. Happy hacking \uD83D\uDC9C"), /*#__PURE__*/



      React.createElement("div", { className: "button-row" }, /*#__PURE__*/
      React.createElement("button", {
        className: "button button--small button--secondary",
        onClick: this.back }, "Back"), /*#__PURE__*/



      React.createElement("button", { className: "button button--small button--green", onClick: this.createPen }, /*#__PURE__*/
      React.createElement(Icon, { className: "button__icon", shape: "codepen" }), "Save as Pen"))), /*#__PURE__*/




      React.createElement(Loader, { loading: !markup, className: "loader--huge" }),
      this.renderPortfolio()));


  }

  renderStatefulContent() {
    const { currentStep } = this.state;
    switch (currentStep) {
      case PROFILE:
        return this.renderSettingsForm();
      case PICK_PENS:
        return this.renderPenPicker();
      case SORT_PENS:
        return this.renderPenSorter();
      case PREVIEW:
        return this.renderPreview();
      default:
        return this.renderUsernameForm();}

  }

  render() {
    return /*#__PURE__*/React.createElement("div", { className: "page-wrap" }, this.renderStatefulContent());
  }}


const IconInput = ({ icon, ...inputProps }) => {
  return /*#__PURE__*/(
    React.createElement("div", { className: "icon-input" }, /*#__PURE__*/
    React.createElement(Icon, { shape: icon, className: "icon-input__icon" }), /*#__PURE__*/
    React.createElement("input", _extends({ className: "icon-input__input", autoComplete: "off" }, inputProps))));


};

const Toggle = ({ label, dangerouslySetInnerHTML, ...checkProps }) => {
  return /*#__PURE__*/(
    React.createElement("label", { className: "toggle" }, /*#__PURE__*/
    React.createElement("input", _extends({ className: "toggle__input", type: "checkbox" }, checkProps)), /*#__PURE__*/
    React.createElement("div", { className: "toggle__track" }, /*#__PURE__*/
    React.createElement("div", { className: "toggle__thumb" })), /*#__PURE__*/

    React.createElement("div", {
      className: "toggle__text",
      dangerouslySetInnerHTML: dangerouslySetInnerHTML },

    label)));



};

const Loader = ({ loading, className }) => {
  if (!loading) return null;
  return /*#__PURE__*/(
    React.createElement("svg", {
      xmlns: "http://www.w3.org/2000/svg",
      width: "16",
      height: "16",
      viewBox: "0 0 16 16",
      className: ["loader", className].filter(Boolean).join(" ") }, /*#__PURE__*/

    React.createElement("circle", {
      cx: "8",
      cy: "8",
      r: "7",
      strokeWidth: "2",
      className: "loader__backdrop" }), /*#__PURE__*/

    React.createElement("circle", { cx: "8", cy: "8", r: "7", strokeWidth: "2", className: "loader__circle" })));


};

const PenSortItem = SortableHOC.SortableElement(({ pen, index }) => /*#__PURE__*/
React.createElement("li", {
  className: "pen-sort-list__item",
  dangerouslySetInnerHTML: { __html: pen.title } }));



const PenSortList = SortableHOC.SortableContainer(({ pens }) => {
  return /*#__PURE__*/(
    React.createElement("ul", { className: "pen-sort-list" },
    pens.map((pen, index) => /*#__PURE__*/
    React.createElement(PenSortItem, { key: pen.id, index: index, pen: pen }))));



});

ReactDOM.render( /*#__PURE__*/React.createElement(App, null), document.getElementById("app"));