// set random animation speeds
const hr = document.querySelectorAll('hr')
hr.forEach(function(elm){
  elm.style.animationDelay = Math.random()*5 + 's'
  elm.style.animationDuration = Math.random()*3 + 's'
})

// bg color functions
function color() {
  return 'hsl('+Math.random()*360+'deg,75%,40%)'
}

function setBGColor(){
  document.querySelector('html').style.background = 'linear-gradient(to bottom right,'+color()+','+color()+')'  
}
setBGColor()

window.addEventListener('click', setBGColor)

//zoom on body
var bod = document.getElementsByTagName('body')[0]
var z = 1

function zoom(e) {
  if(e.deltaY < 0) {
    z = z - .1
    if(z < .1) {
      z = .1
    }
  } else {
    z = z + .1
    if(z > 2) {
      z = 2
    }    
  }
  // console.log(z)
  document.documentElement.style.setProperty('--size',"scale("+z+")" )
}
window.addEventListener('wheel', zoom)