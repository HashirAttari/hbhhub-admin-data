# Controlled Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/borntofrappe/pen/qGozVM](https://codepen.io/borntofrappe/pen/qGozVM).

Practice with SVG syntax and a few lines of JavaScript to create an enticing, animated clock.