$(document).ready(function() {

var num = "";
var numTwo = "";
var operator = "";
var total = $("#output");
var decimalAdded = false;

function clearAll() {
  num = "";
  numTwo = "";
  operator = "";
  $("#output").text("0");
}

function backOne() {
  num = num.toString().slice(0, -1);
  $("#output").text(num);
}

 $("button").click(function() {
  if(this.id === "clearAll") {
    clearAll();
  } else if (this.id === "%") {
    numNew = num / 100;
    num = numNew;
    $("#output").text(num);
  } else if(this.id === "backOne") {
    backOne();
  }
   else {
    num += $(this).text();
    $("#output").text(num);
    console.log(num);
}
 })


 $(".yellow").not("#total").click(function() {
  operator = $(this).text();
  numTwo = num;
  num = "";
  console.log("op:"+operator);
  console.log("2:"+numTwo);
  console.log("1:"+num);
  console.log(typeof num );
 });

 $("#total").click(function() {

    if(operator === "+") {
      num = (parseFloat(numTwo) + parseFloat(num));
    } else if(operator === "-") {
      num = (parseFloat(numTwo) - parseFloat(num));
    } else if(operator === "*") {
      num = (parseFloat(numTwo) * parseFloat(num));
    } else if(operator === "/") {
      num = (parseFloat(numTwo) / parseFloat(num));
    } 
    total.text(num);
    num = "";
    numTwo = "";

  })
  
});