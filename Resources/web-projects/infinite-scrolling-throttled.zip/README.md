# Infinite scrolling throttled

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/zqpEGP](https://codepen.io/mselmany/pen/zqpEGP).



Forked from [Corbacho](http://codepen.io/dcorb/)'s Pen [Infinite scrolling throttled](http://codepen.io/dcorb/pen/eJLMxa/).