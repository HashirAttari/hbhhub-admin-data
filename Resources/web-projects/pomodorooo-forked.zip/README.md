# Pomodorooo (forked)

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/bGmWjbO](https://codepen.io/cbolson/pen/bGmWjbO).

Forked from original codepen bySstephanyyy:
https://codepen.io/Sstephanyyy/pen/MWPmaNo

Added :
var to control which button is "active" and therefore get the reset button to use that button default time