const myPomodoro = {
  currentTime: 0,
  startTime: 1500, //1500 seconds = 25min
  shortBreakTime: 300, //300 seconds = 5mim
  longBreakTime: 900, //900 seconds = 15min
  currentType: 'normal'
}

let interval;
let isPaused = false; //to track the current state of the button. Paused or started?


function startTimer(time) {
  let minutes, seconds; //need to convert the secs in minu

  //Step 1: Create setInterval to count
  interval = setInterval(() => {

    //STEP 7: to stop the timer when I click in the pause button..For this, we need to clean up the last interval
    if (isPaused) {
      clearInterval(interval);
    }

    // Step 3: Update the currentTime
    myPomodoro.currentTime = time;
    time--;

    // Step 2: Transform secs in minutes
    minutes = Math.floor(myPomodoro.currentTime / 60);
    seconds = Math.floor(myPomodoro.currentTime % 60);

    //Step 5: increment the "0" in the sec/min below than 10
    if (minutes < 10) {
      minutes = '0' + minutes;
    }
    if (seconds < 10) {
      seconds = '0' + seconds;
    }
   
    const text = document.getElementById('text').innerHTML = minutes + ':' + seconds;

    //Step 4: parar a cronometragem quando chegar no 0
    if (time < 0) {
      clearInterval(interval);
      text.innerHTML = 'Time is up!';
    }


  }, 1000);

}

const myButton = document.getElementById('startButton');
myButton.addEventListener('click', () => {
  toggleButtons();

});

//STEP 6: Increment the PAUSE button 
//STEP 6.1: add an atribute in the 'start' button on the html to store the current state of the button.
//STEP 6.2: GET this atribute on the javascript;
//STEP 6.3: Change the current state of the button according with the situation;

//The toggleButtons function is responsible for changing the text and state of the button when it is clicked, and also for controlling the timer.
function toggleButtons() {
  const myAtribute = myButton.getAttribute('data-state');

  if (myAtribute === 'start') {
    myButton.setAttribute('data-state', 'pause');
    myButton.textContent = 'Pause';
    isPaused = false; //indicates that the timer is running.

    if (myPomodoro.currentTime > 0) { // != 0 or 0 it means that the timer was previously paused and is being resumed -> TRUE
      startTimer(myPomodoro.currentTime);
    } else {
      startTimer(myPomodoro.startTime); //o timer irá começar do começo (25:00);
    }
}else{ 
    startButton.textContent = 'Start';
    startButton.setAttribute('data-state', 'start');
    isPaused = true; 
  }
}

//Step 8: Reset button
const resetButton = document.getElementById('resetButton');
resetButton.addEventListener('click', () => {
  clearInterval(interval);
  // define which reset value to use accordng to the current button type
  const buttonType = myPomodoro.currentType;
  
  console.log("type ", buttonType);
  if(buttonType == "short"){
    myPomodoro.currentTime = myPomodoro.shortBreakTime; 
  } else if (buttonType == "long"){ 
    myPomodoro.currentTime = myPomodoro.longBreakTime;
  } else {
    myPomodoro.currentTime = myPomodoro.startTime; 
  }

  
  //Calculates the new minutes and seconds values based on the updated current time value.
  let minutes = Math.floor(myPomodoro.currentTime / 60);
  let seconds = Math.floor(myPomodoro.currentTime % 60);
  
  if (minutes < 10) {
    minutes = '0' + minutes;
  }
  if (seconds < 10) {
    seconds = '0' + seconds;
  }

  myButton.textContent = 'Start';
  myButton.setAttribute('data-state', 'start');
  isPaused = true
  const text = document.getElementById('text').innerHTML =  minutes + ':' + seconds;

});

const normalButton = document.getElementById('normalButton');
normalButton.addEventListener('click', () => {
  clearInterval(interval);
  myPomodoro.currentTime = myPomodoro.startTime; 
  myPomodoro.currentType = "normal";

  //Calculates the new minutes and seconds values based on the updated current time value.
  let minutes = Math.floor(myPomodoro.currentTime / 60);
  let seconds = Math.floor(myPomodoro.currentTime % 60);


  if (minutes < 10) {
    minutes = '0' + minutes;
  }
  if (seconds < 10) {
    seconds = '0' + seconds;
  }

  const text = document.getElementById('text').innerHTML = minutes + ':' + seconds;
  myButton.setAttribute('data-state', 'start');
  myButton.textContent = 'Start';
  isPaused = true;

  normalButton.style.backgroundColor = "red";

});


const shortButton = document.getElementById('shortButton');
shortButton.addEventListener('click', () => {
  clearInterval(interval);
  myPomodoro.currentTime = myPomodoro.shortBreakTime; // set the currentTime to 5 minutes
  //myPomodoro.startTime = myPomodoro.shortBreakTime; // set the startTime to 5 minutes
myPomodoro.currentType = "short";
  //Calculates the new minutes and seconds values based on the updated current time value.
  let minutes = Math.floor(myPomodoro.currentTime / 60);
  let seconds = Math.floor(myPomodoro.currentTime % 60);
  
  
  if(minutes < 10){
    minutes = '0' + minutes;
  }
  if(seconds < 10){
    seconds = '0' + seconds;
  }

  const text = document.getElementById('text').innerHTML = minutes + ':' + seconds;
  myButton.setAttribute('data-state', 'start');
  myButton.textContent = 'Start';
  isPaused = true;
  
  shortButton.style.backgroundColor = "red";
  
  // Remove red background from long break button
  longButton.style.backgroundColor = '';
  
});

const longButton = document.getElementById('longButton');
longButton.addEventListener('click', () => {
  
  clearInterval(interval);
  
  myPomodoro.currentTime = myPomodoro.longBreakTime;
  //myPomodoro.startTime = myPomodoro.longBreakTime;
  myPomodoro.currentType = "long";
  let minutes = Math.floor(myPomodoro.currentTime / 60);
  let seconds = Math.floor(myPomodoro.currentTime % 60);
  
  myButton.setAttribute('data-state', 'start');
  myButton.textContent = 'Start';
  isPaused = true;
  
  const text = document.getElementById('text').innerHTML;
  
  text.innerHTML = minutes + ":" + seconds;
  
  startTimer(myPomodoro.currentTime);
  
  longButton.style.backgroundColor = 'red';
  
  // Remove red background from short break button
  shortButton.style.backgroundColor = '';
  
})