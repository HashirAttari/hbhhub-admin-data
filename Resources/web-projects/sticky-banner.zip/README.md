# Sticky banner

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/KKgYjZN](https://codepen.io/havardob/pen/KKgYjZN).

Demonstrating how  you can achieve a shrinking, sticky header on scroll without Javascript. Pure CSS, baby. 