# Music App

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/JjJXqZm](https://codepen.io/havardob/pen/JjJXqZm).

A music app concept by Sulton Handaya

Made from this Dribbble shot: https://dribbble.com/shots/16355560-Online-Music-Streaming-App/attachments/8920497?mode=media 