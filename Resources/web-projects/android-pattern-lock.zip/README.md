# Android Pattern Lock

A Pen created on CodePen.io. Original URL: [https://codepen.io/WinterCore/pen/MvEyXP](https://codepen.io/WinterCore/pen/MvEyXP).

Android Pattern lock with the lock screen
Mobile phones are supported