/* external resources *only* for displaying the info boxes */

/* this below is all the JS needed for the demo itself to work
   (in WebKit browsers, it's CSS-only in Firefox, 
    which has a ::-moz-range-progress element)*/
document.documentElement.classList.add('js');

addEventListener('input', e => {
  let _t = e.target;
  
  _t.style.setProperty('--val', +_t.value)
});