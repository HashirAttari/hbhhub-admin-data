document.addEventListener("DOMContentLoaded",app);

function app() {
	let calc = document.forms[0],
		isCalcing = false,
		isError = false,
		val = 0,
		op = "",
		exp = [],
		lastPart = "",
		lastOperand = 0,
		action = e => {
			let kbdClick = e.keyCode == 9 || e.keyCode == 32;
			
			if (!kbdClick) {
				let tar = e.target || e,
					fn = tar.getAttribute("data-fn") || fnByKey(e.keyCode,e.shiftKey,e.altKey),
					output = calc.output;

				if (fn && output) {
					let maxLen = +output.maxLength,
						signs = /[\/\*\-\+]/,
						fnIsNum = !isNaN(fn),
						fnIsDec = fn == ".",
						fnIsSign = fn == "+-",
						fnIsOp = "/*-+".indexOf(fn) > -1,
						fnIsEquals = fn == "=",
						fnIsClear = fn == "C";

					if (!isError) {
						if (exp.length)
							lastPart = exp[exp.length - 1];

						if (fnIsNum || fnIsDec || fnIsSign || fnIsOp) {
							// start a new expression if `=` was previously pressed
							if (!isCalcing) {
								isCalcing = true;
								if (fnIsNum || fnIsDec) {
									op = "";
									exp = ["0"];
									lastPart = exp[0];
									lastOperand = 0;
								}
							}
							if (!exp.length)
								exp.push("0");
						}
						// number
						if (fnIsNum) {
							if (isNaN(lastPart)) {
								exp.push(fn);
							} else if (lastPart.length < maxLen) {
								let numToAdd = lastPart + fn;
								if (numToAdd[0] == "0" && numToAdd[1] != ".")
									numToAdd = numToAdd.substr(1);

								exp[exp.length - 1] = numToAdd;
							}
						// decimal point
						} else if (fnIsDec) {
							if (lastPart.indexOf(".") == -1) {
								if (isNaN(lastPart))
									exp.push("0.");
								else if (lastPart.length < maxLen - 1)
									exp[exp.length - 1] += fn;
							}
						// toggle sign
						} else if (fnIsSign) {
							if (exp.length) {
								if  (!isNaN(lastPart))
									exp[exp.length - 1] = String(-exp[exp.length - 1]);
								else
									exp[0] = String(-exp[0]);
							}
						// operation
						} else if (fnIsOp) {
							op = fn;
							// switch operator
							if (isNaN(lastPart)) {
								exp[exp.length - 1] = op;
							// calculate the current expression before using the operator
							} else {
								let curExp = exp.join(" ");
								if (signs.test(curExp)) {
									exp = [`${solve(exp[0],exp[1],exp[2])}`];
									exp[0] = nearest1000th(exp[0]);
									lastPart = exp[0];
									val = lastPart;
								}
								exp.push(op);
							}
						// equals
						} else if (fnIsEquals) {
							isCalcing = false;

							if (op && exp.indexOf(op) > -1)
								lastOperand = lastPart;
							// equal again
							if (lastOperand && exp.indexOf(op) == -1) {
								exp = [`${solve(val,op,lastOperand)}`];
							// normal equals
							} else if (!isNaN(lastOperand)) {
								exp = [`${solve(exp[0],op,lastOperand)}`];
							// equals without second operand
							} else {
								lastOperand = exp[0];
								exp = [`${solve(val,op,val)}`];
							}
							exp[0] = nearest1000th(exp[0]);
						}
						if (fn != "C") {
							lastPart = exp[exp.length - 1];
							if (!isNaN(lastPart) || lastPart == "NaN")
								val = lastPart;
							// deal with integer overflow and infinity, or 0 / 0
							if (val <= -1e4 || val >= 1e5 || val == "NaN")
								isError = true;
							// update the display
							let outputVal = isError ? "ERROR" : String(val);
							if (!isError) {
								// fit the value into the screen without ending with a decimal point
								if ((val >= -1e3 && val < -1e2) || (val >= 1e3 && val < 1e4))
									outputVal = outputVal.substr(0,maxLen - 1);
								else
									outputVal = outputVal.substr(0,maxLen);
							}
							output.value = outputVal;
						}
					}
					// clear
					if (fnIsClear) {
						isCalcing = false;
						isError = false;
						val = 0;
						op = "";
						exp = [];
						lastPart = "";
						lastOperand = 0;
						output.value = val;
					}
					//console.log(exp);
				}
			}
		},
		fnByKey = (kc,isShift,isAlt) => {
			let fn = "";
			switch (kc) {
				case 12:
				case 27:
				case 67:
					fn = "C";
					break;
				case 48:
				case 96:
					fn = "0";
					break;
				case 49:
				case 97:
					fn = "1";
					break;
				case 50:
				case 98:
					fn = "2";
					break;
				case 51:
				case 99:
					fn = "3";
					break;
				case 52:
				case 100:
					fn = "4";
					break;
				case 53:
				case 101:
					fn = "5";
					break;
				case 54:
				case 102:
					fn = "6";
					break;
				case 55:
				case 103:
					fn = "7";
					break;
				case 56:
					fn = isShift ? "*" : "8";
					break;
				case 104:
					fn = "8";
					break;
				case 57:
				case 105:
					fn = "9";
					break;
				case 106:
					fn = "*";
					break;
				case 13:
					fn = "=";
					break;
				case 107:
					fn = "+";
					break;
				case 187:
					fn = isShift ? "+" : "=";
					break;
				case 109:
				case 189:
					fn = isAlt ? "+-" : "-";
					break;
				case 110:
				case 190:
					fn = ".";
					break;
				case 111:
				case 191:
					fn = "/";
					break;
				default:
					// do nothing
					break;
			}
			return fn;
		},
		nearest1000th = n => {
			let r = Math.round(n / 1e-3) * 1e-3;
			return String(+r.toFixed(4));
		},
		solve = (A,op,B) => {
			let r = 0,
				a = !isNaN(A) ? +A : r,
				b = !isNaN(B) ? +B : a;

			switch (op) {
				case "/":
					r = a / b;
					break;
				case "*":
					r = a * b;
					break;
				case "-":
					r = a - b;
					break;
				case "+":
					r = a + b;
					break;
				default:
					r = a;
					break;
			}
			return r;
		};

	calc.addEventListener("click",action);
	document.addEventListener("keydown",action);
}