# SPECIMEN

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/ZEWOOaQ](https://codepen.io/chrisgannon/pen/ZEWOOaQ).

Check out this version on [Instagram](https://www.instagram.com/p/CEApeMugXHy/) with glitch effects and audio.