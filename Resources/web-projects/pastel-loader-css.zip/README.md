# Pastel loader (CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/wvemmVz](https://codepen.io/amit_sheen/pen/wvemmVz).

