# Transparent text

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/wvRawqd](https://codepen.io/cbolson/pen/wvRawqd).

