# Line reveal block

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/ErQggz](https://codepen.io/ig_design/pen/ErQggz).

