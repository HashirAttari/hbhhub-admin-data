# Swiper custom slides transform effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/udovichenko/pen/LGeQae](https://codepen.io/udovichenko/pen/LGeQae).

Swiper custom slides transform effect. Ready for Swiper ver. 4. Vanilla js. Slider with beautiful transition/animation effect.