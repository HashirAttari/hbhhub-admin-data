# Jump and Slide 

A Pen created on CodePen.io. Original URL: [https://codepen.io/ste-vg/pen/OEbYqZ](https://codepen.io/ste-vg/pen/OEbYqZ).

Original animation by Vitaly Silkin: https://dribbble.com/shots/4268258-Evitare-loader

Also inspired by the @keyframers! https://www.twitch.tv/keyframers