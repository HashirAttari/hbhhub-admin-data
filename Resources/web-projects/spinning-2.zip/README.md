# Spinning 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/wWaNZG](https://codepen.io/giana/pen/wWaNZG).

