# Before After 3 Layer Image Slider (Vanilla)

A Pen created on CodePen.io. Original URL: [https://codepen.io/nosurprisethere/pen/JJzdoP](https://codepen.io/nosurprisethere/pen/JJzdoP).

Playing around with a new idea using my two layer before/after image slider. Keeping it minimal. Keeping it vanilla. Like it if it's useful :)