# CSS-only Notifications Component

A Pen created on CodePen.io. Original URL: [https://codepen.io/damianmuti/pen/GEZoeG](https://codepen.io/damianmuti/pen/GEZoeG).

This is a Sass mixin that provides notifications functionality using little-to-none Javascript.
It makes use of CSS transitions and animations to display notifications as popups or bars on different locations of the viewport.
The best thing is that it is fully customizable and easy to use. :)


CHANGELOG

- Fixed issues with Firefox not rendering the icons