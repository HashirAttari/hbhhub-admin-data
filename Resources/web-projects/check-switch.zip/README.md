# Check Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/qBNvKjE](https://codepen.io/aaroniker/pen/qBNvKjE).

