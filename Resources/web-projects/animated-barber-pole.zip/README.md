# Animated barber pole

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/RwrXPVr](https://codepen.io/havardob/pen/RwrXPVr).

A quick little CSS drawing of a barber pole