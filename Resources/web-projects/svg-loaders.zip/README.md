# SVG Loaders

A Pen created on CodePen.io. Original URL: [https://codepen.io/zslabs/pen/YwygoQ](https://codepen.io/zslabs/pen/YwygoQ).

http://samherbert.net/svg-loaders/ redone in GSAP