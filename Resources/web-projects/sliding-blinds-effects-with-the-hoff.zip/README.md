# Sliding blinds effects with The Hoff

A Pen created on CodePen.io. Original URL: [https://codepen.io/chriskirknielsen/pen/WMrdKY](https://codepen.io/chriskirknielsen/pen/WMrdKY).

Using CSS custom properties, we can get a pretty fun result.