# Clock || clocks ?

A Pen created on CodePen.io. Original URL: [https://codepen.io/MoorLex/pen/NrEvNd](https://codepen.io/MoorLex/pen/NrEvNd).

