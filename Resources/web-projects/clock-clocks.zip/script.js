// Hy! You can really help me if you donate me leastways 1 dollor :)
// -_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-



$('.clocks').addClass('type_'+Math.floor((Math.random() * 3) + 1));

//fill the items with clocks ($cols * $rows)
$('.item').each(function(i){
  for (i = 0; i < (5 * 6); i++) {
    $(this).append('<div class="clock"></div>');
  }
})

//every second get current user time and update the clock
setInterval( function() {
  var hours = new Date().getHours(),
      minutes = new Date().getMinutes(),
      seconds = new Date().getSeconds();
  var time = (hours < 10 ? "0" : "") + hours + '' + (minutes < 10 ? "0" : "") + minutes + '' + (seconds < 10 ? "0" : "") + seconds;
  $('.clocks .num').each(function(i){
    $(this).attr('id', 'l_'+time[i]);
  })
},1000);