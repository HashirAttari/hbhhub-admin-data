(function() {
  var $, applyTransform, getTransform, makeTransformable;

  $ = jQuery;

  getTransform = function(from, to) {
    var A, H, b, h, i, k, k_i, l, lhs, m, ref, rhs;
    console.assert((from.length === (ref = to.length) && ref === 4));
    A = []; // 8x8
    for (i = k = 0; k < 4; i = ++k) {
      A.push([from[i].x, from[i].y, 1, 0, 0, 0, -from[i].x * to[i].x, -from[i].y * to[i].x]);
      A.push([0, 0, 0, from[i].x, from[i].y, 1, -from[i].x * to[i].y, -from[i].y * to[i].y]);
    }
    b = []; // 8x1
    for (i = l = 0; l < 4; i = ++l) {
      b.push(to[i].x);
      b.push(to[i].y);
    }
    // Solve A * h = b for h
    h = numeric.solve(A, b);
    H = [[h[0], h[1], 0, h[2]], [h[3], h[4], 0, h[5]], [0, 0, 1, 0], [h[6], h[7], 0, 1]];
// Sanity check that H actually maps `from` to `to`
    for (i = m = 0; m < 4; i = ++m) {
      lhs = numeric.dot(H, [from[i].x, from[i].y, 0, 1]);
      k_i = lhs[3];
      rhs = numeric.dot(k_i, [to[i].x, to[i].y, 0, 1]);
      console.assert(numeric.norm2(numeric.sub(lhs, rhs)) < 1e-9, "Not equal:", lhs, rhs);
    }
    return H;
  };

  applyTransform = function(element, originalPos, targetPos, callback) {
    var H, from, i, j, p, to;
    // All offsets were calculated relative to the document
    // Make them relative to (0, 0) of the element instead
    from = (function() {
      var k, len, results;
      results = [];
      for (k = 0, len = originalPos.length; k < len; k++) {
        p = originalPos[k];
        results.push({
          x: p[0] - originalPos[0][0],
          y: p[1] - originalPos[0][1]
        });
      }
      return results;
    })();
    to = (function() {
      var k, len, results;
      results = [];
      for (k = 0, len = targetPos.length; k < len; k++) {
        p = targetPos[k];
        results.push({
          x: p[0] - originalPos[0][0],
          y: p[1] - originalPos[0][1]
        });
      }
      return results;
    })();
    // Solve for the transform
    H = getTransform(from, to);
    
    // Apply the matrix3d as H transposed because matrix3d is column major order
    // Also need use toFixed because css doesn't allow scientific notation
    $(element).css({
      'transform': `matrix3d(${((function() {
        var k, results;
        results = [];
        for (i = k = 0; k < 4; i = ++k) {
          results.push((function() {
            var l, results1;
            results1 = [];
            for (j = l = 0; l < 4; j = ++l) {
              results1.push(H[j][i].toFixed(20));
            }
            return results1;
          })());
        }
        return results;
      })()).join(',')})`,
      'transform-origin': '0 0'
    });
    return typeof callback === "function" ? callback(element, H) : void 0;
  };

  makeTransformable = function(selector, callback) {
    return $(selector).each(function(i, element) {
      var controlPoints, originalPos, p, position;
      $(element).css('transform', '');
      
      // Add four dots to corners of `element` as control points
      controlPoints = (function() {
        var k, len, ref, results;
        ref = ['left top', 'left bottom', 'right top', 'right bottom'];
        results = [];
        for (k = 0, len = ref.length; k < len; k++) {
          position = ref[k];
          results.push($('<div>').css({
            border: '10px solid black',
            borderRadius: '10px',
            cursor: 'move',
            position: 'absolute',
            zIndex: 100000
          }).appendTo('body').position({
            at: position,
            of: element,
            collision: 'none'
          }));
        }
        return results;
      })();
      // Record the original positions of the dots
      originalPos = (function() {
        var k, len, results;
        results = [];
        for (k = 0, len = controlPoints.length; k < len; k++) {
          p = controlPoints[k];
          results.push([p.offset().left, p.offset().top]);
        }
        return results;
      })();
      
      // Transform `element` to match the new positions of the dots whenever dragged
      $(controlPoints).draggable({
        start: () => {
          return $(element).css('pointer-events', 'none'); // makes dragging around iframes easier 
        },
        drag: () => {
          return applyTransform(element, originalPos, (function() {
            var k, len, results;
            results = [];
            for (k = 0, len = controlPoints.length; k < len; k++) {
              p = controlPoints[k];
              results.push([p.offset().left, p.offset().top]);
            }
            return results;
          })(), callback);
        },
        stop: () => {
          applyTransform(element, originalPos, (function() {
            var k, len, results;
            results = [];
            for (k = 0, len = controlPoints.length; k < len; k++) {
              p = controlPoints[k];
              results.push([p.offset().left, p.offset().top]);
            }
            return results;
          })(), callback);
          return $(element).css('pointer-events', 'auto');
        }
      });
      return element;
    });
  };

  makeTransformable('.box', function(element, H) {
    var i, j;
    console.log($(element).css('transform'));
    return $(element).html($('<table>').append($('<tr>').html($('<td>').text('matrix3d('))).append((function() {
      var k, results;
      results = [];
      for (i = k = 0; k < 4; i = ++k) {
        results.push($('<tr>').append((function() {
          var l, results1;
          results1 = [];
          for (j = l = 0; l < 4; j = ++l) {
            results1.push($('<td>').text(H[j][i] + ((i === j && j === 3) ? '' : ',')));
          }
          return results1;
        })()));
      }
      return results;
    })()).append($('<tr>').html($('<td>').text(')'))));
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiPGFub255bW91cz4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBLENBQUEsRUFBQSxjQUFBLEVBQUEsWUFBQSxFQUFBOztFQUFBLENBQUEsR0FBSTs7RUFFSixZQUFBLEdBQWUsUUFBQSxDQUFDLElBQUQsRUFBTyxFQUFQLENBQUE7QUFDZixRQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsQ0FBQSxFQUFBLEdBQUEsRUFBQSxDQUFBLEVBQUEsR0FBQSxFQUFBLENBQUEsRUFBQSxHQUFBLEVBQUE7SUFBRSxPQUFPLENBQUMsTUFBUixDQUFlLENBQUEsSUFBSSxDQUFDLE1BQUwsWUFBZSxFQUFFLENBQUMsT0FBbEIsT0FBQSxLQUE0QixDQUE1QixDQUFmO0lBRUEsQ0FBQSxHQUFJLEdBRk47SUFHRSxLQUFTLHlCQUFUO01BQ0UsQ0FBQyxDQUFDLElBQUYsQ0FBTyxDQUFDLElBQUksQ0FBQyxDQUFELENBQUcsQ0FBQyxDQUFULEVBQVksSUFBSSxDQUFDLENBQUQsQ0FBRyxDQUFDLENBQXBCLEVBQXVCLENBQXZCLEVBQTBCLENBQTFCLEVBQTZCLENBQTdCLEVBQWdDLENBQWhDLEVBQW1DLENBQUMsSUFBSSxDQUFDLENBQUQsQ0FBRyxDQUFDLENBQVQsR0FBYSxFQUFFLENBQUMsQ0FBRCxDQUFHLENBQUMsQ0FBdEQsRUFBeUQsQ0FBQyxJQUFJLENBQUMsQ0FBRCxDQUFHLENBQUMsQ0FBVCxHQUFhLEVBQUUsQ0FBQyxDQUFELENBQUcsQ0FBQyxDQUE1RSxDQUFQO01BQ0EsQ0FBQyxDQUFDLElBQUYsQ0FBTyxDQUFDLENBQUQsRUFBSSxDQUFKLEVBQU8sQ0FBUCxFQUFVLElBQUksQ0FBQyxDQUFELENBQUcsQ0FBQyxDQUFsQixFQUFxQixJQUFJLENBQUMsQ0FBRCxDQUFHLENBQUMsQ0FBN0IsRUFBZ0MsQ0FBaEMsRUFBbUMsQ0FBQyxJQUFJLENBQUMsQ0FBRCxDQUFHLENBQUMsQ0FBVCxHQUFhLEVBQUUsQ0FBQyxDQUFELENBQUcsQ0FBQyxDQUF0RCxFQUF5RCxDQUFDLElBQUksQ0FBQyxDQUFELENBQUcsQ0FBQyxDQUFULEdBQWEsRUFBRSxDQUFDLENBQUQsQ0FBRyxDQUFDLENBQTVFLENBQVA7SUFGRjtJQUlBLENBQUEsR0FBSSxHQVBOO0lBUUUsS0FBUyx5QkFBVDtNQUNFLENBQUMsQ0FBQyxJQUFGLENBQU8sRUFBRSxDQUFDLENBQUQsQ0FBRyxDQUFDLENBQWI7TUFDQSxDQUFDLENBQUMsSUFBRixDQUFPLEVBQUUsQ0FBQyxDQUFELENBQUcsQ0FBQyxDQUFiO0lBRkYsQ0FSRjs7SUFhRSxDQUFBLEdBQUksT0FBTyxDQUFDLEtBQVIsQ0FBYyxDQUFkLEVBQWlCLENBQWpCO0lBRUosQ0FBQSxHQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRCxDQUFGLEVBQU8sQ0FBQyxDQUFDLENBQUQsQ0FBUixFQUFhLENBQWIsRUFBZ0IsQ0FBQyxDQUFDLENBQUQsQ0FBakIsQ0FBRCxFQUNDLENBQUMsQ0FBQyxDQUFDLENBQUQsQ0FBRixFQUFPLENBQUMsQ0FBQyxDQUFELENBQVIsRUFBYSxDQUFiLEVBQWdCLENBQUMsQ0FBQyxDQUFELENBQWpCLENBREQsRUFFQyxDQUFJLENBQUosRUFBVSxDQUFWLEVBQWEsQ0FBYixFQUFtQixDQUFuQixDQUZELEVBR0MsQ0FBQyxDQUFDLENBQUMsQ0FBRCxDQUFGLEVBQU8sQ0FBQyxDQUFDLENBQUQsQ0FBUixFQUFhLENBQWIsRUFBbUIsQ0FBbkIsQ0FIRCxFQWZOOztJQXFCRSxLQUFTLHlCQUFUO01BQ0ksR0FBQSxHQUFNLE9BQU8sQ0FBQyxHQUFSLENBQVksQ0FBWixFQUFlLENBQUMsSUFBSSxDQUFDLENBQUQsQ0FBRyxDQUFDLENBQVQsRUFBWSxJQUFJLENBQUMsQ0FBRCxDQUFHLENBQUMsQ0FBcEIsRUFBdUIsQ0FBdkIsRUFBMEIsQ0FBMUIsQ0FBZjtNQUNOLEdBQUEsR0FBTSxHQUFHLENBQUMsQ0FBRDtNQUNULEdBQUEsR0FBTSxPQUFPLENBQUMsR0FBUixDQUFZLEdBQVosRUFBaUIsQ0FBQyxFQUFFLENBQUMsQ0FBRCxDQUFHLENBQUMsQ0FBUCxFQUFVLEVBQUUsQ0FBQyxDQUFELENBQUcsQ0FBQyxDQUFoQixFQUFtQixDQUFuQixFQUFzQixDQUF0QixDQUFqQjtNQUNOLE9BQU8sQ0FBQyxNQUFSLENBQWUsT0FBTyxDQUFDLEtBQVIsQ0FBYyxPQUFPLENBQUMsR0FBUixDQUFZLEdBQVosRUFBaUIsR0FBakIsQ0FBZCxDQUFBLEdBQXVDLElBQXRELEVBQTRELFlBQTVELEVBQTBFLEdBQTFFLEVBQStFLEdBQS9FO0lBSko7V0FLQTtFQTNCYTs7RUE2QmYsY0FBQSxHQUFpQixRQUFBLENBQUMsT0FBRCxFQUFVLFdBQVYsRUFBdUIsU0FBdkIsRUFBa0MsUUFBbEMsQ0FBQTtBQUNqQixRQUFBLENBQUEsRUFBQSxJQUFBLEVBQUEsQ0FBQSxFQUFBLENBQUEsRUFBQSxDQUFBLEVBQUEsRUFBQTs7O0lBRUUsSUFBQTs7QUFBTztNQUFBLEtBQUEsNkNBQUE7O3FCQUNMO1VBQUEsQ0FBQSxFQUFHLENBQUMsQ0FBQyxDQUFELENBQUQsR0FBTyxXQUFXLENBQUMsQ0FBRCxDQUFHLENBQUMsQ0FBRCxDQUF4QjtVQUNBLENBQUEsRUFBRyxDQUFDLENBQUMsQ0FBRCxDQUFELEdBQU8sV0FBVyxDQUFDLENBQUQsQ0FBRyxDQUFDLENBQUQ7UUFEeEI7TUFESyxDQUFBOzs7SUFHUCxFQUFBOztBQUFLO01BQUEsS0FBQSwyQ0FBQTs7cUJBQ0g7VUFBQSxDQUFBLEVBQUcsQ0FBQyxDQUFDLENBQUQsQ0FBRCxHQUFPLFdBQVcsQ0FBQyxDQUFELENBQUcsQ0FBQyxDQUFELENBQXhCO1VBQ0EsQ0FBQSxFQUFHLENBQUMsQ0FBQyxDQUFELENBQUQsR0FBTyxXQUFXLENBQUMsQ0FBRCxDQUFHLENBQUMsQ0FBRDtRQUR4QjtNQURHLENBQUE7O1NBTFA7O0lBVUUsQ0FBQSxHQUFJLFlBQUEsQ0FBYSxJQUFiLEVBQW1CLEVBQW5CLEVBVk47Ozs7SUFjRSxDQUFBLENBQUUsT0FBRixDQUFVLENBQUMsR0FBWCxDQUNFO01BQUEsV0FBQSxFQUFhLENBQUEsU0FBQSxDQUFBLENBQVk7O0FBQUM7UUFBQSxLQUE4Qyx5QkFBOUM7OztBQUFBO1lBQUEsS0FBNkIseUJBQTdCOzRCQUFBLENBQUMsQ0FBQyxDQUFELENBQUcsQ0FBQyxDQUFELENBQUcsQ0FBQyxPQUFSLENBQWdCLEVBQWhCO1lBQUEsQ0FBQTs7O1FBQUEsQ0FBQTs7VUFBRCxDQUF1RCxDQUFDLElBQXhELENBQTZELEdBQTdELENBQVosQ0FBQSxDQUFBLENBQWI7TUFDQSxrQkFBQSxFQUFvQjtJQURwQixDQURGOzRDQUlBLFNBQVUsU0FBUztFQW5CSjs7RUFxQmpCLGlCQUFBLEdBQW9CLFFBQUEsQ0FBQyxRQUFELEVBQVcsUUFBWCxDQUFBO1dBQ2xCLENBQUEsQ0FBRSxRQUFGLENBQVcsQ0FBQyxJQUFaLENBQWlCLFFBQUEsQ0FBQyxDQUFELEVBQUksT0FBSixDQUFBO0FBQ25CLFVBQUEsYUFBQSxFQUFBLFdBQUEsRUFBQSxDQUFBLEVBQUE7TUFBSSxDQUFBLENBQUUsT0FBRixDQUFVLENBQUMsR0FBWCxDQUFlLFdBQWYsRUFBNEIsRUFBNUIsRUFBSjs7O01BR0ksYUFBQTs7QUFBZ0I7QUFBQTtRQUFBLEtBQUEscUNBQUE7O3VCQUNkLENBQUEsQ0FBRSxPQUFGLENBQ0UsQ0FBQyxHQURILENBRUk7WUFBQSxNQUFBLEVBQVEsa0JBQVI7WUFDQSxZQUFBLEVBQWMsTUFEZDtZQUVBLE1BQUEsRUFBUSxNQUZSO1lBR0EsUUFBQSxFQUFVLFVBSFY7WUFJQSxNQUFBLEVBQVE7VUFKUixDQUZKLENBT0UsQ0FBQyxRQVBILENBT1ksTUFQWixDQVFFLENBQUMsUUFSSCxDQVNJO1lBQUEsRUFBQSxFQUFJLFFBQUo7WUFDQSxFQUFBLEVBQUksT0FESjtZQUVBLFNBQUEsRUFBVztVQUZYLENBVEo7UUFEYyxDQUFBOztXQUhwQjs7TUFrQkksV0FBQTs7QUFBZTtRQUFBLEtBQUEsK0NBQUE7O3VCQUFBLENBQUMsQ0FBQyxDQUFDLE1BQUYsQ0FBQSxDQUFVLENBQUMsSUFBWixFQUFrQixDQUFDLENBQUMsTUFBRixDQUFBLENBQVUsQ0FBQyxHQUE3QjtRQUFBLENBQUE7O1dBbEJuQjs7O01BcUJJLENBQUEsQ0FBRSxhQUFGLENBQWdCLENBQUMsU0FBakIsQ0FDRTtRQUFBLEtBQUEsRUFBTyxDQUFBLENBQUEsR0FBQTtpQkFDTCxDQUFBLENBQUUsT0FBRixDQUFVLENBQUMsR0FBWCxDQUFlLGdCQUFmLEVBQWlDLE1BQWpDLEVBREs7UUFBQSxDQUFQO1FBRUEsSUFBQSxFQUFNLENBQUEsQ0FBQSxHQUFBO2lCQUNKLGNBQUEsQ0FBZSxPQUFmLEVBQXdCLFdBQXhCOztBQUFzQztZQUFBLEtBQUEsK0NBQUE7OzJCQUFBLENBQUMsQ0FBQyxDQUFDLE1BQUYsQ0FBQSxDQUFVLENBQUMsSUFBWixFQUFrQixDQUFDLENBQUMsTUFBRixDQUFBLENBQVUsQ0FBQyxHQUE3QjtZQUFBLENBQUE7O2NBQXRDLEVBQWlHLFFBQWpHO1FBREksQ0FGTjtRQUlBLElBQUEsRUFBTSxDQUFBLENBQUEsR0FBQTtVQUNKLGNBQUEsQ0FBZSxPQUFmLEVBQXdCLFdBQXhCOztBQUFzQztZQUFBLEtBQUEsK0NBQUE7OzJCQUFBLENBQUMsQ0FBQyxDQUFDLE1BQUYsQ0FBQSxDQUFVLENBQUMsSUFBWixFQUFrQixDQUFDLENBQUMsTUFBRixDQUFBLENBQVUsQ0FBQyxHQUE3QjtZQUFBLENBQUE7O2NBQXRDLEVBQWlHLFFBQWpHO2lCQUNBLENBQUEsQ0FBRSxPQUFGLENBQVUsQ0FBQyxHQUFYLENBQWUsZ0JBQWYsRUFBaUMsTUFBakM7UUFGSTtNQUpOLENBREY7YUFTQTtJQS9CZSxDQUFqQjtFQURrQjs7RUFrQ3BCLGlCQUFBLENBQWtCLE1BQWxCLEVBQTBCLFFBQUEsQ0FBQyxPQUFELEVBQVUsQ0FBVixDQUFBO0FBQzFCLFFBQUEsQ0FBQSxFQUFBO0lBQUUsT0FBTyxDQUFDLEdBQVIsQ0FBWSxDQUFBLENBQUUsT0FBRixDQUFVLENBQUMsR0FBWCxDQUFlLFdBQWYsQ0FBWjtXQUNBLENBQUEsQ0FBRSxPQUFGLENBQVUsQ0FBQyxJQUFYLENBQ0UsQ0FBQSxDQUFFLFNBQUYsQ0FDRSxDQUFDLE1BREgsQ0FFSSxDQUFBLENBQUUsTUFBRixDQUFTLENBQUMsSUFBVixDQUNFLENBQUEsQ0FBRSxNQUFGLENBQVMsQ0FBQyxJQUFWLENBQWUsV0FBZixDQURGLENBRkosQ0FNRSxDQUFDLE1BTkg7O0FBT0k7TUFBQSxLQUFTLHlCQUFUO3FCQUNFLENBQUEsQ0FBRSxNQUFGLENBQVMsQ0FBQyxNQUFWOztBQUNFO1VBQUEsS0FBUyx5QkFBVDswQkFDRSxDQUFBLENBQUUsTUFBRixDQUFTLENBQUMsSUFBVixDQUFlLENBQUMsQ0FBQyxDQUFELENBQUcsQ0FBQyxDQUFELENBQUosR0FBVSxDQUFHLENBQUEsQ0FBQSxLQUFLLENBQUwsSUFBSyxDQUFMLEtBQVUsQ0FBVixDQUFILEdBQW9CLEVBQXBCLEdBQTRCLEdBQTVCLENBQXpCO1VBREYsQ0FBQTs7WUFERjtNQURGLENBQUE7O1FBUEosQ0FhRSxDQUFDLE1BYkgsQ0FjSSxDQUFBLENBQUUsTUFBRixDQUFTLENBQUMsSUFBVixDQUNFLENBQUEsQ0FBRSxNQUFGLENBQVMsQ0FBQyxJQUFWLENBQWUsR0FBZixDQURGLENBZEosQ0FERjtFQUZ3QixDQUExQjtBQXRGQSIsInNvdXJjZXNDb250ZW50IjpbIiQgPSBqUXVlcnlcblxuZ2V0VHJhbnNmb3JtID0gKGZyb20sIHRvKSAtPlxuICBjb25zb2xlLmFzc2VydCBmcm9tLmxlbmd0aCA9PSB0by5sZW5ndGggPT0gNFxuXG4gIEEgPSBbXSAjIDh4OFxuICBmb3IgaSBpbiBbMCAuLi4gNF1cbiAgICBBLnB1c2ggW2Zyb21baV0ueCwgZnJvbVtpXS55LCAxLCAwLCAwLCAwLCAtZnJvbVtpXS54ICogdG9baV0ueCwgLWZyb21baV0ueSAqIHRvW2ldLnhdXG4gICAgQS5wdXNoIFswLCAwLCAwLCBmcm9tW2ldLngsIGZyb21baV0ueSwgMSwgLWZyb21baV0ueCAqIHRvW2ldLnksIC1mcm9tW2ldLnkgKiB0b1tpXS55XVxuXG4gIGIgPSBbXSAjIDh4MVxuICBmb3IgaSBpbiBbMCAuLi4gNF1cbiAgICBiLnB1c2ggdG9baV0ueFxuICAgIGIucHVzaCB0b1tpXS55XG5cbiAgIyBTb2x2ZSBBICogaCA9IGIgZm9yIGhcbiAgaCA9IG51bWVyaWMuc29sdmUoQSwgYilcblxuICBIID0gW1toWzBdLCBoWzFdLCAwLCBoWzJdXSxcbiAgICAgICBbaFszXSwgaFs0XSwgMCwgaFs1XV0sXG4gICAgICAgWyAgIDAsICAgIDAsIDEsICAgIDBdLFxuICAgICAgIFtoWzZdLCBoWzddLCAwLCAgICAxXV1cblxuICAjIFNhbml0eSBjaGVjayB0aGF0IEggYWN0dWFsbHkgbWFwcyBgZnJvbWAgdG8gYHRvYFxuICBmb3IgaSBpbiBbMCAuLi4gNF1cbiAgICAgIGxocyA9IG51bWVyaWMuZG90KEgsIFtmcm9tW2ldLngsIGZyb21baV0ueSwgMCwgMV0pXG4gICAgICBrX2kgPSBsaHNbM11cbiAgICAgIHJocyA9IG51bWVyaWMuZG90KGtfaSwgW3RvW2ldLngsIHRvW2ldLnksIDAsIDFdKVxuICAgICAgY29uc29sZS5hc3NlcnQobnVtZXJpYy5ub3JtMihudW1lcmljLnN1YihsaHMsIHJocykpIDwgMWUtOSwgXCJOb3QgZXF1YWw6XCIsIGxocywgcmhzKVxuICBIXG5cbmFwcGx5VHJhbnNmb3JtID0gKGVsZW1lbnQsIG9yaWdpbmFsUG9zLCB0YXJnZXRQb3MsIGNhbGxiYWNrKSAtPlxuICAjIEFsbCBvZmZzZXRzIHdlcmUgY2FsY3VsYXRlZCByZWxhdGl2ZSB0byB0aGUgZG9jdW1lbnRcbiAgIyBNYWtlIHRoZW0gcmVsYXRpdmUgdG8gKDAsIDApIG9mIHRoZSBlbGVtZW50IGluc3RlYWRcbiAgZnJvbSA9IGZvciBwIGluIG9yaWdpbmFsUG9zXG4gICAgeDogcFswXSAtIG9yaWdpbmFsUG9zWzBdWzBdXG4gICAgeTogcFsxXSAtIG9yaWdpbmFsUG9zWzBdWzFdXG4gIHRvID0gZm9yIHAgaW4gdGFyZ2V0UG9zXG4gICAgeDogcFswXSAtIG9yaWdpbmFsUG9zWzBdWzBdXG4gICAgeTogcFsxXSAtIG9yaWdpbmFsUG9zWzBdWzFdXG5cbiAgIyBTb2x2ZSBmb3IgdGhlIHRyYW5zZm9ybVxuICBIID0gZ2V0VHJhbnNmb3JtKGZyb20sIHRvKVxuICBcbiAgIyBBcHBseSB0aGUgbWF0cml4M2QgYXMgSCB0cmFuc3Bvc2VkIGJlY2F1c2UgbWF0cml4M2QgaXMgY29sdW1uIG1ham9yIG9yZGVyXG4gICMgQWxzbyBuZWVkIHVzZSB0b0ZpeGVkIGJlY2F1c2UgY3NzIGRvZXNuJ3QgYWxsb3cgc2NpZW50aWZpYyBub3RhdGlvblxuICAkKGVsZW1lbnQpLmNzc1xuICAgICd0cmFuc2Zvcm0nOiBcIm1hdHJpeDNkKCN7KEhbal1baV0udG9GaXhlZCgyMCkgZm9yIGogaW4gWzAuLi40XSBmb3IgaSBpbiBbMC4uLjRdKS5qb2luKCcsJyl9KVwiXG4gICAgJ3RyYW5zZm9ybS1vcmlnaW4nOiAnMCAwJ1xuXG4gIGNhbGxiYWNrPyhlbGVtZW50LCBIKVxuXG5tYWtlVHJhbnNmb3JtYWJsZSA9IChzZWxlY3RvciwgY2FsbGJhY2spIC0+XG4gICQoc2VsZWN0b3IpLmVhY2ggKGksIGVsZW1lbnQpIC0+XG4gICAgJChlbGVtZW50KS5jc3MoJ3RyYW5zZm9ybScsICcnKVxuICAgIFxuICAgICMgQWRkIGZvdXIgZG90cyB0byBjb3JuZXJzIG9mIGBlbGVtZW50YCBhcyBjb250cm9sIHBvaW50c1xuICAgIGNvbnRyb2xQb2ludHMgPSBmb3IgcG9zaXRpb24gaW4gWydsZWZ0IHRvcCcsICdsZWZ0IGJvdHRvbScsICdyaWdodCB0b3AnLCAncmlnaHQgYm90dG9tJ11cbiAgICAgICQoJzxkaXY+JylcbiAgICAgICAgLmNzc1xuICAgICAgICAgIGJvcmRlcjogJzEwcHggc29saWQgYmxhY2snXG4gICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTBweCdcbiAgICAgICAgICBjdXJzb3I6ICdtb3ZlJ1xuICAgICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnXG4gICAgICAgICAgekluZGV4OiAxMDAwMDBcbiAgICAgICAgLmFwcGVuZFRvICdib2R5J1xuICAgICAgICAucG9zaXRpb25cbiAgICAgICAgICBhdDogcG9zaXRpb25cbiAgICAgICAgICBvZjogZWxlbWVudFxuICAgICAgICAgIGNvbGxpc2lvbjogJ25vbmUnXG5cbiAgICAjIFJlY29yZCB0aGUgb3JpZ2luYWwgcG9zaXRpb25zIG9mIHRoZSBkb3RzXG4gICAgb3JpZ2luYWxQb3MgPSAoW3Aub2Zmc2V0KCkubGVmdCwgcC5vZmZzZXQoKS50b3BdIGZvciBwIGluIGNvbnRyb2xQb2ludHMpXG4gICAgXG4gICAgIyBUcmFuc2Zvcm0gYGVsZW1lbnRgIHRvIG1hdGNoIHRoZSBuZXcgcG9zaXRpb25zIG9mIHRoZSBkb3RzIHdoZW5ldmVyIGRyYWdnZWRcbiAgICAkKGNvbnRyb2xQb2ludHMpLmRyYWdnYWJsZVxuICAgICAgc3RhcnQ6ID0+XG4gICAgICAgICQoZWxlbWVudCkuY3NzKCdwb2ludGVyLWV2ZW50cycsICdub25lJykgIyBtYWtlcyBkcmFnZ2luZyBhcm91bmQgaWZyYW1lcyBlYXNpZXIgXG4gICAgICBkcmFnOiA9PiBcbiAgICAgICAgYXBwbHlUcmFuc2Zvcm0oZWxlbWVudCwgb3JpZ2luYWxQb3MsIChbcC5vZmZzZXQoKS5sZWZ0LCBwLm9mZnNldCgpLnRvcF0gZm9yIHAgaW4gY29udHJvbFBvaW50cyksIGNhbGxiYWNrKVxuICAgICAgc3RvcDogPT4gXG4gICAgICAgIGFwcGx5VHJhbnNmb3JtKGVsZW1lbnQsIG9yaWdpbmFsUG9zLCAoW3Aub2Zmc2V0KCkubGVmdCwgcC5vZmZzZXQoKS50b3BdIGZvciBwIGluIGNvbnRyb2xQb2ludHMpLCBjYWxsYmFjaylcbiAgICAgICAgJChlbGVtZW50KS5jc3MoJ3BvaW50ZXItZXZlbnRzJywgJ2F1dG8nKVxuXG4gICAgZWxlbWVudFxuXG5tYWtlVHJhbnNmb3JtYWJsZSgnLmJveCcsIChlbGVtZW50LCBIKSAtPlxuICBjb25zb2xlLmxvZygkKGVsZW1lbnQpLmNzcygndHJhbnNmb3JtJykpXG4gICQoZWxlbWVudCkuaHRtbChcbiAgICAkKCc8dGFibGU+JylcbiAgICAgIC5hcHBlbmQoXG4gICAgICAgICQoJzx0cj4nKS5odG1sKFxuICAgICAgICAgICQoJzx0ZD4nKS50ZXh0KCdtYXRyaXgzZCgnKVxuICAgICAgICApXG4gICAgICApXG4gICAgICAuYXBwZW5kKFxuICAgICAgICBmb3IgaSBpbiBbMCAuLi4gNF1cbiAgICAgICAgICAkKCc8dHI+JykuYXBwZW5kKFxuICAgICAgICAgICAgZm9yIGogaW4gWzAgLi4uIDRdXG4gICAgICAgICAgICAgICQoJzx0ZD4nKS50ZXh0KEhbal1baV0gKyBpZiBpID09IGogPT0gMyB0aGVuICcnIGVsc2UgJywnKVxuICAgICAgICAgIClcbiAgICAgIClcbiAgICAgIC5hcHBlbmQoXG4gICAgICAgICQoJzx0cj4nKS5odG1sKFxuICAgICAgICAgICQoJzx0ZD4nKS50ZXh0KCcpJylcbiAgICAgICAgKVxuICAgICAgKVxuICApXG4pIl19
//# sourceURL=coffeescript