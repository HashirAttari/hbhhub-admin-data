# Minimal CSS 3D Cube

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/gOYywZo](https://codepen.io/aaroniker/pen/gOYywZo).

