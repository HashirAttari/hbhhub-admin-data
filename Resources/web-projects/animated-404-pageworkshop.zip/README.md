# Animated 404 Page - Workshop

A Pen created on CodePen.io. Original URL: [https://codepen.io/amyleeux/pen/jGbxoR](https://codepen.io/amyleeux/pen/jGbxoR).

