# Stopwatch

A Pen created on CodePen.io. Original URL: [https://codepen.io/emilcarlsson/pen/yzgjOy](https://codepen.io/emilcarlsson/pen/yzgjOy).

Simple JavaScript stopwatch.