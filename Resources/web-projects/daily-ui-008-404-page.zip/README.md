# Daily UI #008 404 Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/emilcarlsson/pen/Pzrqdo](https://codepen.io/emilcarlsson/pen/Pzrqdo).

