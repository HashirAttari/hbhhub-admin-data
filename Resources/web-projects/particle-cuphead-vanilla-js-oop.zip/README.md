# Particle Cuphead Vanilla JS OOP

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/VwyggPo](https://codepen.io/franksLaboratory/pen/VwyggPo).

