# Date Range Picker

A Pen created on CodePen.io. Original URL: [https://codepen.io/petethepig/pen/PZqVqq](https://codepen.io/petethepig/pen/PZqVqq).

Date range picker component. Can be integrated with jQuery or Knockout js. Documentation: http://sensortower.github.io/daterangepicker/