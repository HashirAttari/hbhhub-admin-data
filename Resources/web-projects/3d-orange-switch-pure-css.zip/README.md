# 3D Orange Switch (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/jOwjmJe](https://codepen.io/ykadosh/pen/jOwjmJe).

A 3D switch concept based on Voicu Apostol's desgin: 
 https://dribbble.com/shots/16562606-3D-Orange-Switch