function reverseList() {
  var ul1 = document.getElementById('ul1');
  var li1 = document.getElementById('li1');
  var li2 = document.getElementById('li2');
  var li3 = document.getElementById('li3');
  var li4 = document.getElementById('li4');
  var li5 = document.getElementById('li5');
  
  ul1.removeChild(ul1.childNodes[0]);
  ul1.removeChild(ul1.childNodes[1]);
  ul1.removeChild(ul1.childNodes[2]);
  ul1.removeChild(ul1.childNodes[3]);
  ul1.removeChild(ul1.childNodes[4]);
  
  ul1.appendChild(li5);
  ul1.appendChild(li4);
  ul1.appendChild(li3);
  ul1.appendChild(li2);
  ul1.appendChild(li1);
}