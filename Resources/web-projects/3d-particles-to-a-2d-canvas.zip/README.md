# 3D particles to a 2D canvas

A Pen created on CodePen.io. Original URL: [https://codepen.io/borian/pen/navyYY](https://codepen.io/borian/pen/navyYY).

HTML5 Canvas - Projecting 3D particles to a 2D canvas.
from rectangleworld.com

added JQuery slider to resize