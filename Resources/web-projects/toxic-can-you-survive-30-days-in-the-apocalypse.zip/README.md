# Toxic. Can you survive 30 days in the apocalypse?

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/MWYKzaq](https://codepen.io/jcoulterdesign/pen/MWYKzaq).

