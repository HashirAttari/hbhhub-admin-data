# lines in a circle

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/OJjmdJE](https://codepen.io/amit_sheen/pen/OJjmdJE).

