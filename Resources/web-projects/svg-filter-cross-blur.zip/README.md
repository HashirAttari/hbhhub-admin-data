#  SVG Filter — Cross Blur

A Pen created on CodePen.io. Original URL: [https://codepen.io/rodzyk/pen/KKEgQeG](https://codepen.io/rodzyk/pen/KKEgQeG).

