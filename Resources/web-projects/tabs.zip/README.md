# Tabs

A Pen created on CodePen.io. Original URL: [https://codepen.io/jdniki/pen/PzZERJ](https://codepen.io/jdniki/pen/PzZERJ).

