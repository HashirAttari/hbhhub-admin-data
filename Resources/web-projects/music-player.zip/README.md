# Music Player

A Pen created on CodePen.io. Original URL: [https://codepen.io/emilcarlsson/pen/aOYbmK](https://codepen.io/emilcarlsson/pen/aOYbmK).

Playing around with a music player mockup.

This is a work in progress.