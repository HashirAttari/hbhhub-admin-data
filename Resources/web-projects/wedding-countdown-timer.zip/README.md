# Wedding Countdown Timer

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/rppQoB](https://codepen.io/run-time/pen/rppQoB).

