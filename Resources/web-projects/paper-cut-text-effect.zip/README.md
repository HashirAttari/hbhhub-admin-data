# Paper Cut Text Effect! ✂️

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/PoWgbbj](https://codepen.io/ykadosh/pen/PoWgbbj).

This effect is achieved by layering 3 instances of the text, one for the cutoff, one for the overlaying characters, and one for the shadow.

The text is selectable just like regular text.