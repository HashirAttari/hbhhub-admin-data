const title =[...document.querySelectorAll('#title-animation')]

const char = Splitting({target:title})

const word = Splitting({target:title, by:'word'})

const line = Splitting({target:title, by:'lines'})