# SVG Triangle Hover/Page Transition

A Pen created on CodePen.io. Original URL: [https://codepen.io/ramsaylanier/pen/QbqMeK](https://codepen.io/ramsaylanier/pen/QbqMeK).

Using trianglify javascript plugin and GSAP, this effect animates svg triangles in and out on hover, and then provides a neat post loading transition effect when a post title is clicked. 