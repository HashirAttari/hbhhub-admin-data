# QR Code generator with Lego bricks

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/wvoMbWx](https://codepen.io/agalliat/pen/wvoMbWx).

