# Latest transactions

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/PoWbeoZ](https://codepen.io/havardob/pen/PoWbeoZ).

Concept component displaying your latest money transactions. 


Inspired by this Dribbble shot: https://dribbble.com/shots/15301605-Banking-Dashboard/attachments/7056969?mode=media 