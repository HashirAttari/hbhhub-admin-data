# Canvas Cloth with Strings

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/EPZyvm](https://codepen.io/leenalavanya/pen/EPZyvm).

Let it sway.