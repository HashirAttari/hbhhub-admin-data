var c = document.getElementById("c");
var ctx = c.getContext('2d');
ctx.lineWidth = 1;
var boxWidth = 5;
var boxHeight = 5;
var verticalLimit = c.height - 79;
var range = -2;
var change = 0.1;
var linesNumber = (c.width - 40) / boxWidth + ((verticalLimit - 20) / boxHeight) + 1;
var times = -1 * boxWidth;
var times2 = 0;
var con = document.getElementById('console');
var i;

function drawCircle() {
	ctx.clearRect(0, 0, c.width, c.height);
	var img = document.getElementById("canv");
	var pat = ctx.createPattern(img, "repeat");
	ctx.strokeStyle = pat;
	times = 20;
	times2 = 20;
	loadBackground(range * 1.2, 0);
	i = 0;
	for (i = 0; i < linesNumber; i++) {
		if (times <= c.width - 20) {
			ctx.beginPath();
			ctx.moveTo(times, 10);
			ctx.quadraticCurveTo(times + range * 3, verticalLimit - 200, times + range, verticalLimit);
			ctx.stroke();
			times += boxWidth;
		} else if (times2 <= verticalLimit) {
			ctx.beginPath();
			ctx.moveTo(12, times2);
			ctx.lineTo(c.width - 12, times2);
			ctx.stroke();
			times2 += boxHeight;
		}
	}
	window.setTimeout(drawCircle, 1000 / 60);
	if (range >= 2) {
		change = -0.1;
	} else if (range <= -2) {
		change = 0.1;
	}
	range += change
}

var ct = document.getElementById('canv');
ct.width = c.width;
ct.height = c.height;
var ctxt = ct.getContext('2d');
var imgt = document.getElementById('imgt');

function loadBackground(a, b) {
	ctxt.drawImage(imgt, a, b, c.width + a, c.height + b)
}

function isOnString(a, b) {
	con.innerHTML = "Point: " + a + ',' + b;
}

drawCircle()