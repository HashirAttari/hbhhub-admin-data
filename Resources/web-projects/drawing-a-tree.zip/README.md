# Drawing a tree

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/Lmdeae](https://codepen.io/run-time/pen/Lmdeae).

A wonderful procedural tree in a canvas