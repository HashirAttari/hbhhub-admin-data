const count = 20
let size, pallete

function setup() {
	if (innerWidth > 600)
		createCanvas(innerWidth/2, innerWidth/2)
	else
		createCanvas(innerWidth/1.5, innerWidth/1.5)
	
	size = {
		w: width/count,
		h: height/count
	}
	colorMode(HSB)
	noLoop()
	background(255);
}

const hsbPallets = [
	[0, 100],
	[50, 200],
	[150, 255],
	[0, 200],
	[100, 200]
]


function draw() {
	background(255);
	strokeWeight(random(count/3, count/1.2))
	pallete = random(hsbPallets)
	
	for(let i=0; i<count; i++){
		const x = i*size.w
		for(let j=0; j<count; j++){
			const y = j*size.h
			randomline(x, y, x + size.w, y+ size.h)
		}
	}	
	
}



function randomline(x1,y1,x2,y2) {
	const h = random(pallete[0], pallete[1])
	const s = random(pallete[0], pallete[1])
	stroke(h,s,255)
	
	if (random(0,1) > 0.5)
		line(x1, y1, x2, y2)
	else
		line(x2, y1, x1, y2)
	
	if (random(0,1) > 0.7) {
		point(x1, y2)
	}
	
	if (random(0,1) > 0.2) {
		point(x2, y2)
	}
}

function mouseClicked() {
	background(255);
	draw()
}