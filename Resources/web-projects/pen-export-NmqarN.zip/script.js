new Vue({
  el: "#app",
    data() {
    return {
      csv: null,
      selected: null,
      search: 'Bla',
      settings: {
        strokeColor: '#19B5FF',
        width: 960,
        height: 3000
      }
    }
  },

  computed: {
    // once we have the CSV loaded, the "root" will be calculated

    root() {
      var that = this

      // if (this.csv) {}
      var stratify = d3.stratify().parentId(function(d) {
        return d.id.substring(0, d.id.lastIndexOf('.'))
      })

      // attach the tree to the Vue data object
      return (
        this.csv &&
        this.tree(
          stratify(that.csv).sort(function(a, b) {
            return a.height - b.height || a.id.localeCompare(b.id)
          })
        )
      )
    },

    // the "tree" is also a computed property so that it is always up to date when the width and height settings change

    tree() {
      return d3
        .cluster()
        .size([this.settings.height, this.settings.width - 160])
    },

    // Instead of enter, update, exit, we mainly use computed properties and instead of "d3.data()" we can use array.map to create objects that hold class names, styles, and other attributes for each datum

    nodes() {
      var that = this

      return (
        this.root &&
        this.root.descendants().map(function(d) {
          return {
            id: d.id,
            value: d.data.value,
            r: 4,
            className:
              'node' + (d.children ? ' node--internal' : ' node--leaf'),
            text: d.id.substring(d.id.lastIndexOf('.') + 1),
            highlight:
              d.id.toLowerCase().indexOf(that.search.toLowerCase()) != -1 &&
              that.search != '',
            style: {
              transform: 'translate(' + d.y + 'px,' + d.x + 'px)'
            },
            textpos: {
              x: d.children ? -8 : 8,
              y: 3
            },
            textStyle: {
              textAnchor: d.children ? 'end' : 'start'
            }
          }
        })
      )
    },

    // Instead of enter, update, exit, we mainly use computed properties and instead of "d3.data()" we can use array.map to create objects that hold class names, styles, and other attributes for each datum

    links() {
      var that = this

      return (
        this.root &&
        this.root
          .descendants()
          .slice(1)
          .map(function(d) {
            return {
              id: d.id,
              d:
                'M' +
                d.y +
                ',' +
                d.x +
                'C' +
                (d.parent.y + 100) +
                ',' +
                d.x +
                ' ' +
                (d.parent.y + 100) +
                ',' +
                d.parent.x +
                ' ' +
                d.parent.y +
                ',' +
                d.parent.x,

              // here we could of course calculate colors depending on data but for now all links share the same color from the settings object that we can manipulate using UI controls and v-model

              style: {
                stroke: that.settings.strokeColor
              }
            }
          })
      )
    }
  },
  mounted() {
    var that = this

    d3.csv(
      'https://raw.githubusercontent.com/zupra/test/gh-pages/csv/flare.csv',
      function(error, data) {
        if (error) throw error

        // Load the CSV data
        // After the CSV has been loaded, the computed properties will automatically re-compute (root, tree, and then nodes & links…)

        that.csv = data
      }
    )
  },
  methods: {
    add() {
      this.csv.push({
        id: 'flare.physics.Dummy',
        value: 0
      })
    },
    select(index, node) {
      this.selected = node //`idx:${index}`;
    }
  }
});