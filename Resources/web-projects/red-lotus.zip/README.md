# Red Lotus

A Pen created on CodePen.io. Original URL: [https://codepen.io/Raphael/pen/nRvPQY](https://codepen.io/Raphael/pen/nRvPQY).

Sass + Bourbon strike again