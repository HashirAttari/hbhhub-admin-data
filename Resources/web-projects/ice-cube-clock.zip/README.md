# ICE-CUBE Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/wvPYjeL](https://codepen.io/kitjenson/pen/wvPYjeL).

inspired by: Stix - https://codepen.io/stix/pen/mVXypr
7-Segment digits made using CSS only