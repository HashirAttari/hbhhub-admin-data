# Calcoolator

A Pen created on CodePen.io. Original URL: [https://codepen.io/yagoestevez/pen/ERVONM](https://codepen.io/yagoestevez/pen/ERVONM).

Project of a calculator made for the FreeCodeCamp curriculum.