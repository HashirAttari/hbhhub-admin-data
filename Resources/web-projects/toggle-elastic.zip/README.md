# Toggle Elastic

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/yLrJvPJ](https://codepen.io/alvaromontoro/pen/yLrJvPJ).

inspired by Josetxu's https://codepen.io/josetxu/pen/mdQePNo