# Styled native range input #3 (updated 2020)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/PwOPMG](https://codepen.io/thebabydino/pen/PwOPMG).

**February 2020 update**

Turned it into an actual two thumb slider - the technique used is explained in a series of two articles ([one](https://css-tricks.com/multi-thumb-sliders-particular-two-thumb-case/) and [two](https://css-tricks.com/multi-thumb-sliders-general-case/)). Used `datalist` for tick marks/ tick labels (see [this twitter thread](https://twitter.com/anatudor/status/1225113768629325825)). Hopefully accessible.

See my other styled sliders in [this collection](https://codepen.io/collection/DgYaMj?sort_by=id).

---

If the work I've been putting out since early 2012 has helped you in any way or you just like it and you wish me to be able to continue putting out stuff, please consider one of the following:

* being a cool cat 😼🎩 and becoming a patron on Patreon

[![become a patron button](https://assets.codepen.io/2017/btn_patreon.png)](https://www.patreon.com/anatudor)

* making a one time donation via Ko-fi

[![ko-fi](https://assets.codepen.io/2017/btn_kofi.svg)](https://ko-fi.com/anatudor)

* making a weekly anonymous donation via Liberapay 

[![Liberapay](https://assets.codepen.io/2017/btn_liberapay.svg)](https://liberapay.com/anatudor/)

* getting me something off my Amazon WishList 

[🎁 🇺🇸](https://www.amazon.com/gp/registry/wishlist/2Y3C4722GXH0I/)

[🎁 🇬🇧](https://www.amazon.co.uk/gp/registry/wishlist/2I25W7U0KADSR/)

[🎁 🇩🇪](https://www.amazon.de/hz/wishlist/ls/IB791KQETDEA)

[🎁 🇫🇷](https://www.amazon.fr/hz/wishlist/ls/3KS098MMUUUPX)

* or at least sharing this to show the world what can be done with CSS these days

Thank you!

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need the JS, Firefox and Chrome/ Opera rely on it a bit for styling. There's a bit of an extra in Chrome/ Opera with a nicely styled tooltip. This is done using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). IE also has the value in a tooltip (no JS needed for updating in this case), but I have no clue how to style that asshole... Fallback for no JS: simply display the same background for the entire track, both before and after the thumb and no tooltip (well, except for the ugly one in IE). 

---

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design stuff would result in something that looks like a cat that's been washed in a washing machine puked it. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found.

Original design I tried to reproduce here: [Clean Slider](https://www.uipixels.com/clean-sliderpsd/) ([via](https://i.imgur.com/eA5cRDa.jpg)).