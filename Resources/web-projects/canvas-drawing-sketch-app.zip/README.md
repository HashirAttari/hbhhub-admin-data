# Canvas Drawing/Sketch App

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/zvGmZZ](https://codepen.io/leenalavanya/pen/zvGmZZ).

A Complete HTML5 Canvas Drawing App for Laptops and Mobile.
Works on all laptops and tablets.
Comes with 'undo', clear, download and save function and 10 preset colours.