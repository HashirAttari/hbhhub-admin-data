# Mac OS X

A Pen created on CodePen.io. Original URL: [https://codepen.io/Farctated/pen/LYQGRz](https://codepen.io/Farctated/pen/LYQGRz).

Simple Operating System concept Based on /Venerons/Pen/GogIv.
The docks are apple icons... 