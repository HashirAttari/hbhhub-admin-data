# Morphing Emoji Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/GRRVWvE](https://codepen.io/aaroniker/pen/GRRVWvE).

From https://dribbble.com/shots/8205174-Mood-Tracking-Emoji-Morphing