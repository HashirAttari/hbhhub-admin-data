# Sexy input box

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/GgxGzv](https://codepen.io/jcoulterdesign/pen/GgxGzv).

Just messing around with :valid and :invalid selectors. Seems to work fine in chrome and firefox (Although there is a light outline around the tick on firefox that i cant seem to get rid of). I think ill be adding some more to this pen at some point