# Random City

A Pen created on CodePen.io. Original URL: [https://codepen.io/ddietle/pen/zBjoRJ](https://codepen.io/ddietle/pen/zBjoRJ).

Builds a 3D city randomly, sizes the window, and gives you a nice 5 minute day that starts with your current time

Update: I made some major improvements that reduce the number of elements created by an order of magnitude