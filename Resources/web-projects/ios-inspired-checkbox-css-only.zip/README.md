# iOS-inspired checkbox | CSS only

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/RajdNR](https://codepen.io/havardob/pen/RajdNR).

Checkbox with design inspired by the iOS-toggle buttons. 