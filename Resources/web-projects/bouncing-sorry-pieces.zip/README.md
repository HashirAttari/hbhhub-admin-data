# Bouncing Sorry Pieces

A Pen created on CodePen.io. Original URL: [https://codepen.io/WithAnEs/pen/yyMExE](https://codepen.io/WithAnEs/pen/yyMExE).

Animation test for the #sorry project to see if I can make a sorry game piece moving down the board animation. Tougher to come up with a good animation on top down. Want it to look like it's hopping from left to right edge.