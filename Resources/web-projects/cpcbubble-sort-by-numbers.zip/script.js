window.CP.PenTimer.MAX_TIME_IN_LOOP_WO_EXIT = 6000;

document.addEventListener("DOMContentLoaded", function () {
    const generateBtn = document.getElementById("generateBtn");
    const sortBtn = document.getElementById("sortBtn");
    const bubbleArea = document.getElementById("bubbleArea");
    //let bubbles = [];
    const TOTAL_BUBBLES = 50;
    const DELAY =200;
    let random_hue = 100;

    generateBtn.addEventListener("click", generateBubbles);
    sortBtn.addEventListener("click", startSort);

  function generateBubbles() {
      bubbles = [];
      bubbleArea.innerHTML = "";
      const min = 1; // min width of bubble
      const max = 100; // max width of bubble
      const delay = 0; 
      let index = 0;
      random_hue = getRandom(1,255)

      sortBtn.disabled = true;

      function appendBubbleWithDelay() {
          if (index < TOTAL_BUBBLES) {
              const random = getRandom(min,max);
              
              const baseColor = getRandomColor();
              const bubble = document.createElement("div");
              bubble.classList.add("bubble");
              bubble.innerText = random;
              // Assign background color based on width and base color
              bubble.style.backgroundColor = getColor(random, baseColor);
              // bubbles.push(bubble);
              bubbleArea.append(bubble);
              setTimeout(() => bubble.style.opacity = "100%",50);
              index++;
              setTimeout(appendBubbleWithDelay, delay); 

              // enable "sort" button
              if (index == TOTAL_BUBBLES) {
                  sortBtn.disabled = false;
              }
          }
      }
      appendBubbleWithDelay();
  }
  // generate random number between given
  function getRandom(min,max){
    return  Math.floor(Math.random() * (max - min + 1)) + min
  }
  
  // define base color
  function getColor(random, baseColor) {
      let hue = random_hue - (random / 100 * 60); 
      return `hsl(${hue}, 100%, 50%)`;
  }

  function getRandomColor() {
      const seed = Math.floor(Math.random() * 1000000);
      const hue = (seed * 102) % 360; 
      const saturation = Math.floor(Math.random() * 101);
      const lightness = Math.floor(Math.random() * 51) + 25;
      return `hsl(${hue}, ${saturation}%, ${lightness}%)`; 
  }


  function startSort() {
      generateBtn.disabled = true;
      sortBtn.disabled = true;
      let bubbles = Array.from(document.querySelectorAll(".bubble"));
      bubbleSort(bubbles, bubbles.length);
  }

  async function bubbleSort(bubbles) {
      let length = bubbles.length;
      for (let i = 0; i < length - 1; i++) {
          for (let j = 0; j < length - i - 1; j++) {
              let k = j + 1;
              let value1 = parseInt(bubbles[j].textContent);
              let value2 = parseInt(bubbles[k].textContent);
              
              bubbles[j].classList.add('active');
               bubbles[k].classList.add('active');
            
              if (value1 > value2) {
                  // Swap the bubbles in the array
                  [bubbles[j], bubbles[k]] = [bubbles[k], bubbles[j]];
                  // Move the bubbles in the DOM 
                  await swapWithDelay(bubbles[k], bubbles[j]);
              }
            
            bubbles[j].classList.remove("active");
       	  bubbles[k].classList.remove("active");
          }
        
          
        
          bubbles[length - i - 1].classList.add('sorted');
          bubbles[length - i - 1].style.zIndex = length - i; // Adjusted zIndex calculation
      }

      // Add the 'sorted' class to the first element 
      bubbles[0].classList.add('sorted');

      // enable button to start again
      generateBtn.disabled = false;
  }

  function swapWithDelay(bubble1, bubble2) {
      return new Promise(resolve => {
          setTimeout(() => {
              bubbleArea.insertBefore(bubble2, bubble1);
              resolve();
          }, DELAY); 
      });
  }

	
	
	generateBubbles()
});