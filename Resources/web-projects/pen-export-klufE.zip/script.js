document.addEventListener('DOMContentLoaded', function () {
    var counter = setInterval(function() {
      var numberElem = document.getElementById('number');
      numberElem.innerHTML = parseInt(numberElem.innerHTML) + 1;
      if ( parseInt(numberElem.innerHTML) == 100 ) {
        clearInterval(counter);
      }
    }, 7500/98);
  });