const _C = document.getElementById('c') /* canvas element */,
C = _C.getContext('2d') /* 2L canvas context */,
D = _C.width /* edge length of canvas square */,
N = 24 /* numbers of rows/ columns */,
NP = N * N /* total number of polygons */,
L = D / N /* edge length of a grid cell */,
RC = .375 * L /* max circumradius of in-cell polygon */,
UA = ~~(360 / (N - 1)),

THEME = ['#8ba6ac', '#d7d7b8', '#bdcdd0', '#e5e6c9'],
NT = THEME.length,
NVMAX = 8,
NVMIN = 3,
NVDIF = NVMAX - NVMIN,

OPTS = ['fill', 'stroke'],
NO = OPTS.length,

POLY = [] /* array of polygons */,
FN = ['line', 'move'];

function rand(max = 1, min = 0, dec = 0) {
  return +(min + (max - min) * Math.random()).toFixed(dec);
};

class Poly {
  constructor(i, j) {
    this.i = .5 * N - ~~Math.abs(i - .5 * (N - 1)); /* row index */
    this.j = .5 * N - ~~Math.abs(j - .5 * (N - 1)); /* column index */

    /* coordinates of circumcircle centre */
    this.ox = (j + .5) * L;
    this.oy = (i + .5) * L;

    this.n = NVMIN; /* number of polygon vertices */
    this.β = 2 * Math.PI / this.n; /* base angle corresponding to an edge */
    this.δ = Math.round((this.i + this.j) * UA); /* initial angular offset of pulse */
    this.f = .5 * (1 - Math.cos(this.δ * Math.PI / 180)); /* scaling factor */
    this.b = ~~(Math.round(Math.atan2(this.oy - .5 * D, this.ox - .5 * D) * 180 / Math.PI + 180) / 90); /* paint bucket index */
    this.o = (this.i + this.j) % 2;
    this.vx = [];

    for (let k = 0; k < this.n; k++) {
      let γ = -.5 * (Math.PI + (this.n + 1) % 2 * this.β) + k * this.β;

      this.vx.push([RC * Math.cos(γ), RC * Math.sin(γ)]);
    }
  }

  get coords() {
    this.δ += .25 * UA;

    if (this.δ >= 360) {
      this.δ = 0;
      this.n += this.n === NVMAX ? -NVDIF : 1;
      this.β = 2 * Math.PI / this.n;
      this.b += this.b === NT - 1 ? 1 - NT : 1;
      this.o = 1 - this.o;

      this.vx = [];

      for (let k = 0; k < this.n; k++) {
        let γ = -.5 * (Math.PI + (this.n + 1) % 2 * this.β) + k * this.β;

        this.vx.push([RC * Math.cos(γ), RC * Math.sin(γ)]);
      }
    }

    this.f = .5 * (1 - Math.cos(this.δ * Math.PI / 180));

    return this.vx.map(c => [
    this.ox + this.f * c[0],
    this.oy + this.f * c[1]]);

  }}
;

function draw() {
  C.clearRect(0, 0, D, D); /* clean canvas before drawing again */

  for (let i = 0; i < NT; i++) {
    let b = POLY.filter(c => c.b === i); /* polygons in current bucket */

    for (let j = 0; j < NO; j++) {
      let o = b.filter(c => c.o === j); /* polygons with current option */

      C[`${OPTS[j]}Style`] = THEME[i]; /* set stroke or fill */
      C.beginPath();

      o.forEach(c => {
        let coords = c.coords; /* current poly absolute coordinate array */

        for (let k = 0; k <= c.n; k++)
        C[`${FN[0 ** k]}To`](...coords[k % c.n]);
      });

      C.closePath();
      C[OPTS[j]]();
    }
  }

  requestAnimationFrame(draw);
};

function init() {
  for (let i = 0; i < N; i++) {
    for (let j = 0; j < N; j++) {
      POLY.push(new Poly(i, j));
    }
  }

  C.globalCompositeOperation = 'overlay';
  draw();
};

init();