# Color Separation | A Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/eadVNd](https://codepen.io/joshonweb/pen/eadVNd).

With the help of css variables and two keyframe animation  the separation of color is created.  This is a loader whose loading dots are spinning so fast their colors are separating.
Using the  svg filter goo effect and animation of color creates the illusion of these primary color mixing together to create a secondary color.