# HTML + CSS Keyboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/gschier/pen/VKgyaY](https://codepen.io/gschier/pen/VKgyaY).

This is a Mac keyboard made in HTML and CSS. There is some JavaScript to control the keys, but that's it.