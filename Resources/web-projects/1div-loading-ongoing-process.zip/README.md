# 1div Loading... [ongoing process]

A Pen created on CodePen.io. Original URL: [https://codepen.io/iGadget/pen/aZmEGR](https://codepen.io/iGadget/pen/aZmEGR).

A simple "1 div" Element loader collection