# CSS Art: Dragon riding an unicycle

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/YzOjOWQ](https://codepen.io/alvaromontoro/pen/YzOjOWQ).

