# Skeuomorphic Toggle Switch (vol. 4)

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/WNaqEgp](https://codepen.io/nicolasjesenberger/pen/WNaqEgp).

Design by @sanbronliong on Twitter