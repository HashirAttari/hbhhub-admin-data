console.clear();
const app = document.querySelector("#app");
const images = [...document.querySelectorAll(".wrap")];

let state = {
	photo: 0
};

function send(event) {
	const actives = document.querySelectorAll("[data-active]");
	const removeActives =
		actives && actives.forEach(el => el.removeAttribute("data-active"));
	switch (event) {
		case "next":
			state.photo =
				 Math.min(state.photo + 1, images.length - 1);
			break;
		case "prev":
			state.photo =
				 Math.max(state.photo - 1, 0);
	}
	console.log(state.photo);
	const setActive = document.querySelector(`[data-key="${state.photo}"]`);
	setActive.dataset.active = "true";
}
const next = document.querySelector('[data-dir="next"]')
const prev = document.querySelector('[data-dir="prev"]')

next.addEventListener('click', function(){
	send("next")
})
prev.addEventListener('click', function(){
	send("prev")
	console.log('prev')
})