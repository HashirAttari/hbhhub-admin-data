# Animated slideshow

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/WBepMa](https://codepen.io/joshonweb/pen/WBepMa).

A Slide show.  Simple version of a slider that the @keyframers created