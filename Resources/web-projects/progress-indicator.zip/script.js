let progress = 0;

const progressIndicator = document.querySelector('.progressIndicator');
const progressText = progressIndicator.querySelector('text');

function updateIndicator() {
  progressIndicator.style.setProperty('--progress', progress);
  progressText.textContent = `${Math.floor(progress)}%`;
  
  if (progress === 100) {
    progressIndicator.classList.add('done');
  }
}

//mocking progress calls
function mockProgress() {
  progress = Math.min(100, progress + Math.random() * 25 + 5);
  updateIndicator();
  
  if (progress < 100) {
    setTimeout(mockProgress, 1000);
  }
}
setTimeout(mockProgress, 1000);