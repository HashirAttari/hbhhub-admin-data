# Hide/reveal password

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/geLNwN](https://codepen.io/ainalem/pen/geLNwN).

A playful micro interaction animation to hide and reveal the password. Uses morphing and translation