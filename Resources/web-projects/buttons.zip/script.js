// TODO:
// * Shadows
// * Selected states
// * Consider larger sizes
// * Consider darker primary buttons

const icons12 = {
  'down-chevron': { paths: '<path fill-rule="evenodd" clip-rule="evenodd" d="M1.29289 3.29289C1.68342 2.90237 2.31658 2.90237 2.70711 3.29289L6 6.58579L9.29289 3.29289C9.68342 2.90237 10.3166 2.90237 10.7071 3.29289C11.0976 3.68342 11.0976 4.31658 10.7071 4.70711L6.70711 8.70711C6.31658 9.09763 5.68342 9.09763 5.29289 8.70711L1.29289 4.70711C0.902369 4.31658 0.902369 3.68342 1.29289 3.29289Z" />' },
  'date': { paths: '<path fill-rule="evenodd" clip-rule="evenodd" d="M5 2.99999H7V3.99999C7 4.55228 7.44772 4.99999 8 4.99999C8.55228 4.99999 9 4.55228 9 3.99999V2.99999C9.55229 2.99999 10 3.44771 10 3.99999V8.99999C10 9.55228 9.55229 9.99999 9 9.99999H3C2.44772 9.99999 2 9.55228 2 8.99999V3.99999C2 3.44771 2.44772 2.99999 3 2.99999L3 3.99999C3 4.55228 3.44772 4.99999 4 4.99999C4.55228 4.99999 5 4.55228 5 3.99999V2.99999ZM9 0.999996C10.6569 0.999992 12 2.34314 12 3.99999V8.99999C12 10.6568 10.6569 12 9 12H3C1.34315 12 0 10.6568 0 8.99999V3.99999C0 2.34314 1.34315 0.999992 3 0.999992C3 0.447709 3.44772 -3.8147e-06 4 -3.8147e-06C4.55228 -3.8147e-06 5 0.447709 5 0.999992H7C7 0.447709 7.44772 -3.8147e-06 8 -3.8147e-06C8.55228 -3.8147e-06 9 0.447711 9 0.999996Z" />' },
  'plus': { paths: '<path fill-rule="evenodd" clip-rule="evenodd" d="M6 0C6.55228 0 7 0.447715 7 1V5H11C11.5523 5 12 5.44772 12 6C12 6.55228 11.5523 7 11 7H7V11C7 11.5523 6.55228 12 6 12C5.44772 12 5 11.5523 5 11V7H1C0.447715 7 0 6.55228 0 6C0 5.44772 0.447715 5 1 5H5V1C5 0.447715 5.44772 0 6 0Z" />' },
  'chat': { paths: '<path fill-rule="evenodd" clip-rule="evenodd" d="M2 3C2 2.44772 2.44772 2 3 2H9C9.55228 2 10 2.44772 10 3V6.52786C10 7.66418 9.35799 8.70297 8.34164 9.21115L7.91583 9.42405C7.66851 8.60023 6.90435 8 6 8H3C2.44772 8 2 7.55228 2 7V3ZM3 0C1.34315 0 0 1.34315 0 3V7C0 8.65685 1.34315 10 3 10H6V11C6 11.3466 6.17945 11.6684 6.47427 11.8507C6.76909 12.0329 7.13723 12.0494 7.44721 11.8944L9.23607 11C10.93 10.153 12 8.42172 12 6.52786V3C12 1.34315 10.6569 0 9 0H3ZM4 4C3.44772 4 3 4.44772 3 5C3 5.55228 3.44772 6 4 6H8C8.55228 6 9 5.55228 9 5C9 4.44772 8.55228 4 8 4H4Z" />' },
  'left-arrow': { paths: '<path fill-rule="evenodd" clip-rule="evenodd" d="M11 6C11 6.55228 10.5523 7 10 7H4.41421L6.70711 9.29289C7.09763 9.68342 7.09763 10.3166 6.70711 10.7071C6.31658 11.0976 5.68342 11.0976 5.29289 10.7071L1.29289 6.70711C0.902369 6.31658 0.902369 5.68342 1.29289 5.29289L5.29289 1.29289C5.68342 0.902369 6.31658 0.902369 6.70711 1.29289C7.09763 1.68342 7.09763 2.31658 6.70711 2.70711L4.41421 5H10C10.5523 5 11 5.44772 11 6Z" />' },
  'right-arrow': { paths: '<path fill-rule="evenodd" clip-rule="evenodd" d="M1 6C1 5.44772 1.44772 5 2 5H7.58579L5.29289 2.70711C4.90237 2.31658 4.90237 1.68342 5.29289 1.29289C5.68342 0.902369 6.31658 0.902369 6.70711 1.29289L10.7071 5.29289C11.0976 5.68342 11.0976 6.31658 10.7071 6.70711L6.70711 10.7071C6.31658 11.0976 5.68342 11.0976 5.29289 10.7071C4.90237 10.3166 4.90237 9.68342 5.29289 9.29289L7.58579 7H2C1.44772 7 1 6.55229 1 6Z" />' },
  'filter': { paths: '<path fill-rule="evenodd" clip-rule="evenodd" d="M0 2C0 1.44772 0.447715 1 1 1H11C11.5523 1 12 1.44772 12 2C12 2.55228 11.5523 3 11 3H1C0.447715 3 0 2.55228 0 2ZM2 6C2 5.44772 2.44772 5 3 5H9C9.55229 5 10 5.44772 10 6C10 6.55228 9.55229 7 9 7H3C2.44772 7 2 6.55228 2 6ZM4 10C4 9.44772 4.44772 9 5 9H7C7.55228 9 8 9.44772 8 10C8 10.5523 7.55228 11 7 11H5C4.44772 11 4 10.5523 4 10Z" />' },
  'more': { paths: '<path fill-rule="evenodd" clip-rule="evenodd" d="M7.5 1.5C7.5 2.32843 6.82843 3 6 3C5.17157 3 4.5 2.32843 4.5 1.5C4.5 0.671573 5.17157 0 6 0C6.82843 0 7.5 0.671573 7.5 1.5ZM7.5 6C7.5 6.82843 6.82843 7.5 6 7.5C5.17157 7.5 4.5 6.82843 4.5 6C4.5 5.17157 5.17157 4.5 6 4.5C6.82843 4.5 7.5 5.17157 7.5 6ZM6 12C6.82843 12 7.5 11.3284 7.5 10.5C7.5 9.67157 6.82843 9 6 9C5.17157 9 4.5 9.67157 4.5 10.5C4.5 11.3284 5.17157 12 6 12Z" />' },
  'trash': { paths: '<path fill-rule="evenodd" clip-rule="evenodd" d="M3.27273 1C3.27273 0.447715 3.72044 0 4.27273 0H7.54545C8.09774 0 8.54545 0.447715 8.54545 1H8.81818C10.475 1 11.8182 2.34315 11.8182 4V5C11.8182 5.54258 11.3861 5.98423 10.8472 5.99959L10.1257 10.3288C9.96493 11.2932 9.13055 12 8.15287 12H3.84713C2.86945 12 2.03507 11.2932 1.87434 10.3288L1.15287 6H1C0.447715 6 0 5.55228 0 5V4C0 2.34315 1.34315 1 3 1H3.27273ZM3.18046 6L3.84713 10H8.15287L8.81954 6H3.18046ZM9.81818 4H2C2 3.44772 2.44772 3 3 3H8.81818C9.37047 3 9.81818 3.44772 9.81818 4Z" />' },
  'x': { paths: '<path fill-rule="evenodd" clip-rule="evenodd" d="M1.75736 1.75736C2.14788 1.36684 2.78104 1.36684 3.17157 1.75736L6 4.58579L8.82842 1.75736C9.21895 1.36683 9.85211 1.36684 10.2426 1.75736C10.6332 2.14788 10.6332 2.78105 10.2426 3.17157L7.41421 6L10.2426 8.82843C10.6332 9.21895 10.6332 9.85212 10.2426 10.2426C9.85211 10.6332 9.21895 10.6332 8.82842 10.2426L6 7.41421L3.17157 10.2426C2.78104 10.6332 2.14788 10.6332 1.75736 10.2426C1.36683 9.85212 1.36683 9.21895 1.75736 8.82843L4.58578 6L1.75736 3.17157C1.36683 2.78105 1.36683 2.14788 1.75736 1.75736Z" />' } };


const Icon = ({ uid, size = 24, color = '', valign, className }) => {
  let paths;
  let style = {};
  let icons = size === 24 ? ZestIcons : icons12;
  if (uid in icons) {
    paths = icons[uid].paths;
  } else {
    throw new Error('Invalid UID for icon: ' + uid);
  }
  if (valign) {
    style['verticalAlign'] = valign;
  }
  return /*#__PURE__*/(
    React.createElement("svg", { width: size, height: size, viewBox: [0, 0, size, size].join(' '), className: className, style: style }, /*#__PURE__*/
    React.createElement("g", { fill: color, dangerouslySetInnerHTML: { __html: paths } })));


};

const ButtonCaret = ({ color = '' }) => {
  const paths = icons12['down-chevron'].paths;
  return /*#__PURE__*/(
    React.createElement("svg", { width: "12", height: "12", viewBox: "0 0 12 12", className: "button-caret" }, /*#__PURE__*/
    React.createElement("g", { fill: color, dangerouslySetInnerHTML: { __html: paths } })));


};

const Button = props => {
  const { small, large, icon, leftIcon, rightIcon, left, right, applied, dropdown, selected, block, destructive, disabled, children } = props;
  const klasses = ['button'];
  const licon = icon || leftIcon;
  const ricon = rightIcon;
  const iconOnly = !children;
  const isize = small ? 12 : 24;
  internals = [];
  if (small) {klasses.push('small');}
  if (large) {klasses.push('large');}
  if (block) {klasses.push('block');}
  if (left) {klasses.push('text-left');}
  if (right) {klasses.push('text-right');}
  if (props['applied']) {klasses.push('applied');}
  if (props['primary']) {klasses.push('primary');}
  if (props['borderless']) {klasses.push('borderless');}
  if (props['destructive']) {klasses.push('destructive');}
  if (selected) {klasses.push('is-selected');}
  if (iconOnly) {
    internals.push( /*#__PURE__*/React.createElement(Icon, { className: "button-icon alone", uid: icon, size: isize }));
  } else {
    if (licon) {internals.push( /*#__PURE__*/React.createElement(Icon, { className: "button-icon left", uid: licon, size: isize }));}
    internals.push(children);
    if (ricon) {internals.push( /*#__PURE__*/React.createElement(Icon, { className: "button-icon right", uid: ricon, size: isize }));}
  }
  return /*#__PURE__*/React.createElement("button", { className: klasses.join(' '), disabled: disabled },
  internals, dropdown ? /*#__PURE__*/React.createElement(ButtonCaret, null) : '');

};

const Examples = () => {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/
  React.createElement("h2", null, "Default"), /*#__PURE__*/
  React.createElement("table", null, /*#__PURE__*/
  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Small"), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true }, "Button")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, icon: "plus" }, "Add")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, icon: "left-arrow" }, "Back")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, rightIcon: "right-arrow" }, "Next")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, dropdown: true }, "Dropdown")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, dropdown: true, icon: "filter" }, "Filter")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, icon: "plus" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, icon: "more" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, dropdown: true, icon: "filter" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, applied: true, dropdown: true, icon: "date" }, "Applied")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, destructive: true, icon: "x" }, "Destructive")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, disabled: true }, "Disabled"))), /*#__PURE__*/

  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Medium"), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, null, "Button")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { icon: "plus" }, "Add")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { icon: "left-arrow" }, "Back")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { rightIcon: "right-arrow" }, "Next")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { dropdown: true }, "Dropdown")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { dropdown: true, icon: "filter" }, "Filter")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { icon: "plus" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { icon: "more" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { dropdown: true, icon: "filter" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { applied: true, dropdown: true, icon: "calendar" }, "Applied")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { destructive: true, icon: "x" }, "Destructive")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { disabled: true }, "Disabled"))), /*#__PURE__*/

  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Large"), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true }, "Button")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, icon: "plus" }, "Add")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, icon: "left-arrow" }, "Back")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, rightIcon: "right-arrow" }, "Next")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, dropdown: true }, "Dropdown")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, dropdown: true, icon: "filter" }, "Filter")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, icon: "plus" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, icon: "more" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, dropdown: true, icon: "filter" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, applied: true, dropdown: true, icon: "calendar" }, "Applied")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, destructive: true, icon: "x" }, "Destructive")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, disabled: true }, "Disabled")))), /*#__PURE__*/



  React.createElement("h2", null, "Primary"), /*#__PURE__*/
  React.createElement("table", null, /*#__PURE__*/
  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Small"), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, primary: true }, "Button")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, primary: true, icon: "plus" }, "Add")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, primary: true, left: "left-arrow" }, "Back")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, primary: true, rightIcon: "right-arrow" }, "Next")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, primary: true, dropdown: true }, "Dropdown")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, primary: true, dropdown: true, icon: "filter" }, "Filter")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, primary: true, icon: "plus" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, primary: true, icon: "more" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, primary: true, dropdown: true, icon: "filter" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, primary: true, applied: true, dropdown: true, icon: "date" }, "Applied")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, primary: true, destructive: true, icon: "x" }, "Destructive")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, primary: true, disabled: true }, "Disabled"))), /*#__PURE__*/

  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Medium"), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { primary: true }, "Button")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { primary: true, icon: "plus" }, "Add")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { primary: true, icon: "left-arrow" }, "Back")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { primary: true, rightIcon: "right-arrow" }, "Next")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { primary: true, dropdown: true }, "Dropdown")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { primary: true, dropdown: true, icon: "filter" }, "Filter")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { primary: true, icon: "plus" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { primary: true, icon: "more" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { primary: true, dropdown: true, icon: "filter" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { primary: true, applied: true, dropdown: true, icon: "calendar" }, "Applied")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { primary: true, destructive: true, icon: "x" }, "Destructive")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { primary: true, disabled: true }, "Disabled"))), /*#__PURE__*/

  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Large"), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, primary: true }, "Button")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, primary: true, icon: "plus" }, "Add")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, primary: true, icon: "left-arrow" }, "Back")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, primary: true, rightIcon: "right-arrow" }, "Next")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, primary: true, dropdown: true }, "Dropdown")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, primary: true, dropdown: true, icon: "filter" }, "Filter")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, primary: true, icon: "plus" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, primary: true, icon: "more" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, primary: true, dropdown: true, icon: "filter" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, primary: true, applied: true, dropdown: true, icon: "calendar" }, "Applied")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, primary: true, destructive: true, icon: "x" }, "Destructive")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, primary: true, disabled: true }, "Disabled")))), /*#__PURE__*/



  React.createElement("h2", null, "Borderless"), /*#__PURE__*/
  React.createElement("table", null, /*#__PURE__*/
  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Small"), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, borderless: true }, "Button")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, borderless: true, icon: "plus" }, "Add")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, borderless: true, icon: "left-arrow" }, "Back")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, borderless: true, rightIcon: "right-arrow" }, "Next")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, borderless: true, dropdown: true }, "Dropdown")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, borderless: true, dropdown: true, icon: "filter" }, "Filter")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, borderless: true, icon: "plus" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, borderless: true, icon: "more" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, borderless: true, dropdown: true, icon: "filter" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, borderless: true, applied: true, dropdown: true, icon: "date" }, "Applied")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, borderless: true, destructive: true, icon: "x" }, "Destructive")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { small: true, borderless: true, disabled: true }, "Disabled"))), /*#__PURE__*/

  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Medium"), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { borderless: true }, "Button")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { borderless: true, icon: "plus" }, "Add")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { borderless: true, icon: "left-arrow" }, "Back")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { borderless: true, rightIcon: "right-arrow" }, "Next")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { borderless: true, dropdown: true }, "Dropdown")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { borderless: true, dropdown: true, icon: "filter" }, "Filter")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { borderless: true, icon: "plus" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { borderless: true, icon: "more" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { borderless: true, dropdown: true, icon: "filter" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { borderless: true, applied: true, dropdown: true, icon: "calendar" }, "Applied")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { borderless: true, destructive: true, icon: "x" }, "Destructive")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { borderless: true, disabled: true }, "Disabled"))), /*#__PURE__*/

  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Large"), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, borderless: true }, "Button")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, borderless: true, icon: "plus" }, "Add")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, borderless: true, icon: "left-arrow" }, "Back")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, borderless: true, rightIcon: "right-arrow" }, "Next")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, borderless: true, dropdown: true }, "Dropdown")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, borderless: true, dropdown: true, icon: "filter" }, "Filter")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, borderless: true, icon: "plus" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, borderless: true, icon: "more" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, borderless: true, dropdown: true, icon: "filter" })), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, borderless: true, applied: true, dropdown: true, icon: "calendar" }, "Applied")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, borderless: true, destructive: true, icon: "x" }, "Destructive")), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/React.createElement(Button, { large: true, borderless: true, disabled: true }, "Disabled")))), /*#__PURE__*/





  React.createElement("h2", null, "Block"), /*#__PURE__*/

  React.createElement("table", null, /*#__PURE__*/
  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Small"), /*#__PURE__*/
  React.createElement("td", { style: { width: "240px" } }, /*#__PURE__*/
  React.createElement(Button, { small: true, block: true }, "Block")), /*#__PURE__*/

  React.createElement("td", { style: { width: "240px" } }, /*#__PURE__*/
  React.createElement(Button, { small: true, block: true, icon: "chat" }, "Send Message")), /*#__PURE__*/

  React.createElement("td", { style: { width: "240px" } }, /*#__PURE__*/
  React.createElement(Button, { small: true, block: true, left: true, icon: "chat" }, "Send Message")), /*#__PURE__*/

  React.createElement("td", { style: { width: "240px" } }, /*#__PURE__*/
  React.createElement(Button, { small: true, block: true, right: true, rightIcon: "right-arrow" }, "Send Message"))), /*#__PURE__*/


  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Medium"), /*#__PURE__*/
  React.createElement("td", { style: { width: "240px" } }, /*#__PURE__*/
  React.createElement(Button, { block: true }, "Block")), /*#__PURE__*/

  React.createElement("td", { style: { width: "240px" } }, /*#__PURE__*/
  React.createElement(Button, { block: true, icon: "chat-bubble" }, "Send Message")), /*#__PURE__*/

  React.createElement("td", { style: { width: "240px" } }, /*#__PURE__*/
  React.createElement(Button, { block: true, left: true, icon: "chat-bubble" }, "Send Message")), /*#__PURE__*/

  React.createElement("td", { style: { width: "240px" } }, /*#__PURE__*/
  React.createElement(Button, { block: true, right: true, rightIcon: "right-arrow" }, "Send Message"))), /*#__PURE__*/


  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Large"), /*#__PURE__*/
  React.createElement("td", { style: { width: "240px" } }, /*#__PURE__*/
  React.createElement(Button, { large: true, block: true }, "Block")), /*#__PURE__*/

  React.createElement("td", { style: { width: "240px" } }, /*#__PURE__*/
  React.createElement(Button, { large: true, block: true, icon: "chat-bubble" }, "Send Message")), /*#__PURE__*/

  React.createElement("td", { style: { width: "240px" } }, /*#__PURE__*/
  React.createElement(Button, { large: true, block: true, left: true, icon: "chat-bubble" }, "Send Message")), /*#__PURE__*/

  React.createElement("td", { style: { width: "240px" } }, /*#__PURE__*/
  React.createElement(Button, { large: true, block: true, right: true, rightIcon: "right-arrow" }, "Send Message")))), /*#__PURE__*/




  React.createElement("h2", null, "Groups"), /*#__PURE__*/

  React.createElement("table", null, /*#__PURE__*/
  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Small"), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/
  React.createElement("div", { class: "button-group" }, /*#__PURE__*/
  React.createElement(Button, { small: true, selected: true }, "Day"), /*#__PURE__*/
  React.createElement(Button, { small: true }, "Week"), /*#__PURE__*/
  React.createElement(Button, { small: true }, "Month"))), /*#__PURE__*/


  React.createElement("td", null, /*#__PURE__*/
  React.createElement("div", { class: "button-group" }, /*#__PURE__*/
  React.createElement(Button, { small: true, borderless: true, selected: true }, "Day"), /*#__PURE__*/
  React.createElement(Button, { small: true, borderless: true }, "Week"), /*#__PURE__*/
  React.createElement(Button, { small: true, borderless: true }, "Month")))), /*#__PURE__*/



  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Medium"), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/
  React.createElement("div", { class: "button-group" }, /*#__PURE__*/
  React.createElement(Button, { selected: true }, "Day"), /*#__PURE__*/
  React.createElement(Button, null, "Week"), /*#__PURE__*/
  React.createElement(Button, null, "Month"))), /*#__PURE__*/


  React.createElement("td", null, /*#__PURE__*/
  React.createElement("div", { class: "button-group" }, /*#__PURE__*/
  React.createElement(Button, { borderless: true, selected: true }, "Day"), /*#__PURE__*/
  React.createElement(Button, { borderless: true }, "Week"), /*#__PURE__*/
  React.createElement(Button, { borderless: true }, "Month")))), /*#__PURE__*/



  React.createElement("tr", null, /*#__PURE__*/
  React.createElement("td", null, "Large"), /*#__PURE__*/
  React.createElement("td", null, /*#__PURE__*/
  React.createElement("div", { class: "button-group" }, /*#__PURE__*/
  React.createElement(Button, { large: true, selected: true }, "Apples"), /*#__PURE__*/
  React.createElement(Button, { large: true }, "Oranges"), /*#__PURE__*/
  React.createElement(Button, { large: true }, "Bananas"))), /*#__PURE__*/


  React.createElement("td", null, /*#__PURE__*/
  React.createElement("div", { class: "button-group" }, /*#__PURE__*/
  React.createElement(Button, { borderless: true, large: true, selected: true }, "Apples"), /*#__PURE__*/
  React.createElement(Button, { borderless: true, large: true }, "Oranges"), /*#__PURE__*/
  React.createElement(Button, { borderless: true, large: true }, "Bananas"))))));





};

ReactDOM.render( /*#__PURE__*/
React.createElement(Examples, null),
document.getElementById('examples'));