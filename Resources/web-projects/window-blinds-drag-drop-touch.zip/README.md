# Window Blinds (Drag&Drop&Touch)

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/LYxwmYW](https://codepen.io/kitjenson/pen/LYxwmYW).

