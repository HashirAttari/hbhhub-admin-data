const slats = document.querySelectorAll('.blind_slat')
const window_container = document.querySelector('#window_container')
const open_string = document.querySelector('#open_string')
const hero = document.querySelector('#hero-text')

open_string.addEventListener('touchmove', function(event) {
  event.preventDefault();
  var touch = event.touches[0].clientY; 
  if(touch < 0) {
    touch = 0
  }     
  var touch_perc = (touch/window.innerHeight)*100
  if(touch_perc > 90) {
    touch_perc = 90
  }  
  
  slats.forEach(function(elm) {
    if(touch_perc < 88) {
      elm.style.transform = 'rotateX('+(-1)*(touch_perc)+'deg)'  
    }
    if(touch_perc <= 5) {
      elm.style.transform = ''
    }
  })
  open_string.style.top = touch_perc+'%'
}, false);

dragElement(open_string);
function dragElement(elmnt) {
  var dist = window.innerHeight*.8
  var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  elmnt.onmousedown = dragMouseDown;

  function dragMouseDown(e) {
    e = e || window.event;
    e.preventDefault();
    // get the mouse cursor position at startup:
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    // call a function whenever the cursor moves:
    document.onmousemove = elementDrag;
    elmnt.classList.toggle('grabbing')
  }

  function elementDrag(e) {
    e = e || window.event;
    e.preventDefault();

    pos2 = pos4 - e.clientY;
    pos4 = e.clientY;
    // set the element's new position:
    var newY = elmnt.offsetTop - pos2
    var perc = (newY/window.innerHeight)*100
    if(perc < 5) {
      perc = 5
      
    }
    if(perc > 90) {
      perc = 90
    }
    elmnt.style.top = (perc) + '%'
    hero.style.opacity = '0'

    slats.forEach(function(elm) {
      if(perc < 88) {
        elm.style.transform = 'rotateX('+(-1)*(perc)+'deg)'       
      }
      if(perc <= 5) {
        elm.style.transform = ''
        hero.style.opacity = '1'
      }
    })
  }

  function closeDragElement() {
    /* stop moving when mouse button is released:*/
    document.onmouseup = null;
    document.onmousemove = null;
    elmnt.classList.toggle('grabbing')
  }
}