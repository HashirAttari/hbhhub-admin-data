const container = document.querySelector('.container');
const letters = ['P', 'O', 'P'];
const grid = [21, 9];
let gridNumber = grid[0] * grid[1];

var focused,
animating,
promises = [];

window.addEventListener('mousemove', e => {
  focused = e.target.classList[1];
});



Promise.all(promises).then(() => {
  loop(gridNumber);
});


function pulse() {
  if (animating) {
    console.log('animated');
    return;
  } else {
    anime({
      targets: '.letter_cont',
      begin: () => {
        animating = true;
      },
      scale: [
      { value: '0', easing: 'easeOutSine', duration: 400 },
      { value: '1', easing: 'easeInOutQuad', duration: 900 }],

      translateY: [
      { value: '10', easing: 'easeOutSine', duration: 200 },
      { value: '0', easing: 'easeInOutQuad', duration: 900 }],

      color: [
      { value: '#FF1EAD', easing: 'easeOutSine', duration: 100 },
      { value: '#ffffff', easing: 'easeInOutQuad', duration: 200 }],

      complete: () => {
        animating = false;
      },
      delay: anime.stagger(70, { grid: grid, from: focused }) });

  }
}



function loop(n) {
  for (var i = 0; i < n; i++) {
    let letterCont = document.createElement('div');
    letterCont.innerHTML = letters[i % letters.length];
    letterCont.classList.add('letter_cont', i);
    container.appendChild(letterCont);
  }
}

setInterval(function () {pulse();}, 2000);