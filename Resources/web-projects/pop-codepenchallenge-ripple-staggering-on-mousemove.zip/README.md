# Pop CodepenChallenge ripple staggering on mousemove

A Pen created on CodePen.io. Original URL: [https://codepen.io/RMKNGY/pen/wNMvNQ](https://codepen.io/RMKNGY/pen/wNMvNQ).

