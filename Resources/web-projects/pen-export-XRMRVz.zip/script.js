var pBox=document.getElementById("placebox"),canvas=document.getElementById("canvas"),ctx=canvas.getContext("2d");
var move=null,points=[],initialized=false,thread=null,lastCoords;
var vertices=0,dots=0,last=-1;

var options={
  isStart:0,
  pmode:0,
  ratio:0.5,
  interval:5,
  mass:1000
};

pBox.addEventListener("mousedown",function(event){placeDot(event);});
pBox.addEventListener("dblclick",function(event){removeDot(event);});
pBox.addEventListener("mousemove",function(event){moveDot(event);});
pBox.addEventListener("mouseup",leaveDot);
document.getElementById("ratioinput").addEventListener("keyup",function(){
  options.ratio=parseFloat(this.value) || options.ratio;
});

var toggles=document.getElementsByClassName("toggle");
for (var i=0;i<toggles.length;i++){
  toggles[i].addEventListener("mousedown",function(event){toggleButton(event);});
}

function placeDot(evt){
  var dot=document.createElement("div");
  dot.className="dot";
  vertices++;
  if (options.isStart){
    dot.classList.add("startp");
    var startps=pBox.getElementsByClassName("startp");
    if (startps.length>0){
      startps[0].parentElement.removeChild(startps[0]);
    }
    vertices--;
  }else{
    dot.classList.add("normalp");
  }
  dot.style.left=(evt.clientX/window.innerWidth)*100+"%";
  dot.style.top=(evt.clientY/window.innerHeight)*100+"%";
  dot.addEventListener("mousedown",function(event){selectDot(event);});
  pBox.appendChild(dot);
  setCanPlay();
  setPoints();
  setInfo();
}

function removeDot(evt){
  evt.target.parentElement.removeChild(evt.target);
  setCanPlay();
  move=null;
  vertices=pBox.getElementsByClassName("normalp").length;
  setPoints();
  setInfo();
}

function selectDot(evt){
  move=evt.target;
  move.classList.add("selected");
  evt.stopPropagation();
}

function moveDot(evt){
  if (move){
    move.style.left=(evt.clientX/window.innerWidth)*100+"%";
    move.style.top=(evt.clientY/window.innerHeight)*100+"%";
    setPoints();
  }
}

function leaveDot(){
  if (move){
    move.classList.remove("selected");
    move=null;
  }
}

function setCanPlay(){
  document.getElementById("toolbar").setAttribute("canplay",(pBox.getElementsByClassName("startp").length==1&&pBox.children.length>2));
}
  
function toggleButton(evt){
  var parent=evt.target.parentElement;
  var toggle=parent.getElementsByClassName("toggle");
  for (var i=0;i<toggle.length;i++){
    toggle[i].classList.remove("selected");
    if (toggle[i]==evt.target){
      toggle[i].classList.add("selected");
      options[parent.getAttribute("data-variable")]=i;
    }
  }
}

function playPause(elem){
  if (!initialized) initCanvas();
  document.body.setAttribute("playing",!thread);
  if (thread){
    clearInterval(thread);
    thread=null;
    elem.innerHTML="play";
  }else{
    if (options.pmode){
      thread=setInterval(massSim,0);
    }else{
      thread=setInterval(relaySim,options.interval);
    }
    document.getElementById("ratioinput").value=options.ratio;
    elem.innerHTML="pause";
  }
}

function step(){
  if (!initialized) initCanvas();
  options.pmode?massSim():relaySim();
}

function initCanvas(){
  canvas.width=window.innerWidth;
  canvas.height=window.innerHeight;
  lastCoords=points[0];
  ctx.fillStyle="white";
  initialized=true;
}

function simulate(){
  var nextIndex;
  while (true){
    nextIndex=Math.floor(Math.random()*(points.length-1))+1;
    if (nextIndex!=last){
      last=nextIndex;
      break;
    }
  }
  var nextCoords=points[nextIndex];
  var newCoords=[lastCoords[0]+(nextCoords[0]-lastCoords[0])*options.ratio,lastCoords[1]+(nextCoords[1]-lastCoords[1])*options.ratio];
  /*ctx.beginPath();
  ctx.arc(newCoords[0]*canvas.width,newCoords[1]*canvas.height,1,0,Math.PI*2);
  ctx.fill();*/
  ctx.fillRect(newCoords[0]*canvas.width-1,newCoords[1]*canvas.height-1,2,2);
  lastCoords=newCoords;
}

function relaySim(){
  simulate();
  dots++;
  setInfo();
}

function massSim(){
  for (var i=0;i<options.mass;i++){
    simulate();
  }
  dots+=options.mass;
  setInfo();
}

function setPoints(){
  points=[];
  var offs,pElems=toArrayConcat(pBox.getElementsByClassName("startp"),pBox.getElementsByClassName("normalp"));
  if (pElems.length>0){
    offs=pElems[0].offsetWidth/2;
  }
  for (var i=0;i<pElems.length;i++){
    var cr=pElems[i].getBoundingClientRect();
    points.push([(cr.left+offs)/window.innerWidth,(cr.top+offs)/window.innerHeight]);
  }
}

function setInfo(){
  document.getElementById("vertexinfo").innerHTML=vertices+(vertices==1?" vertex":" vertices");
  document.getElementById("dotinfo").innerHTML=dots+" dot"+(dots==1?"":"s");
}

//the arguments are HTML collections. We need arrays.
function toArrayConcat(htmlc,htmlc2){
  var out=[];
  for (var i=0;i<htmlc.length;i++){
    out.push(htmlc[i]);
  }
  for (var i=0;i<htmlc2.length;i++){
    out.push(htmlc2[i]);
  }
  return out;
}

function clearCanvas(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  dots=0;
  setInfo();
  initialized=false;
}

function clearAll(){
  clearCanvas();
  pBox.innerHTML="";
  setCanPlay();
  vertices=0;
  if (thread) playPause(document.getElementsByTagName("button")[0]);
  setInfo();
}