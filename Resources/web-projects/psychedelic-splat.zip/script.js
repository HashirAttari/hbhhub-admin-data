gsap.set('svg', {
	visibility: 'visible'
})
let select = s => document.querySelector(s),
  selectAll = s =>  document.querySelectorAll(s),
		mainSVG = select('#mainSVG'),
		dripPaths = gsap.utils.toArray('#dripLineGroup path'),
		dripEnds = gsap.utils.toArray('#dripEndGroup circle'),
		spectrumArray  = ['#00a0db','#362983','#e4007d','#e31f21','#ffe900','#009447'],
		allStops = gsap.utils.toArray('#rainbowGrad stop')


gsap.set('#centerSplat', {
	transformOrigin: '50% 50%'
})
let mainTl = gsap.timeline({
	repeat: -1,
	repeatDelay: 2
})
mainTl.fromTo('#centerSplat', {
		y: 400,
},{
	y: -200,
	ease: 'sine'
	})
.fromTo('#centerSplat', {
		scale: 0
},{
		scale: 0.91,
	ease: 'sine.in'
	}, 0)
.from('#rainbowGrad stop', {
		stopColor: '#000'
}, 0)
.to('#centerSplat', {
	duration: 0.2,
	y: 0,
	ease: 'power2.in'
})
.to('#centerSplat', {
	duration: 0.4,
	scale: 1,
	ease: 'sine'
}, '-=0.3')
.add('allSplats')

dripPaths.forEach((path, i) => {
	let duration = gsap.utils.random(0.2, 0.4)
	let tl = gsap.timeline();
	tl	.add('splat')
	.to(dripEnds[i], {
		duration: () => {
			return duration
		},	
		ease: 'expo',
		motionPath: {
			path: path,
			align: path,
			alignOrigin: [0.5, 0.5]
		}
	}, 'splat')
	.from(path, {
		duration: () => {
			return duration
		},		
		ease: 'expo',
		drawSVG: '0% 0%'
	}, 'splat')
	.fromTo(dripEnds[i], {
		scale: 0
	}, {
		scale: 'random(0.56, 0.81)',
		duration: () => {
			return duration
		},
		ease: 'sine',
	}, 'splat')
	
	mainTl.add(tl, 'allSplats-=0.12')
})

gsap.globalTimeline.timeScale(1.2)