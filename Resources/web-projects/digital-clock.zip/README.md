# Digital Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/BamPmGg](https://codepen.io/kitjenson/pen/BamPmGg).

