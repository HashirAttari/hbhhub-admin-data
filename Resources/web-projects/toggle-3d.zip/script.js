window.addEventListener("load", function () {
  document.getElementsByClassName("toggleMe")[0].checked = "true";
});