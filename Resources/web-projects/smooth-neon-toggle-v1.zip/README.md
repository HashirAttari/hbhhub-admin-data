# Smooth Neon Toggle (v1)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/KKEbRYy](https://codepen.io/alvaromontoro/pen/KKEbRYy).

Inspired by Josh Dillon's Silky Smooth checkboxes: https://codepen.io/jdillon/pen/PoLBVmV