# Draw an image on a LED matrix with color mixing using React

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/ewaKmZ](https://codepen.io/agalliat/pen/ewaKmZ).

Display an image on a LED matrix written in React, using color mixing and opacity to simulate real light color mixing.