function _defineProperty(obj, key, value) {if (key in obj) {Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true });} else {obj[key] = value;}return obj;}const imgData_ReactLogo = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAAC+lBMVEUAAABg2voSKS8LGh5g2vpg2vpbz+4lVmJYyOVe1fVg2vpe1vVVwt5f2Pdf2flg2votZ3Zg2vpf1/df1/de1vZf2fle1/de1vZf2Phg2vpf2Phg2vpg2vpf2fhf1/df2Phf2Phe1fVe1/Zd1PNg2vpe1/db0e9azOpc0vFg2vpg2flPtM9Vwd5f2PgzdYcYNz9g2vpg2vpc0vBg2vpg2vpbz+5f2flf2flZy+lg2vpTvdlg2vpg2vlSutVc0vFe1vVPs85g2vlf2fhf2Phd1PNf2Phf2fld1PRbz+1g2vpZyuhd0/JXyOVZyedg2vpf2flUwNxf2flf2PhVwt9TvNhf2flg2vpg2vlZyuhf2flJpr5WxOFIo7tEmrFe1fVZzOk7hpo4gZRg2vlEnLNXxuNe1/ZSutZKqMFe1/ZCl60xcIEQJis7h5te1vVd0/Fg2vpe1fVe1/dazetd0/Jf2PdXx+Rg2vpYyOVc0/Ff2Phe1fRe1/dg2vpf1/dTvdle1/ZPtM9azexf2PdOss1GnrZf2PhNrsdf2flDmK9b0O4/kKVf2PdFnbRKqcJd0/Je1fVd0/Fg2vpbzuxZyudazOpg2vpe1vVf2Pdbz+5azetYyude1vVazOpc0e9Zy+hc0fBazOpRutVc0vFd1fRPtM5TvdlZyuhPtM9NsMlf2PhOssxKqMFb0O9g2vld1PNf2PhSvNhYyOVf1/dRudRGn7dc0vFPtM9Blqxbz+1Jpr9PtdA9jKFSu9dTvdk9i59Vwd5e1vYyc4QoXGld1PNc0vFc0O9azuxd1PNb0O9d1fRVw+Be1/Zb0e9UwNxazuxWw+BXx+RXyOVTvNhe1vVWw+BYyedc0vFazuxQt9JTvtpc0fBf2PhOssxIpb1UwNxHo7tg2flb0e9YyeZSvNdRt9Jf2Phb0O9e1/dOssxe2PhMrMVQttBCl61IpLxf1/Y3fpE6hZlazexYyOVQttFbz+5WxOFDmbBDmK5IpLxHorlDmK5g2vtg2flf2Pg6XXnkAAAA+3RSTlMA/gIE/PoEDAb28xkC/fbZE+zqZQj8+/ni4f740H09KCQg9vLx7ebZ0rWbij02Gwj97+zn5eDNxMS8noZtaxYNCP77+PXx6unl1dDLyr6xr62op6Sii3l0b2hWRkZFMScmIyIXFBAQDAsJBgYE8u/p5d7d29DFubSqo6KXgXl4cGloXFxRT0pIPzo6LCsb6OLg2tjUy8nGwbCurKuloZ2Sko6MiIWDgYF+c3FpYmFfV1RTUkA8NjIwLy4sKiQdGxoTEA/v59rPzsS8urW1s6uoppmVk4yGhHl1b21rYmFgXVpXT05MS0lGREI8ODUgHhoSy4tjW1pMOSciHpzLVl4AAAaoSURBVFjD7VZlVFRBFH7fBrILu+wusCyhGKSAiggKCiaNKJIGFip2d3d3d3d3d3d3d3fr7J7jvLe77NuDu+p/v/N+zHxz3p07d+797jD/8RtU9Ayqb2eTn3dqHBRUxPaPvzsNDA+RKh1SBkaZ0faeK7q6enlpahWyt/5/83R3ENBPFObYzEQXKe/KkhSq1QKrBiqIUTQpdaZfUUB8aouBtF3nAYJik8+d93OGKtDa/40dIFmuEAhz1k+nJjQDKrFkVLoUKB2RrRAKx/QCprewYsARqFmAG7XYkKiFfF4ThvH0L0VcTma34uh9YfB+Zfl/+x5wqWOc7Jknh3P3fUFhIKWXK4xsQWhvWLnBKSSuYd6s0gAVMNUB8B0szCOHueOC5TDaOZAEBW/+sAMAbdJIHlVfiW6tLBoo4krKFeATN52BtvX4TOEypHqBvzbgOYX1oGcz6wbMj/DhAG/aFfBtD+eFlUzcKHqEkhYNNA0jR/aasrI4iO/IDd6QZ5nCVkiKVKFFA7b+iN2Rd6eZYuIzmLG/KYeqLmPEOpF2AWMZveDyOO/ClKi2SkCtLqyMY7tNeaDrb60UoO3Lbu4UVfiFB9BxaUbBgn0WeQPd6xdpypayTS1I6lkx8EKOGds3ZhQPjy8jBR+llK5h/r36PQuKJ6GNrIjBsxjIlSKAEFDodDKZWi1z02lBwVLuMWJydKeNhQiOygxvBxYyiY8P4JJ2vf/tQRSfIvueBqqExrroQCHWpKx9a59fSYb1CNHvEnqxf71t3YEzCl6GdYZsyeihN+ZGg4XIIb2+uRs2hWpIQbTFklKjyfH3DPPEi8SNZHh4IEen3TSNQkhoKqs2CLnUgLe8v7wSRO27IFuRG442m5j90yBbblZzlXoC81vTW6p8UZjzaO44LeCwulJefieXIm6TVjZiM2wFKn9kKohIlxJcMg+p4BjkxI62a6iYOXWFZDCdtN55ZRwgX2gokrfhVDICGul33B4Cv8B4VKvDHuy+hxgI7sE52wc4+zSYJOkjI9g5h8rNvBZc9HsBHQcba5xmStVEkV7Y1niBw9TdrDNhiD4G3TLGgBZZ3qg6gCuPYOLz1XTaje6gDmWzJ3OAAfPZwzmKAeKzjTFCMEAOvzF0UJ6a5QWsSVmgclpJTmGN6PTGsIC0VrzAzoJ6PfU5BcU2Mzz0A9oOZwfpMKLNS06yS6GaWR04cpVjX4tbNyEDKLaJ4VwzwLBDBUDymOGhNjWgF+orvCPYeQCY3ZIrfehBfEuYFnga7q9vAltioHpoogeKoIU3qyBRU6GHbDG7QSboQuxWU+1kiEkCa9l+EaD5bGMsyGRIqosxPZeO63bg9nc7U0J/J23LQbs0T/56S0m1Vfq4zwK8jKkdpCQJr6eg6Bd2Ejgj1kXSMYDbJh1I3dQOiTmG4vEXEZcAgz7vm1MFmFCwgb0+IgHMWnckjuGyZcfQelyGM4XakcPDbWqg6CPWzULFlSDFFh9kDMjNGgdAU/xJVNOy7B1WPEV9FZg1vWToFrRib/JCy8ZrkoNBi+ceX963zlUBcPeoISVdFHS/GLQPNLsxMZlEu6ZnGbSv4Sqiv4cG0CkfrV/N71QFLNr3zByypSdwuhmvnUyAevGI+72pagAEkoRlu/I3B8GbuzPHO7PrEAXHAOJZvfv0u1W79q0VGeXLAjKVtBS36OIbUaeEhQYtDFShzXiJG6eq5iCU0coOhVYlkxvm35zf/Ws2fB55eWa5I7GVAWc3HYVMC6h9JnY5t+T25h2dyfgfjGVkQnedc+XA3q3TgIkrIyMj+y/xhjZt17sCQv0bpuhzKwaKQzLUOB6hQdUsAddjkZTXTPpAF2mlsXQlpU2KsVoO7w2MTW8xics26Y0Ily0b2O9BJu41VcsiZ3QIdGRT3hT0EVKctxxEuwlkMu+B0aw7oFFCHcBLOc929IHx10+cPScAyCIO/v0bSWNugOknAg4NZf7ljXT0Pa/hrQkBRecR/GdesLUjNC+Lw99NFVjQC24nE4EOD0yddIgYEQJreaBenxeuFDFRp5VocAKIvtrEyNImsJKxDCqIM3L1ilXbgUpGgIJGksqNaNpTW/1zPp6U/mbFgF1nVL0aZePU2LGsGOh4hztt7jUV4FVriJ2trWcK95y3grVSiD2Sw1nNkNR8LTBoRd3jzoB7vL+/K0jccMYabK9Fg1BA0uUO7/pzsvyq6Pm4exZDaNztbKexPgkRdRTm/Ji7s/3GjvWNGClg/oSWP0fvUgh/w+eMHv1OyPxHfvwCGd/3CracbUgAAAAASUVORK5CYII=";

function createLedDataBuffer(props) {
  const LedRows = props.rows;
  const LedCols = props.cols;

  const LedData = Array(LedRows).fill(0).map(
  _ => Array(LedCols).fill(0).map(
  _ => ({ r: 0, g: 0, b: 0 })));



  return LedData;
}

function updateLedData(context, LedData) {
  const width = LedData[0].length;
  const height = LedData.length;

  const imgData = context.getImageData(0, 0, width, height);

  for (let row = 0; row < imgData.height; row++) {
    for (let col = 0; col < imgData.width; col++) {
      let i = row * imgData.width + col;

      let r = imgData.data[i * 4 + 0];
      let g = imgData.data[i * 4 + 1];
      let b = imgData.data[i * 4 + 2];
      let a = imgData.data[i * 4 + 3];

      if (a < 128) {
        LedData[row][col] = { r: 0, g: 0, b: 0 };
      } else
      {
        LedData[row][col] = { r: r, g: g, b: b };
      }
    }
  }

  return LedData;
}

class Led extends React.Component {
  render() {
    const { led } = this.props;

    const active = led.r > 0 || led.g > 0 || led.b > 0 ? true : false;

    const color_r = `rgba(255, 0, 0, ${led.r / 255})`;
    const color_g = `rgba(0, 255, 0, ${led.g / 255})`;
    const color_b = `rgba(0, 0, 255, ${led.b / 255})`;

    if (active) {
      return /*#__PURE__*/(
        React.createElement("div", { className: "Led" }, /*#__PURE__*/
        React.createElement("div", { className: "red", style: { color: color_r } }), /*#__PURE__*/
        React.createElement("div", { className: "green", style: { color: color_g } }), /*#__PURE__*/
        React.createElement("div", { className: "blue", style: { color: color_b } })));


    } else
    {
      return /*#__PURE__*/React.createElement("div", { className: "Led" });
    }
  }}


class LedRow extends React.Component {
  render() {
    return /*#__PURE__*/React.createElement("div", { className: "LedRow" },

    this.props.row.map(led => {
      return /*#__PURE__*/React.createElement(Led, { led: led });
    }));


  }}


class LedMatrix extends React.Component {
  render() {
    return /*#__PURE__*/(
      React.createElement("div", { id: "LedMatrix" },

      this.props.LedData.map(row => /*#__PURE__*/React.createElement(LedRow, { row: row }))));



  }}


class App extends React.Component {constructor(...args) {super(...args);_defineProperty(this, "state",
    { LedData: createLedDataBuffer({ rows: 64, cols: 64 }) });}

  render() {
    return /*#__PURE__*/React.createElement(LedMatrix, { LedData: this.state.LedData });
  }

  componentDidMount() {
    const canvas = document.getElementById("img");
    const context = canvas.getContext("2d");

    const image = new Image();
    image.src = imgData_ReactLogo;
    //image.crossorigin = "anonymous";
    //image.src = "http://devarticles.in/wp-content/uploads/2019/05/react.png";

    image.onload = () => {
      canvas.width = image.width;
      canvas.height = image.height;

      context.translate(canvas.width / 2, canvas.height / 2);
      context.drawImage(image, -canvas.width / 2, -canvas.height / 2);

      this.setState(state => {
        return { LedData: updateLedData(context, state.LedData) };
      });

      setInterval(() => {
        context.clearRect(-canvas.width / 2, -canvas.height / 2, canvas.width, canvas.height);

        context.rotate(5 * (Math.PI / 180));
        context.drawImage(image, -canvas.width / 2, -canvas.height / 2);

        this.setState(state => {
          return { LedData: updateLedData(context, state.LedData) };
        });
      }, 100);
    };
  }}


ReactDOM.render( /*#__PURE__*/React.createElement(App, null), document.getElementById("app"));