# HARDCELL - 32x32px Doodler #LOWREZJAM

A Pen created on CodePen.

Original URL: [https://codepen.io/njmcode/pen/KKgMVr](https://codepen.io/njmcode/pen/KKgMVr).

A quick pixel art editor, using the frankly awesome Classic Doom 256-color and Commodore 64 16-color palettes.  Has pencil and eraser, plus render to image.  Inspired by the #LOWREZJAM game jam! http://jams.gamejolt.io/lowrezjam2014