const spec = {
  name: "dummy",
  aliases: ["test"],
  inputs: {
    value: { name: "value", type: "T" },
    errors: { name: "errors", type: "[error]" } },

  outputs: {
    output: { name: "output", type: "T" } },

  state: {
    value: "" },

  documentation: "Just a dummy box" };


const nospec = {
  name: "undefined",
  aliases: [],
  inputs: {},
  outputs: {},
  documentation: "empty node" };


class Node extends React.Component {
  constructor(props) {var _this$props$spec;
    super(props);

    this.spec = (_this$props$spec = this.props.spec) !== null && _this$props$spec !== void 0 ? _this$props$spec : nospec;
  }

  render() {
    return /*#__PURE__*/(
      React.createElement("div", { className: "node" }, /*#__PURE__*/
      React.createElement("div", { className: "header" }, /*#__PURE__*/
      React.createElement("span", { className: "name" }, this.spec.name), /*#__PURE__*/
      React.createElement("div", { className: "icons" }, /*#__PURE__*/
      React.createElement("i", { className: "fa fa-info", "aria-hidden": "true" }), /*#__PURE__*/
      React.createElement("i", { className: "fa fa-minus", "aria-hidden": "true" }))), /*#__PURE__*/



      React.createElement("div", { className: "connections" }, /*#__PURE__*/
      React.createElement("div", { className: "inputs" },
      Object.keys(this.spec.inputs).map((v, i) => /*#__PURE__*/
      React.createElement("div", { className: "input" }, /*#__PURE__*/
      React.createElement("div", { className: "connection" }), /*#__PURE__*/
      React.createElement("span", { key: i },
      this.spec.inputs[v].name + ":", /*#__PURE__*/
      React.createElement("small", null, this.spec.inputs[v].type))))), /*#__PURE__*/




      React.createElement("div", { className: "outputs" },
      Object.keys(this.spec.outputs).map((v, i) => /*#__PURE__*/
      React.createElement("div", { className: "output" }, /*#__PURE__*/
      React.createElement("span", { key: i },
      this.spec.outputs[v].name + ":", /*#__PURE__*/
      React.createElement("small", null, this.spec.outputs[v].type)), /*#__PURE__*/

      React.createElement("div", { className: "connection" }))))), /*#__PURE__*/





      React.createElement("div", { className: "state" },
      Object.keys(this.spec.state).map((v, i) => {
        switch (typeof this.spec.state[v]) {
          case "string":
            return /*#__PURE__*/(
              React.createElement("input", {
                key: i,
                type: "text",
                name: v,
                autoComplete: "off",
                placeholder: v }));


          default:
            return /*#__PURE__*/React.createElement(React.Fragment, null);}

      }))));



  }}


/*
 * A simple React component
 */
class Application extends React.Component {
  render() {
    return /*#__PURE__*/React.createElement(Node, { spec: spec });
  }}


/*
 * Render the above component into the div#app
 */
React.render( /*#__PURE__*/React.createElement(Application, null), document.getElementById("app"));