# Neumorphism/Soft UI JavaScript Calculator | Dark mode ON/OFF

A Pen created on CodePen.io. Original URL: [https://codepen.io/theHocineSaad/pen/bGVRzjV](https://codepen.io/theHocineSaad/pen/bGVRzjV).

A very simple Calculator made using HTML, CSS and JavaScript with Neumorphism/Soft UI style + a toggle button to activate or deactivate Dark Mode.
Fork it on Github: https://github.com/theHocineSaad/Neumorphism-JavaScript-Calculator-with-Dark-Mode