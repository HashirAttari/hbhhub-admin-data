var bottom_spot = 0,
	flake_width = window.innerWidth / 42;
function addFlake() {
	var f = document.createElement("div");
	f.className = "snowflake falling";
	f.style.left = Math.floor(Math.random() * 42) * flake_width + "px";
	f.style.animationDuration = Math.random() * 15 + 5 + "s";
	f.onanimationend = function () {
		this.classList.remove("falling");
		this.classList.add("sitting");
		addFlake();
	};
	document.body.prepend(f);
}

function checkFlakes() {
	var flakes = document.querySelectorAll(".falling");
	flakes.forEach(function (elm) {
		var elm_loc = elm.getBoundingClientRect(),
			point = document.elementFromPoint(elm_loc.x + 16, elm_loc.y + 32);

		if (document.querySelectorAll(".snowflake").length > 600) {
			clearInterval(add);
		}

		if (point && point.classList.contains("sitting")) {
			elm.style.animationPlayState = "paused";
			elm.classList.remove("falling");
			elm.classList.add("sitting");
		}
	});
}
var check = setInterval(checkFlakes, 1000 / 20),
	add = setInterval(addFlake, 100);