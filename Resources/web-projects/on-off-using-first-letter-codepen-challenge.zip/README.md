# On / Off using ::first-letter | CodePen Challenge 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/bGgmVbq](https://codepen.io/havardob/pen/bGgmVbq).

Ever heard about the ::first-letter psuedo-element? Here's a demonstration of something cool you can do with it