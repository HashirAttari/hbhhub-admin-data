let code = ''

const comp = document.getElementById('component')
const out = document.getElementById('output')

const escapeHTML = (string) => {
  // use the browser to auto-escape characters which need escaping inside a pre
  const pre = document.createElement('pre')
  const text = document.createTextNode(string)
  pre.appendChild(text)
  return pre.innerHTML
}

const add = (line) => {
  code += escapeHTML(line) + '\n'
}

const update = () => {
  code = ``
  
  const c = comp.value
  const d = `${c}Default`
  const p = `${c}Custom`
  
  const addStorySettings = (s) => {
    const n = s.replace(c,'')
    add(`${s}.story = {`)
    add(`  name: '${n}',`)
    add(`//  decorators: [],`)
    add(`//  parameters: {`)
    add(`//    notes: 'additional search terms for ${n} story'`)
    add(`//  },`)
    add(`}`)
    add(``)
  }
  
  add(`import React from 'react'`)
  add(`import base from 'paths.macro'`)
  add(`import { action } from '@storybook/addon-actions'`)
  add(`import ${c} from './${c}'`)
  add(``)
  add(`export default {`)
  add(`  component: ${c},`)
  add(`  title: 'Discovery|\${base}/${c}',`)
  add(`  // decorators: [],`)
  add(`  // parameters: { notes: 'additional search terms for ${c}'},`)
  add(`}`)
  add(``)
  add(`export const ${d} = () => <${c} onClick={ action('${d} clicked!') } />`)
  addStorySettings(d)
  add(`export const ${p} = () => {`)
  add(`  const props = {}`)
  add(`  return <${c} {...props} onClick={ action('${p} with props clicked!') } />`)
  add(`}`)
  addStorySettings(p)
  add(``)
  
  out.innerHTML = code
}

update()

comp.addEventListener("input", () => update());