# Valentine's Day (empty) Envelope Animation 

A Pen created on CodePen.

Original URL: [https://codepen.io/christadejesus/pen/ZEMELzd](https://codepen.io/christadejesus/pen/ZEMELzd).

