# Contact Form Send Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/pqxRvb](https://codepen.io/joshonweb/pen/pqxRvb).

Using Greensock to animate a sending animation for a simple contact form.