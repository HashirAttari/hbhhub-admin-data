for (
	var imgmagnify = document.getElementsByClassName("img-magnify"), i = 0;
	i < imgmagnify.length;
	i++
) {
	var imgmagnifym = document.createElement("div"),
		imgmagnifys = imgmagnify[i].getAttribute("data-img-magnify-size") || 100,
		imgmagnifyf = imgmagnify[i].getAttribute("data-img-magnify-zoom") || 1.5,
		imgmagnifyl =
			imgmagnify[i].getAttribute("data-img-magnify-location") || "cursor",
		imgmagnifyst =
			imgmagnify[i].currentStyle || window.getComputedStyle(imgmagnify[i]);
	imgmagnifym.style =
		"width:" +
		imgmagnifys +
		"px;height:" +
		imgmagnifys +
		"px; border-radius:" +
		(imgmagnifyl == "cursor" ? "100%" : "0%") +
		";background-repeat:no-repeat;border:1px solid silver;position:absolute;pointer-events:none;top:-" +
		imgmagnifys +
		"px;left:-" +
		imgmagnifys +
		"px;background-image:url('" +
		imgmagnify[i].src +
		"')";
	imgmagnify[i].onmouseenter = function(a) {
		var imgmagnifyw =
			this.clientWidth -
			parseInt(imgmagnifyst.paddingLeft) -
			parseInt(imgmagnifyst.paddingRight);
		var imgmagnifyh =
			this.clientHeight -
			parseInt(imgmagnifyst.paddingTop) -
			parseInt(imgmagnifyst.paddingBottom);

		imgmagnifym.style.backgroundSize =
			imgmagnifyw * imgmagnifyf + "px " + imgmagnifyh * imgmagnifyf + "px";

		if (imgmagnifyl == "static") {
			if (
				document.body.offsetWidth - this.offsetLeft - this.offsetWidth >
				imgmagnifys
			) {
				imgmagnifym.style.top = this.offsetTop + "px";
				imgmagnifym.style.left = this.offsetWidth + this.offsetLeft + 20 + "px";
			} else if (this.offsetLeft > imgmagnifys) {
				imgmagnifym.style.top = this.offsetTop + "px";
				imgmagnifym.style.left = this.offsetLeft + 20 + "px";
			} else if (this.offsetTop > imgmagnifys) {
				imgmagnifym.style.top = this.offsetTop - imgmagnifys - 20 + "px";
				imgmagnifym.style.left = this.offsetLeft + "px";
			} else if (
				("innerHeight" in window
					? window.innerHeight
					: document.documentElement.offsetHeight) -
					this.offsetTop -
					this.offsetHeight >
				imgmagnifys
			) {
				imgmagnifym.style.top = this.offsetTop + this.offsetHeight + 20 + "px";
				imgmagnifym.style.left = this.offsetLeft + "px";
			} else {
				imgmagnifym.style.top = this.offsetTop + 10 + "px";
				imgmagnifym.style.left = this.offsetLeft + 10 + "px";
			}
		}
	};
	imgmagnify[i].onmouseover = imgmagnify[i].onmousemove = function(event) {
		if (imgmagnifyl == "cursor") {
			imgmagnifym.style.top = event.clientY - imgmagnifys / 2 + "px";
			imgmagnifym.style.left = event.clientX - imgmagnifys / 2 + "px";
		}
		var imgmagnifyx =
			(-event.clientX -
				((window.pageXOffset || document.documentElement.scrollLeft) -
					(document.documentElement.clientLeft || 0)) +
				this.offsetLeft +
				this.clientLeft +
				parseInt(imgmagnifyst.paddingLeft)) *
				imgmagnifyf +
			imgmagnifys / 2;
		var imgmagnifyy =
			(-event.clientY -
				((window.pageYOffset || document.documentElement.scrollTop) -
					(document.documentElement.clientTop || 0)) +
				this.offsetTop +
				this.clientTop +
				parseInt(imgmagnifyst.paddingTop)) *
				imgmagnifyf +
			imgmagnifys / 2;
		imgmagnifym.style.backgroundPosition =
			imgmagnifyx + "px " + imgmagnifyy + "px";
	};
	imgmagnify[i].onmouseleave = function(a) {
		imgmagnifym.style.top = imgmagnifys * imgmagnifyf * -1 + "px";
		imgmagnifym.style.left = imgmagnifys * imgmagnifyf * -1 + "px";
	};
	document.body.appendChild(imgmagnifym);
}