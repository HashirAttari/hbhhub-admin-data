# imgmagnify - both

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/NXyGKg](https://codepen.io/leenalavanya/pen/NXyGKg).

