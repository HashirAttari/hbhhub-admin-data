# Styled native range input #52 (updated 2022)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/MYGBWZ](https://codepen.io/thebabydino/pen/MYGBWZ).

**March 2022 update**

Major changes:

* got rid of Compass and Modernizr dependencies, neither of which was needed anyway

* since I now know how to code a multi thumb slider (see my [article](https://css-tricks.com/multi-thumb-sliders-particular-two-thumb-case/) on CSS-Tricks for details), I ditched the 1 element restriction for some sliders and added that feature to match the design too (original 2015 version only had a single handle for all sliders, even though the design shows multiple handles for some of them)

* now generating the HTML in a logical manner  from a Pug data array; since it now has some config CSS vars in style attributes, the generated HTML has gone up from 377 bytes to 446 bytes, but this is more than compensated by how much the CSS and JS have now shrunk

* ditched `absolute` positioning in favour of using a truly responsive `grid` layout now

* used smarter gradient techniques for the slider thumbs to better reproduce the design without needing pseudos on the thumbs, something that was only ever supported in Chromium and it stopped working even there before the end of 2015 anyway

* cleaned up the CSS and made it more maintainable by using CSS variables and the DRY switching technique, explained in this two part article I wrote for CSS-Tricks: [part one](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) and [part two](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/); this has meant reducing the SCSS by more than 25% from 11.5kB to 8.5kB and the compiled CSS by almost 75% (to just about a quarter of what it was before) from over 32.5kB to less than 9.5kB

* got rid of the convoluted JS that was adding the fill/ progress/ range highlight for the WebKit browsers and Firefox and switched to a simpler method based on CSS variables; thus reduced the JS by about 80% (to just about a fifth of what it was before) from over 1kB to about 200 bytes, in spite of also spicing things up with some extra functionality

* made it degrade gracefully in the no JS case (the wrapper's `::before` pseudo/ the track `background` that are used to create the range highlights gets `display: none`/ gets `background-size` zeroed in the no JS case since the values they depend on don't get updated anyway)

* would have loved to make at least the 1 thumb sliders with highlight fully functional without JS in Firefox, but the `-moz-range-progress` element behaves in a weird way that makes it just not suitable to use when the track has rounded corners

* added `:focus-within`/ `:hover` styles

* ensured it now behaves consistently in both WebKit browsers and Firefox

* not providing free IE/ pre-Chromium support anymore

The result should now look like below:

![screenshot](https://assets.codepen.io/2017/internal/screenshots/pens/MYGBWZ.custom.png?version=1646328136)

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need any JS, while Firefox and Chrome/ Opera rely on it a bit for updating the fill of the range track. Chrome/ Opera also have a bit of an extra, the shape of the thumb in the first set. This is done using `/deep/` - careful, experimental stuff, [the spec has already changed](http://dev.w3.org/csswg/css-scoping-1/#deep-combinator), uncertain future in Chrome ([link #1](https://groups.google.com/a/chromium.org/forum/#!msg/blink-dev/hRw781MV3mE/pQHWrsKhmj0J), [link #2](https://code.google.com/p/chromium/issues/detail?id=433977)). Fallback for no JS: display the same background for the entire track, both before and after the thumb. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/5PeKfdU.jpg) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 