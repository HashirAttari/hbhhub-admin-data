/* external resources *only* for displaying the info boxes */

/* this below is all the JS needed for the demo itself to work */
document.documentElement.classList.add('js')

addEventListener('input', e => {
	let _t = e.target, i = _t.dataset.i, 
			_m = i ? _t.parentNode : _t, 
			n = `--v${i ? i : ''}`;
	
	_m.style.setProperty(n, +_t.value)
})