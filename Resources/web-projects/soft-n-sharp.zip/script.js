/*
This pen is a very simple example of a transition from ultra soft to soft-ish to sharp.
Uses hover and active states. 
(hover with mouse and press'n'hold left mouse)
*/