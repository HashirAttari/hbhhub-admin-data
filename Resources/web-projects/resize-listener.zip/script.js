function addResizeListener(elemOrSelector, callback, absolute) {
	const target = elemOrSelector instanceof Element ?
		elemOrSelector :
		document.querySelector(elemOrSelector);
	
	if (!(target instanceof Element))
		throw new Error("Cannot listen to resize: target is not an element");
	
	if (typeof callback != "function")
		throw new TypeError("Cannot listen to resize: no callback function provided");
	
	const requestFrame = window.requestAnimationFrame || setTimeout;

	const state = {
		width: 0,
		height: 0,
		lastWidth: 0,
		lastHeight: 0,
		widthChanged: true,
		heightChanged: true,
		triggers: 0
	};

	const runtime = {
		state,
		keys: ["shrink", "expand"],
		observer: null,
		detectors: {
			shrink: null,
			expand: null
		},
		scrollers: {
			shrink: null,
			expand: null
		},
		bars: {
			width: 0,
			height: 0
		},
		lastTimestamp: 0,
		debounceTolerance: 10,
		animationFrameRequested: false
	};
	
	const handleResize = evt => {
		evt = evt || event;

		if (runtime.animationFrameRequested || evt.timeStamp < runtime.lastTimestamp + runtime.debounceTolerance)
			return;
		
		runtime.lastTimestamp = evt.timeStamp;
		runtime.animationFrameRequested = true;
		
		requestFrame(_ => {
			updateDetectors();
			
			if (!state.triggers || state.widthChanged || state.heightChanged) {
				state.triggers++;
				callback(state, evt, runtime);
			}
			
			runtime.animationFrameRequested = false;
		}, 0);
	};
	
	const updateDetectors = _ => {
		runtime.detectors.shrink.scrollTop = 1e5;
		runtime.detectors.shrink.scrollLeft = 1e5;
		
		state.width = runtime.detectors.shrink.scrollLeft + runtime.bars.width;
		state.height = runtime.detectors.shrink.scrollTop + runtime.bars.height;
		
		const widthChanged = state.width != state.lastWidth,
			heightChanged = state.height != state.lastHeight;
		
		// Split up to bundle DOM reads and writes separately
		if (widthChanged)
			runtime.scrollers.expand.style.width = `${state.width * 1.5 || 1}px`;
		if (heightChanged)
			runtime.scrollers.expand.style.height = `${state.height * 1.5 || 1}px`;
		
		if (widthChanged)
			runtime.detectors.expand.scrollLeft = 1e5;
		if (heightChanged)
			runtime.detectors.expand.scrollTop = 1e5;
		
		state.widthChanged = widthChanged;
		state.heightChanged = heightChanged;
		state.lastWidth = state.width;
		state.lastHeight = state.height;
	};
	
	const observer = document.createElement("div");
	observer.setAttribute("class", "resize-observer");
	observer.setAttribute("style", (absolute ? "position: absolute; top: 0; left: 0;" : "") + "width: 100%; height: 100%; pointer-events: none; opacity: 0; -ms-filter:'progid:DXImageTransform.Microsoft.Alpha(Opacity=0)'; overflow:hidden");
	runtime.observer = observer;
	
	for (let i = runtime.keys.length - 1; i >= 0; i--) {
		const key = runtime.keys[i];
		
		const detector = document.createElement("div");
		detector.setAttribute("class", `resize-detector ${key}`);
		detector.setAttribute("style", "width: 100%; height: 100%; overflow: scroll");
		runtime.detectors[key] = detector;
		detector.onscroll = handleResize;
		
		const scroller = document.createElement("div");
		scroller.setAttribute("class", "resize-scroller");
		scroller.setAttribute("style", "width: 200%; height: 200%");
		runtime.scrollers[key] = scroller;
		
		detector.appendChild(scroller);
		observer.appendChild(detector);
	}
	
	target.appendChild(observer);
	updateDetectors();

	runtime.bars.width = observer.clientWidth - runtime.detectors.shrink.clientWidth;
	runtime.bars.height = observer.clientHeight - runtime.detectors.shrink.clientHeight;
	
	return runtime;
}

let count = 0;
const track = document.querySelector("#track");

const rt = addResizeListener(".resize-test", payload => {
	track.style.width = `${payload.width + 2}px`;
	track.style.height = `${payload.height + 2}px`;
	track.textContent = `${payload.width} × ${payload.height}`;
	console.log(payload);
	count++;
});

console.log(rt);

// Minified (1692 bytes (1007 bytes gzipped), most backwards compatible (Down to IE8))
// var addResizeListener=function(B,G,J,K){return function(e,t,n){var i=e instanceof G?e:B.querySelector(e);if(!(i instanceof G))throw new J("Cannot listen to resize: target is not an element");if("function"!=typeof t)throw new J("Cannot listen to resize: no callback function provided");var r="width",a="height",s="lastWidth",l="lastHeight",c=r+"Changed",d=a+"Changed",o="scroll",h=o+"Top",f=o+"Left",u="setAttribute",p="appendChild",m="createElement",v="triggers",g="timeStamp",w="lastTimestamp",b="debounceTolerance",y="animationFrameRequested",z="width:100%;height:100%;",C=["shrink","expand"],T="class",q="style",x="div",A="clientWidth",E="clientHeight",k=window.requestAnimationFrame||setTimeout,F={},H={},L={},R={},S={state:F,o:null,d:H,s:L,b:R};function W(e){e=e||event,S[y]||e[g]<S[w]+S[b]||(S[w]=e[g],S[y]=!0,k(function(){D(),!F[v]|F[c]|F[d]&&(F[v]++,t(F,e,S)),S[y]=!1},0))}function D(){var e=H[C[0]],t=H[C[1]],n=L[C[1]][q];e[h]=K,e[f]=K,F[r]=e[f]+R[r],F[a]=e[h]+R[a];var i=F[r]!=F[s],o=F[a]!=F[l];i&&(n[r]=(2*F[r]||1)+"px"),o&&(n[a]=(2*F[a]||1)+"px"),i&&(t[f]=K),o&&(t[h]=K),F[c]=i,F[d]=o,F[s]=F[r],F[l]=F[a]}F[r]=F[s]=F[a]=F[l]=F[v]=0,F[c]=F[d]=!1,S[w]=0,S[b]=10,S[y]=!1;var I=B[m](x);I[u](T,"resize-observer"),I[u](q,(n?"position:absolute;top:0;left:0;":"")+z+"pointer-events:none;opacity:0;-ms-filter:'progid:DXImageTransform.Microsoft.Alpha(Opacity=0)';overflow:hidden"),S.o=I;for(var M=0;M<2;M++){var O=C[M],X=B[m](x),j=B[m](x);X[u](T,"resize-detector "+O),X[u](q,z+"overflow:scroll"),(H[O]=X)["on"+o]=W,j[u](T,"resize-scroller"),j[u](q,"width:200%;height:200%"),L[O]=j,X[p](j),I[p](X)}return i[p](I),D(),R[r]=I[A]-H[C[0]][A],R[a]=I[E]-H[C[1]][E],S}}(document,Element,Error,1e5);

// Old version - Minified (1330 bytes, state keys preserved)
// function addResizeListener(e,t,y){var ce=document.createElement.bind(document),sa="setAttribute",w="width",h="height",m=1e5,wc="widthChanged",hc="heightChanged",st="scrollTop",sl="scrollLeft",ap="appendChild",s=e instanceof Element?e:document.querySelector(e);if(!(s instanceof Element))throw new Error("Cannot listen to resize: target is not an element");if("function"!=typeof t)throw new TypeError("Cannot listen to resize: no callback function provided");var i={s:{width:0,height:0,lastWidth:0,lastHeight:0,widthChanged:1,heightChanged:1},k:["s","e"],z:null,x:{},c:{},a:!1},n=function(e){i.a||(i.a=!0,setTimeout(function(){r(),t(i.s,e,i),i.a=!1},0))},r=function(){i.x.s[st]=m,i.x.s[sl]=m,i.s[w]=i.x.s[sl],i.s[h]=i.x.s[st];var e=i.s[w]!=i.s.lastWidth,t=i.s[h]!=i.s.lastHeight;e&&(i.c.e.style[w]=2*i.s[w]+"px"),t&&(i.c.e.style[h]=2*i.s[h]+"px"),e&&(i.x.e[sl]=m),t&&(i.x.e[st]=m),i.s[wc]=e,i.s[hc]=t;i.s.lastWidth=i.s[w];i.s.lastHeight=i.s[h]},a=ce("div");a[sa]("style",(y?"position:absolute;top:0;left:0;":"")+"width:100%;height:100%;pointer-events:none;opacity:0;overflow:hidden"),i.z=a;for(var o=i.k.length-1;o>=0;o--){var l=i.k[o],p=ce("div");p[sa]("style","width:100%;height:100%;overflow:scroll"),i.x[l]=p,p.onscroll=n;var d=ce("div");d[sa]("style","width:200%;height:200%"),i.c[l]=d,p[ap](d),a[ap](p)}return s[ap](a),r(),i}

// Old version - Ultra minified (1194 bytes, state keys minified)
// function addResizeListener(e,t,y){var ce=document.createElement.bind(document),sa="setAttribute",m=1e5,st="scrollTop",sl="scrollLeft",ap="appendChild",s=e instanceof Element?e:document.querySelector(e);if(!(s instanceof Element))throw new Error("Cannot listen to resize: target is not an element");if("function"!=typeof t)throw new TypeError("Cannot listen to resize: no callback function provided");var i={s:{w:0,h:0,lw:0,lh:0,wc:1,hc:1},k:["s","e"],z:null,x:{},c:{},a:!1},n=function(e){i.a||(i.a=!0,setTimeout(function(){r(),t(i.s,e,i),i.a=!1},0))},r=function(){i.x.s[st]=m,i.x.s[sl]=m,i.s.w=i.x.s[sl],i.s.h=i.x.s[st];var e=i.s.w!=i.s.lw,t=i.s.h!=i.s.lh;e&&(i.c.e.style.width=2*i.s.w+"px"),t&&(i.c.e.style.height=2*i.s.h+"px"),e&&(i.x.e[sl]=m),t&&(i.x.e[st]=m),i.s.wc=e,i.s.hc=t;i.s.lw=i.s.w;i.s.lh=i.s.h},a=ce("div");a[sa]("style",(y?"position:absolute;top:0;left:0;":"")+"width:100%;height:100%;pointer-events:none;opacity:0;overflow:hidden"),i.z=a;for(var o=i.k.length-1;o>=0;o--){var l=i.k[o],p=ce("div");p[sa]("style","width:100%;height:100%;overflow:scroll"),i.x[l]=p,p.onscroll=n;var d=ce("div");d[sa]("style","width:200%;height:200%"),i.c[l]=d,p[ap](d),a[ap](p)}return s[ap](a),r(),i}

// Old version - Dangerously minified (996 bytes, no validation, state keys minified)
// function addResizeListener(e,t,y){var ce=document.createElement.bind(document),sa="setAttribute",m=1e5,st="scrollTop",sl="scrollLeft",ap="appendChild",s=e instanceof Element?e:document.querySelector(e);var i={s:{w:0,h:0,lw:-1,lh:-1,wc:1,hc:1},k:["s","e"],z:null,x:{},c:{},a:!1},n=function(e){i.a||(i.a=!0,setTimeout(function(){r(),t(i.s,e,i),i.a=!1},0))},r=function(){i.x.s[st]=m,i.x.s[sl]=m,i.s.w=i.x.s[sl],i.s.h=i.x.s[st];var e=i.s.w!=i.s.lw,t=i.s.h!=i.s.lh;e&&(i.c.e.style.width=2*i.s.w+"px"),t&&(i.c.e.style.height=2*i.s.h+"px"),e&&(i.x.e[sl]=m),t&&(i.x.e[st]=m),i.s.wc=e,i.s.hc=t;i.s.lw=i.s.w||-1;i.s.lh=i.s.h||-1},a=ce("div");a[sa]("style",(y?"position:absolute;top:0;left:0;":"")+"width:100%;height:100%;pointer-events:none;opacity:0;overflow:hidden"),i.z=a;for(var o=i.k.length-1;o>=0;o--){var l=i.k[o],p=ce("div");p[sa]("style","width:100%;height:100%;overflow:scroll"),i.x[l]=p,p.onscroll=n;var d=ce("div");d[sa]("style","width:200%;height:200%"),i.c[l]=d,p[ap](d),a[ap](p)}return s[ap](a),r(),i}