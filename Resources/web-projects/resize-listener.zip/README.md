# Resize Listener

A Pen created on CodePen.io. Original URL: [https://codepen.io/PicturElements/pen/PowXJQL](https://codepen.io/PicturElements/pen/PowXJQL).

Super simple alternative to ResizeObserver for basic resizing observation. It uses overflowing elements and scroll events to detect when elements are resized. While this is by no means a perfect substitute to RO, and not exceedingly performant, it does offer the following benefits over other polyfill strategies:

1. Zero non-native listeners or observers. Minimal additional memory needed to store runtime data, and no polling required.
2. Accurate detection. The callback is invoked every time the element is resized.
3. Backwards compatible. This script, with minor changes, is compatible with Chrome, Firefox, Safari, Brave, IE11, and IE8 (emulated).