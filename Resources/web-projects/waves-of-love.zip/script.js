/*
The toggle button is from this pen
https://codepen.io/himalayasingh/pen/EdVzNL

*/


document.getElementById('toggle').addEventListener('click', e => {
  if (e.target.checked) {
    setTimeout(function () {
      document.getElementById('svg-wrapper').classList.add('active');
    }, 500);

  } else
  {
    document.getElementById('svg-wrapper').classList.remove('active');
  }
});