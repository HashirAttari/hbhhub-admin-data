# waves of love

A Pen created on CodePen.

Original URL: [https://codepen.io/vastrideside/pen/PoqZpqw](https://codepen.io/vastrideside/pen/PoqZpqw).

A pen for Valentine's Day (Click to activate love).

The toggle button is from @himalayasingh

https://codepen.io/himalayasingh/pen/EdVzNL