# CSS Loading Spinners

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/qZNqeB](https://codepen.io/mselmany/pen/qZNqeB).

12 Spinners HTML5 and CSS3 no images, just css animations and 1 div tag in the HTML. NO JS

Forked from [Harold Soto](http://codepen.io/bernethe/)'s Pen [CSS Loading Spinners](http://codepen.io/bernethe/pen/dorozd/).