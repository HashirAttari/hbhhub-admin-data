# Alex the CSS Husky Reactive

A Pen created on CodePen.io. Original URL: [https://codepen.io/davidkpiano/pen/aNKxeo](https://codepen.io/davidkpiano/pen/aNKxeo).

Move your mouse around!

Based on a playful [Dribbble shot by Ryan Rumbolt](https://dribbble.com/shots/2418721-Husky-love) and [illustration by Alexey Kuvaldin](https://dribbble.com/kuvaldin).

Works best in Chrome :)