# 30+ Bootstrap Modal Animation Effects

A Pen created on CodePen.io. Original URL: [https://codepen.io/antoncabon/pen/WxQLbM](https://codepen.io/antoncabon/pen/WxQLbM).

antoncabon.github.io