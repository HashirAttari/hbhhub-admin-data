# Border

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/wvJjXyb](https://codepen.io/yuanchuan/pen/wvJjXyb).

