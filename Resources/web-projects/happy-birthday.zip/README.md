# Happy Birthday!

A Pen created on CodePen.io. Original URL: [https://codepen.io/the_Northway/pen/PNWoeb](https://codepen.io/the_Northway/pen/PNWoeb).

I hate the generic Facebook wall post wishing someone a happy birthday. It takes too little effort. So I made this for my friend's birthday as his 'card'.