const SVG_PATHS = [
    // Frog
    "M479.708,388.306c-4.237-0.529-8.219,1.294-10.659,4.443l-16.587-2.075l23.895-23.56c3.873,1.003,8.158,0,11.188-3.036c4.546-4.572,4.521-11.959-0.031-16.496c-4.556-4.543-11.937-4.526-16.493,0.027c-2.999,3.016-4,7.255-3.027,11.099l-21.354,21.059l7.119-27.083c3.767-1.119,6.956-3.936,8.03-8.024c1.635-6.228-2.086-12.596-8.309-14.235c-6.229-1.645-12.608,2.086-14.243,8.309c-1.075,4.084,0.317,8.105,3.047,10.94l-7.735,29.412l-8.74-31.621c2.703-2.862,4.038-6.9,2.918-10.977c-1.722-6.201-8.135-9.846-14.343-8.14c-11.048,3.054-11.732,18.941,0,22.267l6.855,24.829c-5.206,2.254-41.182,17.816-44.884,19.431c2.511-11.028,1.948-8.594,11.039-48.423c0.046,0.232,0.557-3.514,0.578-5.395c0.655-21.727-19.479-41.76-46.648-32.457c-1.326,0.478,0.225-0.382-27.782,14.393c6.501-25.659,11.015-53.027,13.091-78.882c30.157,18.346,42.284-1.996,45.582-10.792c0.438-1.167,36.843-109.899,36.843-109.899l24.944-25.018c3.829,0.929,7.996,0.094,10.977-2.894c4.549-4.57,4.524-11.957-0.032-16.5c-4.552-4.539-11.937-4.52-16.489,0.032c-2.981,2.998-3.798,7.165-2.859,10.994l-21.685,21.748l7.279-27.661c3.771-1.127,6.957-3.944,8.031-8.03c1.638-6.23-2.083-12.598-8.309-14.235c-6.229-1.645-12.604,2.082-14.243,8.308c-1.074,4.082,0.317,8.103,3.05,10.938l-7.735,29.407l-8.74-31.614c2.703-2.864,4.038-6.902,2.918-10.979c-1.722-6.201-8.139-9.846-14.343-8.138c-6.208,1.714-9.847,8.138-8.139,14.355c1.126,4.065,4.347,6.836,8.128,7.911l8.044,29.098c0,0-19.609,38.349-39.034,76.356c-2.594-2.601-5.203-5.213-7.533-7.551c-3.19-3.195-6.101-6.115-8.688-8.71c-3.141-18.676-8.344-34.419-15.223-47.171c2.709-3.806,4.34-8.432,4.34-13.45c0-12.854-10.424-23.268-23.272-23.268c-1.241,0-2.431,0.177-3.62,0.361l-13.192-13.191c0.069-0.791,0.236-1.545,0.236-2.348c0-15.71-12.713-28.541-28.402-28.541c-15.688,0-28.401,12.831-28.401,28.541c0,0.803,0.167,1.557,0.236,2.348L204.112,87.71c-1.189-0.184-2.379-0.361-3.62-0.361c-12.848,0-23.272,10.414-23.272,23.268c0,5.019,1.631,9.644,4.34,13.45c-6.879,12.753-12.082,28.495-15.223,47.171c-2.588,2.595-5.499,5.514-8.689,8.71c-2.33,2.338-4.938,4.95-7.533,7.551c-19.425-38.007-39.034-76.356-39.034-76.356l8.044-29.098c3.781-1.075,7.002-3.846,8.128-7.911c1.708-6.217-1.93-12.641-8.139-14.355c-6.205-1.708-12.622,1.937-14.343,8.138c-1.12,4.077,0.215,8.115,2.918,10.979l-8.74,31.614l-7.735-29.407c2.733-2.835,4.125-6.855,3.05-10.938c-1.639-6.226-8.014-9.953-14.243-8.308c-6.226,1.637-9.947,8.005-8.309,14.235c1.075,4.086,4.261,6.904,8.031,8.03l7.279,27.661L65.34,90.035c0.939-3.829,0.122-7.996-2.859-10.994c-4.553-4.552-11.937-4.571-16.489-0.032c-4.556,4.543-4.581,11.93-0.032,16.5c2.98,2.988,7.147,3.823,10.976,2.894l24.944,25.018c0,0,36.406,108.732,36.843,109.899c3.299,8.796,15.426,29.138,45.582,10.792c2.077,25.855,6.591,53.223,13.091,78.882c-28.007-14.774-26.456-13.915-27.782-14.393c-27.168-9.304-47.302,10.729-46.647,32.457c0.021,1.881,0.532,5.628,0.578,5.395c9.091,39.829,8.528,37.395,11.039,48.423c-3.702-1.615-39.678-17.177-44.884-19.431l6.855-24.829c11.732-3.327,11.048-19.214,0-22.267c-6.208-1.706-12.621,1.938-14.343,8.14c-1.12,4.076,0.215,8.114,2.918,10.977l-8.74,31.621l-7.735-29.412c2.73-2.835,4.122-6.856,3.047-10.94c-1.635-6.222-8.014-9.954-14.243-8.309c-6.223,1.639-9.944,8.007-8.309,14.235c1.075,4.088,4.264,6.906,8.03,8.024l7.119,27.083l-21.353-21.059c0.974-3.844-0.028-8.083-3.027-11.099c-4.556-4.553-11.937-4.57-16.493-0.027c-4.552,4.537-4.577,11.924-0.031,16.496c3.03,3.036,7.315,4.039,11.188,3.036l23.894,23.56l-16.587,2.075c-2.44-3.148-6.422-4.972-10.659-4.443c-6.392,0.804-10.924,6.633-10.128,13.009C1.9,407.7,7.73,412.238,14.129,411.452c4.237-0.533,7.642-3.284,9.23-6.938l25.93-3.246c2.735,1.52,77.314,42.958,77.314,42.958c8.08,4.489,17.998,4.048,25.647-1.14c7.649-5.188,11.735-14.241,10.545-23.406c-3.038-23.399-5.912-45.436-5.925-45.54c1.551,1.023,42.217,28.987,62.839,43.05c8.099,8.784,16.762,14.044,25.76,14.044c8.998,0,17.661-5.261,25.76-14.044c20.622-14.063,61.289-42.027,62.839-43.05c-0.013,0.104-2.887,22.141-5.925,45.54c-1.19,9.165,2.897,18.219,10.545,23.406c7.65,5.188,17.567,5.629,25.647,1.14c0,0,74.58-41.438,77.314-42.958l25.93,3.246c1.588,3.654,4.993,6.405,9.23,6.938c6.399,0.787,12.229-3.752,13.025-10.137C490.632,394.938,486.1,389.109,479.708,388.306z"
];

const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const svgContainer = document.getElementById('svgContainer');

// Configuration
const NUM_POINTS = 150;
const MORPH_DURATION = 3000; // milliseconds
const SHAPE_SIZE = 400; // max width/height for shapes

// Generate random hex color
function randomColor() {
    return '#' + Math.floor(Math.random()*16777215).toString(16).padStart(6, '0');
}

// Sample points from SVG path
function samplePath(pathData, numPoints) {
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", pathData);
    svgContainer.appendChild(path);

    const points = [];
    const length = path.getTotalLength();

    for (let i = 0; i < numPoints; i++) {
        const point = path.getPointAtLength((i / numPoints) * length);
        points.push([point.x, point.y]);
    }

    svgContainer.removeChild(path);
    return points;
}

// Create circle points
function createCircle(cx, cy, radius, numPoints) {
    const points = [];
    for (let i = 0; i < numPoints; i++) {
        const angle = (i / numPoints) * Math.PI * 2;
        points.push([
            cx + Math.cos(angle) * radius,
            cy + Math.sin(angle) * radius
        ]);
    }
    return points;
}

// Scale and center shape to fit canvas
function scaleAndCenter(points, maxSize) {
    let minX = Infinity, maxX = -Infinity;
    let minY = Infinity, maxY = -Infinity;

    points.forEach(([x, y]) => {
        minX = Math.min(minX, x);
        maxX = Math.max(maxX, x);
        minY = Math.min(minY, y);
        maxY = Math.max(maxY, y);
    });

    const width = maxX - minX;
    const height = maxY - minY;
    const scale = Math.min(maxSize / width, maxSize / height);

    return points.map(([x, y]) => [
        (x - minX) * scale + (canvas.width - width * scale) / 2,
        (y - minY) * scale + (canvas.height - height * scale) / 2
    ]);
}

// Linear interpolation between two points
function lerp(start, end, progress) {
    return [
        start[0] + (end[0] - start[0]) * progress,
        start[1] + (end[1] - start[1]) * progress
    ];
}

// Smooth easing function
function easeInOutCubic(t) {
    return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

// Initialize all shapes
const shapes = [
    createCircle(canvas.width / 2, canvas.height / 2, 150, NUM_POINTS)
];

// Add SVG shapes from shapes.js
SVG_PATHS.forEach(pathData => {
    const points = samplePath(pathData, NUM_POINTS);
    shapes.push(scaleAndCenter(points, SHAPE_SIZE));
});

// Animation state
let progress = 0;
let currentShapeIndex = 0;
let lastTime = Date.now();
let currentColor = randomColor();

// Main animation loop
function draw() {
    const now = Date.now();
    const delta = now - lastTime;
    lastTime = now;

    // Update progress
    progress += delta / MORPH_DURATION;

    // Move to next shape when transition completes
    if (progress >= 1) {
        progress = 0;
        currentShapeIndex = (currentShapeIndex + 1) % shapes.length;
        currentColor = randomColor();
    }

    // Apply easing for smooth animation
    const easedProgress = easeInOutCubic(progress);

    // Get current and next shape
    const fromShape = shapes[currentShapeIndex];
    const toShape = shapes[(currentShapeIndex + 1) % shapes.length];

    // Clear canvas
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw morphed shape
    ctx.beginPath();
    ctx.fillStyle = currentColor;

    for (let i = 0; i < NUM_POINTS; i++) {
        const point = lerp(fromShape[i], toShape[i], easedProgress);

        if (i === 0) {
            ctx.moveTo(point[0], point[1]);
        } else {
            ctx.lineTo(point[0], point[1]);
        }
    }

    ctx.closePath();
    ctx.fill();

    requestAnimationFrame(draw);
}

// Start animation
draw();