# Checkbox Spinner

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/nOObNe](https://codepen.io/hakimel/pen/nOObNe).

A spinner animation made out of checkboxes.