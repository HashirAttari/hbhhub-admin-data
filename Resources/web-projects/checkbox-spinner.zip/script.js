// by Hakim El Hattab | @hakimel

var boxes = document.querySelectorAll( 'i input' );
var offset = 0;

setInterval( function() {

  var box = boxes[ offset ];
  if( box ) box.checked = !box.checked;
  offset = ( offset + 1 ) % boxes.length;

}, 3000 / boxes.length );