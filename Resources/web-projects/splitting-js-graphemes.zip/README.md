# Splitting JS graphemes

A Pen created on CodePen.io. Original URL: [https://codepen.io/ste-vg/pen/JjqWbyO](https://codepen.io/ste-vg/pen/JjqWbyO).

Animating characters in verbs to represent their action. Leave a comment if there's a word you'd like to see added and animated on this list.

Part two: https://codepen.io/hexagoncircle/pen/OJLxWKq <br />
Part three: https://codepen.io/hexagoncircle/pen/oNvMLRQ