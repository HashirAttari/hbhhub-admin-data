import React, { useRef, useEffect } from 'https://cdn.skypack.dev/react';
import ReactDOM from 'https://cdn.skypack.dev/react-dom';
import PropTypes from 'https://cdn.skypack.dev/prop-types';
import { Scrollable } from 'https://cdn.skypack.dev/webrix/components';
import { ResizeObserver } from 'https://cdn.skypack.dev/webrix/tools';

const random = (min, max) => Math.floor(Math.random() * (max - min) + min);

const Box = () => /*#__PURE__*/
React.createElement("div", { className: "box" }, /*#__PURE__*/
React.createElement("img", { src: `https://picsum.photos/seed/${random(1, 200)}/200/${random(100, 400)}` }));



const Column = () => {
  const ref = useRef();
  const handleOnResize = ({ height }) => {
    ref.current.style.setProperty('--col-height', height + 'px');
  };

  return /*#__PURE__*/(
    React.createElement(ResizeObserver, { onResize: handleOnResize }, /*#__PURE__*/
    React.createElement("div", { className: "column", ref: ref },
    [...new Array(5)].map(() => /*#__PURE__*/
    React.createElement(Box, null)))));




};

const Content = () => {
  const ref = useRef();
  const handleOnResize = ({ height }) => {
    ref.current.style.setProperty('--height', height + 'px');
  };

  return /*#__PURE__*/(
    React.createElement(ResizeObserver, { onResize: handleOnResize }, /*#__PURE__*/
    React.createElement("div", { className: "content", ref: ref },
    [...new Array(3)].map(() => /*#__PURE__*/
    React.createElement(Column, null)))));




};

const App = () => /*#__PURE__*/
React.createElement(Scrollable, null, /*#__PURE__*/
React.createElement(Content, null));



ReactDOM.render( /*#__PURE__*/React.createElement(App, null), document.body);