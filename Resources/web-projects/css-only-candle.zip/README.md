# CSS Only: Candle

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/GbexQE](https://codepen.io/kitjenson/pen/GbexQE).

A burning candle only lasts so long.