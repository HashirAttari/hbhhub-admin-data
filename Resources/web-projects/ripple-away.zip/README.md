# Ripple Away

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/PobPWBG](https://codepen.io/joshonweb/pen/PobPWBG).

Small Demo of how  you can animate elements staggering the siblings from the element that was clicked