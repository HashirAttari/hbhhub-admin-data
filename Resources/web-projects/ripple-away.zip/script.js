const cards = document.querySelectorAll(".card");
cards.forEach((card) => card.addEventListener("click", handleCardClick));

//--//--//--//--//--//--//--//--//--//--//--//--
function handleCardClick(e) {
	const originCard = e.currentTarget;
	const originPoint = getCoordinateOnWindow(originCard);

	const cards = document.querySelectorAll(".card");

	cards.forEach(staggerAway(originPoint));
}

function staggerAway(origin) {
	return function staggerAwayFromClicked(card) {
		const cardCoord = getCoordinateOnWindow(card);

		const distance = getDistance(origin, cardCoord);

		card.style.setProperty("--delay", distance);

		card.classList.add("disappear"); //TODO uncomment me please

		setTimeout(() => {
			card.classList.remove("disappear");
		}, 1000 + distance);
	};
}

//--//--//--//--//--//--//--//--//--//--//--//--
function getDistance([startX, startY], [endX, endY]) {
	const width = getSide(startX, endX);
	const height = getSide(startY, endY);
	return getHypotenuse(width, height);
}
function getHypotenuse(a, b) {
	return Math.sqrt(square(a) + square(b));
}
function getSide(start, end) {
	return Math.abs(start - end);
}
const square = (num) => num * num;

//--//--//--//--//--//--//--//--//--//--//--//--
function getCoordinateOnWindow(el) {
	const {
		y: elY,
		x: elX,
		width: elWidth,
		height: elHeight
	} = el.getBoundingClientRect();
	const yPosition = Math.floor(window.pageYOffset + findCenter(elY, elHeight));
	const xPosition = Math.floor(window.pageXOffset + findCenter(elX, elWidth));
	return [xPosition, yPosition];
}
function findCenter(coord, size) {
	return coord + size / 2;
}
[...cards][12].click();