function initialsToImage(str, options) {
  let settings = options || {
    "height": 100,
    "width": 100,
    "fontSize": 42,
    "textColor": "#fff",
    "backgroundColor": "#000"
  };
  
  let svg = `<svg xmlns="http://www.w3.org/2000/svg" pointer-events="none" width="${settings.width}" height="${settings.height}" style="background-color: ${settings.backgroundColor}; width: ${settings.width}px; height: ${settings.height}px;"><text fill="${settings.textColor}" font-family="sans-serif" font-size="${settings.fontSize}px" pointer-events="auto" text-anchor="middle" x="50%" y="50%" dy="0.35em">${str.substring(0,2)}</text></svg>`;
  
  let svgHtml = window.btoa(unescape(encodeURIComponent(svg)));

  return 'data:image/svg+xml;base64,' + svgHtml;
}




let imgList = document.querySelectorAll('img');

imgList.forEach(img => {
  let names = img.dataset.name.split(' ');
  let initials = names[0].substring(0,1) + names[names.length-1].substring(0,1);
  img.src = initialsToImage(initials);
});