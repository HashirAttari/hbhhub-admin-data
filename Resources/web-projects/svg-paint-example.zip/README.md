# SVG Paint Example

A Pen created on CodePen.io. Original URL: [https://codepen.io/orhanveli/pen/jRpyjX](https://codepen.io/orhanveli/pen/jRpyjX).

