const c = document.querySelector('#v');

c.addEventListener('change', () => {
  const btns = document.querySelectorAll('button');
  btns.forEach(btn => btn.classList.toggle('test'))
})