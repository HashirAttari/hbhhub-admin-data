# Cog loading animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/bNxeKY](https://codepen.io/jcoulterdesign/pen/bNxeKY).

A quick loading animation using CSS. This is taken from the dribbble shot https://dribbble.com/shots/946595-App-loader-GIF-animation