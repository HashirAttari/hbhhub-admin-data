# Minimal Colorpicker

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/NLjmdz](https://codepen.io/aaroniker/pen/NLjmdz).

