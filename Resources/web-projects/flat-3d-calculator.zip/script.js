$(function(){
  
  function compute(curr, num){
    var calc = curr + num;
    $("input").val(calc);  
  }
  
$(".numpad button").click(function(){
  var curr = $("input").val();
  var num = $(this).text();
  
  compute(curr, num);
});
  
  $(".calculator").click(function(){
    $("html").addClass("clearable");
  });
  
  $(".controlspad button").click(function(){
  var curr = $("input").val();
  var num = " " + $(this).text() + " ";
  
  compute(curr, num);
});
  
  $(".clear, .equals").click(function(){
      $("input").val("");
  });
  
});