# Bubbles (CodePen Circles Challenge)

A Pen created on CodePen.io. Original URL: [https://codepen.io/soju22/pen/aXqVQQ](https://codepen.io/soju22/pen/aXqVQQ).

Simple threejs sprite test, try your mouse/keyboard  to control camera