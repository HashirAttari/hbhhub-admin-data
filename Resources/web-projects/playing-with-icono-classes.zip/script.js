var iconoClasses = ["home", "mail", "rss", "bars", "plus", "cross", "check", "power", "heart", "flag", "share", "pin", "locationArrow", "asterisk", "image", "video", "music", "document", "file", "folder", "smile", "frown", "meh", "user", "eye", "sliders", "infinity", "sync", "reset", "gear", "signIn", "signOut", "book", "support", "dropper", "chain", "paperClip", "search", "rename", "crop", "trash", "keyboard", "mouse", "headphone", "microphone", "display", "imac", "iphone", "macbook", "imacBold", "iphoneBold", "macbookBold", "nexus", "terminal", "youtube", "market", "clock", "tiles", "list", "forbidden", "plusCircle", "crossCircle", "checkCircle", "exclamationCircle", "exclamation", "textAlignRight", "textAlignCenter", "textAlignLeft", "indent", "outdent", "comment", "commentEmpty", "areaChart", "barChart", "pieChart", "bookmark", "bookmarkEmpty", "filter", "volume", "volumeLow", "volumeMedium", "volumeHigh", "volumeDecrease", "volumeIncrease", "volumeMute", "tag", "calendar", "camera", "piano", "ruler", "cup", "creditCard", "facebook", "twitter", "linkedIn", "instagram", "flickr", "delicious", "codepen", "blogger"];
    var start = setInterval(iconoCycle, 1500);
    var i = 1;
    var items = document.querySelectorAll('li>i');
    function iconoCycle(){
        Array.prototype.forEach.call(items, function(el, i){
            var number = Math.floor(iconoClasses.length*Math.random());
            el.setAttribute('class', 'icono-'+iconoClasses[number]);
        });
    }