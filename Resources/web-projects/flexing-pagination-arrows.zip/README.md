# Flexing pagination arrows

A Pen created on CodePen.io. Original URL: [https://codepen.io/hakimel/pen/nOzqdW](https://codepen.io/hakimel/pen/nOzqdW).

