// Helper
const $ = document.querySelector.bind(document);

// Elements
let img = $(".img");
let header = $(".header");
let subtext = $(".subtext");
let x = $(".x");
let dots = $(".dots");
let menu = $(".menu");
let images = document.querySelectorAll('.content a img');
let arrows = document.querySelectorAll('.arrow');

const halfScreenHeight = (window.innerHeight / 2);

// Bind scroll listeners
window.addEventListener("scroll", onScroll);
window.addEventListener("resize", onScroll);
  
function onScroll(e) {
  // Window scroll position
  let scrolled = window.scrollY || window.pageYOffset;

  // Position for end of scroll effects
  let endPos = (halfScreenHeight - 73); // minus header height
  // PX until end of scroll effects
  let elapsedScroll = (endPos - scrolled);
  // 1-0 value until end of scroll effects
  let relScroll = 1 - (elapsedScroll / endPos);
  
  // Img parallax effect
  img.style.top = -(scrolled * 0.2) + 'px';

  // Scroll effects
  if (elapsedScroll >= 0) {
    // Header
    header.style.background =
      'rgba(56, 56, 61, ' + relScroll + ')';
    header.style.fontSize =
      linear(relScroll, 38, 28) + 'px';
    
    // Subtext
    subtext.style.margin =
      linear(relScroll, 0, -25) + 'px';
    subtext.style.marginLeft =
      linear(relScroll, 0, 140) + 'px';
    
    // Remove sticky class
    header.classList.remove('sticky');
    // Change subtext
    subtext.innerHTML = subtext.innerHTML.split('| ').join('');
  }
  else {
    // Add sticky class
    header.classList.add('sticky');
    // Change subtext
    subtext.innerHTML = '| ' +
subtext.innerHTML.split('| ').join('');
  }
}

let open;
images.forEach(img => {
  img.addEventListener('click', e => {
    // Toggle classes
    document.documentElement.classList.toggle('open');
    header.classList.toggle('open');
    // If open
    if (header.classList.contains('open')) {
      open = img;
      // Add sticky class
      header.classList.add('sticky');
      // Set all images position to fixed
      images.forEach(image => {
        let rect = image.getBoundingClientRect();
        image.style.top = rect.top+'px';
        image.style.left = rect.left+'px';
      })
      images.forEach(image => {
        image.style.position = 'fixed';
      })
    }
    // Else, wait out the transition & set their position to relative
    else {
      window.setTimeout(function() {
        images.forEach(image => {
          image.style.position = '';
        })
      }, 300)
    }
    // Toggle image class
    img.classList.toggle('open');
  })
})
// Close button functionality
x.addEventListener('click', e => {
  open.click();
})
// Arrow functionality
arrows.forEach(arrow => {
  arrow.addEventListener('click', e => {
    images.forEach(image => {
      image.style.transition = 'none';
    })
    window.setTimeout(function() {
      images.forEach(image => {
        image.style.transition = '';
      })
    }, 300)
    open.classList.remove('open');
    try {
      if (arrow.classList.contains('next')) {
        open.nextSibling.classList.add('open');
        open = open.nextSibling;
      }
      else {
        open.previousSibling.classList.add('open');
        open = open.previousSibling;
      }
    }
    catch {
      document.documentElement.classList.toggle('open');
      header.classList.remove('open');
      images.forEach(image => {
        image.style.transition = '';
      })
      window.setTimeout(function() {
        images.forEach(image => {
            image.style.position = '';
          })
      }, 300)
    }
  })
})

// Helper function
function linear(value, start, end) {
  
  const full = end - start;
  
  const onePercent = full / 100;
  const percentage = value * 100;
  
  let resp = onePercent * percentage;
  resp = resp + start;
  
  return resp;
  
}