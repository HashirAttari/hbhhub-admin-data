# Preloaders - pure css - #04

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/WLmogM](https://codepen.io/ig_design/pen/WLmogM).

