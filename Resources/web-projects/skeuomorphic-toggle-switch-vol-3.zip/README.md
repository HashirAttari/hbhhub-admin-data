# Skeuomorphic Toggle Switch (vol. 3)

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/BaqYwea](https://codepen.io/nicolasjesenberger/pen/BaqYwea).

Inspired by MVBen on Dribbble: https://dribbble.com/shots/797923-Buttons-And-Switches-PSD