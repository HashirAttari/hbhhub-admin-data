// Inspired by MVBen on Dribbble:
// https://dribbble.com/shots/797923-Buttons-And-Switches-PSD