const meta = document.querySelector( 'meta[name="theme-color"]' );
const input = document.querySelector( 'input' );
const preview = document.querySelector( '.preview' );

document.querySelector( 'input' ).oninput = event => updateColor();

function updateColor() {
  meta.setAttribute( 'content', input.value );
  preview.innerHTML = input.value;
  document.body.style.backgroundColor = input.value;
}

updateColor();