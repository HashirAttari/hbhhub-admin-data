# Day/night switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/jesperkc/pen/pydMqb](https://codepen.io/jesperkc/pen/pydMqb).

Click the switch to change between daytime and nighttime reading