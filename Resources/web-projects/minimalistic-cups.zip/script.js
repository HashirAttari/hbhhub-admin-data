const animateCubes = new TimelineMax({ repeat: -1, yoyo: true });

animateCubes
  .fromTo(".ice-cubes", 2, { translateY: -2 },{ translateY: 2 });