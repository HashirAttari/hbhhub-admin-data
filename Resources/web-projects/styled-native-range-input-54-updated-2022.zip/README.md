# Styled native range input #54 (updated 2022)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/JovQwE](https://codepen.io/thebabydino/pen/JovQwE).

**March 2022 update**

Major changes:

* got rid of Compass and Modernizr dependencies, neither of which was needed anyway

* now generating the HTML in a logical manner  from a Pug data array; since it now has some config CSS vars in style attributes, the generated HTML has gone up from 170 bytes to 350 bytes, but this is more than compensated by how much the CSS and JS have now shrunk

* ditched `absolute` positioning in favour of using a truly responsive `grid` layout now

* used smarter gradient techniques for the slider progress and thumb to better reproduce the design

* cleaned up the CSS and made it more maintainable by using CSS variables and the DRY switching technique, explained in this two part article I wrote for CSS-Tricks: [part one](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) and [part two](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/); this has meant reducing the SCSS by about 25% from ~4.8kB to ~3.6kB and the compiled CSS by more than 66% (to less than third of what it was before) from almost 15.4kB to barely over 5.1kB

* got rid of the convoluted JS that was adding the fill/ progress/ range highlight for the WebKit browsers (Firefox has a CSS-only fill using `::-moz-range-progress`, though the way this works makes my technique a pretty hacky one - it maybe worth considering whether it's not better to use the WebKit approach,  just ditch the `::-moz-range-progress` styles and use the same JS-depending progress on the track - that is, simply get rid of the `@if` in the `track` mixin and make the styles inside that block available for all browsers) and switched to a simpler method based on CSS variables; thus reduced the JS by over 85% (to less than one eighth of what it was before) from over 930 bytes to just 140 bytes, in spite of also spicing things up with some extra functionality

* made it degrade gracefully in the no JS case in WebKit browsers (the track wrapper `background` that's used to create the range highlights gets `background-size` zeroed in the no JS case since the values they depend on don't get updated anyway); Firefox works fully with no JS

* there's a tiny little extra shadow detail in WebKit browsers - a little dark shadow underneath the thumb; this is created by setting a drop shadow on the track parent; in Firefox, this doesn't work as the track and the thumb are siblings, not nested like in WebKit; tried using a box-shadow on the thumb, but not only doesn't this work on the 1st slider's thumb (which is clipped using `clip-path`), but gets cut off weirdly in the lower side for the other thumbs in all browsers

* added `:focus`/ `:hover` styles

* ensured it now behaves consistently in both WebKit browsers and Firefox

* not providing free IE/ pre-Chromium support anymore

The result should now look like below:

![screenshot](https://assets.codepen.io/2017/internal/screenshots/pens/JovQwE.custom.png?version=1646636695)

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/). 

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11 on Windows 8. IE doesn't need any JS, while Firefox and Chrome/ Opera rely on it a bit for updating the fill of the range track. Fallback for no JS: display the same background for the entire track, both before and after the thumb. 

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found.

Design featured in [this roundup](https://pixel77.com/illustrator-tutorials-roundup-2012/). (original link is dead; [via](http://i.imgur.com/r9RVpSo.png)).