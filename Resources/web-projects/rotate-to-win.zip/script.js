import {render, html} from '//unpkg.com/lighterhtml?module';
const WIDTH = 6;
const defaultState = window.defaultState = {
  didWin: false,
  camera: { y: 45, x: 0, z: 200, rotation: 0 },
  colors: ['#000', '#fff', '#ff1ead'],
  collisionMap: [],
  turnCount: 0.0,
  lastKey: null,
  levelIndex: 0,
  levels: [{
    turnPar: 6.0,
    gameboard: [
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 1, 0, 0,
    ],
    player: {x: 4, y: 1, type: 'player'},
    objects: [
      {x: 0, y: 0, type: 'building', subtype: 'short', width: 2},
      {x: 1, y: 3, type: 'building', subtype: 'tall'},
      {x: 2, y: 3, type: 'building', subtype: 'short', direction: 90, height: 2},
      {x: 3, y: 0, type: 'building', subtype: 'tall'},
      {x: 4, y: 2, type: 'building', subtype: 'tall'},
      {x: 5, y: 0, type: 'building', subtype: 'tall'},
      {x: 5, y: 1, type: 'building', subtype: 'short', direction: 90, height: 2},
      {x: 5, y: 4, type: 'building', subtype: 'short', direction: 90, height: 2},
    ],
  }, {
    turnPar: 7.0,
    gameboard: [
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 1, 0, 0,
    ],
    player: {x: 1, y: 2, type: 'player'},
    objects: [
      {x: 0, y: 3, type: 'building', subtype: 'short', width: 2},
      {x: 0, y: 0, type: 'building', subtype: 'short', width: 2},
      {x: 0, y: 2, type: 'building', subtype: 'tall'},
      {x: 4, y: 5, type: 'building', subtype: 'tall'},
      {x: 5, y: 1, type: 'building', subtype: 'tall'},
      {x: 1, y: 5, type: 'building', subtype: 'tall'},
    ],
  }, {
    turnPar: 9.0,
    gameboard: [
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0,
      0, 0, 0, 1, 0, 0,
    ],
    player: {x: 4, y: 1, type: 'player'},
    objects: [
      {x: 0, y: 0, type: 'building', subtype: 'tall'},
      {x: 2, y: 0, type: 'building', subtype: 'tall'},
      {x: 5, y: 1, type: 'building', subtype: 'short', hight: 2, direction: -90},
      {x: 3, y: 4, type: 'building', subtype: 'tall'},
      {x: 1, y: 4, type: 'building', subtype: 'tall'},
      {x: 1, y: 2, type: 'building', subtype: 'short', width: 2},
      {x: 4, y: 2, type: 'building', subtype: 'tall'},
      {x: 2, y: 5, type: 'building', subtype: 'short', hight: 2, direction: -90},
      {x: 5, y: 5, type: 'building', subtype: 'tall'},
    ],
  }],
};
const BLOCK_PATTERNS = [
  /*0*/ {type: 'empty'},
  /*1*/ {className: 'palette--active', isGoal: true },
  /*2*/ {className: 'palette--white'},
];
//
//
// Start the game.
// The JSON.parse(JSON.stringify junk just guarantees a deep clone. Not something we actually need here in this codepen.
window.gameState = JSON.parse(JSON.stringify(defaultState));
//WISH: that I could pass in the inital state here, and all the actions/events everyone will somehow have the latest game state. (instead of the global window.gameState that use now.)
doAction({type: 'NewGame'});

// Listen to events on elements we are not creating.
// of course, if we did a react style App, we wouldn't need to do this.
// But I like showing that the system works with external components and internal ones.
// Bind the camera controls.
document.addEventListener('keyup', keyupToAction);
// Bind gameboard rotation events.
window.elGameboard.addEventListener('transitionend', endAnimationToAction);








//
// Render/Update the DOM with state data.
// This could also be <App /> or something.
// I like using HTML as much as possible, saving the generated markup for annoying/boring stuff.
//
function renderState(state) {
  // Render the Gameboard
  const elGameboard = window.elGameboard;
  render(elGameboard, renderGameboard.bind(null, state));
  
  // Rotate the world/gameboard based on the "camera position".
  elGameboard.style.transform = `rotateX(${state.camera.y}deg) rotateZ(${state.camera.x}deg)`;
  document.body.style.perspective = `${state.camera.z}vh`;
  
  // Keyboard Controls
  const elKeyboardControls = window.elKeyboardControls;
  render(elKeyboardControls, renderKeyboardControls.bind(null, state));
  
  // Turn Counter
  const elTurnCounter = window.elTurnCounter;
  render(elTurnCounter, renderTurnCounter.bind(null, state));
  
  const elBanner = window.elBanner;
  if (state.didWin) {
    render(elBanner, renderBanner.bind(null, {
      turnCount: state.turnCount,
      turnPar: state.turnPar,
      isLastLevel: state.levelIndex >= state.levels.length-1,
    }));
  }
  else {
    render(elBanner, () => html``);
  }
  
  // Update the color vars!
  document.body.style.setProperty('--color-background', state.colors[0]);
  document.body.style.setProperty('--color-foreground', state.colors[1]);
  document.body.style.setProperty('--color-highlight',  state.colors[2]);
}

// Render/Update the gamebaord based on state.
// The Gameboard is made from several layered CSS Grids.
function renderGameboard(state) {
  const { gameboard, objects, player } = state;
  const objectLayer = objects.concat(player); // Add the Player to the list of layer objects.
  
  return html`<div class="layer--floor grid">${gameboard.map((cell, index) => {
    const pattern = BLOCK_PATTERNS[cell];
    return html`<div data-index=${index} class=${pattern.className}></div>`;
  })}</div>
  <div class="layer--objects grid">${objectLayer.map(renderObject)}</div>`;
}

// Render the WASD UI controls.
function renderKeyboardControls(state) {
  const { lastKey } = state;
  // elControlsCamera.setAttribute('lastKey', state.lastKey);
  return html`<div class="keyboard-wasd" lastKey=${lastKey} onclick=${clickToAction}>
  <div code="KeyW">W</div>
  <div code="KeyA">A</div>
  <div code="KeyS">S</div>
  <div code="KeyD">D</div>
  <div code="KeyQ">Q</div>
  <div code="KeyE">E</div>
  </div>`;
}

function renderTurnCounter({turnCount}) {
  return html`<h2>Turn: ${turnCount.toFixed(1)}</h2>`;
}

function renderBanner({turnCount, turnPar, isLastLevel}) {
  console.log('renderBanner', arguments);
  let nextButton = html`<div onclick=${loadNextLevel} class="keyboard--key">Next Level</div>`;
  return html`
  <h1>You Win in ${turnCount.toFixed(1)} Turns!</h1>
  <h3>Par is ${turnPar.toFixed(1)} Turns</h3>
  ${!isLastLevel ? nextButton : ''}
  `;
}

// Renders an object based on props.
function renderObject(props) {
  const transform = `rotateZ(${props.direction || 0}deg)`;
  const style = `grid-area: ${props.y+1} / ${props.x+1}; transform: ${transform};`;
  let renderModel;
  
  switch(props.type) {
    case 'player':
    renderModel = renderPlayerModel;
    break;
    case 'building':
    renderModel = renderBuildingModel;
    break;
    default:
    renderModel = () => html`<h1>ROSE</h1>`;
  }
  return html`<div style=${style}>${renderModel(props)}</div>`;
}
// Renders the player
function renderPlayerModel(props) {
  const { offsetX = 0, offsetY = 0 } = props;
  let style = 'transition: none;';
  // if we have an offset, enable the transition animation.
  if (offsetX !== 0 || offsetY !== 0) {
    style = `transition: transform 1s; transform: translateX(${offsetX}em) translateY(${offsetY}em);`;
  }
  
  return html`<div 
  class="root-3d cube-3d player"
  style=${style}
  ontransitionend=${endAnimationToAction}
  data-next-action="EndSlide">
  <div></div><div></div><div></div><div></div><div></div><div></div>
  </div>`;
}
// Buildings are rectangles with "skins" via box-shadow art.
function renderBuildingModel(props) {
  const { skins, subtype } = props;
  const className = `root-3d building-3d ${subtype}`;
  return html`<div class=${className}>
  <div class="roof"></div>
  ${skins.map((skin) => {
    return html`<div class="${skin}"></div>`;
  })}
  </div>`;
}



//
// Events to Actions
//
// Converts the keyUp event into a cameraUpdate action.
function keyupToAction(event) {
  const { code, shiftKey } = event;
  let x = 0;
  let y = 0;
  let z = 0;
  let turnDelta = 0;
  
  // Camera controls
  if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyQ', 'KeyE'].includes(code)) {
    // Convert keyboard into into an action.
    if (code === 'KeyA') { 
      x = -1;
      turnDelta += 0.5;
    } 
    else if (code === 'KeyD') { 
      x = 1;
      turnDelta += 0.5;
    }
    
    if (code === 'KeyW') { y = -1;} 
    else if (code === 'KeyS') { y = 1;}
    
    if (code === 'KeyQ') { z = -1;} 
    else if (code === 'KeyE') { z = 1;}
    
    // Hold shift to move slower
    if (!shiftKey) {
      x *= 3;
      y *= 3;
    }
    
    doAction({
      type: 'CameraUpdate',
      keyCode: code,
      turnDelta,
      x, y, z,
    });
  }
  
  // Invert the colors!
  // Surprise for those reading the code! (Or mashing keys 😃)
  if (code === 'KeyI') {
    doAction({
      type: 'InvertColors',
    });
  }
}
function clickToAction(event) {
  const { target } = event;
  // Ignore if the attribute is missing.
  if (!target.hasAttribute('code')) { return; }
  
  // Trigger as the key input.
  keyupToAction({
    code: target.getAttribute('code'),
  });
}

function endAnimationToAction(event) {
  //BUG: we are getting extra calls when a child transitions.
  //   : To work around this issue, ignore calls from targets that are not us.
  if (this !== event.target) { return; }
  
  const nextAction = this.dataset.nextAction;
  doAction({
    type: nextAction,
  });
}

function loadNextLevel(event) {
  console.log('loadNextLevel');
  doAction({
    type: 'LoadNextLevel',
  });
}







//
// Action/State Game Logic
// Updates gameState and triggers a re-render.
//
function doAction(action = {}) {
  const { type } = action;
  let state = window.gameState;
  // console.log('action', action);
  state.lastKey = null;
  // update state,
  switch(type) {
    case 'NewGame':
      state = Object.assign(state, JSON.parse(JSON.stringify(state.levels[state.levelIndex])));
      state = createCollisionMap(state);
      // Hydrate the buildings with helpful data.
      state.objects.filter(p => p.type === 'building').forEach((props) => {
        // Pick random skins for each side on the buildings.
        props.skins = randomSort(['skin-1', 'skin-2','skin-3','skin-4']);
      });
      state.turnCount = 0;
      state.didWin = false;
      break;
    case 'CameraUpdate':
      state.camera.x += action.x * 15;
      state.camera.y += action.y * 15;
      state.camera.z += action.z * 10;
      state.lastKey = action.keyCode;
      // Create a rotation value that is only between 0-360 so we can calculate which direction we are facing.
      // Because the user can rotate positive and negative, allowing the x value to exceed 360.
      state.camera.rotation += action.x * 15;
      if (state.camera.rotation < 0) {
        state.camera.rotation = 360 + state.camera.rotation;
      }
      else if (state.camera.rotation === Math.abs(360)) {
        state.camera.rotation = 0;
      }

      if (action.turnDelta) {
        state.turnCount += action.turnDelta;
      }
      break;
    
    case 'InvertColors':
      const tmp = state.colors[0];
      state.colors[0] = state.colors[1];
      state.colors[1] = tmp;
      break;
    //
    // After rotating, see if the player should change positions.
    case 'EndRotate':
      const newPosition = findSlideEnd(state);
      state.player.nextX = newPosition.x;
      state.player.nextY = newPosition.y;
      state.player.offsetX = newPosition.x - state.player.x;
      state.player.offsetY = newPosition.y - state.player.y;
      break;
    case 'EndSlide':
      // Move the player to the next position and remove the temp vars.
      state.player.x = state.player.nextX;
      state.player.y = state.player.nextY;
      state.player.nextX = -1;
      state.player.nextY = -1;
      state.player.offsetX = 0;
      state.player.offsetY = 0;

      state.didWin = didWin(state.gameboard, state.player);
      break;
      
    //
    // Attempts to load the next level.
    case 'LoadNextLevel':
      state.levelIndex += 1;
      // We are out of levels once we reach the end of the levels array.
      if (state.levelIndex < state.levels.length) {
        doAction({type: 'NewGame'});
      }
      break;
  }
  
  // call renderState with new state.
  // I use lighterhtml/hyperHTML so the DOM will update intelligently.
  renderState(state);
  window.gameState = state;
}
window.doAction = doAction;



// Finds the farthest spot the player can slide to from their current position including rotation.
function findSlideEnd(state) {
  const rotation = state.camera.rotation;
  const { player, objects, collisionMap } = state;
  const { x: deltaX, y: deltaY } = rotationToDelta(rotation);
  // abort if there is no change.
  //TODO: this is the wrong place for this. don't call findSlideEnd if we don't need to slide.
  if (deltaX === 0 && deltaY === 0) { return {x: player.x, y: player.y}; }
  let x = player.x + deltaX;
  let y = player.y + deltaY;
  
  // Find the first non-empty cell in delta direction.
  while (isCellEmpty(collisionMap, x, y)) {
    x += deltaX;
    y += deltaY;
  }
  
  // We need to subtract the detla before returning
  // Because we walked until it was not empty, so the one before is empty.
  return {
    x: x - deltaX, 
    y: y - deltaY,
  };
}

// Turns rotation into x,y delta values.
function rotationToDelta(rotation) {
  if (/*North*/rotation % 360 === 0) {
    return {x: 0, y: 1};
  }
  else if (/*West*/rotation % 270 === 0) {
    return {x: -1, y: 0};
  }
  else if (/*South*/rotation % 180 === 0) {
    return {x: 0, y: -1};
  }
  else if (/*East*/rotation % 90 === 0) {
    return {x: 1, y:0};
  }
  return {x: 0, y: 0};
}

// Checks if a cell on the map is empty
function isCellEmpty(collisionMap, x, y) {
  const GRID_WIDTH = WIDTH-1; // length of 6 minus 1 for index 0
  // anything off grid is not empty.
  if (x < 0 || x > GRID_WIDTH || y < 0 || y > GRID_WIDTH) {
    return false;
  } 
  const index = pointToIndex({x, y});
  return collisionMap[index] === 0;
}

function didWin(grid, player) {
  const index = pointToIndex(player);
  const patternIndex = grid[index];
  const block = BLOCK_PATTERNS[patternIndex];
  return block.isGoal === true;
}

// Creates a collision map based on the gameboard and objects.
function createCollisionMap(state) {
  const { gameboard, objects } = state;
  const map = (new Array(gameboard.length)).fill(0);
  
  // Mark the grid if there is an object on top of it.
  objects.forEach((props) => {
    const { x=0, y=0, width=1, height=1 } = props;
    let index = pointToIndex({x, y});
    map[index] = 1;
    
    // also mark along the width/height.
    let i = width;
    while (--i) {
      index = pointToIndex({ x: x + (width-i), y });
      map[index] = 1;
    }
    i = height;
    while (--i) {
      index = pointToIndex({ x, y: y + (height-i) });
      map[index] = 1;
    }
  });
  
  state.collisionMap = map;
  return state;
}

// Somethings are easier with points, others with index.
// handy functions to convert between the two formats.
function indexToPoint(index) {
  return {
    x: 0| index % WIDTH,
    y: 0| index / WIDTH,
  }
}
function pointToIndex({x, y}) {
  return x + (y * WIDTH);
}

function randomSort(array) {
  return array.sort(() => (0|Math.random()*3)-1)
}