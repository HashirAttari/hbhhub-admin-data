# Spotify Wrapped Animation using GSAP

A Pen created on CodePen.io. Original URL: [https://codepen.io/petebarr/pen/oJvVpw](https://codepen.io/petebarr/pen/oJvVpw).

The lovely original Spotify site https://spotifywrapped.com is built in WebGL but I wanted to have a stab at it using DOM elements and of course Greensock's GSAP using the SplitText plugin.