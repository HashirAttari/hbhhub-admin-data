$(document).ready( function () {
  wrapCharacters($('.fire-text'));
  setInterval(flicker, 80);
});

var fireTxt = document.querySelector("#fire_msg");

function wrapCharacters(element) {
  fireTxt.innerHTML = fireTxt.innerText;
  
  $(element).contents().each(function() {
    if(this.nodeType === 1) {
      wrapCharacters(this);
    }
    else if(this.nodeType === 3) {
      $(this).replaceWith($.map(this.nodeValue.split(''), function(c) {
        return '<div>' + c + '</div>';
      }).join(''));
    }
    $('.fire-text div').each(function(){$(this).attr("y_pos","0");});
  });
}

function flicker() {
  $('.fire-text div').each(function(){
    var x = parseFloat($(this).attr("x_pos"));
    var y = parseFloat($(this).attr("y_pos"));

    if ($(this).attr("data-up") == "1") {
      y += getVariance(1,2);
      if (y > 10) { $(this).attr("data-up", "0"); }
    }
    else {
      y -= getVariance(3,5);
      if (y < 2) { $(this).attr("data-up", "1"); }
    }

    $(this).attr("y_pos", y);

    var yO = 1/(10/(y+1));
    var yB = yO * (yO * getVariance(10,20));

    var ts = "0px 0px " + Math.floor(getVariance(30,50)) + "px #627d4d, " + 
        getShake() + "1px -" + (Math.floor(getVariance(1,y)) + 30) + "px " + getVariance(40,90) + "px rgba(200,200,200,"+yO+"), " + 
        getShake() + Math.floor(y/5) + "px -" + y + "px " + yB + "px rgba(255,200,60,"+yO+"), " + 
        getShake() + Math.floor(y/7) + "px -" + y + "px " + yB + "px rgba(210,180,20,"+yO+")";
    $(this).css("-webkit-text-shadow", ts);
    $(this).css("-moz-text-shadow", ts);
    $(this).css("-ms-text-shadow", ts);
    $(this).css("-text-shadow", ts);
    $(this).css("text-shadow", ts);

    var cl = 'rgba('+Math.floor(getVariance(240,250))+','+Math.floor(getVariance(160,180))+',0,'+getVariance(0.5,0.9)+')';
    $(this).css('color', cl);

    var mx = 'matrix(' + getVariance(0.98, 1.02) + 
        ', ' + getVariance(-0.02, 0.02) + 
        ', ' + getVariance(-0.02, 0.02) + 
        ', ' + getVariance(0.98, 1.02) + 
        ', ' + Math.floor(getVariance(-1, 1)) + 
        ', ' + Math.floor(getVariance(-1, 1)) + 
        ')';
    $(this).css('-webkit-transform', mx);
    $(this).css('-moz-transform', mx);
    $(this).css('-ms-transform', mx);
    $(this).css('-transform', mx);
    $(this).css('transform', mx);
  });
}

function getVariance(min,max) {
  return Math.random() * (max - min) + min;
}

function getShake() {
  return (Math.random() > 0.5) ? "-" : "";
}




// setChangeListener(fireTxt, function(event){
//   fireTxt.innerHTML = fireTxt.innerText;
//   wrapCharacters($('.fire-text'));
// });

// function setChangeListener (el, listener) {
//     el.addEventListener("blur", listener);
//     el.addEventListener("keyup", listener);
//     el.addEventListener("paste", listener);
//     el.addEventListener("copy", listener);
//     el.addEventListener("cut", listener);
//     el.addEventListener("delete", listener);
//     el.addEventListener("mouseup", listener);
// }