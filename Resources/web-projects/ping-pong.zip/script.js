/*
Designed by: Gal Shir
Original image: https://dribbble.com/shots/4272534-Ping-Pong-Slow-Motion
*/