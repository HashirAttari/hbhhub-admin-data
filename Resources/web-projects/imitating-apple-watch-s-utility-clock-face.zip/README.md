# Imitating Apple Watch's Utility clock face

A Pen created on CodePen.io. Original URL: [https://codepen.io/dtinth/pen/vYVgKR](https://codepen.io/dtinth/pen/vYVgKR).

Original by Apple: http://www.apple.com/watch/design/