# CSS : clip -path with fake borders

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/PoymyjJ](https://codepen.io/cbolson/pen/PoymyjJ).

