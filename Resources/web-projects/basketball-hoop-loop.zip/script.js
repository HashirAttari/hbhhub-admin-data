gsap.config({trialWarn: false});
MotionPathPlugin.convertToPath('#mainPath');

gsap.set('svg', {
	visibility: 'visible'
})

let ballProp = gsap.getProperty('#ball');
const rotateShine = () => {
	gsap.set('#shineBounce', {
	
		x: ballProp('x'),
		y: ballProp('y'),
		rotation: 42,
		transformOrigin: '50% 50%'
	})
}
let tl = gsap.timeline({paused: false, onUpdate: rotateShine});
tl.to('.startPath', {
	duration: 0.8,
	morphSVG: {
		shape: '#endPath'
	},
	ease: 'power3.inOut',
	stagger: {
	repeat: -1,
		each: 0.2
	}
})
.from('.startPath', {
	duration: 0.8,
	strokeWidth:0,
	ease: 'slow(0.2, 0.8, true)',
	stagger: {
	repeat: -1,
		each: 0.2
	}
},0)
.to('#ball', {
	motionPath: {
		path: '#mainPath',
		align: '#mainPath',
		alignOrigin: [0.5, 0.5],
		autoRotate: false
	},
	duration: 3.5,
	repeat: -1,
	ease: 'none'
}, 0)
.to('#ball', {
	rotation: `-=${gsap.utils.random(-360, 360)}`,
	duration: 2,
	repeat: -1,
	ease: 'sine.in',
	repeatRefresh: true
}, 0)
.fromTo('#ball, #ballGradShadow, #ballGradShine', {
	scale: 1.82,
	transformOrigin: '50% 50%',
}, {
	duration: 0.4,
	transformOrigin: '50% 50%',
	scale: 0.95,
	repeat: -1,
	yoyo: true,
	ease: 'power1.in'
}, 0)
.to('#shine', {
	duration: 0.4,
	opacity: 0.05, 
	transformOrigin: '160% 100%',
	scale: 0.5,
	repeat: -1,
	yoyo: true,
	ease: 'power1.in'
}, 0).seek(100)