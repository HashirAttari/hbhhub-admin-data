// An awful lot of box shadows, to do...

// This: x.com/TylerNickerson/status/1799185732998992219

// A recreation of Tyler Nickerson's amazing image using only CSS

// instagram.com/ivorjetski
// twitter.com/ivorjetski
// youtube.com/c/ivorjetski