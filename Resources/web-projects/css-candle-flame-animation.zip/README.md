# CSS Candle Flame Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/kh-mamun/pen/YLGjvx](https://codepen.io/kh-mamun/pen/YLGjvx).

Animated candle flame with pure css