# The Weasley Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/oliviale/pen/KKKYJZm](https://codepen.io/oliviale/pen/KKKYJZm).

Not responsive, for sanity reasons.