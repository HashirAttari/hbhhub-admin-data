# Auxetic Cubes (CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/XWGpJOV](https://codepen.io/amit_sheen/pen/XWGpJOV).

