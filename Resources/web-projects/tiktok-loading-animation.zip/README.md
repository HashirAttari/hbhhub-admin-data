# TikTok Loading Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/rNWZPzx](https://codepen.io/benhatsor/pen/rNWZPzx).

