# Pure CSS Loading Bar Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/NxbePR](https://codepen.io/jcoulterdesign/pen/NxbePR).

Based on @jackthomsonn's pen funky loader.