# CSS tentacles

A Pen created on CodePen.io. Original URL: [https://codepen.io/meodai/pen/BazVQvZ](https://codepen.io/meodai/pen/BazVQvZ).

