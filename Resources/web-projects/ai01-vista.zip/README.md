# AI01: Vista

A Pen created on CodePen.io. Original URL: [https://codepen.io/cjgammon/pen/PoBxXrP](https://codepen.io/cjgammon/pen/PoBxXrP).

Alien Interfaces: 01 - Designed by AI / ML with midjourney.  
See the process here: 
https://alieninterfaces.com/cases/vista.html