const G = 10;

// Shuffle an array: https://stackoverflow.com/questions/2450954/how-to-randomize-shuffle-a-javascript-array
function shuffle(array) {
  var currentIndex = array.length,temporaryValue,randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}

function distance(x1, y1, x2, y2) {
  let a = x2 - x1;
  let b = y2 - y1;
  return Math.sqrt(a * a + b * b);
}

function constrain(value, min, max) {
  return Math.max(Math.min(value, max), min);
}

class Spawner {
  constructor(count, fuse) {
    this.current = 0;
    this.count = count;
    this.lastSpawn = performance.now();
    this.fuse = fuse;
  }

  shouldSpawn() {
    if (this.current < this.count && this.lastSpawn + this.fuse < performance.now()) {
      this.current += 1;
      this.lastSpawn = performance.now();
      return true;
    }
  }}


const Logo = ({ cx, cy, scale }) => {
  const size = 512;
  const x = cx - size * scale / 2;
  const y = cy - size * scale / 2;
  return /*#__PURE__*/(
    React.createElement("g", { transform: `translate(${x},${y}) scale(${scale})` }, /*#__PURE__*/
    React.createElement("rect", { x: "0", y: "0", width: "512", height: "512", rx: "96", stroke: "white", strokeWidth: "32" }), /*#__PURE__*/
    React.createElement("rect", { x: "0", y: "0", width: "512", height: "512", rx: "96", fill: "#00C3A1" }), /*#__PURE__*/
    React.createElement("path", { d: "M144 112H366.2M144 112C144 129.673 129.673 144 112 144C94.3269 144 80 129.673 80 112C80 94.3269 94.3269 80 112 80C129.673 80 144 94.3269 144 112ZM366.2 112C366.2 94.3269 380.527 80 398.2 80C415.873 80 430.2 94.3269 430.2 112C430.2 129.673 415.873 144 398.2 144C389.821 144 382.195 140.78 376.49 135.51M366.2 112C366.2 121.294 370.162 129.663 376.49 135.51M144 400H366.2M144 400C144 417.673 129.673 432 112 432C94.3269 432 80 417.673 80 400C80 382.327 94.3269 368 112 368C120.837 368 128.837 371.582 134.627 377.373M144 400C144 391.163 140.418 383.163 134.627 377.373M366.2 400C366.2 417.673 380.527 432 398.2 432C415.873 432 430.2 417.673 430.2 400C430.2 382.327 415.873 368 398.2 368C380.527 368 366.2 382.327 366.2 400ZM134.627 377.373L376.49 135.51", fill: "transparent", stroke: "white", strokeWidth: "32" })));


};

class Demo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      spawner: new Spawner(ZestIcons.count, 200),
      icons: shuffle(ZestIcons.all),
      particles: [] };


  }

  componentDidMount() {
    this.tick();
  }

  tick() {
    requestAnimationFrame(time => {
      if (!this._lastTime) {this._lastTime = time;}
      const ellapsed = time - this._lastTime;
      this._lastTime = time;
      this.update(ellapsed);
      this.tick(); // help
    });
  }

  update(ellapsed) {
    const { width, height } = this.props;
    const { particles, spawner } = this.state;
    const cx = width / 2;
    const cy = height / 2;
    if (spawner.shouldSpawn()) {
      particles.push({
        x: width / 2,
        y: height / 2 - 200,
        vx: -1,
        vy: 0 });

    }
    particles.forEach(p => {
      const d = constrain(distance(cx, cy, p.x, p.y), 1, 20);
      const a = Math.atan2(cy - p.y, cx - p.x);
      const strength = constrain(G / (d * d), 0, 3);
      const ax = strength * Math.cos(a);
      const ay = strength * Math.sin(a);
      p.vx += ax;
      p.vy += ay;
      p.x += p.vx * ellapsed;
      p.y += p.vy * ellapsed;
    });
    this.setState({ particles: particles });
  }

  render() {
    const { width, height } = this.props;
    const { particles, icons } = this.state;
    const els = particles.map((p, i) => {
      return /*#__PURE__*/React.createElement("g", { key: `icon-${i}`, transform: `translate(${p.x - 24}, ${p.y - 24}) scale(2)`, dangerouslySetInnerHTML: { __html: icons[i].paths } });
    });
    return /*#__PURE__*/(
      React.createElement("a", { target: "_blank", href: "http://zesticons.com" }, /*#__PURE__*/
      React.createElement("svg", {
        width: width,
        height: height,
        viewBox: [0, 0, width, height].join(" ") }, /*#__PURE__*/

      React.createElement("rect", {
        x: 0,
        y: 0,
        width: width,
        height: height,
        fill: "white" }),
      els, /*#__PURE__*/
      React.createElement(Logo, { cx: width / 2, cy: height / 2, scale: 0.25 }))));



  }}


ReactDOM.render( /*#__PURE__*/
React.createElement(Demo, { width: window.innerWidth * 1.25, height: window.innerHeight * 1.25 }),
document.getElementById('example'));