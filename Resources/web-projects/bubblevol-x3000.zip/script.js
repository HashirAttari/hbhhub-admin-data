var bufferVolume=0,sort=false,foundSwap,index,progress,boxes;

function createNumberboxes(amount){
  var wrapper=document.getElementById("numberwrapper");
  for (var i=0;i<amount;i++){
    var box=document.createElement("div");
    box.className="numberbox";
    (function(vol){
      box.addEventListener("click",function(){
        bufferVolume=vol;
        if (!sort) setupSort();
      });
    })(i/(amount-1));
    box.innerHTML=i;
    box.id=i;
    wrapper.appendChild(box);
  }
  shuffleBoxes();
}

function shuffleBoxes(){
  boxes=document.getElementsByClassName("numberbox");
  var wrapper=document.getElementById("numberwrapper");
  for (var i=0;i<boxes.length;i++){
    wrapper.insertBefore(boxes[i],boxes[Math.floor(Math.random()*boxes.length)])
  }
  getSortStatus();
}

function setupSort(){
  foundSwap=false;
  index=0;
  progress=1;
  sort=true;
}

function slowSort(){
  if (sort){
    if (parseInt(boxes[index+1].id)<parseInt(boxes[index].id)){
      document.getElementById("numberwrapper").insertBefore(boxes[index+1],boxes[index]);
      foundSwap=true;
    }
    getSortStatus();
    index++;
    document.getElementById("movebox").style.left=2.2*index+"em";
    if (index==boxes.length-progress){
      if (!foundSwap){
        document.getElementById("audio").volume=bufferVolume;
        sort=false;
        document.getElementById("volume").innerHTML=Math.floor(bufferVolume*100);
        setTimeout(function(){
          shuffleBoxes();
        },1000);
      }
      document.getElementById("movebox").style.left="0";
      index=0;
      progress++;
      foundSwap=false;
    }
  }
}

function getSortStatus(){
  for (var i=0;i<boxes.length;i++){
    if (boxes[i].id==i){
      boxes[i].classList.add("sorted");
    }else{
      boxes[i].classList.remove("sorted");
    }
  }
}

setInterval(slowSort,50);
createNumberboxes(15);