# AI Animated Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/cjgammon/pen/KKYYqwO](https://codepen.io/cjgammon/pen/KKYYqwO).

Created with AI / ML with Remix.ai
See the process here: https://www.youtube.com/watch?v=rXPWrE326CA