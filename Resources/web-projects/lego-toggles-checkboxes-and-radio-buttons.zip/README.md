# Lego toggles, checkboxes and radio buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolasjesenberger/pen/MWZLVLo](https://codepen.io/nicolasjesenberger/pen/MWZLVLo).

