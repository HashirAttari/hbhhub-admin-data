let ocv = 12
function create(type = "") {
  return document.createElementNS("http://www.w3.org/2000/svg", type)
}
const svg = create("svg")
const keyboard = create("g")
keyboard.classList.add("keyboard")
document.body.appendChild(svg)
svg.appendChild(keyboard)

const map = new WeakMap()
const activeKeys = new Set()
const actx = new window.AudioContext()
window.addEventListener('click', () => actx.resume())
let volume
try {
  volume = actx.createGain()
  volume.gain.value = 0.5
  volume.connect(actx.destination)
} catch (e) {}

document.querySelector(".volume").addEventListener("input", function() {
  volume.gain.value = +this.value
})

const chordButton = document.querySelector(".playChord")
const playOver = document.querySelector(".playOver")
document.querySelector(".removeChord").addEventListener("click", removeChord)
function removeChord() {
  activeKeys.forEach(key => key.classList.remove("active"))
  activeKeys.clear(1)
}

keyboard.addEventListener("mouseover", e => playOver.checked && play(e))
keyboard.addEventListener("mouseout", e => playOver.checked && play(e))

chordButton.addEventListener("mousedown", playChord)
chordButton.addEventListener("mouseup", playChord)

keyboard.addEventListener("mousedown", toggle)

const waveformInput = document.querySelector('.waveform')
let waveform = waveformInput.value
waveformInput.addEventListener('change', () => {
  waveform = waveformInput.value
})

function toggle(e) {
  const key = e.target
  if (activeKeys.has(key)) {
    activeKeys.delete(key)
    key.classList.remove("active")
    keyboard.insertBefore(key, keyboard.firstChild)
  } else {
    activeKeys.add(key)
    key.classList.add("active")
    keyboard.appendChild(key)
  }
}

function playChord(e) {
  activeKeys.forEach(key => {
    play({ target: key, type: e.type })
  })
}

function play(e) {
  const note = map.get(e.target)
  if (e.type === 'keydown' || e.type === "mouseover" || e.type === "mousedown") note.play()
  else note.stop()
}
/*const noteRef = {
  note: 69,
  freq: 440,
}*/
const noteRef = {
  note: 64,
  freq: 329.6275569128699
}
function note2freq(n = 0) {
  return noteRef.freq * Math.pow(2, (n - noteRef.note) / ocv)
}
function freq2note(f = 1) {
  return noteRef.note + ocv * Math.log(f / noteRef.freq) / Math.log(2)
}
class Note {
  constructor(notenumber) {
    this.number = notenumber
    this.freq = note2freq(this.number)
  }
  createOsc() {
    if (this.osc) this.stop()
    this.gain = actx.createGain()
    this.gain.gain.setValueAtTime(0, actx.currentTime)
    this.osc = actx.createOscillator()
    this.osc.connect(this.gain)
    this.gain.connect(volume)
    this.osc.type = waveform
    this.osc.frequency.value = this.freq
    this.osc.onended = e => {
      this.osc.disconnect()
      this.gain.disconnect()
      this.osc = null;
    }
  }
  play() {
    this.createOsc()
    this.osc.start()
    this.fade(.08, 0.4)
    this.fadeOut(3)
  }
  stop() {
    if(this.osc) this.fadeOut(.2, true)
  }
  fadeOut(time = 0.01, imediate) {
    this.fade(time, 0, imediate)
  }
  fade(time = 0.01, to = 0, imediate) {
    if(imediate) {
      console.log(this.gain.gain.value)
      this.gain.gain.cancelScheduledValues(actx.currentTime)
      //this.gain.gain.setValueAtTime(this.gain.gain.value, actx.currentTime)
    }
    this.gain.gain.linearRampToValueAtTime(to, actx.currentTime + time)
    //this.gain.gain.exponentialRampToValueAtTime(to+.001, actx.currentTime+time);
  }
}

const WHITE_POSITIONS = [0, null, 1, null, 2, 3, null, 4, null, 5, null, 6]
const KEY_COUNT = 128
const OCTAVE_WIDTH = 60
const KEYBOARD_SIZE = OCTAVE_WIDTH / 12 * KEY_COUNT
const NOTE_HEIGHT = 5.5 / 7
function posSharp(noteNumber) {
  const note = noteNumber % 12
  const octave = (noteNumber - note) / 12
  let pos
  if (note <= 5) {
    pos = note * 3 / 7 / 5
  } else pos = 3 / 7 + (note - 5) * 4 / 7 / 7
  return pos + octave
}
function createNote(noteNumber) {
  const SHARP_HEIGHT = Math.abs(ocv) === 12 ? 7 / 12 : 1
  const note = noteNumber % 12
  const octave = (noteNumber - note) / 12
  const noteHeight = OCTAVE_WIDTH * NOTE_HEIGHT
  const sharpHeight = noteHeight * SHARP_HEIGHT
  const keyboardCenter = OCTAVE_WIDTH / 12 * 64
  const noteWidth = OCTAVE_WIDTH / 7
  const posSharp1 = posSharp(noteNumber) * OCTAVE_WIDTH - keyboardCenter
  const posSharp2 = posSharp(noteNumber + 1) * OCTAVE_WIDTH - keyboardCenter
  const polygon = create("polygon")
  const sharp = WHITE_POSITIONS[note] == null
  let points = [
    posSharp1,
    sharpHeight,
    posSharp1,
    0,
    posSharp2,
    0,
    posSharp2,
    sharpHeight
  ]
  if (Math.abs(ocv) === 12 && !sharp) {
    const whitePosition = WHITE_POSITIONS[note]
    const posNote1 =
      whitePosition * noteWidth + octave * OCTAVE_WIDTH - keyboardCenter
    const posNote2 = posNote1 + noteWidth
    points = points.concat([
      posNote2,
      sharpHeight,
      posNote2,
      noteHeight,
      posNote1,
      noteHeight,
      posNote1,
      sharpHeight
    ])
  }
  polygon.setAttribute("points", points)
  polygon.title = note
  polygon.setAttribute("stroke", "black")
  polygon.setAttribute(
    "fill",
    `hsl(${Math.round(noteNumber / ocv * 360)}, 50%, ${50 + (Math.abs(ocv) === 12 ? 15 : 0) * (sharp ? -1 : 1)}%)`
  )
  //polygon.style.transform = `translateX(${pos0}px)`;
  keyboard.appendChild(polygon)
  map.set(polygon, new Note(noteNumber))
  svg.style.height = noteHeight + 4 + "px"
}

const input = document.querySelector(".octave")
const scaleInput = document.querySelector(".scale")

function setOctave() {
  const min = Math.round(64 - KEY_COUNT / 2)
  const max = Math.round(64 + KEY_COUNT / 2)
  for (let i = min; i < max; i++)
    createNote(i)
  resize()
}

input.addEventListener("input", e => {
  removeChord()
  while (keyboard.firstChild) {
    keyboard.removeChild(keyboard.firstChild)
  }
  ocv = +input.value
  setOctave()
})

setOctave()

scaleInput.addEventListener("input", resize)

window.addEventListener("resize", resize)

window.addEventListener("wheel", e => {
  e.preventDefault()
  let val = +scaleInput.value
  val += e.deltaY / 30
  scaleInput.value = val
  resize()
})

function resize() {
  const w = window.innerWidth
  const scale = w / (OCTAVE_WIDTH / 12 * +scaleInput.value)
  const noteHeight = OCTAVE_WIDTH * NOTE_HEIGHT
  //keyboard.style.transform = `scale(${scale})`;
  keyboard.setAttribute("transform", `translate(${w / 2}) scale(${scale})`)
  svg.style.height = noteHeight * scale + 4 + "px"
}
resize()

var key = "zxcvbnm,./"
window.addEventListener("keydown", e => {
  console.log(e, e.code)
})

window.addEventListener("keydown", (e) => {
  if(e.code !== "Space") return
  if(e.repeat) return
  playChord(e)
})

window.addEventListener("keyup", (e) => {
  if(e.code !== "Space") return
  playChord(e)
})