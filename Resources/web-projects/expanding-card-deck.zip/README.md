# Expanding Card Deck

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/bGGNqEO](https://codepen.io/MananTank/pen/bGGNqEO).

Deck of cards with transitioning transforms that appear as animations