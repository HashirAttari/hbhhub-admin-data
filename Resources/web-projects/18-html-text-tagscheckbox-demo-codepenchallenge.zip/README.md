# 18 HTML Text Tags - Checkbox Demo #CodePenChallenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/EpGoeZ](https://codepen.io/leenalavanya/pen/EpGoeZ).

