var c = document.getElementById("myCanvas"); // Get the canvas
var ctx = c.getContext('2d');
var canvasWidth = c.width; //Get its width
var canvasHeight = c.height; //Get its height

var angle = 0; //The angle of the finished circle in radians
var startAngle = 0; // The starting angle of the circle in radians
var radius = 70; // The radius of the circle
var speed = 1.8; // The speed of the animation

ctx.strokeStyle = "white"; //Color of the line
ctx.lineCap = "round";
ctx.lineWidth = 5; // Width of the line

var requestAnimationFrame = window.requestAnimationFrame ||
	window.mozRequestAnimationFrame ||
	window.webkitRequestAnimationFrame ||
	window.msRequestAnimationFrame; //Required to get the animation started

function drawCircle() {
	ctx.clearRect(0, 0, canvasWidth, canvasHeight); //Empty the canvas 
	ctx.beginPath();
	ctx.arc(225, 225, radius, startAngle, angle / 2, false); //Draw the arc at the center of the canvas
	ctx.stroke();
	angle += Math.PI / 50 * speed; //Increase the angle
	startAngle += Math.PI / 200 * speed; //Increase the starting angle, but at a slower rate
	if (angle > Math.PI * 8) { //Once the circle is complete, draw a tick
		ctx.font = "50px Arial";
		ctx.fillStyle = "white";
		ctx.textAlign = "center";
		ctx.fillText("✔", c.width / 2, c.height / 2 + 18);
	} else { //If its not complete, keep the animation going until it is
		requestAnimationFrame(drawCircle);
	}
}