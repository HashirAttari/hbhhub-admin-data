# 3D Walkman - Pure CSS Art

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/RwBZMGB](https://codepen.io/ricardoolivaalonso/pen/RwBZMGB).

