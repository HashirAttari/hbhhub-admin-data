# Toggle badge

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/vYPOvVd](https://codepen.io/alvaromontoro/pen/vYPOvVd).

