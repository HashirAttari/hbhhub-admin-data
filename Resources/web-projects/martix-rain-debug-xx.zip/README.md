# Martix rain debug XX

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/ZErypBW](https://codepen.io/franksLaboratory/pen/ZErypBW).

