console.clear();

const elInput = document.querySelector('#input');
const elDisplay = document.querySelector('#display');

Splitting({ whitespace: true });
elInput.addEventListener('input',()=>{
  elDisplay.innerHTML = Splitting.html({ content: elInput.value, whitespace: true });
});

window.setTimeout(()=>{ document.querySelector('#reveal').click() }, 1000);