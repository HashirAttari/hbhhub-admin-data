# iOS style scrolling dock with scroll-driven animation 🤔

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/xxmRyJO](https://codepen.io/jh3y/pen/xxmRyJO).

