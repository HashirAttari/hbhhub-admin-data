$('.panel').mousemove(function(event){
    var size = 180;
    console.log(size)
    var xDifference = ($(window).width() - $('.panel').width())/2 + (size/2);
    var x = event.clientX - xDifference;
    var yDifference = ($(window).height() - $('.panel').height())/2 + (size/2);
    var y = event.clientY - yDifference;
    $('.panel_reveal').css('-webkit-mask','url("https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/mask.png")  ' + x + 'px ' + y + 'px/' + size + 'px ' + size + 'px no-repeat');
    $('.panel_reveal').css('mask','url("https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/mask.png")  ' + x + 'px ' + y + 'px/' + size + 'px ' + size + 'px no-repeat');
    
})

$('.panel').mouseout(function(){
    $('.panel_reveal').css('-webkit-mask','url("https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/mask.png")  -130px -130px/50px 50px no-repeat');
    $('.panel_reveal').css('mask','url("https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/mask.png")  -130px -130px/50px 50px no-repeat');
})