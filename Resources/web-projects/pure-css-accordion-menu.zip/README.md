# Pure Css Accordion Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/anzjoy/pen/kymqbZ](https://codepen.io/anzjoy/pen/kymqbZ).

Hre is how to create Stylish Pure css Accordion Mneu with out any javascript !