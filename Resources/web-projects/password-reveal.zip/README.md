# Password Reveal

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/RwWgexd](https://codepen.io/ainalem/pen/RwWgexd).

Dribbble remake of Show password by prekesh https://dribbble.com/shots/4298963-Show-password

Using CSS clip-path morhping and SVG morphing to create a password reveal effect