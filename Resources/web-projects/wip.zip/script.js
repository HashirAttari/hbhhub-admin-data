const secondSelector = document.querySelector('.seconds');
const minuteSelector = document.querySelector('.minutes');
const hourSelector = document.querySelector('.hours');

function setDate() {
  const now = new Date();
  const seconds = now.getSeconds();
  const minutes = now.getMinutes();
  const hours = now.getHours();

  const getSecondsDegrees = ((seconds / 60) * 360);
  const getMinutesDegrees = ((minutes / 60) * 360);
  const getHoursDegrees = ((hours / 60) * 360);

  secondSelector.style.transform = `rotate(${getSecondsDegrees}deg)`;
  minuteSelector.style.transform = `rotate(${getMinutesDegrees}deg)`;
  hourSelector.style.transform = `rotate(${getHoursDegrees}deg)`;
}

setInterval(setDate, 1000);