# Menu Animated Dropdown and Icon

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/qbmyRZ](https://codepen.io/leenalavanya/pen/qbmyRZ).

A full screen animated menu icon and dropdown using pure javacsript and css3,