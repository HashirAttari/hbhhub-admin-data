$(function(){
  $('input').on('keyup', function(){
    var $this = $(this);
    var val = $this.val();
    
    
    $('[class*="mdi"]').css('color','black');
    $('.icons [class*="'+ val +'"]').css('color','red');
  })
});