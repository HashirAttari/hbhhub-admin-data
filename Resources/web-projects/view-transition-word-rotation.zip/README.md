# View Transition Word Rotation 😎

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/mdaEJRG](https://codepen.io/jh3y/pen/mdaEJRG).

