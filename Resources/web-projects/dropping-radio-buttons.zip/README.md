# Dropping Radio Buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/rNPYjvN](https://codepen.io/jkantner/pen/rNPYjvN).

A radio button animation where the clicked option stretches to the current or next one and causes it to drop into place. The effect was inspired by a [Dribbble shot](https://dribbble.com/shots/4928355-Radio-Buttons-Interaction-II) by Oleg Frolov.