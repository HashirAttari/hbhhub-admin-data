# Circles

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/BmvKqX](https://codepen.io/yuanchuan/pen/BmvKqX).

css-doodle DEMO http://yuanchuan.name/css-doodle