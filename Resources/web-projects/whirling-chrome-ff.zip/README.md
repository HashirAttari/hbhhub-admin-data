# Whirling (Chrome, FF)

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/yrobOe](https://codepen.io/yuanchuan/pen/yrobOe).

Liam's Floating Melancholy https://codepen.io/shubniggurath/pen/yroLjq  inspired me to make a small hole