/*var xV = 0;

var maxV = 1000;

var prevMousePos = {x: 0, y: 0};
var mousePos = {x: 0, y: 0};

var acc = 0.001;
var deacc = 0.01;

var rotY = 30;

var direction = 'left';

window.setInterval(function() {
  // Movement
  if (prevMousePos != mousePos) {
    var traveledX = (prevMousePos.x - mousePos.x);
    
    if (traveledX < 0) {
      direction = 'left';
    }
    else {
      direction = 'right';
    }
    
    xV += (traveledX * acc);
    
    if (xV > maxV) {
      xV = maxV;
    }
  }
  else {
    xV -= deacc;
    
    if (xV < 0) {
      xV = 0;
    }
    
    rotY += xV;
  }
  prevMousePos = mousePos;

  document.querySelector('#iphone').style.transform = 'rotateY('+rotY+'deg) rotateX(30deg)';
}, 20)

document.onmousemove = (e) => {
  var currentX = e.clientX;
	var currentY = e.clientY;
  
  mousePos = {x: currentX, y: currentY};
  
  /*document.querySelector('#iphone').style.transform = 'rotateY('+linearM(currentX, 30, 50)+'deg) rotateX('+linear(currentY, 20, 40)+'deg)'; // 30*/

function linear(x, y1, y2) {
  return (y2 - y1) * -1 * x + y2;
}

function linearM(x, y1, y2) {
  return (y2 - y1) * -1 * x + y2;
}*/