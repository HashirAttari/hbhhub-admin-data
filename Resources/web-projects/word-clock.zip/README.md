# Word clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/kjwon15/pen/XWmNmJ](https://codepen.io/kjwon15/pen/XWmNmJ).

