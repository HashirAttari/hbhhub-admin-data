/*
Designed by: Alex Safayan
Original image: https://dribbble.com/shots/6211601-Suburban-Home
*/
const m = document.querySelector("#m");
const b = document.querySelector("#b");
const d = document.querySelector("#d");

let base = (e) => {
    let  x = e.pageX / window.innerWidth - 0.5;
    let  y = e.pageY / window.innerHeight - 0.5;
    b.style.transform = `
        perspective(10000px)
        rotateX(${ y * 40  + 70}deg)
        rotateZ(-${ x * 100  + 40}deg)
    `;
}

let debug = (e) => {
    m.classList.toggle("main-debug");
    b.classList.toggle("b-debug");
}


m.addEventListener("mousemove", base);
d.addEventListener("click", debug);