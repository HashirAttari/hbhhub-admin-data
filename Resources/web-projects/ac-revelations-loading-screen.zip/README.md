# AC: Revelations Loading Screen

A Pen created on CodePen.io. Original URL: [https://codepen.io/tdullah/pen/vepJmw](https://codepen.io/tdullah/pen/vepJmw).

Having a little bit of fun with particles.js to create the Assassin's Creed: Revelations' (my favourite game) loading screen.