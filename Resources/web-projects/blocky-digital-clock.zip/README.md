# Blocky Digital Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/KQaZdp](https://codepen.io/jkantner/pen/KQaZdp).

A digital clock inspired by some typography in the [GameCube BIOS](http://orig00.deviantart.net/5d8e/f/2016/289/b/e/gmse01_1_by_machriderz-dal9de1.png). The cubes that make up the digits move according to the current system time. All drawn using CSS cubes.

Update 5/27/23: Just a description update