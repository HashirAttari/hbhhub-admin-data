# Responsive CSS Tabs

A Pen created on CodePen.io. Original URL: [https://codepen.io/hluebbering/pen/PoaWLrw](https://codepen.io/hluebbering/pen/PoaWLrw).

