# Border transformations - Symmetry

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/xpqGMW](https://codepen.io/yuanchuan/pen/xpqGMW).

More CSS patterns made with transformations on the borders.