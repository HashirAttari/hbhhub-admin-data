window.addEventListener('scroll', (e) => {
  
  let target = document.querySelector('.header__img');
  
  let scrolled = window.pageYOffset;
  let rate = scrolled * -.2;
  target.style.transform = 'translate3d(0px,' + rate + 'px, 0px)';
  target.style.transition = 'all .2s ease';

});