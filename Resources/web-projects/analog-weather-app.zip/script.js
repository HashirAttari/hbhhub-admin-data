// Source:
// http://dribbble.com/shots/1235592-Analog-Weather-App/