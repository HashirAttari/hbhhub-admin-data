# Ripple Away And Expand

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshonweb/pen/JjbYMEo](https://codepen.io/joshonweb/pen/JjbYMEo).

Small Demo of how  you can animate elements staggering the siblings from the element that was clicked