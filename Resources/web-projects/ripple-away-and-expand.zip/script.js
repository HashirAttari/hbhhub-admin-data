const cards = document.querySelectorAll(".card");
const details = document.querySelector(".detail");
details.addEventListener("click", closeCard);
cards.forEach(setup);
function setup(card, i) {
	card.addEventListener("click", handleCardClick);
	card.dataset.index = i;
}

//--//--//--//--//--//--//--//--//--//--//--//--
function handleCardClick(e) {
	const originCard = e.currentTarget;
	const originPoint = getCoordinateOnWindow(originCard);

	const cards = [...document.querySelectorAll(".card")];

	flip(() => {
		details.parentElement.dataset.active = "true";
	}, originCard);
	cards.filter((card) => card != originCard).forEach(staggerAway(originPoint));
}

function closeCard(e) {
	const card = e.currentTarget;
	delete card.parentElement.dataset.active;
	document.querySelectorAll(".disappear").forEach(animatedBackIn);
}

//--//--//--//--//--//--//--//--//--//--//--//--
function staggerAway(origin) {
	return function staggerAwayFromClicked(card) {
		const cardCoord = getCoordinateOnWindow(card);

		const distance = getDistance(origin, cardCoord);

		card.style.setProperty("--delay", distance);

		card.classList.add("disappear");
		card.addEventListener("animationend", cleanUpAnimateOut);
	};
}

//--//--//--//--//--//--//--//--//--//--//--//--
function getDistance([startX, startY], [endX, endY]) {
	const width = getSide(startX, endX);
	const height = getSide(startY, endY);
	return getHypotenuse(width, height);
}
function getHypotenuse(a, b) {
	return Math.sqrt(square(a) + square(b));
}
function getSide(start, end) {
	return Math.abs(start - end);
}
const square = (num) => num * num;

//--//--//--//--//--//--//--//--//--//--//--//--
function getCoordinateOnWindow(el) {
	const {
		y: elY,
		x: elX,
		width: elWidth,
		height: elHeight
	} = el.getBoundingClientRect();
	const yPosition = Math.floor(window.pageYOffset + findCenter(elY, elHeight));
	const xPosition = Math.floor(window.pageXOffset + findCenter(elX, elWidth));
	return [xPosition, yPosition];
}
function findCenter(coord, size) {
	return coord + size / 2;
}
//--//--//--//--//--//--//--//--//--//--//--//--
function flip(action, el) {
	const cachedSize = el.getBoundingClientRect();

	setTimeout(() => {
		action();
		const modal = document.querySelector(".detail");
		const newSize = modal.getBoundingClientRect();
		// modal.animate([{ background: "red" }, { background: "green" }], 2000);
		console.log({ cachedSize, newSize });
		el.style.opacity = "0";
		el.classList.add("disappear");

		modal.animate(
			[
				{
					transformOrigin: `0px 0px`,
					transform: `translate(${cachedSize.left - newSize.left}px, ${
						cachedSize.top - newSize.top
					}px) scale(${cachedSize.width / newSize.width}, ${
						cachedSize.height / newSize.height
					})`,
					borderRadius: `30px`
				},
				{
					borderRadius: `40px`,
					transformOrigin: `0px 0px`,
					transform: `translate(0,0) scale(1)`
				}
			],
			{
				fill: "forwards",
				duration: 500,
				easing: `cubic-bezier(0.5, 0, 0.5, 1)`
			}
		);
	}, 200);
}
//--//--//--//--//--//--//--//--//--//--//--//--
function animatedBackIn(card) {
	card.classList.remove("disappear");
	card.style.removeProperty("opacity");
	card.classList.add("animate-in");
	card.addEventListener("animationend", cleanUpAfterAnimation);
}
function cleanUpAfterAnimation(e) {
	e.target.classList.remove("animate-in");
	e.target.removeEventListener("animationend", cleanUpAfterAnimation);
}
function cleanUpAnimateOut(e) {
	e.target.removeEventListener("animationend", cleanUpAnimateOut);
}
//--//--//--//--//--//--//--//--//--//--//--//--