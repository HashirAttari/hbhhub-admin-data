var global_cal={};
//計算式
global_cal.caltext="";
//答案
global_cal.ans=0;
var lastcal=false;


//將計算式 答案資料與介面同步
var vm = new Vue({
  el: "#app",
  data: global_cal
});

$(".btnnum").click(function(){
  //當有這個class的時候，計算式直接加上span裡面的文字
  global_cal.caltext+=$(this).children("span").text();
  lastcal=false;
});

//取倒數
$("#btn_reverse").click(function(){
  //計算 並把計算式設為空字串
  global_cal.ans=(""+(1/parseInt(global_cal.caltext))).substr(0,9);
  global_cal.caltext="";
});

//開根號
$("#btn_sqrt").click(function(){
  //如果剛剛做完運算(lastcal=true)就再做一次
  if (lastcal)
    global_cal.ans=(""+(Math.sqrt(parseInt(global_cal.ans)))).substr(0,9);   
  else
    global_cal.ans=(""+(Math.sqrt(parseInt(global_cal.caltext)))).substr(0,9);
  
  global_cal.caltext="";
  lastcal=true;
 
});

$("#btn_rvnag").click(function(){
  //取前九個
  global_cal.ans=(""+(-(parseInt(global_cal.caltext)))).substr(0,9);
  global_cal.caltext="";
});

$("#btn_clear_all").click(function(){
  global_cal.ans=0;
  global_cal.caltext="";
});
$("#btn_clear").click(function(){
  global_cal.caltext="";
});
$("#btn_cal_all").click(function(){
  //丟eval計算取前九個，加""之後資料會變文字，取前九個字
  global_cal.ans=(""+eval(global_cal.caltext.split("＊").join("*"))).substr(0,9);
  global_cal.caltext="";
  lastcal=true;
});

$("#btn_back").click(function(){
  //從0開始取(長度-1)個字，所以看起來像退格
  global_cal.caltext=global_cal.caltext.substr(0,global_cal.caltext.length-1);
});