const rangePower = document.getElementById('power');

rangePower.addEventListener('change', () => {
  const power = rangePower.value;
  document.getElementById('neon').style = `--power: ${power}px;`;
}, false);