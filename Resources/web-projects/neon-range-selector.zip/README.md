# Neon range selector

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pedro-Ondiviela/pen/LYqyGPa](https://codepen.io/Pedro-Ondiviela/pen/LYqyGPa).

Neon style with a range selector that changes its intensity