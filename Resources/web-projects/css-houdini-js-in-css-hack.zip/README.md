# CSS Houdini JS-in-CSS hack

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/MVvRYY](https://codepen.io/yuanchuan/pen/MVvRYY).

