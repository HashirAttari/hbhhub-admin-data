if (typeof registerPaint !== 'undefined') {
  
  registerPaint('paint', class {
    static get inputProperties() {
      return [ '--paint' ];
    }
    paint(ctx, size, props, args) {
      let paint = String(props.get('--paint'));
      try {
        let fn = new Function('return ' + paint)();
        fn.apply(this, arguments);
      } catch (e) {
        console.error(e.message);
      }
    }
  });
 
}