# Netflix Logo (single div)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/JjvovNN](https://codepen.io/ykadosh/pen/JjvovNN).

I made this Netflix logo by layering 5 CSS gradients. Everything is applied to a single div, and is infinitely scalable!

I originally created this in a tool that I made called GradientArt.
You can find this logo there too, and further inspect the different layers - https://gra.dient.art/view/pisaztye4p