setTimeout(function(){ 

var lights_count = 11,        
    wire_color = 'transparent',
    glow_size = 3,
    twinkle = true,
    rotation_max = 90,    
    target_elements = document.querySelectorAll('.addLights'),
    colors = ['darkred','darkorange','goldenrod', 'orange','orangered','tomato'],
    l_width = 100 / lights_count

target_elements.forEach(function(elm) {
  var elm_loc = elm.getBoundingClientRect(),
      elm_h = Math.floor(elm_loc.height / (elm_loc.width / lights_count))
  console.log(elm_h)

  // vertical lights
  for(var i=0;i<elm_h;i++) {
    var l = document.createElement('div')
    l.className = 'light_box'
    l.style.width = elm_loc.height / elm_h + 'px'
    l.style.height = elm_loc.width + 'px'
    l.style.position = 'absolute'
    l.style.left = 0
    l.style.top = 100 / elm_h * i + '%'
    var rot = Math.random() < .5 ? -Math.random()*rotation_max : Math.random()*rotation_max
    l.innerHTML = `
    <div class='light' style='--color:${colors[i%colors.length]}; transform:rotate(${rot}deg);'></div>
    <div class='light' style='--color:${colors[(i+2)%colors.length]}; transform:rotate(${rot}deg);'></div>`
    if(twinkle) {
      l.classList.add('twinkle')
      l.style.setProperty('--delay', i / 3 - 1 + 's' )
    }
    l.style.transformOrigin = '0 0'
    var width_px = elm_loc.width/(lights_count)
    l.style.transform = `translateX(${(lights_count)*(width_px)}px) rotate(90deg)`
    elm.appendChild(l)
  }

  // horizontal lights
  for(var i=0;i<lights_count;i++) {
    var l = document.createElement('div')
    l.className = 'light_box'
    l.style.width = l_width + '%'
    l.style.position = 'absolute'
    l.style.left = l_width * i + '%'
    l.style.top = '0'
    l.style.bottom = '0'
    var rot = Math.random() < .5 ? -Math.random()*rotation_max : Math.random()*rotation_max
    l.innerHTML = `
    <div class='light' style='--color:${colors[i%colors.length]}; transform:rotate(${rot}deg);'></div>
    <div class='light' style='--color:${colors[(i+2)%colors.length]}; transform:rotate(${rot}deg);'></div>`
    if(twinkle) {
      l.classList.add('twinkle')
      l.style.setProperty('--delay', i / 3 - 1 + 's' )
    }
    elm.appendChild(l)
  }
})

document.body.innerHTML += `
<style>
.twinkle .light::after {
  animation: twinkle 1s linear var(--delay) infinite;
}
@keyframes twinkle {
  50% { font-size: 30px; }
}

.light_box {
  pointer-events: none;
}
.light {
  width: 50%;
  max-width: 15px;
  aspect-ratio: 1/1;
  position: absolute;
  left: 40%;
  --color: gold;
}
.light:nth-child(1) {
  top: 99.5%;
  transform-origin: 50% 50%;
}
.light:nth-child(2) {
  bottom: 99.5%;
  transform-origin: 50% 50%;
}

.light::after {
  content: '🎃';
  width: 100%;
  aspect-ratio: 1/1;
  font-size: 20px;
  position: absolute;
  left: 50%;
  
  border-radius: 75% 0 75% 0;
}
.light:nth-child(1)::after {
  top: 50%;  
  transform: translate(-50%,-50%);
}
.light:nth-child(2)::after {
  bottom: 50%;
  transform: translate(-50%,50%);
}

.addLights {
  position: relative;
  border: 2px solid ${wire_color};
  border-radius: 1rem;
}
</style>
`
}, 1000)