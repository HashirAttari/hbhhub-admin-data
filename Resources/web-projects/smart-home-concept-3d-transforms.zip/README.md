# Smart Home Concept | 3D Transforms 

A Pen created on CodePen.io. Original URL: [https://codepen.io/yudizsolutions/pen/rNyjgEY](https://codepen.io/yudizsolutions/pen/rNyjgEY).

We have made a smart home design with the help of CSS property transform-style preserve-3d  and tried to make 3d view of the room.

We took reference from our dribble shot:
https://dribbble.com/shots/14758908-Smart-Home-Concept-Adobe-XD-Playoff

Made by Shivangi Majithiya from Yudiz