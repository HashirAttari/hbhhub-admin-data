# AI02: Chiclet

A Pen created on CodePen.io. Original URL: [https://codepen.io/cjgammon/pen/VwBJxBa](https://codepen.io/cjgammon/pen/VwBJxBa).

Alien Interfaces: 01 - Designed by AI / ML with midjourney.  
See the process here: 
https://alieninterfaces.com/cases/vista.html