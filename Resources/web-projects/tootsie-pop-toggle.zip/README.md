# Tootsie Pop Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/VwRJpKm](https://codepen.io/jkantner/pen/VwRJpKm).

The more you interact with this switch, the more the center of the Tootsie Pop will show itself! How many (c)licks will it take to get there?