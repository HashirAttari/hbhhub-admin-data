# Beacon loader | Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/ryOxGp](https://codepen.io/havardob/pen/ryOxGp).

Simple loader with beacon blink effect