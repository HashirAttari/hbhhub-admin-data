gsap.config({trialWarn: false});
let select = s => document.querySelector(s),
		toArray = s => gsap.utils.toArray(s),
		mainSVG = select('#mainSVG'),
		allBars = toArray('.bar'),
		allSweeps = toArray('.sweep'),
		barHeight = 62,
		nodeHeight = 24,
		mainTl = gsap.timeline({repeat: -1})

gsap.set('svg', {
	visibility: 'visible'
})
allBars.forEach((c, i) => {
		gsap.set(c, {
			transformOrigin: '50% 90%',
			y: (i * ((barHeight*2 - nodeHeight)))
		})
		gsap.set(allSweeps[i], {
			attr: {
				//cy: i % 2 ? 56 : 6
			}			
		})
	let tl = gsap.timeline();
	tl.to(c, {
		rotation: i % 2 ? '-=180' : '+=180',
		duration: 2,
		ease: 'elastic(0.7, 0.4)'//blendEases('expo.in', 'back(0.6)')
	})
.to(allSweeps[i], {
		//rotation: -720,
		duration: 2,
		transformOrigin: '50% 50%',
		ease: 'linear'// 'elastic(0.7, 0.4)'//blendEases('expo.in', 'back(0.6)')
	}, 0)
	.fromTo(allSweeps[i], {
		drawSVG: '25% 25%',
		//stroke:
	},{
		stroke: '#FFE66D',
		strokeWidth: 4,
		duration: 1,
		drawSVG: i % 2 ? '25% 75%' : '-75% -125%' ,
		ease: 'power1.in'
	}, 0)
	.to(allSweeps[i], {
		duration: 1,
		drawSVG:i % 2 ? '125% 125%' : '-125% -125%',
		ease: 'power4'
	}, '-=1')
	mainTl.add(tl, i*0.26)
})
gsap.set('#allBars', {
	rotation: -90,
	transformOrigin: '50% 50%'
})
let moveTl = gsap.timeline();
moveTl.to('#allBars', {
	x: `-=${(53 - nodeHeight/2)}`,
	ease: 'linear',
	duration: mainTl.duration()
})
mainTl.add(moveTl, 0)
//ScrubGSAPTimeline(mainTl)
gsap.globalTimeline.timeScale(0.82)