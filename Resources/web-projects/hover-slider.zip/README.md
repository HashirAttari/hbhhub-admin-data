# Hover slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/ZVQLmR](https://codepen.io/ig_design/pen/ZVQLmR).

