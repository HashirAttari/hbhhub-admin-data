function isLeap(y) {
  return new Date(y, 1, 29).getDate() === 29;
}

let output = '';

for (let i=2018; i<2100; i++) {
  output += i + (isLeap(i) ? ' is ':' is not ') + 'a leap year<br>';
}
  
document.write(output);