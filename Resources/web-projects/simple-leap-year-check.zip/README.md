# simple leap year check

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/yvgaMV](https://codepen.io/run-time/pen/yvgaMV).

