const SocialLinks = props => {
  const socialAccounts = ["twitter", "facebook", "instagram"];
  const socialLinksHTML = socialAccounts.map((item) => /*#__PURE__*/
  React.createElement("a", {
    href: `https://${item}.com/beyonce`,
    className: `relative inline-flex items-center justify-center w-32 h-32 text-gray-900 social-link ${item}`,
    key: item,
    target: "blank_" }, /*#__PURE__*/

  React.createElement("i", { className: `relative z-10 fa fa-3x fa-${item}` })));



  return /*#__PURE__*/React.createElement("ul", { className: "flex items-center space-x-12" }, socialLinksHTML);
};

const SocialApp = props => /*#__PURE__*/React.createElement(SocialLinks, null);

ReactDOM.render( /*#__PURE__*/React.createElement(SocialApp, null), document.getElementById("root"));