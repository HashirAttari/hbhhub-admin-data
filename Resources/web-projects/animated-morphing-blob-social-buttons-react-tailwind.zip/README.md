# Animated Morphing Blob Social Buttons (React + Tailwind)

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/GYXgPe](https://codepen.io/markmead/pen/GYXgPe).

Creating an animated morphing blog effect with CSS border-radius