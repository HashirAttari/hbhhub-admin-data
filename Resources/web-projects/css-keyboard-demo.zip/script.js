(function() {
  // JS concept contributed by Nick Walsh 
  // https://twitter.com/nickawalsh
  $(function() {
    return $(window).on('keypress', function(e) {
      $('.key').removeClass('is-active');
      return $(`[data-key=${e.which}]`).addClass('is-active');
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiPGFub255bW91cz4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ2dDO0VBQUE7O0VBQ2hDLENBQUEsQ0FBRSxRQUFBLENBQUEsQ0FBQTtXQUNBLENBQUEsQ0FBRSxNQUFGLENBQVMsQ0FBQyxFQUFWLENBQWEsVUFBYixFQUF5QixRQUFBLENBQUMsQ0FBRCxDQUFBO01BQ3ZCLENBQUEsQ0FBRSxNQUFGLENBQVMsQ0FBQyxXQUFWLENBQXNCLFdBQXRCO2FBQ0EsQ0FBQSxDQUFFLENBQUEsVUFBQSxDQUFBLENBQWEsQ0FBQyxDQUFDLEtBQWYsQ0FBQSxDQUFBLENBQUYsQ0FBMEIsQ0FBQyxRQUEzQixDQUFvQyxXQUFwQztJQUZ1QixDQUF6QjtFQURBLENBQUY7QUFEZ0MiLCJzb3VyY2VzQ29udGVudCI6WyIjIEpTIGNvbmNlcHQgY29udHJpYnV0ZWQgYnkgTmljayBXYWxzaCBcbiMgaHR0cHM6Ly90d2l0dGVyLmNvbS9uaWNrYXdhbHNoXG4kIC0+XG4gICQod2luZG93KS5vbiAna2V5cHJlc3MnLCAoZSkgLT5cbiAgICAkKCcua2V5JykucmVtb3ZlQ2xhc3MoJ2lzLWFjdGl2ZScpXG4gICAgJChcIltkYXRhLWtleT0je2Uud2hpY2h9XVwiKS5hZGRDbGFzcygnaXMtYWN0aXZlJykiXX0=
//# sourceURL=coffeescript