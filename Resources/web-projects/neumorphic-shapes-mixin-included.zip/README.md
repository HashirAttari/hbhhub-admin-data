# Neumorphic Shapes (Mixin Included)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/YzpJNLg](https://codepen.io/ykadosh/pen/YzpJNLg).

A bit late as usual, but I just discovered that this beautiful design trend that I've been seeing more and more lately is called Neumorphism, and I find it very elegant. 

So I decided to recreate this nice dribble shot by Conor Hansen https://dribbble.com/shots/9909652-Neumorphism-Sample

Read more about Neumorphism here - https://uxdesign.cc/neumorphism-in-user-interfaces-b47cef3bf3a6
