# Matrix digital rain (animated version)

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/YoqWeR](https://codepen.io/yuanchuan/pen/YoqWeR).

