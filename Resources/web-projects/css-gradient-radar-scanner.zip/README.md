# CSS Gradient Radar Scanner

A Pen created on CodePen.io. Original URL: [https://codepen.io/GeorgePark/pen/wvEExqg](https://codepen.io/GeorgePark/pen/wvEExqg).

A responsive animated radar scanner using CSS gradients.