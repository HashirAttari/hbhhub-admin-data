"use strict";
class App {
    constructor() {
        this.select = (s) => { return document.querySelector(s); };
        this.selectAll = (s) => { return document.querySelectorAll(s); };
        this.mainTl = new TimelineMax();
        this.isOn = false;
        this.particleArr = [];
        this.bubbleToggle = this.select('#bubbleToggle');
        this.mainBubble = this.select('#mainBubble');
        this.mainHit = this.select('#mainHit');
        this.bubbleL = this.select('#bubbleL');
        this.bubbleR = this.select('#bubbleR');
        this.oldBubble = this.bubbleR;
        this.currentBubble = this.bubbleL;
        this.splashContainer = this.select('#splashContainer');
        this.splashColorArr = ['#C9E5FA', '#C0E1F9', '#8BC8F0', '#BEE0F9'];
        this.clickBubble = e => {
            this.isOn = !this.isOn;
            this.oldBubble = (this.isOn) ? this.bubbleL : this.bubbleR;
            this.currentBubble = (this.isOn) ? this.bubbleR : this.bubbleL;
            var bubbleTl = new TimelineMax().timeScale(0.5);
            bubbleTl.staggerTo([this.bubbleL, this.bubbleR], 0.5, {
                cycle: {
                    alpha: (this.isOn) ? [0, 1] : [0.31, 0],
                    scale: (this.isOn) ? [1.1, 1] : [1, 1.1],
                    duration: (this.isOn) ? [0, 0] : [0, 0],
                    ease: (this.isOn) ? Expo.easeOut : Sine.easeIn
                },
            }, 0)
                .fromTo(this.currentBubble, 1, {
                scaleX: 0.86
            }, {
                scaleX: 1,
                ease: Elastic.easeOut.config(0.8, 0.16)
            }, 0)
                .fromTo(this.currentBubble, 0.6, {
                scaleY: 0.7
            }, {
                scaleY: 1,
                ease: Elastic.easeOut.config(0.6, 0.35)
            }, '-=1');
            if (this.isOn) {
                return;
            }
            this.playSplash();
        };
        this.createSplash = e => {
            const splash = this.select('.splash');
            let num = 50;
            while (--num > -1) {
                let clone = splash.cloneNode(true);
                this.particleArr.push(this.splashContainer.appendChild(clone));
                this.initSplash(clone);
            }
        };
        this.initSplash = clone => {
            TweenMax.set(clone, {
                x: this.randomBetween(Number(this.oldBubble.getAttribute('x')) + 0, Number(this.oldBubble.getAttribute('x')) + 45),
                y: this.randomBetween(Number(this.oldBubble.getAttribute('y')) + 0, Number(this.oldBubble.getAttribute('y')) + 60),
                alpha: 0,
                scale: 1,
                fill: this.splashColorArr[this.randomBetween(0, this.splashColorArr.length - 1)],
                attr: {
                    r: this.randomBetween(15, 30) / 5
                },
                transformOrigin: '50% 50%'
            });
        };
        this.randomBetween = (min, max) => {
            return Math.floor(Math.random() * (max - min + 1) + min);
        };
        TweenMax.staggerTo([this.bubbleL, this.bubbleR], 0, {
            cycle: {
                svgOrigin: ['357 300', '445 300']
            }
        }, 0);
        this.createSplash();
        this.mainHit.addEventListener('click', this.clickBubble);
    }
    playSplash() {
        var tl = new TimelineMax();
        tl.staggerTo(this.particleArr, 0, {
            cycle: {
                scale: (i, t) => {
                    this.initSplash(t);
                    return Math.random();
                }
            },
            alpha: 1
        })
            .staggerTo(this.particleArr, 1, {
            cycle: {
                physics2D: () => {
                    return { velocity: this.randomBetween(10, 30),
                        angle: this.randomBetween(90, -135),
                        gravity: this.randomBetween(-150, -50) };
                },
                duration: () => {
                    return Math.random() * 3;
                }
            },
            scale: 0,
            alpha: 0,
            ease: Sine.easeOut
        });
    }
    get timeline() {
        return this.mainTl;
    }
}
TweenMax.set('svg', {
    visibility: 'visible'
});
new App();