var day = ["Sunday","Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
var mon = ['January','February','March','April','May','June','July','August','September','October','November','December'];

var days = 0
var d = new Date();
var n = d.getDate();
var m = mon[d.getMonth()]
var y = d.getYear() + 1900
var t = document.getElementById('today')

function color() {
  var color = "hsl("+(Math.floor(Math.random()*360))+"deg,60%,50%)";
  return color;
}

function build() {
  var tomorrow = new Date(new Date().setDate(new Date().getDate() + days))
  var month = tomorrow.getMonth()
  var year = tomorrow.getYear() + 1900
  
  var div = document.createElement('div')
  div.className = "day month" + month 
  div.style.filter = "hue-rotate("+(month*30)+"deg)"
  div.setAttribute('title',mon[month] + " " + year)
    
  var date = document.createElement('div')
  date.className = "date"  
  date.innerHTML = tomorrow.getDate() 
  
  // show sundays
  if(tomorrow.getDay() == 0) {
    date.style.color = "#111"
  }
  
  // make months easier to see
  if(month % 2 === 0) {
    div.style.borderRadius = "0"
    div.style.boxShadow = "none"
  }
  
  // add items to page
  document.getElementById('cal').appendChild(div).append(date)  
  
  // stop running
  if(days == 365) {
    clearInterval(stack)    
  }
  days++  
}

var stack = setInterval(build)

// style today
t.innerHTML = n + " " + m + " " + y
setTimeout(function(){
t.style.filter = document.getElementsByClassName('day')[0].style.filter;  
},200)