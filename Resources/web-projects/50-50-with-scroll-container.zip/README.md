# 50/50 with scroll container

A Pen created on CodePen.io. Original URL: [https://codepen.io/hexagoncircle/pen/PoLdzzo](https://codepen.io/hexagoncircle/pen/PoLdzzo).

Read the blog post: <a href="https://ryanmulligan.dev/blog/50-50-overflow/">The Fifty-Fifty Split and Overflow</a>