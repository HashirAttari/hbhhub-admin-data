# Floatting Draggable Menu (Messenger like) 

A Pen created on CodePen.io. Original URL: [https://codepen.io/andyNroses/pen/rLRZgY](https://codepen.io/andyNroses/pen/rLRZgY).

I've always found the messenger menu sexy. Wanted to do one for the web, here it is!
 
Using anime.js & Foundation Icon Fonts 3