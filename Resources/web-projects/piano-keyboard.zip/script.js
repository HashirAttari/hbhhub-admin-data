$(document).ready(function() {
  $(document).keypress(function(e) {
      switch(e.which) {
          //white keys
        case 121 /* Y */: 
          $('.key-w1').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 120 /* x */:
          $('.key-w2').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 99 /* c */:
          $('.key-w3').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 118 /* v */:
          $('.key-w4').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 98 /* b */:
          $('.key-w5').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 110 /* n */:
          $('.key-w6').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 109 /* m */:
          $('.key-w7').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
        case 97 /* a */:
          $('.key-w8').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 115 /* s */:
          $('.key-w9').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 100 /* d */:
          $('.key-w10').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 102 /* f */:
          $('.key-w11').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 103 /* g */:
          $('.key-w12').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 104 /* h */:
          $('.key-w13').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 106 /* j */:
          $('.key-w14').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
          
          // black keys
        case 48 /* 0 */:
          $('.key-b1').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 49 /* 1 */:
          $('.key-b2').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 50 /* 2 */:
          $('.key-b3').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 51 /* 3 */:
          $('.key-b4').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 52 /* 4 */:
          $('.key-b5').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 53 /* 5 */:
          $('.key-b6').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 54 /* 6 */:
          $('.key-b7').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 55 /* 7 */:
          $('.key-b8').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 56 /* 8 */:
          $('.key-b9').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
        case 57 /* 9 */:
          $('.key-b10').addClass("pushed_key").delay(200).queue(function(next) {
            $(this).removeClass('pushed_key');
            next()
          });
          break;
      };
  });
});