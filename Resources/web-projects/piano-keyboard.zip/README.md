# Piano keyboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/alexdevero/pen/nKNRGr](https://codepen.io/alexdevero/pen/nKNRGr).

Quick piano keyboard in HTML, CSS & jQuery code.
Controls:
white key left-to-right:
y(z),x,c,v,b,n,m,a,s,d,f,g,h,j

black keys left-to-right:
0,1,2,3,4,5,6,7,8,9