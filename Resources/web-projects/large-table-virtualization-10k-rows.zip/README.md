# Large Table Virtualization (10K Rows)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/ZdxeYY](https://codepen.io/ykadosh/pen/ZdxeYY).

This is a proof of concept aimed at solving the following issues:
1. The CSS-Grid 1000 row limit  (see https://stackoverflow.com/a/47345676/1096470)
2. Lazy data loading - rendering large tables where only a portion of the data is available at the client side
3. Performance issues that naturally occur when rendering very large tables

The idea here is to only render the rows that are currently  visible to the user based on the scroll position. The non-visible rows are replaced with a single row that receives their total height (this row also receives a gradient background that simulates the horizontal row gap to make it look as if the lines are there).

In terms of performance, a table of 100 rows will perform exactly the same as a table with 10K rows.