# Simply Awesome Soft Search Box with tutorial.

A Pen created on CodePen.

Original URL: [https://codepen.io/nikhil/pen/nrRVqM](https://codepen.io/nikhil/pen/nrRVqM).

Hi, im Nikhil. i was just experimenting with realistic shadows using CSS.

Here is simple soft search box with realistic shadows.

Please feel frank to comment what you like/dislike about this search box and feel good to be a part of this community. 