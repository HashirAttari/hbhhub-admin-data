# (Webkit) Clip Path Carousel

A Pen created on CodePen.io. Original URL: [https://codepen.io/lloydwheeler/pen/PooJmM](https://codepen.io/lloydwheeler/pen/PooJmM).

Using CSS clip-path to transition between carousel items. Webkit only with graceful degradation.