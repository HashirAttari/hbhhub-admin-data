var $this,
        $carousel,
        $carouselItem,
        $navigation,
        $navigationItem,
        $navigationItemActive,
        animated,
        currentItem,
        numOfItems;

    $this = $(this);
    currentItem = 0;
    numOfItems = $('.carousel__items > li').length;
    $carousel = $('.carousel__items');
    $carouselItem = $('.carousel__item');
    $navigation = $('.carousel__navigation');
    animated = false;

    initCarousel();

    function initCarousel() {
      $('.carousel__items > li:eq(' + currentItem + ')').css('z-index', '100').children('div').addClass('show');
      createNavigation();
      setWidths();
    }

    function setWidths() {
      // Calculate the correct width for each slide and the slide container
      $carousel.css('width', (100 * numOfItems) + '%');
      $carouselItem.css('width', (100 / numOfItems) + '%')

      // Center the navigation
      var navWidth = parseInt($navigation.css('width'));
      $navigation.css('margin-left', -(navWidth/2));
    }
    
    function createNavigation() {
      // Creates a bulleted list to act as navigation

      var i = 0;
      for(; i < numOfItems; i++) {
        if (i === currentItem) {
          $navigation.append('<li class="carousel__bullet active"></li>');
        } else {
          $navigation.append('<li class="carousel__bullet"></li>');
        }
      }

      initNavigation();
    }

    function initNavigation() {
      $navigationItem = $('.carousel__bullet');

      $navigationItem.click(function() {
        var $this = $(this);
        var current = $this.hasClass('active');

        if (!animated && !current) {

          animated = true;
          $('.hide').removeClass('hide');
          
          var nextItem = $this.index();
          var $nextItem = $('.carousel__items > li:eq(' + nextItem + ')');
          var $currentItem = $('.carousel__items > li:eq(' + currentItem + ')');

          $('.active').removeClass('active');
          $this.addClass('active');

          $nextItem.css('z-index', '100');
          $currentItem.css('z-index', '99');
      
          setTimeout(function() {
            $currentItem.children('div').removeClass('show').addClass('hide');
            animated = false;
          }, 1000);
        
          $nextItem.children('div').addClass('show');
          currentItem = nextItem;

        }

      });
    }