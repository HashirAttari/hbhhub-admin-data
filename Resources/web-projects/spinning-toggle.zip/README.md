# Spinning toggle 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/VwKEjWW](https://codepen.io/havardob/pen/VwKEjWW).

