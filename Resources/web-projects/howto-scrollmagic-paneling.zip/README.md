# HowTo : ScrollMagic Paneling

A Pen created on CodePen.io. Original URL: [https://codepen.io/grayghostvisuals/pen/rNNKjm](https://codepen.io/grayghostvisuals/pen/rNNKjm).

Demo for ScrollMagic. Customized by making the layout liquid and using transforms w/multiple panel transitions to create cool sliding effects that are curtain-esque.

http://janpaepke.github.io/ScrollMagic