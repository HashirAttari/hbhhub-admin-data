let index = 0;
const classes = ["adidas", "vans", "puma", "nike"];
const pics = document.querySelectorAll(".pic");
const ids = [];
function cycle(pic, clazz) {
  pic.classList.add(clazz);
  void pic.offsetHeight;
  pic.classList.add("active");
}
function restart() {
  ids.forEach(id => clearTimeout(id));
  ids.length = 0;
  pics.forEach((pic, i) => {
    pic.className = `pic`;
    const id = setTimeout(() => {
      cycle(pic, classes[i]);
    }, 1000 + i * 1000);
    ids.push(id);
  });
}
restart();