# Brand cut zoom

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/YbyOYM](https://codepen.io/ainalem/pen/YbyOYM).

Using clip-path to create a playful entry of images.  

Photos from Unsplash.com  by:
Ayo Ogunseinde
Harry Hundal
Zell
Paul Volkmer