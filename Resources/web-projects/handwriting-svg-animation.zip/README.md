# Handwriting: SVG animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/munkholm/pen/EaZJQE](https://codepen.io/munkholm/pen/EaZJQE).

Summerbird's logo (SVG) animated in CSS