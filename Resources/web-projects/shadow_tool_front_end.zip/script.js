const btn=document.getElementById("btn")
const text=document.getElementById("text")


let posX=5;
let posY=5;
let blur=0;
let color="blue"

let shadow=`${posX}px ${posY}px ${blur}px ${color}`;
btn.style.boxShadow = shadow;
text.innerHTML=`shadow-box: ${shadow}`

function setColor(){
  let el=document.getElementById("select-color");
   color=el.value;
  
shadow=`${posX}px ${posY}px ${blur}px ${color}`;
  btn.style.boxShadow = shadow;
text.innerHTML=`shadow-box: ${shadow}`
}

function changePosX(){
    let el=document.getElementById("myRange1");
   posX=el.value;
  
shadow=`${posX}px ${posY}px ${blur}px ${color}`;
  btn.style.boxShadow = shadow;
text.innerHTML=`shadow-box: ${shadow}`
}

function changePosY(){
    let el=document.getElementById("myRange2");
   posY=el.value;
  
shadow=`${posX}px ${posY}px ${blur}px ${color}`;
  btn.style.boxShadow = shadow;
text.innerHTML=`shadow-box: ${shadow}`
}

function changeBlur(){
    let el=document.getElementById("myRange3");
  blur=el.value;
  
shadow=`${posX}px ${posY}px ${blur}px ${color}`;
  btn.style.boxShadow = shadow;
text.innerHTML=`shadow-box: ${shadow}`
}