# Swanky little accordian list

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/dPeMKY](https://codepen.io/jcoulterdesign/pen/dPeMKY).

Here's another little CSS creation using the 'Label for' trick. I plan on maybe making a few more of these in different styles but for the time being i think its a nice 'non javascript' addition to any user interface.