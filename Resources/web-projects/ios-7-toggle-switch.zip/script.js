$(".toggle").on("click", function (){
  $(this).toggleClass("active");
  $(this).toggleClass("inactive");
});