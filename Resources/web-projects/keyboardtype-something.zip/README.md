# Keyboard - Type something

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/KKwqLQy](https://codepen.io/ricardoolivaalonso/pen/KKwqLQy).

