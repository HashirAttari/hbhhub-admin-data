# CSS Tooltip Magic

A Pen created on CodePen.io. Original URL: [https://codepen.io/tutsplus/pen/WROvdG](https://codepen.io/tutsplus/pen/WROvdG).

Read full tutorial [How to Make Magic, Animated Tooltips With CSS](https://webdesign.tutsplus.com/tutorials/css-tooltip-magic--cms-28082) on Tuts+. By [Jase](https://codepen.io/jasesmith/)