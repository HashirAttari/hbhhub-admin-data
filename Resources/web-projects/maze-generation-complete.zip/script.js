const DIRECTIONS = ["n", "e", "s", "w"];
const OPPOSITE = {
  n: "s",
  s: "n",
  w: "e",
  e: "w" };

const DIRECTION_COORDINATES = {
  n: [0, 1],
  e: [1, 0],
  s: [0, -1],
  w: [-1, 0] };

const NODE = {
  n: true,
  e: true,
  s: true,
  w: true,
  visited: false };




function rand(array) {
  const randDirs = array.sort(() => Math.floor(Math.random() - 0.5));
  console.log("randDirs", randDirs);

  return randDirs;
}

function randomizeDirections() {
  const directions = rand(DIRECTIONS);
  return directions;
}

function getModifier(key) {
  return DIRECTION_COORDINATES[key];
}
function getOpposite(key) {
  return OPPOSITE[key];
}

function nextNode(startX, startY, maze) {
  const node = maze[startY][startX];
  node.visited = true;
  randomizeDirection().forEach(direction => {
    const [incrementX, incrementY] = getModifier(direction);
    const nextX = startX + incrementX;
    const nextY = startY + incrementY;

    if (maze[nextY] && maze[nextY][nextX] && !maze[nextY][nextX].visited) {
      node[direction] = false;
      maze[nextY][nextX][getOpposite(direction)] = false;

      nextNode(nextX, nextY, maze);
    }
  });
  return false;
}
function generateMaze(maze, [startX, startY]) {
  const newMaze = [...maze];
  nextNode(startX, startY, newMaze);

  return newMaze;
}


// unit tests
// do not modify the below code
describe("mazes", function () {
  beforeEach(() => {});
  it("5x5", () => {
    setOrder(1);
    const maze = generateMaze(genEmptyMaze(5, 5), [0, 0]);
    writeMaze(maze, document.getElementById("maze-1"));
    expect(maze).toEqual([
    [
    { n: true, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: true, w: false, visited: true }],

    [
    { n: false, e: true, s: true, w: true, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true }],

    [
    { n: false, e: true, s: false, w: true, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: true, w: false, visited: true }],

    [
    { n: false, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true }],

    [
    { n: true, e: true, s: false, w: true, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: false, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: true, w: false, visited: true }]]);


  });

  it("8x8", () => {
    setOrder(2);
    const maze = generateMaze(genEmptyMaze(8, 8), [5, 3]);
    writeMaze(maze, document.getElementById("maze-2"));
    expect(maze).toEqual([
    [
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: true, w: false, visited: true }],

    [
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true }],

    [
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true }],

    [
    { n: false, e: true, s: false, w: true, visited: true },
    { n: true, e: true, s: false, w: true, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: true, visited: true },
    { n: false, e: false, s: false, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true }],

    [
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: true, visited: true }],

    [
    { n: true, e: false, s: true, w: true, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: true, w: true, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: false, w: false, visited: true }],

    [
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: false, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true }],

    [
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true }]]);


  });

  it("15x15", () => {
    setOrder(3);
    const maze = generateMaze(genEmptyMaze(15, 15), [10, 2]);
    writeMaze(maze, document.getElementById("maze-3"));
    expect(maze).toEqual([
    [
    { n: false, e: true, s: true, w: true, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: true, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: true, w: false, visited: true }],

    [
    { n: false, e: false, s: false, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: true, w: false, visited: true }],

    [
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: true, w: true, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: true, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true }],

    [
    { n: false, e: true, s: true, w: true, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: false, e: true, s: false, w: true, visited: true }],

    [
    { n: false, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: false, visited: true },
    { n: true, e: true, s: false, w: true, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: true, s: true, w: true, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: false, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true }],

    [
    { n: false, e: true, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: false, visited: true }],

    [
    { n: false, e: true, s: false, w: true, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true }],

    [
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: false, w: false, visited: true },
    { n: true, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: false, e: true, s: false, w: true, visited: true }],

    [
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: false, e: true, s: false, w: true, visited: true }],

    [
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: true, s: false, w: true, visited: true }],

    [
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: true, w: false, visited: true }],

    [
    { n: false, e: true, s: false, w: true, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: true, e: true, s: false, w: true, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: false, w: false, visited: true }],

    [
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: false, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: true, w: false, visited: true },
    { n: false, e: true, s: false, w: true, visited: true },
    { n: true, e: true, s: false, w: true, visited: true }],

    [
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: true, s: false, w: true, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: false, e: false, s: true, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: false, e: true, s: true, w: false, visited: true }],

    [
    { n: true, e: true, s: false, w: true, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: false, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: true, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: false, s: false, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true },
    { n: true, e: false, s: false, w: true, visited: true },
    { n: true, e: false, s: true, w: false, visited: true },
    { n: true, e: true, s: false, w: false, visited: true }]]);


  });
});