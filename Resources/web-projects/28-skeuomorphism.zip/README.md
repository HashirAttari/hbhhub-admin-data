# 28 Skeuomorphism.

A Pen created on CodePen.io. Original URL: [https://codepen.io/Philip-Walsh/pen/RwdZdGd](https://codepen.io/Philip-Walsh/pen/RwdZdGd).

