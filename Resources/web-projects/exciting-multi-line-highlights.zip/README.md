# Exciting Multi-line Highlights  

A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/qBdyZXR](https://codepen.io/MananTank/pen/qBdyZXR).

Ditch the boring underline, Add some exciting highlights!