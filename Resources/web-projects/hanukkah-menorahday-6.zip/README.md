# Hanukkah menorah - Day 6

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/rNPbbRE](https://codepen.io/amit_sheen/pen/rNPbbRE).

