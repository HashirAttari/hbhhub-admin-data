# border-build v1 (gradient)

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/xxQGZYV](https://codepen.io/cbolson/pen/xxQGZYV).

https://discord.com/channels/436251713830125568/1116857478248939560/1117078387501047811