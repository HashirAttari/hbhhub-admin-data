# Tokyo 2020 (CSS only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/PommNgz](https://codepen.io/amit_sheen/pen/PommNgz).

