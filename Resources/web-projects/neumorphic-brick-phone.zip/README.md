# Neumorphic Brick Phone

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/MWpVEpj](https://codepen.io/jkantner/pen/MWpVEpj).

What ol’ brick phones may look like if we apply neumorphism to it. Also partially operable but no real calls.

## Hotkeys

| Action                | Key   |
|-----------------------|-------|
| Rcl (Recall Memory)   | R     |
| Clr (Clear)           | C     |
| Snd (Send)            | Enter |
| Sto (Store in Memory) | S     |
| Lock                  | L     |
| End                   | E     |
| Pwr (Power)           | P     |