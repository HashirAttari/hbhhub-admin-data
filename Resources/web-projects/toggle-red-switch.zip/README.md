# toggle red switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/MWRYrmv](https://codepen.io/alvaromontoro/pen/MWRYrmv).

inspired by https://codepen.io/ykadosh/pen/ExNOmZx

The original is beautiful and realistic. Mine is clumsy and messy. I don't like mine.