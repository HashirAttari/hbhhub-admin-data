# [cpc] - Smooth Scrolling Scrolls

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/OJYmNdY](https://codepen.io/cbolson/pen/OJYmNdY).

Lots of magic numbers in here and it is not responsive.
This was really just a demo.

https://discord.com/channels/436251713830125568/1247154354096701491/1247154354096701491