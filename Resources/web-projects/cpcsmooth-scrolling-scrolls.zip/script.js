document.addEventListener("DOMContentLoaded", () => {
    // Create the observer
    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("in-viewport");
                entry.target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                });
            } else {
                entry.target.classList.remove("in-viewport");
            }
        });
    }, {
        threshold: 0.1 // Adjust the threshold as needed
    });

    // Target all section elements
    const sections = document.querySelectorAll("section");
    sections.forEach(section => {
        observer.observe(section);
    });
});