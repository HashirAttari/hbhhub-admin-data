# Gooey Toggle Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/GRzmEGb](https://codepen.io/jkantner/pen/GRzmEGb).

The handle and track of this switch are melted together with the touch of an SVG filter.

⚠️ Won’t work properly in Safari.