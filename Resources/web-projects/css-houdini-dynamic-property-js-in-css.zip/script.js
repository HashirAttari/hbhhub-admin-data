if (typeof registerPaint !== 'undefined') {
  
  registerPaint('polygon', class {
    static get inputProperties() {
      return [
        '--polygon',
        '--polygon-sides',
        '--polygon-stroke-color'
      ];
    }

    polygon(radius, options, fn) {
      let sides = options.sides || 4;
      let deg = Math.PI / (sides / 2);
      let points = [];
      if (!fn) {
        fn = t => [ Math.cos(t), Math.sin(t) ];
      }
      for (let i = 0; i < sides; ++i) {
        let t = deg * i;
        let [ x, y ] = (fn(t) || []).map(n => n * radius);
        points.push({ x: x + radius, y: y + radius });
      }
      return points;
    }

    paint(ctx, geom, properties) {
      let polygon = String(properties.get('--polygon'));
      let strokeColor = String(properties.get('--polygon-stroke-color'));
      let sides = Number(properties.get('--polygon-sides'));
      let generator = new Function('return ' + polygon)();

      let { width, height } = geom;
      width -= 2; height -= 2;

      let radius = Math.min(width, height) / 2;
      let center = {
        x: width / 2, y: height / 2
      };

      let points = this.polygon(radius, { sides: sides }, generator);
      ctx.strokeStyle = strokeColor;
      ctx.beginPath();

      for (var i = 0; i < points.length; ++i) {
        let point = points[i];
        let point1 = points[i + 1];
        ctx.moveTo(point.x, point.y);
        if (point1) {
          ctx.lineTo(point1.x, point1.y);
        }
      };
      
      ctx.lineTo(points[0].x, points[0].y);
      ctx.stroke();
    }

  });
  
}