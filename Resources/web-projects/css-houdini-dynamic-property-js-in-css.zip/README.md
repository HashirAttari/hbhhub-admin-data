# CSS Houdini Dynamic property (JS in CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/BrdwXw](https://codepen.io/yuanchuan/pen/BrdwXw).

It's possible to write JS in CSS