# Picket fence animation using scroll animations

A Pen created on CodePen.

Original URL: [https://codepen.io/cbolson/pen/JoKBeaW](https://codepen.io/cbolson/pen/JoKBeaW).

