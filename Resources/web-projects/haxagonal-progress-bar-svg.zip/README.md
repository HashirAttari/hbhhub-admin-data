# Haxagonal progress bar SVG 

A Pen created on CodePen.io. Original URL: [https://codepen.io/AlaricBaraou/pen/POxdRR](https://codepen.io/AlaricBaraou/pen/POxdRR).

Tired of circle and squares ? Add SVG to use shapes that fits your brands ! 

Here two hexagonal SVG's are placed on top of another. The one below has his strokes fully drawed with not full opacity. The one on top get's animated to a certain percentage at the same speed as the numbers increment.

I use GSAP drawSVG plugin to make it easier !

Feel free to contact me if you need help reproducing this ! https://twitter.com/alaricweb