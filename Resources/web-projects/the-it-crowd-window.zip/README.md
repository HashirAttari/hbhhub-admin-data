# The IT Crowd Window

A Pen created on CodePen.io. Original URL: [https://codepen.io/Keyon/pen/gWLBPY](https://codepen.io/Keyon/pen/gWLBPY).

I started to watch The IT Crowd and the window at the end of the intro triggered me too much, so I recreated it  °/

(Try to drag the window over than 10 times)