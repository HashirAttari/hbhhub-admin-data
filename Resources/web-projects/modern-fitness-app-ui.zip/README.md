# Modern fitness app UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/MonaPla/pen/ZEwMjQz](https://codepen.io/MonaPla/pen/ZEwMjQz).

