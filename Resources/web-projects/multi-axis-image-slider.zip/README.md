# Multi axis image slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/neoberg/pen/AJyepG](https://codepen.io/neoberg/pen/AJyepG).

