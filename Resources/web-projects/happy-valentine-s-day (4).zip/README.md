# Happy Valentine's Day

A Pen created on CodePen.

Original URL: [https://codepen.io/natewiley/pen/bEOzaz](https://codepen.io/natewiley/pen/bEOzaz).

Animating some SVG with [Greensock](http://greensock.com/gsap) for Valentine's Day.

Vectors from [vectorbackground.com](http://www.vectorbackground.net/happy-valentines-day-everyone-vector-graphic.html)

Uses the [DrawSVG Plugin](http://greensock.com/drawSVG), a membership benefit of [Club Greensock](http://greensock.com/club/)