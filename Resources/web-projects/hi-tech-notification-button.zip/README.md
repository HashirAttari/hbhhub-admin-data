# Hi-Tech Notification Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/TheMOZZARELLA/pen/QWPbdNY](https://codepen.io/TheMOZZARELLA/pen/QWPbdNY).

A very over-designed and impractical (my favorite) notification button.