# Corner clip with border

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/VwENeLZ](https://codepen.io/cbolson/pen/VwENeLZ).

