# Abstract Audio Visualizer

A Pen created on CodePen.io. Original URL: [https://codepen.io/Francext/pen/ndqaqb](https://codepen.io/Francext/pen/ndqaqb).

An Abstract Audio Visualizer made with ThreeJS. Drag & drop to change the music, click/touch or leap to change the color. Also mouse wheel to zoom in/out. Works best on Chrome.