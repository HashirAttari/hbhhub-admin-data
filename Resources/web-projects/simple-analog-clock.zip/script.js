// Get all tickmarks (iterable nodeList)
const tickmarks = document.querySelectorAll(".tick-radius");

// Get clock hands
const secondHand = document.querySelector(".second-hand");
const minuteHand = document.querySelector(".min-hand");
const hourHand = document.querySelector(".hour-hand");

// Digital clock
const hoursText = document.querySelector("#hours");
const minutesText = document.querySelector("#minutes");
const secondsText = document.querySelector("#seconds");

// Date block
const dateText = document.querySelector(".date");


function expandTicks() {
  //Rotate each tickmark to correct location on circle
  tickmarks.forEach(tickmark => {
    
    // 1. Extract the minute value
    const min = parseInt(tickmark.dataset.minute);
    
    // 2. Calculate the degrees to rotate each tickmark
    const degrees = min / 60 * 360;
    
    // 3. Rotate each tickmark around the clock face
    tickmark.style.transform = `rotate(${degrees}deg)`;

    // 4. Add a 'bold' class to every 5th minute
    if (min % 5 == 0) tickmark.classList.add("bold");
    
  });
}

function setDate() {
  
  // 1. Create date and time objects
  
    // Create date object for current time
  const now = new Date();
    // Create constants for seconds, minutes, hours, date, and month
  const seconds = now.getSeconds();
  const minutes = now.getMinutes();
  var hours = now.getHours();
  const date = now.getDate();
  const month = now.getMonth();
  
  // Test/Screenshot Times
  // ---------------------
  // const seconds = 50;
  // const minutes = 30;
  // var hours = 16;
  // const date = 31;
  // const month = 6;

  // 2. Calculate degrees that each hand should rotate
  const secondsDegrees = seconds / 60 * 360;
  const minutesDegrees = (minutes / 60 + seconds / 60 / 60) * 360;
  const hoursDegrees =
    (hours / 12 + minutes / 60 / 12 + seconds / 60 / 60 / 12) * 360;
  
  // Minute and hour hands tick instead of gliding:
  // ----------------------------------------------
  // const secondsDegrees = ((seconds / 60) * 360);
  // const minutesDegrees = ((minutes / 60) * 360);
  // const hoursDegrees = ((hours / 12) * 360);

  // 3. Rotate hands around the clock
  secondHand.style.transform = `rotate(${secondsDegrees}deg)`;
  // secondsText.classList.add("fade-in");
  minuteHand.style.transform = `rotate(${minutesDegrees}deg)`;
  hourHand.style.transform = `rotate(${hoursDegrees}deg)`;
  
  
  // 5. Format text for digital clock
  
    // If hours are more than 12, make a 12 hour value
  if (hours > 12) {
    hours = hours - 12;
  } 
     
    // If hours are 0, display 12
  if(hours == 0){ 
    hours = 12;
  }
    // If hours are less than 10, add leading 0
  if (hours < 10) {
    hours = "0" + hours;
  }
  
  // 4. Update time on digital clock
  hoursText.innerHTML = "" + hours;
  minutesText.innerHTML = "" + (minutes < 10 ? "0" : "") + minutes;
  
  // 6. Update day and month
  
    // Create array for month abbreviations
  const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    
    // Set date (month and day) inside of clock
  dateText.innerHTML = `${months[month]}  ${date}`;
  
}

//Set interval for setDate to 1000
setInterval(setDate, 1000);

//Set onload function to position tickmarks
document.querySelector("body").onload = expandTicks;