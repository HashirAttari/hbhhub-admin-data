# Masterchef Visual

A Pen created on CodePen.io. Original URL: [https://codepen.io/KikePuma/pen/VwjmKOe](https://codepen.io/KikePuma/pen/VwjmKOe).

