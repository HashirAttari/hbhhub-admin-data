document.querySelector('css-doodle')
  .addEventListener('click', function(e) {
    e.target.update();  
  })