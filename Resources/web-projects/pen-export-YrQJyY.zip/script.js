function sendMessage(message,type){
  var msg=document.createElement("div");
  msg.className="message last-group "+type;
  var p=document.createElement("p");
  p.innerHTML=message.replace(/\n/g,"<br>");
  msg.appendChild(p);
  document.getElementById("inbox").appendChild(msg);
  var h=p.offsetHeight;
  for (var i=69;i>=0;i--){
    p.style.maxWidth=i+"%";
    if (p.offsetHeight!=h){
      p.style.maxWidth=(i+1)+"%";
      break;
    }
  }
  var prev=msg.previousElementSibling;
  if (prev&&prev.classList.contains(type))
    prev.classList.remove("last-group");
  scroll();
}

function scroll(){
  var inbox=document.getElementById("inbox");
  var scrollBy=Math.ceil((inbox.scrollHeight-inbox.offsetHeight-Math.floor(inbox.scrollTop))/30);
  if (scrollBy>0){
    var count=0,
        interval=setInterval(function(){
          inbox.scrollBy(0,scrollBy);
          if (count==35)
            clearInterval(interval);
          count++;
        },10);
  }
}

function initPhone(){
  document.getElementById("send-box").addEventListener("keydown",function(evt){
    var box=this;
    setTimeout(function(){
      var val=box.value.replace(/^[\s\n]+|[\s\n]+$/g,"");
      if (val.replace(/\n/g,"")&&evt.which==13&&!evt.shiftKey){
        sendMessage(val,"out");
        box.value="";
        box.focus();
      }
    },1);
  });
  setPhoneClock();
  setBattery();
}

function setPhoneClock(){
  var update=function(){
    var d=new Date();
    document.getElementById("phone-clock").innerHTML=fillZeroes(d.getHours())+":"+fillZeroes(d.getMinutes());
  };
  
  function fillZeroes(val){
    return ""+(val<10?"0"+val:val);
  }
  
  update();
  setInterval(update,1000);
}

function setBattery(){
  if (navigator.getBattery){
    navigator.getBattery().then(function(battery) {
      updateBattery();
      battery.addEventListener("chargingchange",updateBattery);
      battery.addEventListener("levelchange",updateBattery);
      function updateBattery(){
        var pb=document.getElementById("phone-battery");
        document.getElementById("battery-percentage").innerHTML=Math.floor(battery.level*100)+"%";
        if (battery.charging)
          pb.classList.add("charging");
        else
          pb.classList.remove("charging");
      }
    });
  }
}

initPhone();