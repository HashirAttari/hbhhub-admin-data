(function(){
	const cards = document.querySelectorAll('.card-single')
	const next = document.querySelector('.next')
	const prev = document.querySelector('.prev')
	const firstCard = document.querySelector('.card-single')
	////////
	////
	// controls the navigating of the question cards
	
	firstCard.classList.add('current')
	handleProgressBar()
	next.addEventListener('click',()=>{
		moveCard('next')
		handleProgressBar()
	})
	prev.addEventListener('click',()=>{
		moveCard('prev')
		handleProgressBar()
	})
	
	
	const hideFirstAndLast = ()=>{
		//this function:
			//hides the prev button if its the first card
			//hides the next button if its the last card
		const current = document.querySelector('.current')
		if(current === cards[cards.length - 1]){
			next.style.opacity = '0'
			prev.style.opacity = '1'
		}else{
			next.style.opacity = '1'
		}
		if(current === cards[0]){
			prev.style.opacity = '0'
			next.style.opacity = '1'
		}else{
			prev.style.opacity = '1'
		}
	}
	//calls above function on load
	hideFirstAndLast()
	

	const moveCard=(dir)=>{
		//this function controls which card will be shown
		//dir = 'next' or 'prev' which is which card will be shown next
		const current = document.querySelector('.current')
		if(dir==='next'){
			if(current.nextElementSibling){
				cards.forEach(card=>card.classList.remove('current'))
				current.nextElementSibling.classList.add('current')
			}
		}
		if(dir==='prev'){
			if(current.previousElementSibling){
				cards.forEach(card=>card.classList.remove('current'))
				current.previousElementSibling.classList.add('current')	
			}
		}
		hideFirstAndLast()	
	}
	///////
	////
	//end of control of navigating the question cards
	
	
	
	///////
	////
	//controls the progress bar
	function handleProgressBar(){
		const progressBar = document.querySelector('.progress-bar')
		const indicator = document.querySelector('.progress-bar span')
		
		const current = document.querySelector('.current')
		const currentIndex = [...cards].indexOf(current) + 1
		const percentage = ( currentIndex/cards.length ) * 100
		console.log(currentIndex, percentage )
		progressBar.style.width = `${percentage}%`
		//

		indicator.addEventListener('mouseenter', ()=>showProgress())
		indicator.addEventListener('mouseleave', ()=>hideProgress())
		 function showProgress(){
			indicator.classList.add('show-progress')
			indicator.innerText = `${ currentIndex }/${ cards.length } ` 
		}
		function hideProgress(){
			indicator.classList.remove('show-progress')
			
		}
		
	}
	///////
	////
	//end of control progress bar
})()