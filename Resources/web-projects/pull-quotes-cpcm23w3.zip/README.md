# Pull Quotes | cpcm23w3

A Pen created on CodePen.io. Original URL: [https://codepen.io/mugosagi/pen/eYPPPQj](https://codepen.io/mugosagi/pen/eYPPPQj).

