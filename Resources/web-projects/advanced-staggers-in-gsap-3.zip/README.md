# Advanced staggers in GSAP 3

A Pen created on CodePen.io. Original URL: [https://codepen.io/GreenSock/pen/jdawKx](https://codepen.io/GreenSock/pen/jdawKx).

An interactive example of advanced stagger values (introduced in GSAP 2.1.0).  Poke around, click on cells, and watch how things update (including the code sample). Happy tweening!