# Pricing section component

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/RwLYjJR](https://codepen.io/havardob/pen/RwLYjJR).

A pricing section component created using details and summary to imitate at tooltip-like-pop-up-effect for additional info. 