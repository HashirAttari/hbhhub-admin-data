const handleIntersectionChange = intersections => {
  intersections.forEach(i => {
    if (i.isIntersecting)
      i.target.classList.add('active')
    else 
      i.target.classList.remove('active')
  })
}

const obs = new IntersectionObserver( handleIntersectionChange, {
  threshold: 0.8,
})

const cards = document.querySelectorAll('.card')
cards.forEach( card => obs.observe(card) )