# Audio Recording

A Pen created on CodePen.io. Original URL: [https://codepen.io/eddch/pen/ZMOjPL](https://codepen.io/eddch/pen/ZMOjPL).

An audio recorder and visualizer that allows you to choose your microphone, choose your visualization, record sound,  play it back, and then download the generated WAV file.