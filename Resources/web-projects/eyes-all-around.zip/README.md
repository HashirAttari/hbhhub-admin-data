# Eyes All Around

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/QWPWVWG](https://codepen.io/jkantner/pen/QWPWVWG).

A preloader full of eyes based on an old [Dribbble Shot](https://dribbble.com/shots/2023211-Spinner) by Marc Edwards.