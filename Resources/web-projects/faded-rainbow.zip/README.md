# Faded rainbow

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/aVNmey](https://codepen.io/yuanchuan/pen/aVNmey).

  Original pen by Ana Tudor: 
  https://codepen.io/thebabydino/pen/wPKeom/ 