# Web Gears ⚙️ (Scroll-driven animations)

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/MWxeLyz](https://codepen.io/jh3y/pen/MWxeLyz).

