# CSS loaders and timing functions

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/QEWgBY](https://codepen.io/giana/pen/QEWgBY).

A small collection of timing functions I find particularly interesting or helpful.

Forked from [joogl](http://codepen.io/joogl/)'s Pen [CSS loaders and timing functions](http://codepen.io/joogl/pen/dXyNPM/).