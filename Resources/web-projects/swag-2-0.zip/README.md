# Swag 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/JjJKJRV](https://codepen.io/ricardoolivaalonso/pen/JjJKJRV).

