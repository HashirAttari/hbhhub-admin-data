# 1000 generative okLCH Ramps

A Pen created on CodePen.io. Original URL: [https://codepen.io/meodai/pen/ExQWwar](https://codepen.io/meodai/pen/ExQWwar).

Generates random color harmonies using RampenSau, clicking a sample will console log its settings, https://meodai.github.io/rampensau/ Hit the N key for a new set of palettes