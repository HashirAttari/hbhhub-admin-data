var bl = 0,
  br = 1,
  c = 1,
  g = 0,
  h = '0',
  i = 0,
  o = 1,
  sa = 1,
  se = 0;

function f(a, b) {
  switch (a) {
    case 'bl':
      bl = b;
      break;
    case 'br':
      br = b;
      break;
    case 'c':
      c = b;
      break;
    case 'g':
      g = b;
      break;
    case 'h':
      h = b;
      break;
    case 'i':
      i = b;
      break;
    case 'o':
      o = b;
      break;
    case 'sa':
      sa = b;
      break;
    case 'se':
      se = b;
      break;
  }  document.getElementById('img').style.webkitFilter = 'blur(' + bl + 'px) brightness(' + br + ') contrast(' + c + ') grayscale(' + g + ') hue-rotate(' + h + 'deg) invert(' + i + ') opacity(' + o + ') sepia(' + se + ') saturate(' + sa + ')'
}