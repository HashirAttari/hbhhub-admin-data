# Scratch & Win

A Pen created on CodePen.io. Original URL: [https://codepen.io/Pedro-Ondiviela/pen/gOEdJmK](https://codepen.io/Pedro-Ondiviela/pen/gOEdJmK).

You payed for one "Scratch & Win". Let's see if you got the price. ;)

Done with canvas 2D context and a lot of SCSS, ready to work also on mobile.