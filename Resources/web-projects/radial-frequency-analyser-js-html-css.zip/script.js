$('.fa').click(function() {
    $(this).fadeOut(1000, function() {
        $('.t').fadeIn(1000);
    });
    start();
});

var audio = new Audio('https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/dd.mp3');
audio.crossOrigin = "";
audio.volume = 0.2;

var ctx = new AudioContext();
var audioSrc = ctx.createMediaElementSource(audio);
var analyser = ctx.createAnalyser();
analyser.fftSize = 512;
analyser.connect(ctx.destination);
audioSrc.connect(analyser);

var frequencyData = new Uint8Array(analyser.frequencyBinCount);
var frequencyShift = 0;



function start() {

    audio.play();
    
    setInterval(function() {
        frame();
    },80);
}

function frame() {
    analyser.getByteTimeDomainData(frequencyData);
    for(i = frequencyShift; i < frequencyData.length / 2; i++) {
        p = Math.ceil(frequencyData[i] * 2 ) - 240 
        $('.box_part:nth-of-type(' + (i - frequencyShift) + ')').css('height', p + 'px' );
    }
}


// ## Deep-ui | 3D User interface builder
// ## Depths can be defined on the html element as data-depth.
// ## Depth is calculated from the parent element with depth-ui set as true.
// ## Set data-deep-animate & data-deep-animate-time to true on parent to animate to point.

function deep_ui() {

    // Options
    var global_perspective = 800; // Global perspective set to parent
    var pivot = 30 // The higher this number the more subtle the pivot effect
    var debug = false; // Shows various debug information
    var animation_delay = 100; // Delay before animation starts cannot be 0. In ms.
    var animation_easing = 'ease'; // Animation easing

    // Variables
    var deep_parent = $('*[data-deep-ui="true"]'); // Parent with deep active
    var deep_element = $('[data-depth]'); // Elements with depth
    var count = 0;

    // Set perspective
    deep_parent.each(function() {

        $(this).css({
            'perspective': global_perspective + 'px',
            'transform-style': 'preserve-3d',
            'transform': 'translateY(-50%)'
        }); // Set perspective of parent

        // If animation else is turned on, set the transition

        if ($(this).data('deep-animate') == true) {
            set_depth_animation(); // Set depths
        } else {
            set_depth(); // Set depths
        }

    });

    // Set the depths of each child element
    function set_depth() {
        // Set element depth
        deep_element.each(function() {
            $(this).css({
                'transform': 'translatez(' +
                $(this).data('depth') +
                'px) translateY(-50%)' ,
                'transform-style': 'preserve-3d' // Set CSS to all elements
            });
        });
    }

    function set_depth_animation() {
        // Set element depth

        deep_element.each(function() {
            $(this).css({
                'transform': 'translatez(1000px) translateY(-50%)',
                'transform-style': 'preserve-3d' // Set CSS to all elements
            });
            var deep_animate = 2;
            $(this).css('transition', 'all ' + 1.4 + 's ' + (.3 * count) + 's ' + animation_easing); // Set the transition on elements
            count++;
        });
    }
    // Pivot
    $(document).on('mousemove', function(e) {
        var x = -($(window).innerWidth() / 2 - e.pageX) / pivot; // Get current mouse x
        var y = ($(window).innerHeight() / 2 - e.pageY) / pivot; // Get current mouse y
        deep_parent.css('transform', 'rotateY(' + x + 'deg) rotateX(' + y + 'deg) translateY(-50%)'); // Set parent element rotation
    });

    // Debug
    function deep_debug() {
        deep_element.each(function() {
            $(this).append('<span class="d_label">Depth: ' + $(this).data('depth') + '</span>'); // Append depth tags
        });
        deep_parent.each(function() {
            $(this).append('<span class="d_b_label">Deep parent</span>'); // Append parent tags
        });
    }

    // Run debug if true
    if (debug) {
        deep_debug();
    }
}

// Init
deep_ui();