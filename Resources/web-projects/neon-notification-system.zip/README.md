# Neon notification system

A Pen created on CodePen.io. Original URL: [https://codepen.io/cleveryeti/pen/JjwNqgP](https://codepen.io/cleveryeti/pen/JjwNqgP).

System to shop notifications/popups, based on my neon notification card