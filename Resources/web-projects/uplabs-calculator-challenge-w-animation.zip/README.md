# Uplabs Calculator Challenge w Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/simoberny/pen/NBboqm](https://codepen.io/simoberny/pen/NBboqm).

Calculator Challenge Mockup:  https://www.uplabs.com/posts/calculator-concept-07251555-8d51-433b-b5d8-fd6e8d4fd3f8