//UI Design by me here: https://www.uplabs.com/posts/calculator-concept-07251555-8d51-433b-b5d8-fd6e8d4fd3f8
//Only UI