# Rubber Slider v2

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/PogmVgJ](https://codepen.io/aaroniker/pen/PogmVgJ).

Rewritten https://codepen.io/aaroniker/pen/VwZOOxz