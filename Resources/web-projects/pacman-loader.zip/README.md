# Pacman Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/XWXjdpR](https://codepen.io/chrisgannon/pen/XWXjdpR).

Stay away from the ghosts!