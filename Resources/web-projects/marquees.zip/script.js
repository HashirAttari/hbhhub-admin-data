"use strict";
function getProperty(property) {
    return (element) => {
        return window.getComputedStyle(element).getPropertyValue(property);
    };
}
const getGap = getProperty("gap");
function slide(el) {
    const [child] = [...el.children];
    const { width: childWidth } = child.getBoundingClientRect();
    const gap = parseInt(getGap(el));
    const distance = childWidth + gap;
    el.animate([
        { transform: `translate3D(0,0,0)` },
        { transform: `translate3D(-${distance}px,0,0)` }
    ], {
        duration: 2000,
        easing: "linear",
        fill: "forwards"
    });
    onAnimationFinish(el, () => {
        el.removeChild(child);
        el.appendChild(child);
    });
}
function onAnimationFinish(el, cb) {
    el.getAnimations()[0].finished.then(cb);
}
function run() {
    setTimeout(() => {
        document
            .querySelectorAll(".wrapper")
            .forEach((el) => slide(el));
        run();
    }, 2000);
}
document.querySelectorAll(".wrapper").forEach((el) => slide(el));
run();