# SVG + CSS Spinner

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/pyvqLO](https://codepen.io/run-time/pen/pyvqLO).

