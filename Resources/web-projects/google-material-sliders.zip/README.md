# Google Material Sliders

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/yOWgog](https://codepen.io/leenalavanya/pen/yOWgog).

As shown here:<br/><br/><img src="https://material-design.storage.googleapis.com/publish/material_v_8/material_ext_publish/0Bx4BSt6jniD7R2s2OGFDcVRkZFE/components_sliders_continuous2.png" style="width:100%"></img>