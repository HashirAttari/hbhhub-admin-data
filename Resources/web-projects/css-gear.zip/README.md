# CSS Gear

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/ZEyoJOr](https://codepen.io/amit_sheen/pen/ZEyoJOr).

