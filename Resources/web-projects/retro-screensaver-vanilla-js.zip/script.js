var move_speed = 3,
    dir = [{x:1,y:1},{x:-1,y:-1},{x:1,y:1},{x:1,y:1}],
    ww = window.innerWidth,
    wh = window.innerHeight,
    polys = document.querySelectorAll('.poly'),
    clr = Math.random()*360

polys[0].setAttribute('points',"250 0," + ww + ' 150,' + '500 '+ wh + ',0 500' )
polys[0].style.setProperty('--line-color', "hsl("+clr+"deg,100%,50%)")
polys[1].setAttribute('points',"500 0," + ww + ' 550,' + '200 '+ wh + ',0 200' )
polys[1].style.setProperty('--line-color', "hsl("+(clr+180)+"deg,100%,50%)")

function updateShape() {
  for(var j=0; j<polys.length;j++){
    var new_points = polys[j].getAttribute('points').split(','),
        ps = '';

    for(var i=0;i<new_points.length;i++) {
      if(new_points[i].split(' ')[0] <= 0){
        dir[i].x = 1
      }
      if(new_points[i].split(' ')[0] >= ww){
        dir[i].x = -1
      }
      if(new_points[i].split(' ')[1] <= 0){
        dir[i].y = 1
      }
      if(new_points[i].split(' ')[1] >= wh){
        dir[i].y = -1
      }

      if(i < 3) {
        ps += (Number(new_points[i].split(' ')[0]) + (dir[i].x * move_speed)) + ' ' + (Number(new_points[i].split(' ')[1]) + (dir[i].y * move_speed)) + ','
      } else {
        ps += (Number(new_points[i].split(' ')[0]) + (dir[i].x * move_speed)) + ' ' + (Number(new_points[i].split(' ')[1]) + (dir[i].y * move_speed))
      }    
    }

    polys[j].setAttribute('points', ps)
  }

}
updateShape()
setInterval(updateShape,1000/60)

// function addSvg() {
//   var d = document.createElement('div')
//   d.style.position = 'fixed'
//   d.style.inset = '0'
//   d.style.zIndex = '-1'
//   d.innerHTML = `<svg width="100vw" height="100vh" style="background: var(--bg-color);">
//  <polygon class='poly' points="" stroke="var(--line-color)" fill="transparent" stroke-width="1" ></polygon>
//   <polygon class='poly' points="" stroke="var(--line-color)" fill="transparent" stroke-width="1" ></polygon> 
// </svg>`
//   document.body.appendChild(d)  
// }