# Retro Screensaver Vanilla JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/GRBXOzb](https://codepen.io/kitjenson/pen/GRBXOzb).

A retro styled screensaver made with HTML, CSS, and JavaScript.