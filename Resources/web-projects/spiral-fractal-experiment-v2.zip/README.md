# Spiral fractal experiment v2

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/jOaVMwX](https://codepen.io/franksLaboratory/pen/jOaVMwX).

