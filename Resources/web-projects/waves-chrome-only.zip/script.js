window.addEventListener('load', () => {
  setTimeout(() => {
    document.querySelector('css-doodle').classList.add('repaint');
  }, 200);
});