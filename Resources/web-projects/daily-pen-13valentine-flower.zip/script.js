const km = kelvinUtil.math;
const width = 600;
const height = 600;
const bgColor = 'white';
const bgOpacity = 0;
const color = {
  red1: '#E74C3C',
  red2: '#C0392B',
  orange1: '#E67E22',
  orange2: '#D35400',
  yellow1: '#F1C40F',
  yellow2: '#F39C12',
  green1: '#2ECC71',
  green2: '#27AE60',
  mint1: '#1ABC9C',
  mint2: '#16A085',
  blue1: '#3498DB',
  blue2: '#2980B9',
  purple1: '#9B59B6',
  purple2: '#8E44AD',
  light1: '#ECF0F1',
  light2: '#BDC3C7',
  grey1: '#95A5A6',
  grey2: '#7F8C8D',
  dark1: '#34495E',
  dark2: '#2C3E50' };


let mouseX = 0;
let mouseY = 0;
let frameCount = 0;
let ss = [];
let ss2 = [];
let begin = Date.now();

let stage = new Konva.Stage({
  container: 'container',
  width: width,
  height: height });



let layer = new Konva.FastLayer({
  clearBeforeDraw: false });

stage.add(layer);

let bg = new Konva.Rect({
  x: 0,
  y: 0,
  width: width,
  height: height,
  fill: bgColor,
  opacity: bgOpacity });

layer.add(bg);
bg.moveToBottom();

// stats
let stats = new Stats();
stats.showPanel(0);
stats.domElement.className += ' stats';
document.body.appendChild(stats.domElement);


var shit = new Konva.RegularPolygon({
  x: 0,
  y: 0,
  sides: 5,
  radius: 50,
  fillEnabled: false,
  stroke: '#fc415e',
  strokeWidth: 1,
  opacity: .4,
  globalCompositeOperation: 'lighter' });

layer.add(shit);

var l = new Konva.Line({
  points: [0, 0, 10, 10],
  stroke: '#bc001d',
  strokeWidth: 1 });

layer.add(l);

new Konva.Animation(frame => {
  stats.begin();

  let r0 = 100;
  let r1 = 100;
  let t = (Date.now() - begin) * .001;
  let center = new Victor(.5 * width, .5 * height);
  let orbit = new Victor(km.cos(1 * t), km.sin(1 * t)).multiply(new Victor(r0, r0));
  let tmp = new Victor(km.cos(2.4 * t), km.sin(2.4 * t)).multiply(new Victor(r0, r0));
  let origin = center.clone().add(tmp);
  let p1 = center.clone().add(orbit);
  let r = p1.clone().subtract(origin).length();

  shit.rotate(.6);
  shit.position({ x: p1.x, y: p1.y });
  shit.radius(r);

  l.points([origin.x, origin.y, p1.x, p1.y]);

  stats.end();
}, layer).start();