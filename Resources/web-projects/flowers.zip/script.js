let p = document.querySelector('p'),
		p_width = p.getBoundingClientRect().width,
		fc = ['red','purple','orangered','violet','HotPink','DarkTurquoise','DodgerBlue']

function addBubbles() {
	for(var i=0;i<10;i++) {
		let b = document.createElement('div')
		b.className = 'bubble'
		b.style.height = Math.random() * 25 + 35 + 'px'
		b.style.bottom = '90%'
		b.style.left = (i * 10) + 3 + '%'
		b.style.setProperty('--color-flower', fc[Math.floor(Math.random()*fc.length)])
		b.style.animationDelay = 4 * Math.random() + 's'
		p.appendChild(b)
	}		
}
addBubbles()