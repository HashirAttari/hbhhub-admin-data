# Sandy Text - CSS Only

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/jOyabJx](https://codepen.io/kitjenson/pen/jOyabJx).

