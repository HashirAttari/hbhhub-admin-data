# Multiple Background with Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/EKNXEJ](https://codepen.io/mselmany/pen/EKNXEJ).

Adding animation to each background in multiple background instances.

Forked from [Thoriq Firdaus](http://codepen.io/tfirdaus/)'s Pen [Multiple Background with Animation](http://codepen.io/tfirdaus/pen/obpoYP/).

Forked from [Thoriq Firdaus](http://codepen.io/tfirdaus/)'s Pen [Multiple Background with Animation](http://codepen.io/tfirdaus/pen/obpoYP/).