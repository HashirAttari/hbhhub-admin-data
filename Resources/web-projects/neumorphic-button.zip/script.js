let select = s => document.querySelector(s),
  selectAll = s =>  document.querySelectorAll(s),
		mainSVG = select('#mainSVG')

gsap.set('svg', {
	visibility: 'visible'
})

let tl = gsap.timeline({
	paused: true,
	defaults: {
		duration: 0.1
	}
});
tl.to('.buttonFlood', {	
		floodOpacity: 0.24
})
.to('.btn', {	
	scale: 0.97,
	transformOrigin: '50% 50%'
}, 0)
.to('#lightGlow feFlood', {	
		floodOpacity: 0.2	
}, 0)
.to('#darkGlow feFlood', {	
		floodOpacity: 0.2	
}, 0)
.to('#edgeGlowFlood', {
	floodColor: '#A3FF84'
}, 0)
.to('#edge', {
	fill: '#A3FF84',
	attr: {
		r: 150,
		//cy: 300
	}
}, 0)
//console.log(select('.buttonFlood'))
//ScrubGSAPTimeline(tl)
select('.btn').onclick = e => {
		if(tl.time() > 0) {
			
			tl.reverse()
		} else {
			tl.play()
		}
	
}