# [v2] Apple Watch Face Imitation (Customizable)

A Pen created on CodePen.io. Original URL: [https://codepen.io/dtinth/pen/JjmLob](https://codepen.io/dtinth/pen/JjmLob).

Original by Apple:
- http://www.apple.com/watch/design/
- http://www.apple.com/watch/films/#film-design

At the top left are the customization panel. Click on each item to change the appearance. Appearance is changed by adding/removing classes.