# iOS7 style switch with CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/BandarRaffah/pen/DjaaPL](https://codepen.io/BandarRaffah/pen/DjaaPL).

Using translate3D to move the knob