# Multiple Range Input

A Pen created on CodePen.io. Original URL: [https://codepen.io/zheisey/pen/PoNOBwR](https://codepen.io/zheisey/pen/PoNOBwR).

Taken from Matthew Simpson: https://codepen.io/masimpson/pen/d9fa24ad092ca2b9e7aa51b3c8380ebd?editors=1011