# Random Unsplash images with page curl

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/gQLojd](https://codepen.io/ainalem/pen/gQLojd).

Using CSS, JS and trigonometry to create a page curl effect on random images from Unsplash.com