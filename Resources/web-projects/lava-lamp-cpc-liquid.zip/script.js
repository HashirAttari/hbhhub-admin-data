const blobs = document.querySelectorAll('.blob')
const colorOne = 'hsl('+Math.random()*360+'deg,75%,50%)'

blobs.forEach(function(elm){
  var size = Math.random() < .5 ? 200 : 200
  elm.style.width = size+'px'
  elm.style.height = size+'px'
  elm.style.background = colorOne
  elm.style.animationDuration = (Math.random()*5) + 30 + 's'
  var x = Math.random()*100 
  elm.style.left = (250-size)/2 +'px'
})

function updateBlobs() {
  const colorTwo = 'hsl('+Math.random()*360+'deg,75%,50%)'
  var root = document.documentElement;  
  root.style.setProperty('--bg-color', colorTwo);
  for(var i=0;i<blobs.length;i++){      
    blobs[i].style.borderRadius = ''+((Math.random()*20)+40)+'% '+((Math.random()*20)+40)+'% '+((Math.random()*20)+40)+'% '+((Math.random()*20)+40)+'%'
    blobs[i].style.transform = 'skewX('+Math.random()*10+'deg) scale('+Math.random()+') rotate('+Math.random()*360+'deg)'
    blobs[i].style.background = colorTwo
  }
  setTimeout(updateBlobs,10000)
}
updateBlobs()