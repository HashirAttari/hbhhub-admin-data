# App navigation concept | CSS only

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/RwWKaor](https://codepen.io/havardob/pen/RwWKaor).

Just a simple menu for a fictitious app. No actual functionality other than simulating an active state when a link gets focus. 