# #DailyUI028 Responsive Map

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/MypjbP](https://codepen.io/leenalavanya/pen/MypjbP).

A map for websites and 'contact us' cards!