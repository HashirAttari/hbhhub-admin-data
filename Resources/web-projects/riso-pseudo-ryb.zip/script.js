import { trilerp, converter, formatCss, formatHex, easingSmoothstep } from 'https://cdn.skypack.dev/culori';

console.clear();

const rgb = converter('rgb');

const RYB_CUBE = [
{ mode: 'rgb', r: 248 / 255, g: 237 / 255, b: 220 / 255 }, // white
{
  "mode": "rgb",
  "r": 0.8901960784313725,
  "g": 0.1411764705882353,
  "b": 0.12941176470588237 },
// red
{
  "mode": "rgb",
  "r": 0.9529411764705882,
  "g": 0.9019607843137255,
  "b": 0 },
// yellow
{
  "mode": "rgb",
  "r": 0.9411764705882353,
  "g": 0.5568627450980392,
  "b": 0.10980392156862745 },
// orange
{
  "mode": "rgb",
  "r": 0.08627450980392157,
  "g": 0.6,
  "b": 0.8549019607843137 },
// blue
{
  "mode": "rgb",
  "r": 0.47058823529411764,
  "g": 0.13333333333333333,
  "b": 0.6666666666666666 },
// violet
{
  "mode": "rgb",
  "r": 0,
  "g": 0.5568627450980392,
  "b": 0.3568627450980392 },
// green
{ mode: 'rgb', r: 29 / 255, g: 28 / 255, b: 28 / 255 } // black
];


function ryb2rgb(coords) {
  //const biased_coords = coords.map(t => t * t * (3 - 2 * t));
  const r = easingSmoothstep(coords[0]);
  const y = easingSmoothstep(coords[1]);
  const b = easingSmoothstep(coords[2]);
  return {
    mode: 'rgb',
    r: trilerp(...RYB_CUBE.map(it => it.r), r, y, b),
    g: trilerp(...RYB_CUBE.map(it => it.g), r, y, b),
    b: trilerp(...RYB_CUBE.map(it => it.b), r, y, b) };

}

let risoColors = [];

const doIt = () => {
  document.documentElement.style.setProperty('--w', formatHex(RYB_CUBE)[0]);
  document.documentElement.style.setProperty('--b', formatHex(RYB_CUBE.at(-1)));
};

doIt();

const $w = document.querySelector('[data-c="w"]');
$w.value = formatHex(RYB_CUBE[7]);
const $r = document.querySelector('[data-c="r"]');
$r.value = formatHex(RYB_CUBE[1]);
const $y = document.querySelector('[data-c="y"]');
$y.value = formatHex(RYB_CUBE[2]);
const $o = document.querySelector('[data-c="o"]');
$o.value = formatHex(RYB_CUBE[3]);
const $b = document.querySelector('[data-c="b"]');
$b.value = formatHex(RYB_CUBE[4]);
const $v = document.querySelector('[data-c="v"]');
$v.value = formatHex(RYB_CUBE[5]);
const $g = document.querySelector('[data-c="g"]');
$g.value = formatHex(RYB_CUBE[6]);
const $black = document.querySelector('[data-c="0"]');
$black.value = formatHex(RYB_CUBE[0]);

const els = [$black, $r, $y, $o, $b, $v, $g, $w];

document.querySelector('[data-edges]').addEventListener('input', e => {
  const $target = e.target;
  const value = $target.value;
  const $tarInEls = els.find(($el, i) => $el.isEqualNode($target));
  const index = els.indexOf($tarInEls);
  if (index > -1) {
    RYB_CUBE[index] = rgb(value);
    doIt();
  }
  risoColors = processColors(risoColors);
  doList(risoColors);
});

const $list = document.querySelector('[data-riso]');

function processColors(colors) {
  return colors.map(color => {
    color.ryb = ryb2rgb([color.rgb.r / 255, color.rgb.g / 255, color.rgb.b / 255]);

    return color;
  });
}

function doList(colors) {
  $list.innerHTML = '';
  colors.forEach(color => {
    const $li = document.createElement('li');
    $li.style.setProperty('--rgb', color.hex);
    $li.style.setProperty('--ryb', formatHex(color.ryb));
    $li.innerHTML = `RGB<i></i> RYB<em></em> ${color.name}`;
    $list.append($li);
  });
}

fetch('https://api.color.pizza/v1/?list=risograph').then(d => d.json()).then(d => {
  const { colors } = d;
  risoColors = processColors(colors);
  doList(risoColors);
});