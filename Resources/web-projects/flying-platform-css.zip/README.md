# Flying platform (CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/abRKbwL](https://codepen.io/kitjenson/pen/abRKbwL).

