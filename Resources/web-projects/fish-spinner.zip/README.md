# Fish Spinner

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/gOzgXve](https://codepen.io/chrisgannon/pen/gOzgXve).

Download the Lottie file [here](https://lottiefiles.com/120352-fish-spinner) 