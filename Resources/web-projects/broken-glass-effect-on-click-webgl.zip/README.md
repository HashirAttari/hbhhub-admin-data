# Broken Glass Effect (on click, WebGL)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ksenia-k/pen/abegNPO](https://codepen.io/ksenia-k/pen/abegNPO).

