let index = 0;
const next = () => {
  if (index === 3) return;
  index++;
  document.body.className = `go${index}to${index + 1}`;
};
const prev = () => {
  if (index === 0) return;
  document.body.className = `go${index + 1}to${index}`;
  index--;
};