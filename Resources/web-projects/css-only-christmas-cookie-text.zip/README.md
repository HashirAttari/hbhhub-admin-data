# CSS-only Christmas cookie text

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/aBrXLp](https://codepen.io/giana/pen/aBrXLp).

A Sass mixin for creating Christmas cookie text using text shadows. Works only on a white background (there are workarounds if you need other bg colors). Best used with large, round, heavy fonts.

Looks best in Chrome.