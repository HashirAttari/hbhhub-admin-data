# iPhone 5 CSS Template

A Pen created on CodePen.io. Original URL: [https://codepen.io/charlie-volpe/pen/bGpXzB](https://codepen.io/charlie-volpe/pen/bGpXzB).

I decided I wanted to try and create a responsive iPhone 5 Template.

View iPad fork here: http://codepen.io/charlie-volpe/pen/yvAwm

View GalaxyS3 fork here: http://codepen.io/charlie-volpe/pen/knwpE/