//View iPad fork here: https://codepen.io/charlie-volpe/pen/yvAwm

//View GalaxyS3 fork here: https://codepen.io/charlie-volpe/pen/knwpE/