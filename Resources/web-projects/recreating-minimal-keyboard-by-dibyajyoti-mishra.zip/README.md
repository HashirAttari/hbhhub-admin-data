# Recreating "Minimal keyboard" by Dibyajyoti Mishra

A Pen created on CodePen.

Original URL: [https://codepen.io/Alca/pen/vYeyOwd](https://codepen.io/Alca/pen/vYeyOwd).

