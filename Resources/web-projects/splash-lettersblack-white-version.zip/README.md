# Splash Letters - Black & White version

A Pen created on CodePen.

Original URL: [https://codepen.io/franksLaboratory/pen/eYJyrgw](https://codepen.io/franksLaboratory/pen/eYJyrgw).

