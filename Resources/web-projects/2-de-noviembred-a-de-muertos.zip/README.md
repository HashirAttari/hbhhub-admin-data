# 2 de Noviembre - Día de Muertos

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/wvvdyma](https://codepen.io/ricardoolivaalonso/pen/wvvdyma).

