# Animated Tooltip

A Pen created on CodePen.io. Original URL: [https://codepen.io/myacode/pen/abzxPvY](https://codepen.io/myacode/pen/abzxPvY).

