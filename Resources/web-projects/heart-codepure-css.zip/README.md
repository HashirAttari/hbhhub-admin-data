# Heart Code - Pure CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/itska/pen/aZNOGJ](https://codepen.io/itska/pen/aZNOGJ).

For valentine's day