# Liquid image

A Pen created on CodePen.

Original URL: [https://codepen.io/2Mogs/pen/mdbMOrr](https://codepen.io/2Mogs/pen/mdbMOrr).

An image is sliced with sections attached a particle grid.
Mouse movement affects the grid, deforming the image sections.