/* \ no /
    \  /
pure \/ pure
css  /\ html
    /  \
   / js \ */