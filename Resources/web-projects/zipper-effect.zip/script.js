gsap.registerPlugin(SplitText);
const split = new SplitText(".text", {type:'chars, words'})

const tl = gsap.timeline({yoyo:true, repeat:-1, duration:.5, delay:0, ease:'linear.inOut'})

function init(){
 tl.set('.text-wrapper', {autoAlpha:1})
.from(split.chars, {
  y: gsap.utils.wrap([-50,50]),
  rotation: gsap.utils.wrap([-45,45]),
  stagger: {each: 0.01},
   opacity: 0,
   color: gsap.utils.wrap(['blue', 'indigo', 'violet' ]),
  })   
   .to(split.words, {
    color: gsap.utils.wrap(['red', 'orange', 'yellow', 'green',  ]),
  },0)
//GSDevTools.create(tl)
 }

window.addEventListener('load', init)