# Tiny city

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/oxzvoV](https://codepen.io/mselmany/pen/oxzvoV).

WIP

Forked from [Stepan](http://codepen.io/stepan/)'s Pen [Tiny city](http://codepen.io/stepan/pen/dfjDL/).