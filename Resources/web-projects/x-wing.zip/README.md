# X-wing

A Pen created on CodePen.io. Original URL: [https://codepen.io/benhatsor/pen/poNeWMp](https://codepen.io/benhatsor/pen/poNeWMp).

X-wing with [coco (CSS Orientation Controls)](https://github.com/benhatsor/coco) added.  Move around with keypad & drag to rotate.