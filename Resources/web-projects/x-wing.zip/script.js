var element = document.querySelector('.scene');
var scene = element.coco(false); // false creates a static scene
var x = 0,
    y = 0,
    z = 0;
scene.camera(x, y, z);

document.addEventListener("keydown", checkKey, false);
function checkKey(e) {
  if (e.keyCode == '37') { // left (left arrow key)
    x += 3;
  } else if ( e.keyCode == '39') { // right (right arrow key)
    x -= 3;
  } else if (e.keyCode == '32') { // up (space key)
    y += 3;
  } else if (e.keyCode == '16') { // down (down arrow key)
    y -= 3;
  } else if (e.keyCode == '38') { // forwards (up arrow key)
    z += 3;
  } else if (e.keyCode == '40') { // backwards (down arrow key)
    z -= 3;
  }
  
  scene.camera(x, y, z);
  e.preventDefault();
}