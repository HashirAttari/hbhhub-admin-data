# A Web Dev's Valentine

A Pen created on CodePen.

Original URL: [https://codepen.io/AllThingsSmitty/pen/pNLVWm](https://codepen.io/AllThingsSmitty/pen/pNLVWm).

Show some love to that special person who gives your plain look much needed style.