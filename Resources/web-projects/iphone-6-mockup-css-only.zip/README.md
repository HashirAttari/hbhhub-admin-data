# iPhone 6 mockup | CSS only

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/KzoOMB](https://codepen.io/havardob/pen/KzoOMB).

