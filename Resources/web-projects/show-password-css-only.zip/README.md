# Show password CSS only

A Pen created on CodePen.io. Original URL: [https://codepen.io/n7best/pen/RMxKQr](https://codepen.io/n7best/pen/RMxKQr).

