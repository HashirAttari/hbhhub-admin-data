# Avatars joined by dashed lines - responsive

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbolson/pen/rNQaxJx](https://codepen.io/cbolson/pen/rNQaxJx).

https://discord.com/channels/1059816575936495697/1116247293306359828/1116266420695736320

- Responsive
- unlimited avatars (or whatever elements you want to join)
- Avatars joined via dashed lines