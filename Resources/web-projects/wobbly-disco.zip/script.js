import SimplexNoise from "https://cdn.skypack.dev/simplex-noise@3.0.0";

const simplex = new SimplexNoise();
let time = 0;

const size = 16;
const cells = [];

init();
function init() {
  [...document.querySelectorAll('.cell')].forEach((cell, ix) => {
    cells[ix] = {
      div: cell,
      x: (ix % size) * 0.1,
      y: (Math.floor(ix / size) % size) * 0.1,
    }    
  });
  render();
}

function render() {

  for (let i = 0 ; i < (size*size) ; i++) {
    const cell = cells[i];
    const noise = simplex.noise3D(cell.x, cell.y, time);
    cell.div.style.setProperty('--val', (noise + 1) / 2);
    time += 0.00002;
  }

  requestAnimationFrame(render);
}