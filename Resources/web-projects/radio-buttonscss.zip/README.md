# Radio Buttons - CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/BaOrPLP](https://codepen.io/josetxu/pen/BaOrPLP).

