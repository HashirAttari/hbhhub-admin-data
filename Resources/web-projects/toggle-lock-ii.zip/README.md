# Toggle Lock (II)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/vYMEpzY](https://codepen.io/alvaromontoro/pen/vYMEpzY).

