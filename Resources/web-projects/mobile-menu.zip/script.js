let trigger = document.querySelector("#trigger");
let list = document.querySelector("#list");
let mItem = document.querySelectorAll(".menu__item");

let showMenu = (event) => {

    trigger.classList.toggle("trigger-rotate");
    list.classList.toggle("show-list");

    for (var i = 0; i < mItem.length; i++) {
        mItem[i].classList.toggle("show-item");
    }
}

trigger.addEventListener("click", showMenu);