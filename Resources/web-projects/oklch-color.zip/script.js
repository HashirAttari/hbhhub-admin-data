console.clear();

function hueStepsStops(steps, h = -90, harmonyFn) {
  let harmonyRanges;
  if (harmonyFn) {
    harmonyRanges = harmonyFn((360 + h) % 360);
  }

  return Array.from({ length: steps }, (_, i) => {
    const relI = i / steps;
    const stepSize = 1 / steps;
    const hF = (360 + h + relI * 360) % 360;
    const steoSizeH = stepSize * 360;
    const hRange = hF + steoSizeH;
    let currentColor = `oklch(calc(var(--l) * 100%) calc(var(--c,0) * 100%) calc(${hF} + var(--h,0)))`;

    if (harmonyFn) {
      const matches = findMatchingColor(hF - steoSizeH * .5, hF + steoSizeH * .5, harmonyRanges);
      if (matches == undefined) {
        currentColor = '#fff';
      }
    }

    return `${currentColor} ${relI * 100}% ${(i + 1) / steps * 100}%`;
  }).join(',');
}


const colorHarmonies = {
  complementary: h => [(h + 360) % 360, (h + 540) % 360],
  splitComplementary: h => [
  (h + 360) % 360,
  (h + 510) % 360,
  (h + 570) % 360],

  triadic: h => [(h + 360) % 360, (h + 480) % 360, (h + 600) % 360],
  tetradic: h => [
  (h + 360) % 360,
  (h + 450) % 360,
  (h + 540) % 360,
  (h + 630) % 360],

  monochromatic: h => [(h + 360) % 360],
  doubleComplementary: h => [
  (h + 360) % 360,
  (h + 540) % 360,
  (h + 390) % 360,
  (h + 630) % 360],

  compound: h => [
  (h + 360) % 360,
  (h + 540) % 360,
  (h + 420) % 360,
  (h + 600) % 360],

  analogous: h => [
  (h + 360) % 360,
  (h + 390) % 360,
  (h + 420) % 360] };



const $wheelL = document.querySelector(`[data-wheel="l"]`);
const $wheelC = document.querySelector(`[data-wheel="c"]`);
const $wheelH = document.querySelector(`[data-wheel="h"]`);

const $wheelComp = document.querySelector(`[data-wheel="complementary"]`);
const $wheelSplitComp = document.querySelector(`[data-wheel="splitComplementary"]`);
const $wheelTri = document.querySelector(`[data-wheel="triadic"]`);
const $wheelTet = document.querySelector(`[data-wheel="tetradic"]`);
const $wheelDoubleComp = document.querySelector(`[data-wheel="doubleComplementary"]`);
const $wheelAn = document.querySelector(`[data-wheel="analogous"]`);
const $wheelCompound = document.querySelector(`[data-wheel="compound"]`);
const $wheelMono = document.querySelector(`[data-wheel="monochromatic"]`);

let hueStops = 12;
let lSteps = 6;

function doWheel(hueStops, steps, prop, $prent, harmony) {
  $prent.style.setProperty('--steps', hueStops);
  $prent.innerHTML = '';
  for (let i = 0; i < steps; i++) {
    const relI = i / (steps - 1);
    const $div = document.createElement('div');
    $div.style.setProperty('--grad', hueStepsStops(hueStops, -90, colorHarmonies[harmony]));
    $div.style.setProperty('--scale', 1 - relI);
    let val;
    if (prop === 'l') {
      val = 1 - (.1 + relI * .8);
    } else if (prop === 'c') {
      val = 1 - relI * .9;
    }
    if (prop !== 'h') {
      $div.style.setProperty(`--${prop}`, val);
    }
    $prent.appendChild($div);
  }



  for (let separator = 0; separator < hueStops; separator++) {
    const $hr = document.createElement('hr');
    $hr.style.setProperty('--step', separator / hueStops);
    $prent.appendChild($hr);
  }
}

function allWheels() {
  doWheel(hueStops, lSteps, 'l', $wheelL);
  doWheel(hueStops, lSteps, 'c', $wheelC);
  $wheelH.style.setProperty('--l', .75);
  $wheelH.style.setProperty('--c', .8);
  doWheel(hueStops, 2, 'h', $wheelH);

  doWheel(hueStops, 5, 'l', $wheelMono, 'monochromatic');
  doWheel(hueStops, 5, 'l', $wheelAn, 'analogous');
  doWheel(hueStops, 5, 'l', $wheelComp, 'complementary');
  doWheel(hueStops, 5, 'l', $wheelSplitComp, 'splitComplementary');
  doWheel(hueStops, 5, 'l', $wheelDoubleComp, 'doubleComplementary');
  doWheel(hueStops, 5, 'l', $wheelTri, 'triadic');
  doWheel(hueStops, 5, 'l', $wheelTet, 'tetradic');
  doWheel(hueStops, 5, 'l', $wheelCompound, 'compound');
}

allWheels();



function findMatchingColor(h, hEnd, harmonyRanges) {
  return harmonyRanges.find(targetH => targetH >= h && targetH < hEnd);
}


const $l = document.querySelector('[data-control="l"]');
const $c = document.querySelector('[data-control="c"]');
const $h = document.querySelector('[data-control="h"]');
const $hues = document.querySelector('[data-control="hues"]');
const $steps = document.querySelector('[data-control="steps"]');

$l.addEventListener('input', () => {
  document.body.style.setProperty('--l', $l.value);
});
$c.addEventListener('input', () => {
  document.body.style.setProperty('--c', $c.value);
});
$h.addEventListener('input', () => {
  document.body.style.setProperty('--h', $h.value);
});

$hues.addEventListener('input', () => {
  hueStops = parseInt($hues.value);
  allWheels();
});
$steps.addEventListener('input', () => {
  lSteps = parseInt($steps.value);
  allWheels();
});