# List Animation Concept

A Pen created on CodePen.io. Original URL: [https://codepen.io/emilygoldfein/pen/Pmpvpg](https://codepen.io/emilygoldfein/pen/Pmpvpg).

