# Fancy menu hover effects

A Pen created on CodePen.io. Original URL: [https://codepen.io/kh-mamun/pen/wgVPRq](https://codepen.io/kh-mamun/pen/wgVPRq).

Fancy menu hover effect with pure CSS