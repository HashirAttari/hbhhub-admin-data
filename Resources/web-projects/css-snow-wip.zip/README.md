# CSS Snow (WIP)

A Pen created on CodePen.io. Original URL: [https://codepen.io/giana/pen/XmLYva](https://codepen.io/giana/pen/XmLYva).

