# SVG Spinner

A Pen created on CodePen.io. Original URL: [https://codepen.io/run-time/pen/qBKRWPr](https://codepen.io/run-time/pen/qBKRWPr).

