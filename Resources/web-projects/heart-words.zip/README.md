# Heart Words

A Pen created on CodePen.

Original URL: [https://codepen.io/hexagoncircle/pen/LQzOdq](https://codepen.io/hexagoncircle/pen/LQzOdq).

This Valentine's day, spend your night randomly generating a candy heart-style phrase.