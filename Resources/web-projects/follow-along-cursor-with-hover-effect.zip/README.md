# Follow Along Cursor with Hover Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/markmead/pen/JjPzLLz](https://codepen.io/markmead/pen/JjPzLLz).

