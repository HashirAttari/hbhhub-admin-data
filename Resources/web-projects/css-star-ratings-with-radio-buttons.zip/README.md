# CSS Star Ratings with Radio Buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/lsirivong/pen/nRNLYL](https://codepen.io/lsirivong/pen/nRNLYL).

Replaces radio button group with filled in stars. This allows you to use a normal radio button form and  simply submit the selected value.

Based on Chris Coyier's Star Ratings - http://css-tricks.com/star-ratings/

Shortcomings:
* The radio buttons need to be in a reversed order in the mark up.
* -No way to clear the rating once selected.- (added a special classed radio button to do this.)