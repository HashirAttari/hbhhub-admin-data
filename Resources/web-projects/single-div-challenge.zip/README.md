# Single div challenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/OJPdpKv](https://codepen.io/yuanchuan/pen/OJPdpKv).

https://twitter.com/yuanchuan23/status/1219603199620894720

Note: Firefox does not support conic-gradient yet