# The Ultimate Card Trick

A Pen created on CodePen.

Original URL: [https://codepen.io/cshelton24/pen/Ywavyq](https://codepen.io/cshelton24/pen/Ywavyq).

The Ultimate Mathmagical Card Trick. 
Code could use re-worked. I'm kind of a noob, so this was a good practice working with objects, setTimeouts, delays, and animations., I'm sure there is probably a more efficient way to work the code. Please fork and rework. Would love to rework this into responsive as well. Right now, it's best viewed in full page.
No images used.
 Still tracking down all the credits for the pieces I used.

Credits:

Helveticards.
https://github.com/zachwaugh/Helveticards

CSS3 Background Patterns by Lea Verou.
http://lea.verou.me/css3patterns/

Text Fly in & Out - http://codepen.io/neilcarpenter/details/LstCD/

Fireworks particles - A Pen here on Codepen.

Best in full page.