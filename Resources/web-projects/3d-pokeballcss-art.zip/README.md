# 3D Pokeball - CSS ART

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardoolivaalonso/pen/yLvJOEa](https://codepen.io/ricardoolivaalonso/pen/yLvJOEa).

