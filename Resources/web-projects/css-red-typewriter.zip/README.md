# CSS Red Typewriter

A Pen created on CodePen.io. Original URL: [https://codepen.io/robrehrig/pen/LYdaVv](https://codepen.io/robrehrig/pen/LYdaVv).

Red typewriter inspired by <a href="http://dribbble.com/shots/1473232-Red-Typewriter">this shot</a>. Created as a birthday web-card to give to my mom.