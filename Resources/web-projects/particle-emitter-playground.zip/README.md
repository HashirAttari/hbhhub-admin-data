# Particle emitter playground

A Pen created on CodePen.

Original URL: [https://codepen.io/agalliat/pen/EBgPqd](https://codepen.io/agalliat/pen/EBgPqd).

Particle emitter playground with some sample configurations, like a fire animation.
Real time configuration changes can be done via the dat.GUI configuration panel.

Did you create an awesome configuration with this playground that you would like to share?

Click on the gear icon on the upper right panel and post your configuration in the comments.