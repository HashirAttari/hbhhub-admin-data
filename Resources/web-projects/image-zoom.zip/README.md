# Image Zoom

A Pen created on CodePen.io. Original URL: [https://codepen.io/leenalavanya/pen/qbWRXo](https://codepen.io/leenalavanya/pen/qbWRXo).

