document.getElementById('cont').onmousemove = function(event) {
	var x = event.clientX - 50;
	var y = event.clientY - 50;
	document.getElementById('telHolder').style.left = x + 'px ';
	document.getElementById('telHolder').style.top = y + 'px ';
}

document.getElementById('cont').onclick = function(event) {
	var x = event.clientX - 50;
	var y = event.clientY - 50;
	document.getElementById('telHolder').style.left = x + 'px ';
	document.getElementById('telHolder').style.top = y + 'px ';
}