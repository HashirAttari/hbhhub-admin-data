# Scroll and morph

A Pen created on CodePen.io. Original URL: [https://codepen.io/ainalem/pen/jZzxrP](https://codepen.io/ainalem/pen/jZzxrP).

Uses the basicScroll parallax scroll library to morph text on scroll. Morphing is accomplished through CSS variables & CSS clip-path