# Styled native range input #26 (updated 2021)

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/pvpxRG](https://codepen.io/thebabydino/pen/pvpxRG).

**May 2021 description**

Major changes: 

* eliminated the 1 element constraint and now used a `datalist` for labels (see [this twitter thread](https://twitter.com/anatudor/status/1225113768629325825))

* eliminated hacks like checking for SMIL support for specifically targeting IE 🥴  or using ` /deep/ ` and the `track`'s `::after` pseudo-element (stuff that only ever worked in Chrome, but hasn't been working even there in years, `/deep/` is even deprecated and long removed) for the labels (that's now done cleanly and in a cross-browser manner with the `datalist` element)

* switched to smarter state changes using CSS variables - the technique is explained in this [two](https://css-tricks.com/dry-switching-with-css-variables-the-difference-of-one-declaration/) [part](https://css-tricks.com/dry-state-switching-with-css-variables-fallbacks-and-invalid-values/) article I wrote for CSS-Tricks 3 years ago

* got rid of `absolute` positioning in favour of a CSS `grid` layout

* simplified the JS - it's now just updating a custom property `--val` to always have the current input value - this serves to highlight the label corresponding to the current value

* made it degrade gracefully in the no JS case (check with JS disabled)

* used Houdini with a workaround for Firefox 😏 (degrades gracefully in Safari too!)

* compacted the CSS

* not providing free support for IE/ pre-Chromium Edge anymore

The external resources are only there to add the warnings, which were sadly very necessary given a lot of people shared these saying that I designed them or/ and that they're pure CSS... neither of which is true.

---

**Original description**

Goal: create a nicely styled cross-browser 1 element slider. Tested & works in Firefox 35, 38 (nightly), Chrome 40, 42 (canary)/ Opera 28, IE 11on Windows 8. IE and Firefox don't need any JS, while Chrome/ Opera rely on it a bit for a little extra (styling the labels above depending on the option selected). Fallback for no JS: simply display the same text colour for all the labels above, no matter which one is selected. 

---

**Disclaimer because some people got the wrong idea: I did NOT design these sliders.** Whoever knows me is probably aware of the fact that I'm 100% technical and 0% artistic. Me trying to design something would result in visual vomit. I just googled "slider design" and tried to reproduce (as well as I could) the images that search found. Inspiration for this demo: 

![image](http://i.imgur.com/dxQlIdb.jpg) 

You can see the rest of my 1 range input sliders in [this collection](http://codepen.io/collection/DgYaMj/).