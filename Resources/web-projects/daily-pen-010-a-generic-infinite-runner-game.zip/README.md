# Daily Pen #010: A generic Infinite Runner game

A Pen created on CodePen.io. Original URL: [https://codepen.io/mselmany/pen/obygbd](https://codepen.io/mselmany/pen/obygbd).

I made this game in less than 24 working hours, it's to celebrate 10 days making daily pens.

I used sketch.js to work with canvas.

Forked from [Eduardo Lopes](http://codepen.io/EduardoLopes/)'s Pen [Daily Pen #010: A generic Infinite Runner game](http://codepen.io/EduardoLopes/pen/IJnAr/).