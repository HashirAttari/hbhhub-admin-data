# Tetrahedron

A Pen created on CodePen.io. Original URL: [https://codepen.io/amit_sheen/pen/ZEeaQPa](https://codepen.io/amit_sheen/pen/ZEeaQPa).

