// just change the year and re-run!
let default_calendar = {
  year: 2020,
  key: {
    "true_value": {
      "text": "I did it",
      "color": "#fff",
      "bg": "#368dda"
    },
    "false_value": {
      "text": "I did not do it yet",
      "color": "#666",
      "bg": "#efefef"
    }
  },
  checkmarks: "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
};

let DB = getData();
let p = 0;
let debounceTimer = null;

const MONTH = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const DOW = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];


init();


function init() {
  drawCalendar();
  injectKeyStyles();
}


function drawCalendar() {
  let output = '<div class="year-card"><div class="year-title">' + DB.year + '</div>';
  
  output += '<div class="key-card"><div class="key-label key-label-true">' + DB.key.true_value.text + '</div><div class="key-label key-label-false">' + DB.key.false_value.text + '</div></div>';

  for (let m = 0; m < 12; m++) {
    output += '<div class="month-card">';
    output += '<div class="month-title">' + MONTH[m] + '</div>';
    output += getHeaderRow();
    for (let d = 0; d < 31; d++) {
      let n = new Date(DB.year, m, d + 1);
      let c = n.getDate();
      let w = DOW[n.getDay()];

      if (c > d) {
        if (c === 1) {
          let tdc = n.getDay();
          while (tdc--) {
            output += getDayCell(0);
          }
        }
        output += getDayCell(c);
      }

      if (w === "SAT") {
        output += "<br>";
      }
    }
    output += '</div>';
  }
  output += '</div>';
  document.write(output);
}

function updateCalendar() {
  let dList = DB.checkmarks.split('');
  let d = 366;
  while (d--) {
    updateDay(d, dList[d-1]);
  }
}

function updateDay(d, val) {
  let e = document.querySelector('.day-position-'+d);
  e.classList.remove("key-day-true");
  e.classList.remove("key-day-false");
  
  if (val === "1") {
    e.classList.add("key-day-true");
  }
  else {
    e.classList.add("key-day-false");
  }
  
  //console.log(d, val);
}

function getDayCell(d) {
  let dp = 'day-position-0';
  let kd = 'key-day-false';
  if (d !== 0) {
    let dList = DB.checkmarks.split('');
    let dVal = dList[p];
    if (dVal === "1") {
      kd = 'key-day-true';
    }
    p += 1;
    dp = 'day-position-' + p;
  }
  return (d===0) ? '<div class="day-button day-empty"></div>' : '<div onclick="handleClick(\'' + dp +'\')" class="day-button day-num ' + kd + ' ' + dp + '">' + d + '</div>';
}

function handleClick(d) {
  let dp = parseInt( d.split('day-position-')[1] ) - 1;
  //console.log(dp);
  let dList = DB.checkmarks.split('');
  if (dList[dp] === "0") {
    dList[dp] = "1";
  }
  else {
    dList[dp] = "0";
  }
  DB.checkmarks = dList.join('');
  setData();
  updateCalendar();
  //console.log(DB.checkmarks);
}

function getHeaderRow() {
  return '<div class="day-head">S</div><div class="day-head">M</div><div class="day-head">T</div><div class="day-head">W</div><div class="day-head">T</div><div class="day-head">F</div><div class="day-head">S</div>';
}

function injectKeyStyles() {
  let css = document.createElement('style');
  css.type = 'text/css';
  
  let styles = '.key-day-true { color: ' + DB.key.true_value.color + '; background-color: ' + DB.key.true_value.bg + '; }';
  styles += ' .key-day-false { color: ' + DB.key.false_value.color + '; background-color: ' + DB.key.false_value.bg + '; }';
  
  if (css.styleSheet) {
    css.styleSheet.cssText = styles;
  }
  else {
    css.appendChild(document.createTextNode(styles));
  }
  
  document.getElementsByTagName("head")[0].appendChild(css);
}


















function getData() {
  let db = localStorage.getItem('DB') || JSON.stringify(default_calendar);
  return JSON.parse(db);
}

function setData() {
  let db = JSON.stringify(DB);
  if (db && db.length > 0) {
    localStorage.setItem('DB', db);
  }
}

function clearData() {
  localStorage.removeItem('DB');
}



// basic cross browser addEvent
function addEvent(elem, event, fn) {
  if (elem.addEventListener) {
    elem.addEventListener(event, fn, false);
  }
  else {
    elem.attachEvent("on" + event,
    function(){ return(fn.call(elem, window.event)); });
  }
}