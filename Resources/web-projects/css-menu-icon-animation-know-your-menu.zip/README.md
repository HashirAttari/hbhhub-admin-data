# CSS Menu Icon Animation: Know Your Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/oliviale/pen/gKParr](https://codepen.io/oliviale/pen/gKParr).

