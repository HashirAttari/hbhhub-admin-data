# Combination Lock

A Pen created on CodePen.io. Original URL: [https://codepen.io/Wryte/pen/PJbNYZ](https://codepen.io/Wryte/pen/PJbNYZ).

Enter the proper combination to unlock the lock. Change the lock combination by supplying a search param 'h' to the web page. (ex ?h=7c6 will make the combination be 1990)