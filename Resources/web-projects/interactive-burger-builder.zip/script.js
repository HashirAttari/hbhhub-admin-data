const burger = document.getElementById("burger");
const fillings = ["bun-bottom", "meat", "cheese", "salad", "bun-top"]

const addFilling = (type) => {
  const filling = document.createElement('div');
  filling.classList.add(type);
  burger.insertBefore(filling, burger.firstChild);
}

const generateButtons = () => {
  const nav = document.getElementById("buttons");
  const buttonsWrapper = document.createElement('div');

  fillings.forEach(filling => {
    const button = document.createElement('button');
    button.classList.add('btn');
    button.innerText = filling;
    button.onclick = function() { addFilling(filling); };
    buttonsWrapper.appendChild(button);
  })

  nav.appendChild(buttonsWrapper);
  burger.classList.add("margin-top")
}

const reset = () => burger.innerHTML = "";

const start = (btn) => {
  reset();
  generateButtons();
  
  btn.innerText = "Start Again";
  btn.onclick = reset;
}